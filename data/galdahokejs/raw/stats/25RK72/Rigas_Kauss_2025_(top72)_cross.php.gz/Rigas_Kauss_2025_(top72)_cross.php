<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Rigas Kauss 2025 (top72)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../25RK72/Rigas_Kauss_2025_(top72)_index.php">Rigas Kauss 2025 (top72), 6. December 2025</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group (top72 ) Group A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Va Smagars</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kW>4:0</td>
<td class=br>61:34</td><td class=br>+27</td>
<td class=bc>14 - 2 - 1</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ed Nilsson</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=kT>6:6</td>
<td class=kW>6:5</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=br>66:41</td><td class=br>+25</td>
<td class=bc>12 - 4 - 1</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Mi Kobrle</td><td class=kL>1:2</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>6:3</td>
<td class=kL>5:7</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kL>0:5</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>6:2</td>
<td class=kW>10:5</td>
<td class=kW>8:5</td>
<td class=br>81:54</td><td class=br>+27</td>
<td class=bc>10 - 2 - 5</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>An Liepi��</td><td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>0:6</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=br>48:40</td><td class=br>+8</td>
<td class=bc>7 - 8 - 2</td>
<td class=br><strong>22</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Fi Buhtujevs</td><td class=kL>3:4</td>
<td class=kT>6:6</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kT>4:4</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=br>61:49</td><td class=br>+12</td>
<td class=bc>9 - 4 - 4</td>
<td class=br><strong>22</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Al Sili��</td><td class=kL>2:4</td>
<td class=kL>5:6</td>
<td class=kW>7:5</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=br>50:45</td><td class=br>+5</td>
<td class=bc>8 - 4 - 5</td>
<td class=br><strong>20</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ar Matantsev</td><td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=br>52:49</td><td class=br>+3</td>
<td class=bc>7 - 3 - 7</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ga Bohinc</td><td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=br>46:36</td><td class=br>+10</td>
<td class=bc>8 - 1 - 8</td>
<td class=br><strong>17</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Ma Zenisek</td><td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=br>49:42</td><td class=br>+7</td>
<td class=bc>8 - 1 - 8</td>
<td class=br><strong>17</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>Ja Zalokar Obadi�</td><td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=br>44:52</td><td class=br>-8</td>
<td class=bc>8 - 1 - 8</td>
<td class=br><strong>17</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>A</td><td class=d>11.</td><td class=kt>Go Lonnqvist</td><td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>8:0</td>
<td class=kW>3:2</td>
<td class=k>&nbsp;</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=br>47:43</td><td class=br>+4</td>
<td class=bc>7 - 2 - 7</td>
<td class=br><strong>16</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>A</td><td class=d>12.</td><td class=kt>J� Bitmanis</td><td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=br>45:43</td><td class=br>+2</td>
<td class=bc>6 - 4 - 7</td>
<td class=br><strong>16</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ro Kerns</td><td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kT>0:0</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>0:8</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=br>29:50</td><td class=br>-21</td>
<td class=bc>5 - 5 - 7</td>
<td class=br><strong>15</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Vi Henttonen</td><td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kW>5:0</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=br>40:54</td><td class=br>-14</td>
<td class=bc>5 - 2 - 10</td>
<td class=br><strong>12</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Sa Skarainis</td><td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=k>&nbsp;</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=br>33:46</td><td class=br>-13</td>
<td class=bc>5 - 1 - 10</td>
<td class=br><strong>11</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Al �ernovojs</td><td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kW>6:0</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=br>38:52</td><td class=br>-14</td>
<td class=bc>4 - 2 - 11</td>
<td class=br><strong>10</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Mi Saul�tis</td><td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kL>5:10</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=br>38:62</td><td class=br>-24</td>
<td class=bc>3 - 2 - 12</td>
<td class=br><strong>8</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>To Jakseboga</td><td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>5:8</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=br>25:61</td><td class=br>-36</td>
<td class=bc>2 - 0 - 15</td>
<td class=br><strong>4</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ma Zenisek</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>5 : 8</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ed Nilsson</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ed Nilsson</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Go Lonnqvist</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ed Nilsson</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Zenisek</td><td class=bc>-</td><td class=bl>Ja Zalokar Obadi�</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ed Nilsson</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Ja Zalokar Obadi�</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Go Lonnqvist</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ed Nilsson</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ja Zalokar Obadi�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ed Nilsson</td><td class=bc>-</td><td class=bl>Ja Zalokar Obadi�</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ja Zalokar Obadi�</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Go Lonnqvist</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ed Nilsson</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ja Zalokar Obadi�</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ed Nilsson</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>6 : 6</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>Ja Zalokar Obadi�</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ed Nilsson</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>Ja Zalokar Obadi�</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>7 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Ja Zalokar Obadi�</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Go Lonnqvist</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>7 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ma Zenisek</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>5 : 10</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ma Zenisek</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ed Nilsson</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>2 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group (top72 ) Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ra Miglinieks</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kL>2:8</td>
<td class=kW>5:0</td>
<td class=kW>7:5</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=br>60:47</td><td class=br>+13</td>
<td class=bc>10 - 3 - 4</td>
<td class=br><strong>23</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ra Kuha�skis</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>5:5</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kL>4:5</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kW>6:4</td>
<td class=br>62:50</td><td class=br>+12</td>
<td class=bc>9 - 5 - 3</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>J� Re�is</td><td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>8:5</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kW>6:4</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>7:0</td>
<td class=br>57:39</td><td class=br>+18</td>
<td class=bc>9 - 4 - 4</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ed Ka�eps</td><td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kL>2:7</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>7:4</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kW>6:4</td>
<td class=br>52:49</td><td class=br>+3</td>
<td class=bc>9 - 3 - 5</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ma Madera</td><td class=kW>4:3</td>
<td class=kT>5:5</td>
<td class=kW>6:0</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kL>1:4</td>
<td class=kW>6:0</td>
<td class=br>58:37</td><td class=br>+21</td>
<td class=bc>9 - 3 - 5</td>
<td class=br><strong>21</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ed Caics</td><td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>5:7</td>
<td class=k>&nbsp;</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>6:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=br>58:46</td><td class=br>+12</td>
<td class=bc>7 - 6 - 3</td>
<td class=br><strong>20</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>My Shalomayev</td><td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=br>50:46</td><td class=br>+4</td>
<td class=bc>8 - 3 - 6</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>An Jarvinen</td><td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=k>&nbsp;</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=br>36:33</td><td class=br>+3</td>
<td class=bc>8 - 2 - 6</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Lu Jurka</td><td class=kW>8:2</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=br>45:32</td><td class=br>+13</td>
<td class=bc>6 - 6 - 5</td>
<td class=br><strong>18</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>Sa Kalni��</td><td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=br>36:41</td><td class=br>-5</td>
<td class=bc>7 - 3 - 7</td>
<td class=br><strong>17</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>A</td><td class=d>11.</td><td class=kt>Ja Koski</td><td class=kL>5:7</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kW>7:5</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=br>50:62</td><td class=br>-12</td>
<td class=bc>8 - 0 - 9</td>
<td class=br><strong>16</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>A</td><td class=d>12.</td><td class=kt>An Kuz�ecovs</td><td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kL>5:8</td>
<td class=kW>7:2</td>
<td class=kL>0:4</td>
<td class=k>&nbsp;</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kL>1:5</td>
<td class=kW>6:4</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=br>59:48</td><td class=br>+11</td>
<td class=bc>8 - 0 - 8</td>
<td class=br><strong>16</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Si Pleikys</td><td class=kT>1:1</td>
<td class=kW>5:4</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=br>39:48</td><td class=br>-9</td>
<td class=bc>6 - 3 - 8</td>
<td class=br><strong>15</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Kr Zem�ickis</td><td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=k>&nbsp;</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=br>37:40</td><td class=br>-3</td>
<td class=bc>6 - 2 - 8</td>
<td class=br><strong>14</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Ti Dion</td><td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>4:6</td>
<td class=kL>4:7</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kL>4:6</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=br>42:59</td><td class=br>-17</td>
<td class=bc>5 - 0 - 12</td>
<td class=br><strong>10</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>El R�cen�ja</td><td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>4:6</td>
<td class=kL>2:7</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=br>46:61</td><td class=br>-15</td>
<td class=bc>4 - 2 - 11</td>
<td class=br><strong>10</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>He Nilsson</td><td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=br>34:50</td><td class=br>-16</td>
<td class=bc>4 - 2 - 11</td>
<td class=br><strong>10</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Ne �krlep</td><td class=kL>3:6</td>
<td class=kL>4:6</td>
<td class=kL>0:7</td>
<td class=kL>4:6</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kL>1:7</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=br>38:71</td><td class=br>-33</td>
<td class=bc>3 - 3 - 11</td>
<td class=br><strong>9</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ja Koski</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ne �krlep</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>5 : 8</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>An Jarvinen</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ja Koski</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>7 : 5</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ne �krlep</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>An Jarvinen</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ja Koski</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ne �krlep</td><td class=bc>-</td><td class=blW>An Jarvinen</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ja Koski</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>An Jarvinen</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ne �krlep</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ja Koski</td><td class=bc>-</td><td class=bl>An Jarvinen</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ne �krlep</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>An Jarvinen</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ja Koski</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>He Nilsson</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>An Jarvinen</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ja Koski</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Ne �krlep</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>An Jarvinen</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ja Koski</td><td class=bc>-</td><td class=blW>Ne �krlep</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>An Jarvinen</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Ne �krlep</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ja Koski</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>An Jarvinen</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ne �krlep</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>An Jarvinen</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>He Nilsson</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Ne �krlep</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Ja Koski</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>An Jarvinen</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ne �krlep</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ja Koski</td><td class=bc>7 : 5</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>He Nilsson</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ne �krlep</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>An Jarvinen</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Ja Koski</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>Ne �krlep</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>An Jarvinen</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ja Koski</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Ne �krlep</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ja Koski</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Jarvinen</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ne �krlep</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Ja Koski</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>An Jarvinen</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ne �krlep</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>Ja Koski</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Jarvinen</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Ja Koski</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ne �krlep</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>An Jarvinen</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Ja Koski</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ne �krlep</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>He Nilsson</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>2 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group (top72 ) Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ev Matantsev</td><td class=kx>*</td>
<td class=kW>7:2</td>
<td class=kW>6:5</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>7:1</td>
<td class=kW>5:3</td>
<td class=kW>7:5</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kW>8:3</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>8:0</td>
<td class=kW>6:4</td>
<td class=kW>9:2</td>
<td class=br>87:42</td><td class=br>+45</td>
<td class=bc>14 - 1 - 2</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Pa Petr</td><td class=kL>2:7</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>8:2</td>
<td class=kW>6:1</td>
<td class=kW>5:4</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kW>6:5</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>9:1</td>
<td class=kW>5:3</td>
<td class=br>72:53</td><td class=br>+19</td>
<td class=bc>11 - 1 - 5</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Re Vazoli��</td><td class=kL>5:6</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kW>3:0</td>
<td class=kW>10:1</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>10:0</td>
<td class=kW>4:3</td>
<td class=kW>6:5</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=br>71:48</td><td class=br>+23</td>
<td class=bc>9 - 4 - 4</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Kr Naglis</td><td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kL>3:8</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=br>44:43</td><td class=br>+1</td>
<td class=bc>9 - 3 - 5</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ro Rieksti��</td><td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>9:2</td>
<td class=kW>6:2</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=br>59:37</td><td class=br>+22</td>
<td class=bc>10 - 1 - 6</td>
<td class=br><strong>21</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>An Bozic</td><td class=kL>2:6</td>
<td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>7:2</td>
<td class=kW>1:0</td>
<td class=kW>6:0</td>
<td class=kL>2:4</td>
<td class=br>50:45</td><td class=br>+5</td>
<td class=bc>8 - 3 - 6</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ti Rimski</td><td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=br>38:39</td><td class=br>-1</td>
<td class=bc>7 - 5 - 5</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Sa Krasts</td><td class=kL>3:5</td>
<td class=kL>4:5</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=br>42:35</td><td class=br>+7</td>
<td class=bc>8 - 2 - 7</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Pa Plesak</td><td class=kL>5:7</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kL>0:7</td>
<td class=kT>5:5</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=br>47:55</td><td class=br>-8</td>
<td class=bc>7 - 3 - 7</td>
<td class=br><strong>17</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>Sa Lagzdi��</td><td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kL>1:10</td>
<td class=kT>4:4</td>
<td class=kL>2:9</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kW>7:4</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kL>2:4</td>
<td class=kW>6:2</td>
<td class=br>58:64</td><td class=br>-6</td>
<td class=bc>8 - 1 - 8</td>
<td class=br><strong>17</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>A</td><td class=d>11.</td><td class=kt>Ig Saveljev</td><td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>1:0</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=br>36:47</td><td class=br>-11</td>
<td class=bc>7 - 2 - 8</td>
<td class=br><strong>16</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>A</td><td class=d>12.</td><td class=kt>Ar Zasurcevs</td><td class=kL>3:8</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>8:3</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>6:6</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=br>65:66</td><td class=br>-1</td>
<td class=bc>6 - 4 - 7</td>
<td class=br><strong>16</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Al Skudr�tis</td><td class=kL>1:2</td>
<td class=kL>5:6</td>
<td class=kL>0:10</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=kL>4:7</td>
<td class=kL>0:1</td>
<td class=kT>6:6</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=kL>5:6</td>
<td class=kW>5:3</td>
<td class=br>58:60</td><td class=br>-2</td>
<td class=bc>5 - 5 - 7</td>
<td class=br><strong>15</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Ni Sviklis</td><td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kW>4:0</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kT>5:5</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=br>47:58</td><td class=br>-11</td>
<td class=bc>5 - 3 - 9</td>
<td class=br><strong>13</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Bi Karlsson</td><td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kL>5:6</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>2:7</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=br>47:63</td><td class=br>-16</td>
<td class=bc>4 - 3 - 10</td>
<td class=br><strong>11</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Se Mihejevs</td><td class=kL>0:8</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kT>0:0</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>3:6</td>
<td class=kL>0:2</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=br>29:45</td><td class=br>-16</td>
<td class=bc>4 - 3 - 10</td>
<td class=br><strong>11</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Jo Thyzell</td><td class=kL>4:6</td>
<td class=kL>1:9</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kW>6:5</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>4:6</td>
<td class=br>42:64</td><td class=br>-22</td>
<td class=bc>4 - 3 - 10</td>
<td class=br><strong>11</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Ma Satkus</td><td class=kL>2:9</td>
<td class=kL>3:5</td>
<td class=kL>3:6</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kW>6:4</td>
<td class=kx>*</td>
<td class=br>41:69</td><td class=br>-28</td>
<td class=bc>3 - 1 - 13</td>
<td class=br><strong>7</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Bi Karlsson</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jo Thyzell</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Ti Rimski</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 9</tr></td>
<tr><td class=brW>Bi Karlsson</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Jo Thyzell</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ti Rimski</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Bi Karlsson</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Jo Thyzell</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ti Rimski</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Bi Karlsson</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ti Rimski</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Jo Thyzell</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Ti Rimski</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Bi Karlsson</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jo Thyzell</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Ti Rimski</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Bi Karlsson</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jo Thyzell</td><td class=bc>-</td><td class=blW>Pa Plesak</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ti Rimski</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Bi Karlsson</td><td class=bc>-</td><td class=blW>Pa Plesak</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>Ti Rimski</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Bi Karlsson</td><td class=bc>-</td><td class=bl>Jo Thyzell</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Ti Rimski</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>7 : 5</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Jo Thyzell</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ti Rimski</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=blW>Pa Plesak</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Jo Thyzell</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Bi Karlsson</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>6 : 6</tr></td>
<tr><td class=br>Ti Rimski</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=blW>Jo Thyzell</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=bl>Bi Karlsson</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ti Rimski</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Jo Thyzell</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Bi Karlsson</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Pa Plesak</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ti Rimski</td><td class=bc>-</td><td class=bl>Jo Thyzell</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Bi Karlsson</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>8 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Jo Thyzell</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ti Rimski</td><td class=bc>-</td><td class=bl>Bi Karlsson</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Jo Thyzell</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Bi Karlsson</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ti Rimski</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Jo Thyzell</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Bi Karlsson</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ti Rimski</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>9 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Jo Thyzell</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Bi Karlsson</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Ti Rimski</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Bi Karlsson</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jo Thyzell</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ti Rimski</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Bi Karlsson</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jo Thyzell</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>5 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group (top72 ) Group D</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ra Kalni��</td><td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kW>8:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>8:0</td>
<td class=br>84:27</td><td class=br>+57</td>
<td class=bc>14 - 2 - 1</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ed Naglis</td><td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>9:3</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>8:2</td>
<td class=br>71:33</td><td class=br>+38</td>
<td class=bc>12 - 4 - 1</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ro Nuttunen</td><td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>8:4</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=br>64:39</td><td class=br>+25</td>
<td class=bc>12 - 2 - 3</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>El Sili��</td><td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=br>54:37</td><td class=br>+17</td>
<td class=bc>10 - 4 - 3</td>
<td class=br><strong>24</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>He Prokuratovs</td><td class=kL>2:8</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kL>4:8</td>
<td class=kW>7:0</td>
<td class=kW>10:3</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=br>62:56</td><td class=br>+6</td>
<td class=bc>8 - 4 - 5</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Em Liepi��</td><td class=kL>1:4</td>
<td class=kL>3:9</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kT>5:5</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=br>47:47</td><td class=br>0</td>
<td class=bc>8 - 4 - 5</td>
<td class=br><strong>20</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>R� Kamzols</td><td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kL>2:9</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kW>6:3</td>
<td class=br>53:47</td><td class=br>+6</td>
<td class=bc>7 - 5 - 5</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>K� Balodis</td><td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kT>0:0</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=k>&nbsp;</td>
<td class=br>47:36</td><td class=br>+11</td>
<td class=bc>8 - 3 - 5</td>
<td class=br><strong>19</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Kr Lagzdi�a</td><td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>6:0</td>
<td class=br>49:49</td><td class=br>0</td>
<td class=bc>9 - 0 - 8</td>
<td class=br><strong>18</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>An Kimberg</td><td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=br>41:46</td><td class=br>-5</td>
<td class=bc>7 - 2 - 8</td>
<td class=br><strong>16</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>A</td><td class=d>11.</td><td class=kt>Ol Pylypenko</td><td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>4:8</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>0:2</td>
<td class=kW>9:2</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=br>49:52</td><td class=br>-3</td>
<td class=bc>5 - 3 - 9</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>A</td><td class=d>12.</td><td class=kt>Tr M�nsson</td><td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kT>5:5</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=br>34:50</td><td class=br>-16</td>
<td class=bc>4 - 5 - 8</td>
<td class=br><strong>13</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Be Rjavec</td><td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=br>36:54</td><td class=br>-18</td>
<td class=bc>5 - 3 - 9</td>
<td class=br><strong>13</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Mi Tous</td><td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kW>8:4</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=br>44:47</td><td class=br>-3</td>
<td class=bc>5 - 1 - 11</td>
<td class=br><strong>11</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Gl Storozhenko</td><td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>0:7</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=br>37:59</td><td class=br>-22</td>
<td class=bc>3 - 5 - 9</td>
<td class=br><strong>11</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Ja Forsberg</td><td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>3:10</td>
<td class=kL>0:2</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=br>30:62</td><td class=br>-32</td>
<td class=bc>5 - 0 - 12</td>
<td class=br><strong>10</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Am Fylling</td><td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=br>29:45</td><td class=br>-16</td>
<td class=bc>2 - 5 - 10</td>
<td class=br><strong>9</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>J� Z�l�te</td><td class=kL>0:8</td>
<td class=kL>2:8</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kL>3:6</td>
<td class=k>&nbsp;</td>
<td class=kL>0:6</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=br>25:70</td><td class=br>-45</td>
<td class=bc>2 - 0 - 14</td>
<td class=br><strong>4</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Tous</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ja Forsberg</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Tr M�nsson</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Nuttunen</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Mi Tous</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ja Forsberg</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ro Nuttunen</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Mi Tous</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ja Forsberg</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>3 : 10</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=bl>Tr M�nsson</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ro Nuttunen</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ol Pylypenko</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Tous</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ja Forsberg</td><td class=bc>-</td><td class=bl>Tr M�nsson</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Mi Tous</td><td class=bc>-</td><td class=bl>Tr M�nsson</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ja Forsberg</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=bl>Tr M�nsson</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Tous</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>Tr M�nsson</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Mi Tous</td><td class=bc>-</td><td class=bl>Ja Forsberg</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Tr M�nsson</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=blW>Ja Forsberg</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Tr M�nsson</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>Ja Forsberg</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ol Pylypenko</td><td class=bc>-</td><td class=bl>Mi Tous</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=bl>Tr M�nsson</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ja Forsberg</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>Mi Tous</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>Tr M�nsson</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ja Forsberg</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Mi Tous</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>Ol Pylypenko</td><td class=bc>8 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Tr M�nsson</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ja Forsberg</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Mi Tous</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ol Pylypenko</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Tr M�nsson</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>Ja Forsberg</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>Mi Tous</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ol Pylypenko</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Ro Nuttunen</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Ja Forsberg</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Tr M�nsson</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>Mi Tous</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ol Pylypenko</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>Ja Forsberg</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Mi Tous</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Tr M�nsson</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ro Nuttunen</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ja Forsberg</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Mi Tous</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Ol Pylypenko</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Tr M�nsson</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>Ro Nuttunen</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Mi Tous</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ja Forsberg</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Ol Pylypenko</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Tr M�nsson</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Mi Tous</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ja Forsberg</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Tr M�nsson</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Tous</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ja Forsberg</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Tr M�nsson</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>0 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group A Final</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Ra Kalni��</td><td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>6:4</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>3:2</td>
<td class=kW>8:1</td>
<td class=kW>10:0</td>
<td class=kW>8:5</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kT>0:0</td>
<td class=kW>8:2</td>
<td class=kW>9:2</td>
<td class=kW>4:1</td>
<td class=kW>5:4</td>
<td class=br>119:38</td><td class=br>+81</td>
<td class=bc>22 - 1 - 0</td>
<td class=br><strong>45</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Mi Kobrle</td><td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>7:3</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>8:2</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>4:1</td>
<td class=kL>4:6</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>8:4</td>
<td class=kW>9:3</td>
<td class=kW>6:5</td>
<td class=kW>5:2</td>
<td class=kW>5:4</td>
<td class=kW>8:4</td>
<td class=br>120:66</td><td class=br>+54</td>
<td class=bc>18 - 2 - 3</td>
<td class=br><strong>38</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Ro Nuttunen</td><td class=kL>4:6</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kL>3:4</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=br>82:39</td><td class=br>+43</td>
<td class=bc>17 - 1 - 5</td>
<td class=br><strong>35</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>Ar Matantsev</td><td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>5:4</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kW>9:0</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=br>89:53</td><td class=br>+36</td>
<td class=bc>16 - 2 - 5</td>
<td class=br><strong>34</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Lu Jurka</td><td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>5:5</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=kL>1:3</td>
<td class=kL>4:7</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=br>63:55</td><td class=br>+8</td>
<td class=bc>10 - 8 - 5</td>
<td class=br><strong>28</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>El Sili��</td><td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=br>51:41</td><td class=br>+10</td>
<td class=bc>10 - 5 - 8</td>
<td class=br><strong>25</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Em Liepi��</td><td class=kL>1:6</td>
<td class=kL>3:7</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>6:4</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kW>7:6</td>
<td class=kL>1:3</td>
<td class=br>73:71</td><td class=br>+2</td>
<td class=bc>11 - 3 - 9</td>
<td class=br><strong>25</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Ed Nilsson</td><td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>4:6</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=br>66:59</td><td class=br>+7</td>
<td class=bc>11 - 3 - 9</td>
<td class=br><strong>25</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>An Jarvinen</td><td class=kL>1:7</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>7:5</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=br>59:55</td><td class=br>+4</td>
<td class=bc>9 - 6 - 8</td>
<td class=br><strong>24</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Va Smagars</td><td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=br>63:62</td><td class=br>+1</td>
<td class=bc>10 - 3 - 10</td>
<td class=br><strong>23</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Ar Zasurcevs</td><td class=kL>1:8</td>
<td class=kL>2:8</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>3:6</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=br>64:76</td><td class=br>-12</td>
<td class=bc>10 - 3 - 10</td>
<td class=br><strong>23</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>Fi Buhtujevs</td><td class=kL>0:10</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>0:5</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=br>57:81</td><td class=br>-24</td>
<td class=bc>10 - 2 - 11</td>
<td class=br><strong>22</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>An Kuz�ecovs</td><td class=kL>5:8</td>
<td class=kL>0:7</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kT>5:5</td>
<td class=kL>3:6</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>8:0</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>4:6</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>7:2</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=br>77:76</td><td class=br>+1</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>Kr Lagzdi�a</td><td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kL>3:4</td>
<td class=br>63:63</td><td class=br>0</td>
<td class=bc>8 - 5 - 10</td>
<td class=br><strong>21</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>Ed Naglis</td><td class=kL>2:6</td>
<td class=kW>6:4</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>6:3</td>
<td class=kW>6:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kW>6:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kT>5:5</td>
<td class=kT>4:4</td>
<td class=kW>6:3</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=br>75:77</td><td class=br>-2</td>
<td class=bc>8 - 5 - 10</td>
<td class=br><strong>21</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>An Kimberg</td><td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=br>44:61</td><td class=br>-17</td>
<td class=bc>8 - 4 - 11</td>
<td class=br><strong>20</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ma Zenisek</td><td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>0:5</td>
<td class=kL>4:5</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>5:4</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=br>58:77</td><td class=br>-19</td>
<td class=bc>7 - 4 - 12</td>
<td class=br><strong>18</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Kr Naglis</td><td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kL>3:6</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>0:5</td>
<td class=kT>5:5</td>
<td class=kL>1:4</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=br>59:74</td><td class=br>-15</td>
<td class=bc>5 - 7 - 11</td>
<td class=br><strong>17</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Ra Kuha�skis</td><td class=kL>2:5</td>
<td class=kL>4:8</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kW>7:4</td>
<td class=kL>1:4</td>
<td class=kL>4:6</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kL>2:7</td>
<td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=br>62:85</td><td class=br>-23</td>
<td class=bc>7 - 3 - 13</td>
<td class=br><strong>17</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Al Sili��</td><td class=kT>0:0</td>
<td class=kL>3:9</td>
<td class=kL>2:4</td>
<td class=kL>0:9</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>5:7</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>3:6</td>
<td class=kW>6:1</td>
<td class=kW>1:0</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>2:7</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=br>57:79</td><td class=br>-22</td>
<td class=bc>8 - 1 - 14</td>
<td class=br><strong>17</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Ja Koski</td><td class=kL>2:8</td>
<td class=kL>5:6</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>7:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kL>4:6</td>
<td class=kL>2:4</td>
<td class=br>62:81</td><td class=br>-19</td>
<td class=bc>5 - 5 - 13</td>
<td class=br><strong>15</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Ig Saveljev</td><td class=kL>2:9</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=br>36:64</td><td class=br>-28</td>
<td class=bc>5 - 3 - 15</td>
<td class=br><strong>13</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Pa Plesak</td><td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>6:7</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kW>6:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=br>52:85</td><td class=br>-33</td>
<td class=bc>4 - 5 - 14</td>
<td class=br><strong>13</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Tr M�nsson</td><td class=kL>4:5</td>
<td class=kL>4:8</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=br>48:81</td><td class=br>-33</td>
<td class=bc>6 - 0 - 17</td>
<td class=br><strong>12</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ed Nilsson</td><td class=bc>-</td><td class=bl>Ja Koski</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Tr M�nsson</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>An Jarvinen</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ja Koski</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Ed Nilsson</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>Tr M�nsson</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=bl>An Jarvinen</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ja Koski</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ed Nilsson</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Tr M�nsson</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>An Jarvinen</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ja Koski</td><td class=bc>-</td><td class=blW>Pa Plesak</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ed Nilsson</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Tr M�nsson</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>An Jarvinen</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Ja Koski</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ed Nilsson</td><td class=bc>-</td><td class=bl>Tr M�nsson</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>An Jarvinen</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Zenisek</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ja Koski</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Tr M�nsson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ed Nilsson</td><td class=bc>-</td><td class=blW>An Jarvinen</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Zenisek</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Tr M�nsson</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ja Koski</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>An Jarvinen</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ed Nilsson</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ro Nuttunen</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>Tr M�nsson</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Zenisek</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>An Jarvinen</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ja Koski</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ed Nilsson</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=blW>Tr M�nsson</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>An Jarvinen</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ja Koski</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ed Nilsson</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>6 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Tr M�nsson</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=bl>An Jarvinen</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Koski</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Nuttunen</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ed Nilsson</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Tr M�nsson</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>An Jarvinen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ja Koski</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ed Nilsson</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>4 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>An Jarvinen</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Tr M�nsson</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ja Koski</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>An Jarvinen</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Tr M�nsson</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ja Koski</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ed Nilsson</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>An Jarvinen</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>7 : 5</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Tr M�nsson</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ja Koski</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>An Jarvinen</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ro Nuttunen</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Tr M�nsson</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ro Nuttunen</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>An Jarvinen</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>Tr M�nsson</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>Ed Nilsson</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>5 : 8</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ma Zenisek</td><td class=bc>-</td><td class=bl>Ja Koski</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>An Jarvinen</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Tr M�nsson</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Ed Nilsson</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Ja Koski</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ro Nuttunen</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>An Jarvinen</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Tr M�nsson</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ja Koski</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ed Nilsson</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>An Jarvinen</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Tr M�nsson</td><td class=bc>-</td><td class=bl>Ja Koski</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>An Jarvinen</td><td class=bc>-</td><td class=bl>Ja Koski</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Tr M�nsson</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ed Nilsson</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Ja Koski</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>An Jarvinen</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Tr M�nsson</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ed Nilsson</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Nuttunen</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Ja Koski</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>7 : 6</tr></td>
<tr><td class=br>An Jarvinen</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Tr M�nsson</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>Ja Koski</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>An Jarvinen</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ja Koski</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Pa Plesak</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>An Jarvinen</td><td class=bc>-</td><td class=bl>Tr M�nsson</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=br>Ed Nilsson</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ja Koski</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ro Nuttunen</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Tr M�nsson</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>6 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group B Final</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Ev Matantsev</td><td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>6:4</td>
<td class=kW>6:2</td>
<td class=kW>6:4</td>
<td class=kW>4:2</td>
<td class=kT>5:5</td>
<td class=kW>8:4</td>
<td class=kW>3:0</td>
<td class=kW>7:3</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>5:4</td>
<td class=kW>4:0</td>
<td class=kL>3:6</td>
<td class=kW>6:4</td>
<td class=kW>5:2</td>
<td class=kW>5:4</td>
<td class=kW>6:4</td>
<td class=kT>3:3</td>
<td class=kW>6:5</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=br>110:65</td><td class=br>+45</td>
<td class=bc>20 - 2 - 1</td>
<td class=br><strong>42</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>J� Re�is</td><td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>4:7</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>1:6</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>8:3</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>7:4</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>8:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=br>84:55</td><td class=br>+29</td>
<td class=bc>17 - 1 - 5</td>
<td class=br><strong>35</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Ra Miglinieks</td><td class=kL>4:6</td>
<td class=kW>7:4</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kW>5:4</td>
<td class=kW>1:0</td>
<td class=kT>5:5</td>
<td class=kW>10:0</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kW>7:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=br>86:48</td><td class=br>+38</td>
<td class=bc>15 - 3 - 5</td>
<td class=br><strong>33</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>Sa Lagzdi��</td><td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=kL>0:5</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kT>5:5</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=br>73:50</td><td class=br>+23</td>
<td class=bc>14 - 4 - 5</td>
<td class=br><strong>32</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Ed Caics</td><td class=kL>4:6</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>7:2</td>
<td class=kT>3:3</td>
<td class=kW>7:4</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>7:3</td>
<td class=br>87:60</td><td class=br>+27</td>
<td class=bc>13 - 4 - 6</td>
<td class=br><strong>30</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>Re Vazoli��</td><td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kL>1:5</td>
<td class=kW>6:5</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kL>1:3</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=kW>7:3</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=br>83:57</td><td class=br>+26</td>
<td class=bc>14 - 2 - 7</td>
<td class=br><strong>30</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Ma Madera</td><td class=kT>5:5</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>6:5</td>
<td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=kL>4:5</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=br>86:61</td><td class=br>+25</td>
<td class=bc>12 - 6 - 5</td>
<td class=br><strong>30</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Pa Petr</td><td class=kL>4:8</td>
<td class=kW>6:1</td>
<td class=kL>4:5</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>8:4</td>
<td class=kW>7:4</td>
<td class=kT>4:4</td>
<td class=kW>7:4</td>
<td class=kL>2:4</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kW>8:3</td>
<td class=kW>7:3</td>
<td class=kW>6:3</td>
<td class=br>104:81</td><td class=br>+23</td>
<td class=bc>12 - 3 - 8</td>
<td class=br><strong>27</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>Ro Rieksti��</td><td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kL>0:6</td>
<td class=kL>4:8</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kL>4:5</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=br>67:56</td><td class=br>+11</td>
<td class=bc>12 - 1 - 10</td>
<td class=br><strong>25</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>K� Balodis</td><td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kT>5:5</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kL>4:7</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kL>3:6</td>
<td class=kW>2:0</td>
<td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=br>64:62</td><td class=br>+2</td>
<td class=bc>11 - 3 - 9</td>
<td class=br><strong>25</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>An Bozic</td><td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>0:10</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kL>5:7</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>7:1</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=br>63:66</td><td class=br>-3</td>
<td class=bc>10 - 4 - 9</td>
<td class=br><strong>24</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>He Prokuratovs</td><td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>4:7</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=br>61:65</td><td class=br>-4</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>Ed Ka�eps</td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kL>5:6</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=br>56:64</td><td class=br>-8</td>
<td class=bc>9 - 4 - 10</td>
<td class=br><strong>22</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>R� Kamzols</td><td class=kL>4:5</td>
<td class=kL>3:8</td>
<td class=kL>3:7</td>
<td class=kW>5:4</td>
<td class=kL>4:7</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=br>69:79</td><td class=br>-10</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>J� Bitmanis</td><td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>5:6</td>
<td class=kL>4:5</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>7:5</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kT>0:0</td>
<td class=br>56:67</td><td class=br>-11</td>
<td class=bc>8 - 2 - 13</td>
<td class=br><strong>18</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>An Liepi��</td><td class=kW>6:3</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=br>52:63</td><td class=br>-11</td>
<td class=bc>8 - 2 - 13</td>
<td class=br><strong>18</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ja Zalokar Obadi�</td><td class=kL>4:6</td>
<td class=kL>4:7</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>3:7</td>
<td class=kL>1:6</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kW>5:4</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=kL>0:1</td>
<td class=br>56:74</td><td class=br>-18</td>
<td class=bc>8 - 2 - 13</td>
<td class=br><strong>18</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Sa Krasts</td><td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>2:7</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=br>38:66</td><td class=br>-28</td>
<td class=bc>7 - 2 - 14</td>
<td class=br><strong>16</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Ti Rimski</td><td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=br>40:62</td><td class=br>-22</td>
<td class=bc>6 - 4 - 13</td>
<td class=br><strong>16</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Go Lonnqvist</td><td class=kL>4:6</td>
<td class=kL>2:8</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=br>57:76</td><td class=br>-19</td>
<td class=bc>6 - 4 - 13</td>
<td class=br><strong>16</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Ol Pylypenko</td><td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>3:7</td>
<td class=kL>3:5</td>
<td class=kL>4:5</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=br>54:68</td><td class=br>-14</td>
<td class=bc>6 - 3 - 14</td>
<td class=br><strong>15</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>My Shalomayev</td><td class=kL>5:6</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kT>5:5</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kW>5:4</td>
<td class=kL>3:8</td>
<td class=kL>1:4</td>
<td class=kW>8:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>1:7</td>
<td class=kW>5:0</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=br>59:91</td><td class=br>-32</td>
<td class=bc>4 - 5 - 14</td>
<td class=br><strong>13</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Ga Bohinc</td><td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>3:7</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>46:73</td><td class=br>-27</td>
<td class=bc>4 - 3 - 16</td>
<td class=br><strong>11</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Sa Kalni��</td><td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>3:7</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kT>0:0</td>
<td class=kL>2:5</td>
<td class=kW>1:0</td>
<td class=kL>0:3</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>35:77</td><td class=br>-42</td>
<td class=bc>5 - 1 - 17</td>
<td class=br><strong>11</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=bl>Ja Zalokar Obadi�</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>Ti Rimski</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ol Pylypenko</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ja Zalokar Obadi�</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Ti Rimski</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ol Pylypenko</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ja Zalokar Obadi�</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ti Rimski</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Go Lonnqvist</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ja Zalokar Obadi�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Ti Rimski</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Ja Zalokar Obadi�</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ti Rimski</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Ja Zalokar Obadi�</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Go Lonnqvist</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ol Pylypenko</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ti Rimski</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>8 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ti Rimski</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Go Lonnqvist</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=bl>Ti Rimski</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Ti Rimski</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ol Pylypenko</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Ti Rimski</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ti Rimski</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Ti Rimski</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>6 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ti Rimski</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ti Rimski</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ti Rimski</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ti Rimski</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Ol Pylypenko</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ti Rimski</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Ti Rimski</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ti Rimski</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>Ol Pylypenko</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ti Rimski</td><td class=bc>-</td><td class=bl>Ol Pylypenko</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=blW>Go Lonnqvist</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ja Zalokar Obadi�</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ol Pylypenko</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ti Rimski</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>Ja Zalokar Obadi�</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Ol Pylypenko</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ti Rimski</td><td class=bc>-</td><td class=blW>Ja Zalokar Obadi�</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>5 : 7</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>2 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ol Pylypenko</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ja Zalokar Obadi�</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ti Rimski</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Ol Pylypenko</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Ja Zalokar Obadi�</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ti Rimski</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ol Pylypenko</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ja Zalokar Obadi�</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>1 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
