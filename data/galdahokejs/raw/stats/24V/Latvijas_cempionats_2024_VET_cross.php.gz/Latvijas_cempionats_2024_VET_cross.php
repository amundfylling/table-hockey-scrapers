<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Latvijas cempionats 2024 VET</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../24V/Latvijas_cempionats_2024_VET_index.php">Latvijas cempionats 2024 VET, 13. April 2024</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group VET</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Se Mihejevs</td><td class=kx>*</td>
<td class=kL>1:2 + 3:2</td>
<td class=kT>1:1 + 2:3</td>
<td class=kL>2:3 + 2:0</td>
<td class=kL>1:3 + 3:2</td>
<td class=kW>2:0 + 2:5</td>
<td class=kW>3:2 + 3:1</td>
<td class=kW>5:1 + 6:2</td>
<td class=kW>5:0 + 7:4</td>
<td class=kW>4:2 + 5:0</td>
<td class=br>57:33</td><td class=br>+24</td>
<td class=bc>12 - 1 - 5</td>
<td class=br><strong>25</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Al �ernovojs</td><td class=kW>2:1 + 2:3</td>
<td class=kx>*</td>
<td class=kL>4:5 + 0:1</td>
<td class=kL>1:2 + 3:2</td>
<td class=kW>3:1 + 1:5</td>
<td class=kW>2:0 + 3:1</td>
<td class=kW>2:0 + 3:2</td>
<td class=kW>2:0 + 3:3</td>
<td class=kT>0:0 + 3:0</td>
<td class=kW>2:1 + 5:0</td>
<td class=br>41:27</td><td class=br>+14</td>
<td class=bc>11 - 2 - 5</td>
<td class=br><strong>24</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Sa Skarainis</td><td class=kT>1:1 + 3:2</td>
<td class=kW>5:4 + 1:0</td>
<td class=kx>*</td>
<td class=kW>5:0 + 1:3</td>
<td class=kL>1:2 + 3:1</td>
<td class=kW>2:1 + 3:4</td>
<td class=kL>4:5 + 1:3</td>
<td class=kL>2:4 + 4:2</td>
<td class=kW>7:0 + 6:1</td>
<td class=kW>4:2 + 6:1</td>
<td class=br>59:36</td><td class=br>+23</td>
<td class=bc>11 - 1 - 6</td>
<td class=br><strong>23</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Gu Ern�teins</td><td class=kW>3:2 + 0:2</td>
<td class=kW>2:1 + 2:3</td>
<td class=kL>0:5 + 3:1</td>
<td class=kx>*</td>
<td class=kW>5:2 + 2:3</td>
<td class=kL>3:4 + 2:2</td>
<td class=kW>2:1 + 2:1</td>
<td class=kT>1:1 + 1:1</td>
<td class=kW>6:1 + 8:5</td>
<td class=kW>3:0 + 8:0</td>
<td class=br>53:35</td><td class=br>+18</td>
<td class=bc>10 - 3 - 5</td>
<td class=br><strong>23</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Sa Kalni��</td><td class=kW>3:1 + 2:3</td>
<td class=kL>1:3 + 5:1</td>
<td class=kW>2:1 + 1:3</td>
<td class=kL>2:5 + 3:2</td>
<td class=kx>*</td>
<td class=kT>2:2 + 3:4</td>
<td class=kT>2:2 + 2:1</td>
<td class=kT>1:1 + 2:3</td>
<td class=kW>5:1 + 7:0</td>
<td class=kW>2:1 + 5:0</td>
<td class=br>50:34</td><td class=br>+16</td>
<td class=bc>9 - 3 - 6</td>
<td class=br><strong>21</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Sa Krasts</td><td class=kL>0:2 + 5:2</td>
<td class=kL>0:2 + 1:3</td>
<td class=kL>1:2 + 4:3</td>
<td class=kW>4:3 + 2:2</td>
<td class=kT>2:2 + 4:3</td>
<td class=kx>*</td>
<td class=kT>2:2 + 1:5</td>
<td class=kW>4:1 + 1:2</td>
<td class=kW>10:1 + 2:2</td>
<td class=kW>2:0 + 4:2</td>
<td class=br>49:39</td><td class=br>+10</td>
<td class=bc>8 - 4 - 6</td>
<td class=br><strong>20</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Ro Fa�ken�teins</td><td class=kL>2:3 + 1:3</td>
<td class=kL>0:2 + 2:3</td>
<td class=kW>5:4 + 3:1</td>
<td class=kL>1:2 + 1:2</td>
<td class=kT>2:2 + 1:2</td>
<td class=kT>2:2 + 5:1</td>
<td class=kx>*</td>
<td class=kW>6:1 + 7:2</td>
<td class=kT>2:2 + 5:0</td>
<td class=kT>2:2 + 4:2</td>
<td class=br>51:36</td><td class=br>+15</td>
<td class=bc>7 - 4 - 7</td>
<td class=br><strong>18</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Gu Buls</td><td class=kL>1:5 + 2:6</td>
<td class=kL>0:2 + 3:3</td>
<td class=kW>4:2 + 2:4</td>
<td class=kT>1:1 + 1:1</td>
<td class=kT>1:1 + 3:2</td>
<td class=kL>1:4 + 2:1</td>
<td class=kL>1:6 + 2:7</td>
<td class=kx>*</td>
<td class=kW>3:0 + 3:0</td>
<td class=kW>1:0 + 4:1</td>
<td class=br>35:46</td><td class=br>-11</td>
<td class=bc>7 - 4 - 7</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ja Rektins</td><td class=kL>0:5 + 4:7</td>
<td class=kT>0:0 + 0:3</td>
<td class=kL>0:7 + 1:6</td>
<td class=kL>1:6 + 5:8</td>
<td class=kL>1:5 + 0:7</td>
<td class=kL>1:10 + 2:2</td>
<td class=kT>2:2 + 0:5</td>
<td class=kL>0:3 + 0:3</td>
<td class=kx>*</td>
<td class=kT>2:2 + 3:0</td>
<td class=br>22:81</td><td class=br>-59</td>
<td class=bc>1 - 4 - 13</td>
<td class=br><strong>6</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>J� Zem�ickis</td><td class=kL>2:4 + 0:5</td>
<td class=kL>1:2 + 0:5</td>
<td class=kL>2:4 + 1:6</td>
<td class=kL>0:3 + 0:8</td>
<td class=kL>1:2 + 0:5</td>
<td class=kL>0:2 + 2:4</td>
<td class=kT>2:2 + 2:4</td>
<td class=kL>0:1 + 1:4</td>
<td class=kT>2:2 + 0:3</td>
<td class=kx>*</td>
<td class=br>16:66</td><td class=br>-50</td>
<td class=bc>0 - 2 - 16</td>
<td class=br><strong>2</strong></td><td class=d>10.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>2 : 1 + 2 : 3</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>2 : 2 + 4 : 2</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>1 : 1 + 2 : 3</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Ja Rektins</td><td class=bc>10 : 1 + 2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>1 : 0 + 4 : 1</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>0 : 5 + 3 : 1</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Ja Rektins</td><td class=bc>2 : 2 + 5 : 0</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>1 : 3 + 3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>2 : 1 + 5 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>Ja Rektins</td><td class=bc>3 : 0 + 3 : 0</tr></td>
<tr><td class=brW>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>5 : 2 + 2 : 3</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 2 + 5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>2 : 4 + 1 : 6</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Ja Rektins</td><td class=bc>0 : 0 + 3 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>1 : 4 + 2 : 1</tr></td>
<tr><td class=brW>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>3 : 2 + 0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ja Rektins</td><td class=bc>7 : 0 + 6 : 1</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>1 : 2 + 0 : 5</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 0 + 3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>1 : 6 + 2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ja Rektins</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>1 : 5 + 0 : 7</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 1 + 3 : 4</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>2 : 4 + 0 : 5</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>2 : 0 + 3 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 2 + 3 : 4</tr></td>
<tr><td class=br>Ja Rektins</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>0 : 5 + 4 : 7</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>4 : 5 + 1 : 3</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Gu Ern�teins</td><td class=bc>0 : 3 + 0 : 8</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>2 : 0 + 3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>0 : 2 + 5 : 2</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>2 : 2 + 2 : 1</tr></td>
<tr><td class=br>Ja Rektins</td><td class=bc>-</td><td class=blW>Gu Ern�teins</td><td class=bc>1 : 6 + 5 : 8</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>2 : 4 + 4 : 2</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>3 : 2 + 3 : 1</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>4 : 3 + 2 : 2</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>1 : 1 + 2 : 3</tr></td>
<tr><td class=br>Ja Rektins</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>5 : 4 + 1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Gu Ern�teins</td><td class=bc>1 : 2 + 1 : 2</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>5 : 1 + 6 : 2</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>1 : 3 + 5 : 1</tr></td>
<tr><td class=br>Ja Rektins</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>2 : 2 + 3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>1 : 1 + 1 : 1</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>1 : 2 + 3 : 2</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>2 : 0 + 4 : 2</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>2 : 1 + 1 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
