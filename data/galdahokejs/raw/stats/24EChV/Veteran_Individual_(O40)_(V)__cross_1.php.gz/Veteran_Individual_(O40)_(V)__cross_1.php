<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Veteran Individual (O40) (V) </title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Veteran_Individual_(O40)_(V)__list.php">Veteran Individual (O40) (V) </a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group Veteran 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>To Uimonen</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:8</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=br>61:38</td><td class=br>+23</td>
<td class=bc>14 - 2 - 2</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Pe �stlund</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>9:2</td>
<td class=kT>1:1</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=br>66:19</td><td class=br>+47</td>
<td class=bc>12 - 4 - 2</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Ma Zenisek</td><td class=kW>8:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>7:0</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=br>75:37</td><td class=br>+38</td>
<td class=bc>12 - 2 - 4</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Gu Hermansson</td><td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kL>5:6</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>6:5</td>
<td class=kW>4:1</td>
<td class=kW>7:4</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=br>69:46</td><td class=br>+23</td>
<td class=bc>12 - 1 - 5</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Se Mihejevs</td><td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kW>1:0</td>
<td class=br>43:26</td><td class=br>+17</td>
<td class=bc>11 - 3 - 4</td>
<td class=br><strong>25</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ig Saveljev</td><td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=br>63:36</td><td class=br>+27</td>
<td class=bc>11 - 2 - 5</td>
<td class=br><strong>24</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Sa Kalni��</td><td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>8:2</td>
<td class=kW>6:5</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=br>61:39</td><td class=br>+22</td>
<td class=bc>10 - 3 - 5</td>
<td class=br><strong>23</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Vi Henttonen</td><td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=br>49:31</td><td class=br>+18</td>
<td class=bc>10 - 3 - 5</td>
<td class=br><strong>23</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Au Pleikys</td><td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kL>0:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=br>52:46</td><td class=br>+6</td>
<td class=bc>10 - 2 - 6</td>
<td class=br><strong>22</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Sa Skarainis</td><td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kW>6:5</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>49:46</td><td class=br>+3</td>
<td class=bc>9 - 2 - 7</td>
<td class=br><strong>20</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Va Pikl</td><td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=br>48:40</td><td class=br>+8</td>
<td class=bc>8 - 2 - 8</td>
<td class=br><strong>18</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Va Hamdamov</td><td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>0:5</td>
<td class=kW>2:0</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=br>31:39</td><td class=br>-8</td>
<td class=bc>7 - 3 - 8</td>
<td class=br><strong>17</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Mi Margolis</td><td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>2:8</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=br>33:64</td><td class=br>-31</td>
<td class=bc>5 - 2 - 11</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>My Shalomayev</td><td class=kL>2:5</td>
<td class=kL>2:9</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kL>5:6</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>9:1</td>
<td class=kL>1:2</td>
<td class=br>42:55</td><td class=br>-13</td>
<td class=bc>5 - 2 - 11</td>
<td class=br><strong>12</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>He Petuch</td><td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kL>5:6</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=br>44:62</td><td class=br>-18</td>
<td class=bc>3 - 4 - 11</td>
<td class=br><strong>10</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Vl Voronov</td><td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=br>31:61</td><td class=br>-30</td>
<td class=bc>3 - 2 - 13</td>
<td class=br><strong>8</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Vo Kvasnikov</td><td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kL>4:7</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>0:6</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=br>32:72</td><td class=br>-40</td>
<td class=bc>4 - 0 - 14</td>
<td class=br><strong>8</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Ig Zamiatin</td><td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>1:9</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>0:7</td>
<td class=br>26:86</td><td class=br>-60</td>
<td class=bc>3 - 0 - 15</td>
<td class=br><strong>6</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>La Ulfvensj�</td><td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kW>7:0</td>
<td class=kx>*</td>
<td class=br>26:58</td><td class=br>-32</td>
<td class=bc>2 - 1 - 15</td>
<td class=br><strong>5</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Hamdamov Vafa</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=bl>Uimonen Tomi</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=blW>Margolis Mihail</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ulfvensj� Lars</td><td class=bc>-</td><td class=blW>Voronov Vladimir</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>�stlund Peter</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Hamdamov Vafa</td><td class=bc>-</td><td class=blW>Uimonen Tomi</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Margolis Mihail</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=blW>Voronov Vladimir</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ulfvensj� Lars</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Uimonen Tomi</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Hamdamov Vafa</td><td class=bc>-</td><td class=bl>Margolis Mihail</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=blW>Voronov Vladimir</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Pikl Vaclav</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ulfvensj� Lars</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Margolis Mihail</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Uimonen Tomi</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Hamdamov Vafa</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=blW>�stlund Peter</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Zamiatin Igor</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Margolis Mihail</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Uimonen Tomi</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Hamdamov Vafa</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>�stlund Peter</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pikl Vaclav</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Margolis Mihail</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Uimonen Tomi</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Hamdamov Vafa</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Margolis Mihail</td><td class=bc>-</td><td class=blW>�stlund Peter</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Uimonen Tomi</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Hamdamov Vafa</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=blW>Pikl Vaclav</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>�stlund Peter</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zenisek Martin</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Margolis Mihail</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Uimonen Tomi</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Hamdamov Vafa</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Margolis Mihail</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Uimonen Tomi</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Hamdamov Vafa</td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>�stlund Peter</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Zenisek Martin</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Margolis Mihail</td><td class=bc>-</td><td class=blW>Pikl Vaclav</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Uimonen Tomi</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Hamdamov Vafa</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Margolis Mihail</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Uimonen Tomi</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Petuch Hermann</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Zamiatin Igor</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Zenisek Martin</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Margolis Mihail</td><td class=bc>-</td><td class=blW>Saveljev Igor</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Hamdamov Vafa</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Pikl Vaclav</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Saveljev Igor</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zenisek Martin</td><td class=bc>-</td><td class=bl>Hamdamov Vafa</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Margolis Mihail</td><td class=bc>-</td><td class=blW>Uimonen Tomi</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ulfvensj� Lars</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Pikl Vaclav</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Petuch Hermann</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>�stlund Peter</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Hamdamov Vafa</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Uimonen Tomi</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Zenisek Martin</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ulfvensj� Lars</td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Kvasnikov Volodymyr</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Saveljev Igor</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Hamdamov Vafa</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Uimonen Tomi</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Margolis Mihail</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Pikl Vaclav</td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ulfvensj� Lars</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Hamdamov Vafa</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Uimonen Tomi</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Margolis Mihail</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Zamiatin Igor</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ulfvensj� Lars</td><td class=bc>-</td><td class=blW>Hamdamov Vafa</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Uimonen Tomi</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=bl>Margolis Mihail</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=blW>Saveljev Igor</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=blW>Hamdamov Vafa</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Uimonen Tomi</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ulfvensj� Lars</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Margolis Mihail</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Saveljev Igor</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=bl>Hamdamov Vafa</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=blW>Uimonen Tomi</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Pikl Vaclav</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Margolis Mihail</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ulfvensj� Lars</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>2 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
