<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Veteran Individual (O40) (V) </title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Veteran_Individual_(O40)_(V)__list.php">Final Ranking</a></span></h2></div></div></div></div><h3 align="right">Veteran Individual (O40) (V) &nbsp;&nbsp;</h3>
<p><div align="center">
<p class=v><br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0 class="rnk">
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">M</th>
<th align="center">+</th>
<th align="center">=</th>
<th align="center">-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">P</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al><a href="stats.php?idpl=419&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D419%26x%3D-58%26p%3D%25C3%2596stlund%2520Peter%22%3E%C3%96stlund%20Peter%3C%2Fa%3E"><a href="stats.php?idpl=419&x=-58&p=%C3%96stlund%20Peter">�stlund Peter</a></a></td>
<td class=al>SWE</td>
<td class=ar>33</td>
<td class=ar>24</td>
<td class=ar>4</td>
<td class=ar>5</td>
<td class=ar>97</td>
<td class=al>&nbsp;:&nbsp;33</td>
<td class=ar>52</td>
</tr><tr><td class=br>2.</td>
<td class=bl><a href="stats.php?idpl=391&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D391%26x%3D-58%26p%3DUimonen%2520Tomi%22%3EUimonen%20Tomi%3C%2Fa%3E"><a href="stats.php?idpl=391&x=-58&p=Uimonen%20Tomi">Uimonen Tomi</a></a></td>
<td class=bl>FIN</td>
<td class=br>34</td>
<td class=br>22</td>
<td class=br>2</td>
<td class=br>10</td>
<td class=br>100</td>
<td class=bl>&nbsp;:&nbsp;73</td>
<td class=br>46</td>
</tr><tr><td class=ar>3.</td>
<td class=al><a href="stats.php?idpl=369&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D369%26x%3D-58%26p%3DSpivakovskyy%2520Mykhaylo%22%3ESpivakovskyy%20Mykhaylo%3C%2Fa%3E"><a href="stats.php?idpl=369&x=-58&p=Spivakovskyy%20Mykhaylo">Spivakovskyy Mykhaylo</a></a></td>
<td class=al>UKR</td>
<td class=ar>35</td>
<td class=ar>23</td>
<td class=ar>2</td>
<td class=ar>10</td>
<td class=ar>109</td>
<td class=al>&nbsp;:&nbsp;65</td>
<td class=ar>48</td>
</tr><tr><td class=br>4.</td>
<td class=bl><a href="stats.php?idpl=145&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D145%26x%3D-58%26p%3DZenisek%2520Martin%22%3EZenisek%20Martin%3C%2Fa%3E"><a href="stats.php?idpl=145&x=-58&p=Zenisek%20Martin">Zenisek Martin</a></a></td>
<td class=bl>CZE</td>
<td class=br>33</td>
<td class=br>17</td>
<td class=br>2</td>
<td class=br>14</td>
<td class=br>106</td>
<td class=bl>&nbsp;:&nbsp;83</td>
<td class=br>36</td>
</tr><tr><td class=ar>5.</td>
<td class=al><a href="stats.php?idpl=404&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D404%26x%3D-58%26p%3DMatysek%2520Daniel%22%3EMatysek%20Daniel%3C%2Fa%3E"><a href="stats.php?idpl=404&x=-58&p=Matysek%20Daniel">Matysek Daniel</a></a></td>
<td class=al>CZE</td>
<td class=ar>26</td>
<td class=ar>16</td>
<td class=ar>3</td>
<td class=ar>7</td>
<td class=ar>85</td>
<td class=al>&nbsp;:&nbsp;49</td>
<td class=ar>35</td>
</tr><tr><td class=br>6.</td>
<td class=bl><a href="stats.php?idpl=403&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D403%26x%3D-58%26p%3DCernoch%2520Miroslav%22%3ECernoch%20Miroslav%3C%2Fa%3E"><a href="stats.php?idpl=403&x=-58&p=Cernoch%20Miroslav">Cernoch Miroslav</a></a></td>
<td class=bl>CZE</td>
<td class=br>24</td>
<td class=br>13</td>
<td class=br>5</td>
<td class=br>6</td>
<td class=br>63</td>
<td class=bl>&nbsp;:&nbsp;33</td>
<td class=br>31</td>
</tr><tr><td class=ar>7.</td>
<td class=al><a href="stats.php?idpl=420&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D420%26x%3D-58%26p%3DSteen%2520Herman%22%3ESteen%20Herman%3C%2Fa%3E"><a href="stats.php?idpl=420&x=-58&p=Steen%20Herman">Steen Herman</a></a></td>
<td class=al>SWE</td>
<td class=ar>26</td>
<td class=ar>16</td>
<td class=ar>3</td>
<td class=ar>7</td>
<td class=ar>82</td>
<td class=al>&nbsp;:&nbsp;50</td>
<td class=ar>35</td>
</tr><tr><td class=br>8.</td>
<td class=bl><a href="stats.php?idpl=121&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D121%26x%3D-58%26p%3DHermansson%2520Gustaf%22%3EHermansson%20Gustaf%3C%2Fa%3E"><a href="stats.php?idpl=121&x=-58&p=Hermansson%20Gustaf">Hermansson Gustaf</a></a></td>
<td class=bl>SWE</td>
<td class=br>25</td>
<td class=br>15</td>
<td class=br>1</td>
<td class=br>9</td>
<td class=br>90</td>
<td class=bl>&nbsp;:&nbsp;64</td>
<td class=br>31</td>
</tr><tr><td class=ar>9.</td>
<td class=al><a href="stats.php?idpl=377&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D377%26x%3D-58%26p%3DAxelsen%2520Bjarne%22%3EAxelsen%20Bjarne%3C%2Fa%3E"><a href="stats.php?idpl=377&x=-58&p=Axelsen%20Bjarne">Axelsen Bjarne</a></a></td>
<td class=al>DEN</td>
<td class=ar>19</td>
<td class=ar>13</td>
<td class=ar>1</td>
<td class=ar>5</td>
<td class=ar>69</td>
<td class=al>&nbsp;:&nbsp;38</td>
<td class=ar>27</td>
</tr><tr><td class=br>10.</td>
<td class=bl><a href="stats.php?idpl=8&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D8%26x%3D-58%26p%3DMihejevs%2520Sergejs%22%3EMihejevs%20Sergejs%3C%2Fa%3E"><a href="stats.php?idpl=8&x=-58&p=Mihejevs%20Sergejs">Mihejevs Sergejs</a></a></td>
<td class=bl>LAT</td>
<td class=br>18</td>
<td class=br>11</td>
<td class=br>3</td>
<td class=br>4</td>
<td class=br>43</td>
<td class=bl>&nbsp;:&nbsp;26</td>
<td class=br>25</td>
</tr><tr><td class=ar>11.</td>
<td class=al><a href="stats.php?idpl=422&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D422%26x%3D-58%26p%3DPedersen%2520Richard%22%3EPedersen%20Richard%3C%2Fa%3E"><a href="stats.php?idpl=422&x=-58&p=Pedersen%20Richard">Pedersen Richard</a></a></td>
<td class=al>SWE</td>
<td class=ar>19</td>
<td class=ar>13</td>
<td class=ar>1</td>
<td class=ar>5</td>
<td class=ar>76</td>
<td class=al>&nbsp;:&nbsp;54</td>
<td class=ar>27</td>
</tr><tr><td class=br>12.</td>
<td class=bl><a href="stats.php?idpl=65&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D65%26x%3D-58%26p%3DSaveljev%2520Igor%22%3ESaveljev%20Igor%3C%2Fa%3E"><a href="stats.php?idpl=65&x=-58&p=Saveljev%20Igor">Saveljev Igor</a></a></td>
<td class=bl>EST</td>
<td class=br>18</td>
<td class=br>11</td>
<td class=br>2</td>
<td class=br>5</td>
<td class=br>63</td>
<td class=bl>&nbsp;:&nbsp;36</td>
<td class=br>24</td>
</tr><tr><td class=ar>13.</td>
<td class=al><a href="stats.php?idpl=6&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D6%26x%3D-58%26p%3DKalni%25C5%2586%25C5%25A1%2520Sandis%22%3EKalni%C5%86%C5%A1%20Sandis%3C%2Fa%3E"><a href="stats.php?idpl=6&x=-58&p=Kalni%C5%86%C5%A1%20Sandis">Kalni�� Sandis</a></a></td>
<td class=al>LAT</td>
<td class=ar>18</td>
<td class=ar>10</td>
<td class=ar>3</td>
<td class=ar>5</td>
<td class=ar>61</td>
<td class=al>&nbsp;:&nbsp;39</td>
<td class=ar>23</td>
</tr><tr><td class=br>14.</td>
<td class=bl><a href="stats.php?idpl=119&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D119%26x%3D-58%26p%3DNilsson%2520Henrik%22%3ENilsson%20Henrik%3C%2Fa%3E"><a href="stats.php?idpl=119&x=-58&p=Nilsson%20Henrik">Nilsson Henrik</a></a></td>
<td class=bl>SWE</td>
<td class=br>19</td>
<td class=br>11</td>
<td class=br>3</td>
<td class=br>5</td>
<td class=br>66</td>
<td class=bl>&nbsp;:&nbsp;49</td>
<td class=br>25</td>
</tr><tr><td class=ar>15.</td>
<td class=al><a href="stats.php?idpl=122&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D122%26x%3D-58%26p%3DHenttonen%2520Ville%22%3EHenttonen%20Ville%3C%2Fa%3E"><a href="stats.php?idpl=122&x=-58&p=Henttonen%20Ville">Henttonen Ville</a></a></td>
<td class=al>FIN</td>
<td class=ar>18</td>
<td class=ar>10</td>
<td class=ar>3</td>
<td class=ar>5</td>
<td class=ar>49</td>
<td class=al>&nbsp;:&nbsp;31</td>
<td class=ar>23</td>
</tr><tr><td class=br>16.</td>
<td class=bl><a href="stats.php?idpl=384&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D384%26x%3D-58%26p%3DHagerup%2520Frode%22%3EHagerup%20Frode%3C%2Fa%3E"><a href="stats.php?idpl=384&x=-58&p=Hagerup%20Frode">Hagerup Frode</a></a></td>
<td class=bl>NOR</td>
<td class=br>19</td>
<td class=br>10</td>
<td class=br>3</td>
<td class=br>6</td>
<td class=br>66</td>
<td class=bl>&nbsp;:&nbsp;51</td>
<td class=br>23</td>
</tr><tr><td class=ar>17.</td>
<td class=al><a href="stats.php?idpl=133&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D133%26x%3D-58%26p%3DPleikys%2520Audrius%22%3EPleikys%20Audrius%3C%2Fa%3E"><a href="stats.php?idpl=133&x=-58&p=Pleikys%20Audrius">Pleikys Audrius</a></a></td>
<td class=al>LTU</td>
<td class=ar>18</td>
<td class=ar>10</td>
<td class=ar>2</td>
<td class=ar>6</td>
<td class=ar>52</td>
<td class=al>&nbsp;:&nbsp;46</td>
<td class=ar>22</td>
</tr><tr><td class=br>18.</td>
<td class=bl><a href="stats.php?idpl=20&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D20%26x%3D-58%26p%3D%25C5%25BDernovojs%2520Aleksandrs%22%3E%C5%BDernovojs%20Aleksandrs%3C%2Fa%3E"><a href="stats.php?idpl=20&x=-58&p=%C5%BDernovojs%20Aleksandrs">�ernovojs Aleksandrs</a></a></td>
<td class=bl>LAT</td>
<td class=br>19</td>
<td class=br>8</td>
<td class=br>6</td>
<td class=br>5</td>
<td class=br>66</td>
<td class=bl>&nbsp;:&nbsp;45</td>
<td class=br>22</td>
</tr><tr><td class=ar>19.</td>
<td class=al><a href="stats.php?idpl=374&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D374%26x%3D-58%26p%3DKudrytsky%2520Dmytro%22%3EKudrytsky%20Dmytro%3C%2Fa%3E"><a href="stats.php?idpl=374&x=-58&p=Kudrytsky%20Dmytro">Kudrytsky Dmytro</a></a></td>
<td class=al>UKR</td>
<td class=ar>19</td>
<td class=ar>9</td>
<td class=ar>4</td>
<td class=ar>6</td>
<td class=ar>57</td>
<td class=al>&nbsp;:&nbsp;45</td>
<td class=ar>22</td>
</tr><tr><td class=br>20.</td>
<td class=bl><a href="stats.php?idpl=32&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D32%26x%3D-58%26p%3DSkarainis%2520Salvis%22%3ESkarainis%20Salvis%3C%2Fa%3E"><a href="stats.php?idpl=32&x=-58&p=Skarainis%20Salvis">Skarainis Salvis</a></a></td>
<td class=bl>LAT</td>
<td class=br>18</td>
<td class=br>9</td>
<td class=br>2</td>
<td class=br>7</td>
<td class=br>49</td>
<td class=bl>&nbsp;:&nbsp;46</td>
<td class=br>20</td>
</tr><tr><td class=ar>21.</td>
<td class=al><a href="stats.php?idpl=241&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D241%26x%3D-58%26p%3DPlesak%2520Pavel%22%3EPlesak%20Pavel%3C%2Fa%3E"><a href="stats.php?idpl=241&x=-58&p=Plesak%20Pavel">Plesak Pavel</a></a></td>
<td class=al>CZE</td>
<td class=ar>19</td>
<td class=ar>8</td>
<td class=ar>5</td>
<td class=ar>6</td>
<td class=ar>62</td>
<td class=al>&nbsp;:&nbsp;48</td>
<td class=ar>21</td>
</tr><tr><td class=br>22.</td>
<td class=bl><a href="stats.php?idpl=405&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D405%26x%3D-58%26p%3DPikl%2520Vaclav%22%3EPikl%20Vaclav%3C%2Fa%3E"><a href="stats.php?idpl=405&x=-58&p=Pikl%20Vaclav">Pikl Vaclav</a></a></td>
<td class=bl>CZE</td>
<td class=br>18</td>
<td class=br>8</td>
<td class=br>2</td>
<td class=br>8</td>
<td class=br>48</td>
<td class=bl>&nbsp;:&nbsp;40</td>
<td class=br>18</td>
</tr><tr><td class=ar>23.</td>
<td class=al><a href="stats.php?idpl=125&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D125%26x%3D-58%26p%3DThomas%2520Simon%22%3EThomas%20Simon%3C%2Fa%3E"><a href="stats.php?idpl=125&x=-58&p=Thomas%20Simon">Thomas Simon</a></a></td>
<td class=al>IRL</td>
<td class=ar>19</td>
<td class=ar>9</td>
<td class=ar>3</td>
<td class=ar>7</td>
<td class=ar>56</td>
<td class=al>&nbsp;:&nbsp;42</td>
<td class=ar>21</td>
</tr><tr><td class=br>24.</td>
<td class=bl><a href="stats.php?idpl=396&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D396%26x%3D-58%26p%3DHamdamov%2520Vafa%22%3EHamdamov%20Vafa%3C%2Fa%3E"><a href="stats.php?idpl=396&x=-58&p=Hamdamov%20Vafa">Hamdamov Vafa</a></a></td>
<td class=bl>EST</td>
<td class=br>18</td>
<td class=br>7</td>
<td class=br>3</td>
<td class=br>8</td>
<td class=br>31</td>
<td class=bl>&nbsp;:&nbsp;39</td>
<td class=br>17</td>
</tr><tr><td class=ar>25.</td>
<td class=al><a href="stats.php?idpl=413&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D413%26x%3D-58%26p%3DBruneske%2520Frank%22%3EBruneske%20Frank%3C%2Fa%3E"><a href="stats.php?idpl=413&x=-58&p=Bruneske%20Frank">Bruneske Frank</a></a></td>
<td class=al>GER</td>
<td class=ar>19</td>
<td class=ar>9</td>
<td class=ar>0</td>
<td class=ar>10</td>
<td class=ar>55</td>
<td class=al>&nbsp;:&nbsp;62</td>
<td class=ar>18</td>
</tr><tr><td class=br>26.</td>
<td class=bl><a href="stats.php?idpl=135&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D135%26x%3D-58%26p%3DMargolis%2520Mihail%22%3EMargolis%20Mihail%3C%2Fa%3E"><a href="stats.php?idpl=135&x=-58&p=Margolis%20Mihail">Margolis Mihail</a></a></td>
<td class=bl>ISR</td>
<td class=br>18</td>
<td class=br>5</td>
<td class=br>2</td>
<td class=br>11</td>
<td class=br>33</td>
<td class=bl>&nbsp;:&nbsp;64</td>
<td class=br>12</td>
</tr><tr><td class=ar>27.</td>
<td class=al><a href="stats.php?idpl=33&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D33%26x%3D-58%26p%3DKrasts%2520Sandis%22%3EKrasts%20Sandis%3C%2Fa%3E"><a href="stats.php?idpl=33&x=-58&p=Krasts%20Sandis">Krasts Sandis</a></a></td>
<td class=al>LAT</td>
<td class=ar>19</td>
<td class=ar>8</td>
<td class=ar>1</td>
<td class=ar>10</td>
<td class=ar>33</td>
<td class=al>&nbsp;:&nbsp;42</td>
<td class=ar>17</td>
</tr><tr><td class=br>28.</td>
<td class=bl><a href="stats.php?idpl=115&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D115%26x%3D-58%26p%3DShalomayev%2520Mykhaylo%22%3EShalomayev%20Mykhaylo%3C%2Fa%3E"><a href="stats.php?idpl=115&x=-58&p=Shalomayev%20Mykhaylo">Shalomayev Mykhaylo</a></a></td>
<td class=bl>UKR</td>
<td class=br>18</td>
<td class=br>5</td>
<td class=br>2</td>
<td class=br>11</td>
<td class=br>42</td>
<td class=bl>&nbsp;:&nbsp;55</td>
<td class=br>12</td>
</tr><tr><td class=ar>29.</td>
<td class=al><a href="stats.php?idpl=131&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D131%26x%3D-58%26p%3DVerbytskyy%2520Mykola%22%3EVerbytskyy%20Mykola%3C%2Fa%3E"><a href="stats.php?idpl=131&x=-58&p=Verbytskyy%20Mykola">Verbytskyy Mykola</a></a></td>
<td class=al>UKR</td>
<td class=ar>19</td>
<td class=ar>5</td>
<td class=ar>3</td>
<td class=ar>11</td>
<td class=ar>39</td>
<td class=al>&nbsp;:&nbsp;59</td>
<td class=ar>13</td>
</tr><tr><td class=br>30.</td>
<td class=bl><a href="stats.php?idpl=416&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D416%26x%3D-58%26p%3DPetuch%2520Hermann%22%3EPetuch%20Hermann%3C%2Fa%3E"><a href="stats.php?idpl=416&x=-58&p=Petuch%20Hermann">Petuch Hermann</a></a></td>
<td class=bl>GER</td>
<td class=br>18</td>
<td class=br>3</td>
<td class=br>4</td>
<td class=br>11</td>
<td class=br>44</td>
<td class=bl>&nbsp;:&nbsp;62</td>
<td class=br>10</td>
</tr><tr><td class=ar>31.</td>
<td class=al><a href="stats.php?idpl=202&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D202%26x%3D-58%26p%3DVoronov%2520Vladimir%22%3EVoronov%20Vladimir%3C%2Fa%3E"><a href="stats.php?idpl=202&x=-58&p=Voronov%20Vladimir">Voronov Vladimir</a></a></td>
<td class=al>LTU</td>
<td class=ar>18</td>
<td class=ar>3</td>
<td class=ar>2</td>
<td class=ar>13</td>
<td class=ar>31</td>
<td class=al>&nbsp;:&nbsp;61</td>
<td class=ar>8</td>
</tr><tr><td class=br>32.</td>
<td class=bl><a href="stats.php?idpl=162&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D162%26x%3D-58%26p%3DRemeika%2520Gintautas%22%3ERemeika%20Gintautas%3C%2Fa%3E"><a href="stats.php?idpl=162&x=-58&p=Remeika%20Gintautas">Remeika Gintautas</a></a></td>
<td class=bl>LTU</td>
<td class=br>19</td>
<td class=br>4</td>
<td class=br>0</td>
<td class=br>15</td>
<td class=br>30</td>
<td class=bl>&nbsp;:&nbsp;68</td>
<td class=br>8</td>
</tr><tr><td class=ar>33.</td>
<td class=al><a href="stats.php?idpl=143&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D143%26x%3D-58%26p%3DKvasnikov%2520Volodymyr%22%3EKvasnikov%20Volodymyr%3C%2Fa%3E"><a href="stats.php?idpl=143&x=-58&p=Kvasnikov%20Volodymyr">Kvasnikov Volodymyr</a></a></td>
<td class=al>UKR</td>
<td class=ar>18</td>
<td class=ar>4</td>
<td class=ar>0</td>
<td class=ar>14</td>
<td class=ar>32</td>
<td class=al>&nbsp;:&nbsp;72</td>
<td class=ar>8</td>
</tr><tr><td class=br>34.</td>
<td class=bl><a href="stats.php?idpl=414&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D414%26x%3D-58%26p%3DRompa%2520Eike%22%3ERompa%20Eike%3C%2Fa%3E"><a href="stats.php?idpl=414&x=-58&p=Rompa%20Eike">Rompa Eike</a></a></td>
<td class=bl>GER</td>
<td class=br>19</td>
<td class=br>3</td>
<td class=br>0</td>
<td class=br>16</td>
<td class=br>35</td>
<td class=bl>&nbsp;:&nbsp;74</td>
<td class=br>6</td>
</tr><tr><td class=ar>35.</td>
<td class=al><a href="stats.php?idpl=223&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D223%26x%3D-58%26p%3DZamiatin%2520Igor%22%3EZamiatin%20Igor%3C%2Fa%3E"><a href="stats.php?idpl=223&x=-58&p=Zamiatin%20Igor">Zamiatin Igor</a></a></td>
<td class=al>ISR</td>
<td class=ar>18</td>
<td class=ar>3</td>
<td class=ar>0</td>
<td class=ar>15</td>
<td class=ar>26</td>
<td class=al>&nbsp;:&nbsp;86</td>
<td class=ar>6</td>
</tr><tr><td class=br>36.</td>
<td class=bl><a href="stats.php?idpl=364&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D364%26x%3D-58%26p%3DBernhauser%2520Erik%22%3EBernhauser%20Erik%3C%2Fa%3E"><a href="stats.php?idpl=364&x=-58&p=Bernhauser%20Erik">Bernhauser Erik</a></a></td>
<td class=bl>SVK</td>
<td class=br>19</td>
<td class=br>2</td>
<td class=br>2</td>
<td class=br>15</td>
<td class=br>29</td>
<td class=bl>&nbsp;:&nbsp;83</td>
<td class=br>6</td>
</tr><tr><td class=ar>37.</td>
<td class=al><a href="stats.php?idpl=424&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D424%26x%3D-58%26p%3DUlfvensj%25C3%25B6%2520Lars%22%3EUlfvensj%C3%B6%20Lars%3C%2Fa%3E"><a href="stats.php?idpl=424&x=-58&p=Ulfvensj%C3%B6%20Lars">Ulfvensj� Lars</a></a></td>
<td class=al>SWE</td>
<td class=ar>18</td>
<td class=ar>2</td>
<td class=ar>1</td>
<td class=ar>15</td>
<td class=ar>26</td>
<td class=al>&nbsp;:&nbsp;58</td>
<td class=ar>5</td>
</tr><tr><td class=br>38.</td>
<td class=bl><a href="stats.php?idpl=154&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D154%26x%3D-58%26p%3DSteisunas%2520Julius%22%3ESteisunas%20Julius%3C%2Fa%3E"><a href="stats.php?idpl=154&x=-58&p=Steisunas%20Julius">Steisunas Julius</a></a></td>
<td class=bl>LTU</td>
<td class=br>19</td>
<td class=br>2</td>
<td class=br>2</td>
<td class=br>15</td>
<td class=br>23</td>
<td class=bl>&nbsp;:&nbsp;74</td>
<td class=br>6</td>
</tr><tr><td class=ar>39.</td>
<td class=al><a href="stats.php?idpl=152&x=-58&p=%3Ca%20href%3D%22stats.php%3Fidpl%3D152%26x%3D-58%26p%3DUlis%2520Tomas%22%3EUlis%20Tomas%3C%2Fa%3E"><a href="stats.php?idpl=152&x=-58&p=Ulis%20Tomas">Ulis Tomas</a></a></td>
<td class=al>LTU</td>
<td class=ar>19</td>
<td class=ar>0</td>
<td class=ar>1</td>
<td class=ar>18</td>
<td class=ar>21</td>
<td class=al>&nbsp;:&nbsp;100</td>
<td class=ar>1</td>
</tr></table></td></tr></table></div></p>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
