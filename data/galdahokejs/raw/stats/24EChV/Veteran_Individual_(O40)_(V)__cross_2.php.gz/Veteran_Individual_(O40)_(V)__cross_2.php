<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Veteran Individual (O40) (V) </title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Veteran_Individual_(O40)_(V)__list.php">Veteran Individual (O40) (V) </a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group Veteran 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>My Spivakovskyy</td><td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>8:1</td>
<td class=kW>8:0</td>
<td class=kW>6:0</td>
<td class=br>69:26</td><td class=br>+43</td>
<td class=bc>14 - 2 - 3</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Da Matysek</td><td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>12:0</td>
<td class=br>70:32</td><td class=br>+38</td>
<td class=bc>13 - 3 - 3</td>
<td class=br><strong>29</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Mi Cernoch</td><td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kL>1:3</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=br>58:23</td><td class=br>+35</td>
<td class=bc>12 - 5 - 2</td>
<td class=br><strong>29</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>He Steen</td><td class=kW>2:0</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=br>64:29</td><td class=br>+35</td>
<td class=bc>13 - 3 - 3</td>
<td class=br><strong>29</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Bj Axelsen</td><td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kW>6:3</td>
<td class=kW>7:0</td>
<td class=kW>3:2</td>
<td class=br>69:38</td><td class=br>+31</td>
<td class=bc>13 - 1 - 5</td>
<td class=br><strong>27</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ri Pedersen</td><td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kT>5:5</td>
<td class=kW>6:5</td>
<td class=kW>4:2</td>
<td class=kL>3:6</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kW>11:4</td>
<td class=br>76:54</td><td class=br>+22</td>
<td class=bc>13 - 1 - 5</td>
<td class=br><strong>27</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>He Nilsson</td><td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kL>1:5</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>7:2</td>
<td class=br>66:49</td><td class=br>+17</td>
<td class=bc>11 - 3 - 5</td>
<td class=br><strong>25</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Fr Hagerup</td><td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kT>5:5</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>3:7</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>8:2</td>
<td class=kW>4:2</td>
<td class=kW>10:0</td>
<td class=br>66:51</td><td class=br>+15</td>
<td class=bc>10 - 3 - 6</td>
<td class=br><strong>23</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Al �ernovojs</td><td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kL>5:6</td>
<td class=kL>2:3</td>
<td class=kW>7:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>7:2</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=br>66:45</td><td class=br>+21</td>
<td class=bc>8 - 6 - 5</td>
<td class=br><strong>22</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Dm Kudrytsky</td><td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>6:3</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=br>57:45</td><td class=br>+12</td>
<td class=bc>9 - 4 - 6</td>
<td class=br><strong>22</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Pa Plesak</td><td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kW>6:3</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>7:1</td>
<td class=br>62:48</td><td class=br>+14</td>
<td class=bc>8 - 5 - 6</td>
<td class=br><strong>21</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Si Thomas</td><td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=br>56:42</td><td class=br>+14</td>
<td class=bc>9 - 3 - 7</td>
<td class=br><strong>21</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Fr Bruneske</td><td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kW>2:1</td>
<td class=kL>2:7</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=br>55:62</td><td class=br>-7</td>
<td class=bc>9 - 0 - 10</td>
<td class=br><strong>18</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Sa Krasts</td><td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=br>33:42</td><td class=br>-9</td>
<td class=bc>8 - 1 - 10</td>
<td class=br><strong>17</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>My Verbytskyy</td><td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>7:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=br>39:59</td><td class=br>-20</td>
<td class=bc>5 - 3 - 11</td>
<td class=br><strong>13</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Gi Remeika</td><td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>3:6</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=br>30:68</td><td class=br>-38</td>
<td class=bc>4 - 0 - 15</td>
<td class=br><strong>8</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ei Rompa</td><td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>1:8</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>7:2</td>
<td class=br>35:74</td><td class=br>-39</td>
<td class=bc>3 - 0 - 16</td>
<td class=br><strong>6</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Er Bernhauser</td><td class=kL>1:8</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kL>2:6</td>
<td class=kL>3:6</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>2:8</td>
<td class=kT>1:1</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=br>29:83</td><td class=br>-54</td>
<td class=bc>2 - 2 - 15</td>
<td class=br><strong>6</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Ju Steisunas</td><td class=kL>0:8</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>23:74</td><td class=br>-51</td>
<td class=bc>2 - 2 - 15</td>
<td class=br><strong>6</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>To Ulis</td><td class=kL>0:6</td>
<td class=kL>0:12</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>4:11</td>
<td class=kL>2:7</td>
<td class=kL>0:10</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>3:4</td>
<td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>2:7</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>21:100</td><td class=br>-79</td>
<td class=bc>0 - 1 - 18</td>
<td class=br><strong>1</strong></td><td class=d>20.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Bruneske Frank</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Matysek Daniel</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=bl>Cernoch Miroslav</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kudrytsky Dmytro</td><td class=bc>-</td><td class=blW>Hagerup Frode</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pedersen Richard</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Spivakovskyy Mykhaylo</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Nilsson Henrik</td><td class=bc>-</td><td class=bl>Steen Herman</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=bl>Cernoch Miroslav</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Hagerup Frode</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kudrytsky Dmytro</td><td class=bc>-</td><td class=blW>Spivakovskyy Mykhaylo</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pedersen Richard</td><td class=bc>-</td><td class=blW>Steen Herman</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Cernoch Miroslav</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Bruneske Frank</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Matysek Daniel</td><td class=bc>-</td><td class=bl>Hagerup Frode</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Spivakovskyy Mykhaylo</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Steen Herman</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kudrytsky Dmytro</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Pedersen Richard</td><td class=bc>-</td><td class=blW>Nilsson Henrik</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Cernoch Miroslav</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Hagerup Frode</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=blW>Spivakovskyy Mykhaylo</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Steen Herman</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Nilsson Henrik</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Kudrytsky Dmytro</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=blW>Cernoch Miroslav</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Hagerup Frode</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Spivakovskyy Mykhaylo</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Bruneske Frank</td><td class=bc>-</td><td class=bl>Steen Herman</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Matysek Daniel</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Nilsson Henrik</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Verbytskyy Mykola</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Pedersen Richard</td><td class=bc>4 : 11</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Hagerup Frode</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Spivakovskyy Mykhaylo</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Steen Herman</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=blW>Nilsson Henrik</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Matysek Daniel</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Pedersen Richard</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=bl>Kudrytsky Dmytro</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Hagerup Frode</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=blW>Spivakovskyy Mykhaylo</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Steen Herman</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Bernhauser Erik</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Nilsson Henrik</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=blW>Pedersen Richard</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Matysek Daniel</td><td class=bc>-</td><td class=bl>Kudrytsky Dmytro</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Steisunas Julius</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Hagerup Frode</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Spivakovskyy Mykhaylo</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Steen Herman</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Nilsson Henrik</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Verbytskyy Mykola</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pedersen Richard</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Kudrytsky Dmytro</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Bruneske Frank</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Steen Herman</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Bernhauser Erik</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Nilsson Henrik</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Pedersen Richard</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Kudrytsky Dmytro</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Bruneske Frank</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=blW>Steen Herman</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Hagerup Frode</td><td class=bc>-</td><td class=bl>Nilsson Henrik</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Verbytskyy Mykola</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=blW>Pedersen Richard</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Kudrytsky Dmytro</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Matysek Daniel</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=bl>Nilsson Henrik</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=bl>Pedersen Richard</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Kudrytsky Dmytro</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Matysek Daniel</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Nilsson Henrik</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=bl>Pedersen Richard</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Kudrytsky Dmytro</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Hagerup Frode</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Matysek Daniel</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Bruneske Frank</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Axelsen Bjarne</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Nilsson Henrik</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Pedersen Richard</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Steen Herman</td><td class=bc>-</td><td class=blW>Kudrytsky Dmytro</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Hagerup Frode</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Matysek Daniel</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=blW>Axelsen Bjarne</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Pedersen Richard</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Nilsson Henrik</td><td class=bc>-</td><td class=blW>Kudrytsky Dmytro</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Matysek Daniel</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Bruneske Frank</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Axelsen Bjarne</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Pedersen Richard</td><td class=bc>-</td><td class=bl>Kudrytsky Dmytro</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Nilsson Henrik</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Steisunas Julius</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Steen Herman</td><td class=bc>-</td><td class=blW>Matysek Daniel</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>Axelsen Bjarne</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Kudrytsky Dmytro</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pedersen Richard</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Nilsson Henrik</td><td class=bc>-</td><td class=blW>Matysek Daniel</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Bruneske Frank</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>Rompa Eike</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Hagerup Frode</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Kudrytsky Dmytro</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pedersen Richard</td><td class=bc>-</td><td class=bl>Matysek Daniel</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Bruneske Frank</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Nilsson Henrik</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Cernoch Miroslav</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Matysek Daniel</td><td class=bc>0 : 12</tr></td>
<tr><td class=brW>Kudrytsky Dmytro</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Pedersen Richard</td><td class=bc>-</td><td class=blW>Axelsen Bjarne</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Nilsson Henrik</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Steen Herman</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=blW>Cernoch Miroslav</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Matysek Daniel</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Axelsen Bjarne</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kudrytsky Dmytro</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pedersen Richard</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Nilsson Henrik</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Cernoch Miroslav</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=bl>Hagerup Frode</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Matysek Daniel</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Axelsen Bjarne</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Rompa Eike</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Kudrytsky Dmytro</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Pedersen Richard</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Cernoch Miroslav</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Nilsson Henrik</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Hagerup Frode</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=blW>Axelsen Bjarne</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Rompa Eike</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kudrytsky Dmytro</td><td class=bc>-</td><td class=bl>Cernoch Miroslav</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pedersen Richard</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Hagerup Frode</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Nilsson Henrik</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Spivakovskyy Mykhaylo</td><td class=bc>1 : 8</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
