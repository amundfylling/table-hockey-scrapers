<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Women Individual (W)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Women_Individual_(W)_list.php">Final Ranking</a></span></h2></div></div></div></div><h3 align="right">Women Individual (W)&nbsp;&nbsp;</h3>
<p><div align="center">
<p class=v><br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0 class="rnk">
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">M</th>
<th align="center">+</th>
<th align="center">=</th>
<th align="center">-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">P</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al><a href="stats.php?idpl=113&x=-57&p=Ivantsova%20Hanna">Ivantsova Hanna</a></td>
<td class=al>UKR</td>
<td class=ar>28</td>
<td class=ar>21</td>
<td class=ar>2</td>
<td class=ar>5</td>
<td class=ar>86</td>
<td class=al>&nbsp;:&nbsp;35</td>
<td class=ar>44</td>
</tr><tr><td class=br>2.</td>
<td class=bl><a href="stats.php?idpl=201&x=-57&p=R%C4%81cen%C4%81ja%20El%C4%93na">R�cen�ja El�na</a></td>
<td class=bl>LAT</td>
<td class=br>31</td>
<td class=br>18</td>
<td class=br>1</td>
<td class=br>12</td>
<td class=br>83</td>
<td class=bl>&nbsp;:&nbsp;66</td>
<td class=br>37</td>
</tr><tr><td class=ar>3.</td>
<td class=al><a href="stats.php?idpl=66&x=-57&p=Hrustaljova%20Darja">Hrustaljova Darja</a></td>
<td class=al>EST</td>
<td class=ar>25</td>
<td class=ar>19</td>
<td class=ar>1</td>
<td class=ar>5</td>
<td class=ar>86</td>
<td class=al>&nbsp;:&nbsp;31</td>
<td class=ar>39</td>
</tr><tr><td class=br>4.</td>
<td class=bl><a href="stats.php?idpl=112&x=-57&p=Saveljeva%20Maria">Saveljeva Maria</a></td>
<td class=bl>EST</td>
<td class=br>25</td>
<td class=br>14</td>
<td class=br>3</td>
<td class=br>8</td>
<td class=br>88</td>
<td class=bl>&nbsp;:&nbsp;45</td>
<td class=br>31</td>
</tr><tr><td class=ar>5.</td>
<td class=al><a href="stats.php?idpl=184&x=-57&p=Kamzola%20Laima">Kamzola Laima</a></td>
<td class=al>LAT</td>
<td class=ar>19</td>
<td class=ar>11</td>
<td class=ar>0</td>
<td class=ar>8</td>
<td class=ar>57</td>
<td class=al>&nbsp;:&nbsp;38</td>
<td class=ar>22</td>
</tr><tr><td class=br>6.</td>
<td class=bl><a href="stats.php?idpl=10001&x=-57&p=%C4%80bele%20Margarita">�bele Margarita</a></td>
<td class=bl>LAT</td>
<td class=br>16</td>
<td class=br>7</td>
<td class=br>1</td>
<td class=br>8</td>
<td class=br>40</td>
<td class=bl>&nbsp;:&nbsp;42</td>
<td class=br>15</td>
</tr><tr><td class=ar>7.</td>
<td class=al><a href="stats.php?idpl=24&x=-57&p=%C4%BBiha%C4%8Dova%20Katr%C4%ABna">�iha�ova Katr�na</a></td>
<td class=al>LAT</td>
<td class=ar>16</td>
<td class=ar>7</td>
<td class=ar>0</td>
<td class=ar>9</td>
<td class=ar>44</td>
<td class=al>&nbsp;:&nbsp;44</td>
<td class=ar>14</td>
</tr><tr><td class=br>8.</td>
<td class=bl><a href="stats.php?idpl=226&x=-57&p=Pirumshoieva%20Karyna">Pirumshoieva Karyna</a></td>
<td class=bl>UKR</td>
<td class=br>16</td>
<td class=br>5</td>
<td class=br>1</td>
<td class=br>10</td>
<td class=br>23</td>
<td class=bl>&nbsp;:&nbsp;41</td>
<td class=br>11</td>
</tr><tr><td class=ar>9.</td>
<td class=al><a href="stats.php?idpl=139&x=-57&p=Kvasnikova%20Polina">Kvasnikova Polina</a></td>
<td class=al>UKR</td>
<td class=ar>12</td>
<td class=ar>4</td>
<td class=ar>1</td>
<td class=ar>7</td>
<td class=ar>23</td>
<td class=al>&nbsp;:&nbsp;25</td>
<td class=ar>9</td>
</tr><tr><td class=br>10.</td>
<td class=bl><a href="stats.php?idpl=75&x=-57&p=Bezdel%C4%ABga%20L%C4%81sma">Bezdel�ga L�sma</a></td>
<td class=bl>LAT</td>
<td class=br>12</td>
<td class=br>4</td>
<td class=br>0</td>
<td class=br>8</td>
<td class=br>31</td>
<td class=bl>&nbsp;:&nbsp;35</td>
<td class=br>8</td>
</tr><tr><td class=ar>11.</td>
<td class=al><a href="stats.php?idpl=433&x=-57&p=P%C3%B6ssl%20Susanna">P�ssl Susanna</a></td>
<td class=al>SWE</td>
<td class=ar>12</td>
<td class=ar>2</td>
<td class=ar>0</td>
<td class=ar>10</td>
<td class=ar>20</td>
<td class=al>&nbsp;:&nbsp;61</td>
<td class=ar>4</td>
</tr><tr><td class=br>12.</td>
<td class=bl><a href="stats.php?idpl=428&x=-57&p=Israelsson%20Anna-Maria">Israelsson Anna-Maria</a></td>
<td class=bl>SWE</td>
<td class=br>12</td>
<td class=br>1</td>
<td class=br>0</td>
<td class=br>11</td>
<td class=br>17</td>
<td class=bl>&nbsp;:&nbsp;75</td>
<td class=br>2</td>
</tr><tr><td class=ar>13.</td>
<td class=al><a href="stats.php?idpl=438&x=-57&p=Ulfvensjo%20Vanja">Ulfvensjo Vanja</a></td>
<td class=al>SWE</td>
<td class=ar>12</td>
<td class=ar>0</td>
<td class=ar>0</td>
<td class=ar>12</td>
<td class=ar>0</td>
<td class=al>&nbsp;:&nbsp;60</td>
<td class=ar>0</td>
</tr></table></td></tr></table></div></p>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
