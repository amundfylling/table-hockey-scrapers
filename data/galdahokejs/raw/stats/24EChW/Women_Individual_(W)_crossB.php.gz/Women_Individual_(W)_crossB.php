<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Women Individual (W)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Women_Individual_(W)_list.php">Women Individual (W)</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group Women</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=66&x=-57&p=Da%20Hrustaljova">Da Hrustaljova</a></td><td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>10:1</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=br>53:13</td><td class=br>+40</td>
<td class=bc>10 - 1 - 1</td>
<td class=br><strong>21</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=113&x=-57&p=Ha%20Ivantsova">Ha Ivantsova</a></td><td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kL>0:3</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>8:0</td>
<td class=kW>9:0</td>
<td class=kW>5:0</td>
<td class=br>45:8</td><td class=br>+37</td>
<td class=bc>9 - 2 - 1</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=112&x=-57&p=Ma%20Saveljeva">Ma Saveljeva</a></td><td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kW>8:0</td>
<td class=kW>9:1</td>
<td class=kW>5:0</td>
<td class=br>55:18</td><td class=br>+37</td>
<td class=bc>8 - 3 - 1</td>
<td class=br><strong>19</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=201&x=-57&p=El%20R%C4%81cen%C4%81ja">El R�cen�ja</a></td><td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>3:6</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>7:3</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=br>42:23</td><td class=br>+19</td>
<td class=bc>8 - 1 - 3</td>
<td class=br><strong>17</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=184&x=-57&p=La%20Kamzola">La Kamzola</a></td><td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=br>39:20</td><td class=br>+19</td>
<td class=bc>8 - 0 - 4</td>
<td class=br><strong>16</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=10001&x=-57&p=Marg%20%C4%80bele">Marg �bele</a></td><td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kL>0:6</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>10:1</td>
<td class=kW>5:0</td>
<td class=br>37:24</td><td class=br>+13</td>
<td class=bc>7 - 1 - 4</td>
<td class=br><strong>15</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=24&x=-57&p=Ka%20%C4%BBiha%C4%8Dova">Ka �iha�ova</a></td><td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>6:4</td>
<td class=kW>5:0</td>
<td class=br>40:31</td><td class=br>+9</td>
<td class=bc>7 - 0 - 5</td>
<td class=br><strong>14</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=226&x=-57&p=Ka%20Pirumshoieva">Ka Pirumshoieva</a></td><td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>20:29</td><td class=br>-9</td>
<td class=bc>5 - 1 - 6</td>
<td class=br><strong>11</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=139&x=-57&p=Po%20Kvasnikova">Po Kvasnikova</a></td><td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=br>23:25</td><td class=br>-2</td>
<td class=bc>4 - 1 - 7</td>
<td class=br><strong>9</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=75&x=-57&p=L%C4%81%20Bezdel%C4%ABga">L� Bezdel�ga</a></td><td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>8:2</td>
<td class=kW>5:0</td>
<td class=br>31:35</td><td class=br>-4</td>
<td class=bc>4 - 0 - 8</td>
<td class=br><strong>8</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=433&x=-57&p=Su%20P%C3%B6ssl">Su P�ssl</a></td><td class=kL>1:10</td>
<td class=kL>0:8</td>
<td class=kL>0:8</td>
<td class=kL>3:7</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>20:61</td><td class=br>-41</td>
<td class=bc>2 - 0 - 10</td>
<td class=br><strong>4</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=428&x=-57&p=An%20Israelsson">An Israelsson</a></td><td class=kL>2:7</td>
<td class=kL>0:9</td>
<td class=kL>1:9</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>1:10</td>
<td class=kL>4:6</td>
<td class=kL>1:2</td>
<td class=kL>0:7</td>
<td class=kL>2:8</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=br>17:75</td><td class=br>-58</td>
<td class=bc>1 - 0 - 11</td>
<td class=br><strong>2</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="stats.php?idpl=438&x=-57&p=Va%20Ulfvensjo">Va Ulfvensjo</a></td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=br>0:60</td><td class=br>-60</td>
<td class=bc>0 - 0 - 12</td>
<td class=br><strong>0</strong></td><td class=d>13.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ulfvensjo Vanja</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=blW>Saveljeva Maria</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Kamzola Laima</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=blW>Ivantsova Hanna</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ulfvensjo Vanja</td><td class=bc>-</td><td class=blW>Saveljeva Maria</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=blW>Ivantsova Hanna</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Kamzola Laima</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kvasnikova Polina</td><td class=bc>-</td><td class=bl>Israelsson Anna-Maria</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ulfvensjo Vanja</td><td class=bc>-</td><td class=blW>Ivantsova Hanna</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Israelsson Anna-Maria</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kamzola Laima</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Saveljeva Maria</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ulfvensjo Vanja</td><td class=bc>-</td><td class=blW>Israelsson Anna-Maria</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Kvasnikova Polina</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=blW>Ivantsova Hanna</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Saveljeva Maria</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Israelsson Anna-Maria</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ulfvensjo Vanja</td><td class=bc>-</td><td class=blW>Kvasnikova Polina</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Kamzola Laima</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>P�ssl Susanna</td><td class=bc>-</td><td class=bl>Israelsson Anna-Maria</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Saveljeva Maria</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Kvasnikova Polina</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Kamzola Laima</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ulfvensjo Vanja</td><td class=bc>-</td><td class=blW>Pirumshoieva Karyna</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Israelsson Anna-Maria</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=blW>Kvasnikova Polina</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Saveljeva Maria</td><td class=bc>-</td><td class=bl>Kamzola Laima</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Israelsson Anna-Maria</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>1 : 10</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Kvasnikova Polina</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Kamzola Laima</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=blW>Pirumshoieva Karyna</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Saveljeva Maria</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Ulfvensjo Vanja</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Kvasnikova Polina</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Israelsson Anna-Maria</td><td class=bc>-</td><td class=blW>Kamzola Laima</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>P�ssl Susanna</td><td class=bc>-</td><td class=bl>Ulfvensjo Vanja</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Saveljeva Maria</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=blW>Kamzola Laima</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Israelsson Anna-Maria</td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Ulfvensjo Vanja</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>1 : 10</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Kamzola Laima</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kvasnikova Polina</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Ulfvensjo Vanja</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Israelsson Anna-Maria</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kamzola Laima</td><td class=bc>-</td><td class=bl>Ulfvensjo Vanja</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Israelsson Anna-Maria</td><td class=bc>-</td><td class=blW>Saveljeva Maria</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>7 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Ulfvensjo Vanja</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kamzola Laima</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=blW>Saveljeva Maria</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Israelsson Anna-Maria</td><td class=bc>-</td><td class=blW>Ivantsova Hanna</td><td class=bc>0 : 9</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</table></div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
