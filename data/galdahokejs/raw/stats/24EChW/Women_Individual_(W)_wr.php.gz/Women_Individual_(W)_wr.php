<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Women Individual (W)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Women_Individual_(W)_list.php">Women Individual (W)</a></span></h2></div></div></div></div><h3 align="right">13 Participants&nbsp;&nbsp;</h3>
<p><div align="center">
<a href="Women_Individual_(W)_ranking.php">Final Rank.</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="Women_Individual_(W)_list.php">List</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="Women_Individual_(W)_crossB.php">Basic Groups</a>&nbsp;&nbsp;
<a href="Women_Individual_(W)_cross_1.php">Women</a>&nbsp;&nbsp;<a href="Women_Individual_(W)_playoff.php">Play-Off</a>&nbsp;&nbsp;&nbsp;<a href="Women_Individual_(W)_stats.php">Statistics</a>&nbsp;&nbsp;&nbsp;<a href="Women_Individual_(W)_tour_off.php">Offence</a>&nbsp;&nbsp;&nbsp;<a href="Women_Individual_(W)_tour_def.php">Defence</a>&nbsp;&nbsp;&nbsp;<a href="Women_Individual_(W)_inter.php">International</a>&nbsp;&nbsp;&nbsp;<table class="part_bck" align="center">
<tr class="pl"><td class="pnu">1)</td>
<td class="name">&nbsp;<a href="stats.php?idpl=113&x=-57&p=Hanna%20Ivantsova">Hanna Ivantsova</a>&nbsp;</td><td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=664934">64</a>&nbsp;</td>
<td class="bg"><a href="Women_Individual_(W)_cross_1.php">Women</a></td><td class="bgr">2.</td><td class="bgp">20 pts</td><td class="bgs">45:8</td><td class="fg"><a href="Women_Individual_(W)_ranking.php">1</a></td><td class="fg"><a href="Women_Individual_(W)_playoff.php">p-o</a></td></tr><tr class="pl"><td class="pnu">2)</td>
<td class="name">&nbsp;<a href="stats.php?idpl=66&x=-57&p=Darja%20Hrustaljova">Darja Hrustaljova</a>&nbsp;</td><td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=672220">73</a>&nbsp;</td>
<td class="bg"><a href="Women_Individual_(W)_cross_1.php">Women</a></td><td class="bgr">1.</td><td class="bgp">21 pts</td><td class="bgs">53:13</td><td class="fg"><a href="Women_Individual_(W)_ranking.php">3</a></td><td class="fg"><a href="Women_Individual_(W)_playoff.php">p-o</a></td></tr><tr class="pl"><td class="pnu">3)</td>
<td class="name">&nbsp;<a href="stats.php?idpl=112&x=-57&p=Maria%20Saveljeva">Maria Saveljeva</a>&nbsp;</td><td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=90056">79</a>&nbsp;</td>
<td class="bg"><a href="Women_Individual_(W)_cross_1.php">Women</a></td><td class="bgr">3.</td><td class="bgp">19 pts</td><td class="bgs">55:18</td><td class="fg"><a href="Women_Individual_(W)_ranking.php">4</a></td><td class="fg"><a href="Women_Individual_(W)_playoff.php">p-o</a></td></tr><tr class="pl"><td class="pnu">4)</td>
<td class="name">&nbsp;<a href="stats.php?idpl=201&x=-57&p=El%C4%93na%20R%C4%81cen%C4%81ja">El�na R�cen�ja</a>&nbsp;</td><td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=657459">165</a>&nbsp;</td>
<td class="bg"><a href="Women_Individual_(W)_cross_1.php">Women</a></td><td class="bgr">4.</td><td class="bgp">17 pts</td><td class="bgs">42:23</td><td class="fg"><a href="Women_Individual_(W)_ranking.php">2</a></td><td class="fg"><a href="Women_Individual_(W)_playoff.php">p-o</a></td></tr><tr class="pl"><td class="pnu">5)</td>
<td class="name">&nbsp;<a href="stats.php?idpl=139&x=-57&p=Polina%20Kvasnikova">Polina Kvasnikova</a>&nbsp;</td><td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=673206">225</a>&nbsp;</td>
<td class="bg"><a href="Women_Individual_(W)_cross_1.php">Women</a></td><td class="bgr">9.</td><td class="bgp">9 pts</td><td class="bgs">23:25</td><td class="fg"><a href="Women_Individual_(W)_ranking.php">9</a></td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="pnu">6)</td>
<td class="name">&nbsp;<a href="stats.php?idpl=184&x=-57&p=Laima%20Kamzola">Laima Kamzola</a>&nbsp;</td><td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=654847">259</a>&nbsp;</td>
<td class="bg"><a href="Women_Individual_(W)_cross_1.php">Women</a></td><td class="bgr">5.</td><td class="bgp">16 pts</td><td class="bgs">39:20</td><td class="fg"><a href="Women_Individual_(W)_ranking.php">5</a></td><td class="fg"><a href="Women_Individual_(W)_playoff.php">p-o</a></td></tr><tr class="pl"><td class="pnu">7)</td>
<td class="name">&nbsp;<a href="stats.php?idpl=10001&x=-57&p=Margarita%20%C4%80bele">Margarita �bele</a>&nbsp;</td><td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=668966">389</a>&nbsp;</td>
<td class="bg"><a href="Women_Individual_(W)_cross_1.php">Women</a></td><td class="bgr">6.</td><td class="bgp">15 pts</td><td class="bgs">37:24</td><td class="fg"><a href="Women_Individual_(W)_ranking.php">6</a></td><td class="fg"><a href="Women_Individual_(W)_playoff.php">p-o</a></td></tr><tr class="pl"><td class="pnu">8)</td>
<td class="name">&nbsp;<a href="stats.php?idpl=24&x=-57&p=Katr%C4%ABna%20%C4%BBiha%C4%8Dova">Katr�na �iha�ova</a>&nbsp;</td><td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=670242">440</a>&nbsp;</td>
<td class="bg"><a href="Women_Individual_(W)_cross_1.php">Women</a></td><td class="bgr">7.</td><td class="bgp">14 pts</td><td class="bgs">40:31</td><td class="fg"><a href="Women_Individual_(W)_ranking.php">7</a></td><td class="fg"><a href="Women_Individual_(W)_playoff.php">p-o</a></td></tr><tr class="pl"><td class="pnu">9)</td>
<td class="name">&nbsp;<a href="stats.php?idpl=226&x=-57&p=Karyna%20Pirumshoieva">Karyna Pirumshoieva</a>&nbsp;</td><td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=672918">459</a>&nbsp;</td>
<td class="bg"><a href="Women_Individual_(W)_cross_1.php">Women</a></td><td class="bgr">8.</td><td class="bgp">11 pts</td><td class="bgs">20:29</td><td class="fg"><a href="Women_Individual_(W)_ranking.php">8</a></td><td class="fg"><a href="Women_Individual_(W)_playoff.php">p-o</a></td></tr><tr class="pl"><td class="pnu">10)</td>
<td class="name">&nbsp;<a href="stats.php?idpl=438&x=-57&p=Vanja%20Ulfvensjo">Vanja Ulfvensjo</a>&nbsp;</td><td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=673127">561</a>&nbsp;</td>
<td class="bg"><a href="Women_Individual_(W)_cross_1.php">Women</a></td><td class="bgr">13.</td><td class="bgp">0 pts</td><td class="bgs">0:60</td><td class="fg"><a href="Women_Individual_(W)_ranking.php">13</a></td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="pnu">11)</td>
<td class="name">&nbsp;<a href="stats.php?idpl=75&x=-57&p=L%C4%81sma%20Bezdel%C4%ABga">L�sma Bezdel�ga</a>&nbsp;</td><td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=673878">589</a>&nbsp;</td>
<td class="bg"><a href="Women_Individual_(W)_cross_1.php">Women</a></td><td class="bgr">10.</td><td class="bgp">8 pts</td><td class="bgs">31:35</td><td class="fg"><a href="Women_Individual_(W)_ranking.php">10</a></td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="pnu">12)</td>
<td class="name">&nbsp;<a href="stats.php?idpl=433&x=-57&p=Susanna%20P%C3%B6ssl">Susanna P�ssl</a>&nbsp;</td><td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=661800">654</a>&nbsp;</td>
<td class="bg"><a href="Women_Individual_(W)_cross_1.php">Women</a></td><td class="bgr">11.</td><td class="bgp">4 pts</td><td class="bgs">20:61</td><td class="fg"><a href="Women_Individual_(W)_ranking.php">11</a></td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="pnu">13)</td>
<td class="name">&nbsp;<a href="stats.php?idpl=428&x=-57&p=Anna-Maria%20Israelsson">Anna-Maria Israelsson</a>&nbsp;</td><td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=672575">1769</a>&nbsp;</td>
<td class="bg"><a href="Women_Individual_(W)_cross_1.php">Women</a></td><td class="bgr">12.</td><td class="bgp">2 pts</td><td class="bgs">17:75</td><td class="fg"><a href="Women_Individual_(W)_ranking.php">12</a></td><td class="fg">&nbsp;</td></tr></table></td></tr>
</table></div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
