<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Amatieru Liga 1.posms</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../25AL1/Amatieru_Liga_1.posms_index.php">Amatieru Liga 1.posms, 25. October 2025</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group AL A grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>An Kova��uks</td><td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>8:0</td>
<td class=kW>11:0</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=kW>5:1</td>
<td class=kW>12:0</td>
<td class=kW>12:0</td>
<td class=kW>12:0</td>
<td class=br>116:18</td><td class=br>+98</td>
<td class=bc>16 - 1 - 0</td>
<td class=br><strong>33</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Br Gor�anovs</td><td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>12:0</td>
<td class=kW>5:0</td>
<td class=kW>13:1</td>
<td class=kW>9:0</td>
<td class=kW>12:1</td>
<td class=kW>8:1</td>
<td class=kW>10:0</td>
<td class=kW>6:0</td>
<td class=kW>16:0</td>
<td class=kW>13:0</td>
<td class=br>134:17</td><td class=br>+117</td>
<td class=bc>15 - 2 - 0</td>
<td class=br><strong>32</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>B</td><td class=d>3.</td><td class=kt>Al Puri��</td><td class=kL>3:5</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>9:2</td>
<td class=kW>10:0</td>
<td class=kW>8:0</td>
<td class=kW>7:0</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=kW>10:0</td>
<td class=kW>7:0</td>
<td class=kW>11:0</td>
<td class=kW>12:0</td>
<td class=br>112:22</td><td class=br>+90</td>
<td class=bc>13 - 2 - 2</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>B</td><td class=d>4.</td><td class=kt>Ed Liepi��</td><td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kW>6:4</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>7:0</td>
<td class=br>69:23</td><td class=br>+46</td>
<td class=bc>13 - 0 - 4</td>
<td class=br><strong>26</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt>Ma P�tersons</td><td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>0:0</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=kW>8:0</td>
<td class=br>65:22</td><td class=br>+43</td>
<td class=bc>12 - 2 - 3</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt>Ha V�veris</td><td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>8:0</td>
<td class=kW>8:1</td>
<td class=kW>5:1</td>
<td class=kW>12:0</td>
<td class=kW>11:0</td>
<td class=kW>11:0</td>
<td class=kW>13:0</td>
<td class=br>94:32</td><td class=br>+62</td>
<td class=bc>11 - 2 - 4</td>
<td class=br><strong>24</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Ed Garan�s</td><td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kT>0:0</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kW>13:0</td>
<td class=kW>9:0</td>
<td class=br>66:20</td><td class=br>+46</td>
<td class=bc>8 - 5 - 4</td>
<td class=br><strong>21</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Re Masulis</td><td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kT>0:0</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=br>30:28</td><td class=br>+2</td>
<td class=bc>9 - 3 - 5</td>
<td class=br><strong>21</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ra R�ders</td><td class=kL>1:5</td>
<td class=kL>0:12</td>
<td class=kL>2:9</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>5:4</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>6:0</td>
<td class=kW>10:2</td>
<td class=kW>8:0</td>
<td class=br>60:49</td><td class=br>+11</td>
<td class=bc>8 - 3 - 6</td>
<td class=br><strong>19</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Re Apa�ko</td><td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>0:10</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=br>26:56</td><td class=br>-30</td>
<td class=bc>6 - 2 - 9</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>La Ern�teina</td><td class=kL>0:11</td>
<td class=kL>1:13</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>0:1</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>0:1</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=br>22:64</td><td class=br>-42</td>
<td class=bc>5 - 2 - 10</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ev L�sis</td><td class=kL>0:5</td>
<td class=kL>0:9</td>
<td class=kL>0:7</td>
<td class=kL>4:6</td>
<td class=kL>1:5</td>
<td class=kL>0:8</td>
<td class=kT>0:0</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kW>2:0</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kL>0:2</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=br>27:55</td><td class=br>-28</td>
<td class=bc>5 - 2 - 10</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ma Kudi��</td><td class=kL>0:6</td>
<td class=kL>1:12</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>7:3</td>
<td class=kW>4:0</td>
<td class=br>26:63</td><td class=br>-37</td>
<td class=bc>5 - 1 - 11</td>
<td class=br><strong>11</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Pl Solovjovs</td><td class=kL>0:8</td>
<td class=kL>1:8</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=br>20:68</td><td class=br>-48</td>
<td class=bc>3 - 3 - 11</td>
<td class=br><strong>9</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>Re Holod�aks</td><td class=kL>1:5</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>0:12</td>
<td class=kL>0:5</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=br>17:79</td><td class=br>-62</td>
<td class=bc>3 - 1 - 13</td>
<td class=br><strong>7</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt>El Vasi�jeva</td><td class=kL>0:12</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>0:11</td>
<td class=kL>0:8</td>
<td class=kT>0:0</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=br>8:70</td><td class=br>-62</td>
<td class=bc>2 - 3 - 12</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>C</td><td class=d>17.</td><td class=kt>Ar Voitkevi�s</td><td class=kL>0:12</td>
<td class=kL>0:16</td>
<td class=kL>0:11</td>
<td class=kL>2:4</td>
<td class=kL>0:7</td>
<td class=kL>0:11</td>
<td class=kL>0:13</td>
<td class=kL>0:3</td>
<td class=kL>2:10</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>0:7</td>
<td class=kL>3:7</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=br>16:116</td><td class=br>-100</td>
<td class=bc>0 - 2 - 15</td>
<td class=br><strong>2</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>C</td><td class=d>18.</td><td class=kt>Ne Giri�a</td><td class=kL>0:12</td>
<td class=kL>0:13</td>
<td class=kL>0:12</td>
<td class=kL>0:7</td>
<td class=kL>0:8</td>
<td class=kL>0:13</td>
<td class=kL>0:9</td>
<td class=kL>1:3</td>
<td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=br>5:111</td><td class=br>-106</td>
<td class=bc>0 - 2 - 15</td>
<td class=br><strong>2</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Re Apa�ko</td><td class=bc>-</td><td class=bl>Ar Voitkevi�s</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>La Ern�teina</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ed Garan�s</td><td class=bc>-</td><td class=bl>El Vasi�jeva</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=bl>Pl Solovjovs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>12 : 0</tr></td>
<tr><td class=br>Re Holod�aks</td><td class=bc>-</td><td class=blW>Al Puri��</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>An Kova��uks</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ma Kudi��</td><td class=bc>-</td><td class=blW>Re Masulis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ed Liepi��</td><td class=bc>-</td><td class=bl>Ev L�sis</td><td class=bc>6 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ar Voitkevi�s</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>0 : 11</tr></td>
<tr><td class=brW>Re Apa�ko</td><td class=bc>-</td><td class=bl>El Vasi�jeva</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>La Ern�teina</td><td class=bc>-</td><td class=bl>Pl Solovjovs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=blW>Al Puri��</td><td class=bc>0 : 12</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Re Holod�aks</td><td class=bc>-</td><td class=blW>Re Masulis</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>An Kova��uks</td><td class=bc>-</td><td class=bl>Ev L�sis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Kudi��</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>El Vasi�jeva</td><td class=bc>11 : 0</tr></td>
<tr><td class=br>Ar Voitkevi�s</td><td class=bc>-</td><td class=bl>Pl Solovjovs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Re Apa�ko</td><td class=bc>-</td><td class=blW>Ra R�ders</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>La Ern�teina</td><td class=bc>-</td><td class=blW>Al Puri��</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=blW>Re Masulis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Ev L�sis</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Re Holod�aks</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>An Kova��uks</td><td class=bc>-</td><td class=bl>Ma Kudi��</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>El Vasi�jeva</td><td class=bc>-</td><td class=bl>Pl Solovjovs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ar Voitkevi�s</td><td class=bc>-</td><td class=blW>Al Puri��</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Re Apa�ko</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>La Ern�teina</td><td class=bc>-</td><td class=blW>Re Masulis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=bl>Ev L�sis</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Ma Kudi��</td><td class=bc>12 : 1</tr></td>
<tr><td class=br>Re Holod�aks</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Pl Solovjovs</td><td class=bc>-</td><td class=blW>Ra R�ders</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>El Vasi�jeva</td><td class=bc>-</td><td class=blW>Al Puri��</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ar Voitkevi�s</td><td class=bc>-</td><td class=blW>Re Masulis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Re Apa�ko</td><td class=bc>-</td><td class=blW>Ev L�sis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>La Ern�teina</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ed Garan�s</td><td class=bc>-</td><td class=bl>Ma Kudi��</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>0 : 12</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Re Holod�aks</td><td class=bc>10 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>Al Puri��</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Pl Solovjovs</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>El Vasi�jeva</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>Ev L�sis</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ar Voitkevi�s</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Re Apa�ko</td><td class=bc>-</td><td class=bl>Ma Kudi��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>La Ern�teina</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>0 : 11</tr></td>
<tr><td class=brW>Ed Garan�s</td><td class=bc>-</td><td class=bl>Re Holod�aks</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>0 : 13</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Al Puri��</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>Re Masulis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pl Solovjovs</td><td class=bc>-</td><td class=bl>Ev L�sis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>El Vasi�jeva</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>Ma Kudi��</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Ar Voitkevi�s</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>0 : 12</tr></td>
<tr><td class=brW>Re Apa�ko</td><td class=bc>-</td><td class=bl>Re Holod�aks</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>La Ern�teina</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>1 : 13</tr></td>
<tr><td class=brW>Ed Garan�s</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>9 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Al Puri��</td><td class=bc>-</td><td class=bl>Ev L�sis</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pl Solovjovs</td><td class=bc>-</td><td class=bl>Ma Kudi��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>El Vasi�jeva</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>0 : 12</tr></td>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>Re Holod�aks</td><td class=bc>12 : 0</tr></td>
<tr><td class=br>Ar Voitkevi�s</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>0 : 16</tr></td>
<tr><td class=brW>Re Apa�ko</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>La Ern�teina</td><td class=bc>-</td><td class=blW>Ed Garan�s</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Re Masulis</td><td class=bc>-</td><td class=bl>Ev L�sis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Al Puri��</td><td class=bc>-</td><td class=bl>Ma Kudi��</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Pl Solovjovs</td><td class=bc>-</td><td class=bl>Re Holod�aks</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>El Vasi�jeva</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>13 : 0</tr></td>
<tr><td class=br>Ar Voitkevi�s</td><td class=bc>-</td><td class=blW>Ed Garan�s</td><td class=bc>0 : 13</tr></td>
<tr><td class=br>Re Apa�ko</td><td class=bc>-</td><td class=bl>La Ern�teina</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ev L�sis</td><td class=bc>-</td><td class=bl>Ma Kudi��</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>Re Holod�aks</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Al Puri��</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Ra R�ders</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Pl Solovjovs</td><td class=bc>-</td><td class=blW>Ed Garan�s</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>El Vasi�jeva</td><td class=bc>-</td><td class=bl>La Ern�teina</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>Re Apa�ko</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ar Voitkevi�s</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ev L�sis</td><td class=bc>-</td><td class=bl>Re Holod�aks</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Al Puri��</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ra R�ders</td><td class=bc>-</td><td class=bl>La Ern�teina</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Pl Solovjovs</td><td class=bc>-</td><td class=blW>Re Apa�ko</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>El Vasi�jeva</td><td class=bc>-</td><td class=bl>Ar Voitkevi�s</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ma Kudi��</td><td class=bc>-</td><td class=bl>Re Holod�aks</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ev L�sis</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>La Ern�teina</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Al Puri��</td><td class=bc>-</td><td class=bl>Re Apa�ko</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Ra R�ders</td><td class=bc>-</td><td class=bl>Ar Voitkevi�s</td><td class=bc>10 : 2</tr></td>
<tr><td class=br>Pl Solovjovs</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>El Vasi�jeva</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ma Kudi��</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ed Liepi��</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ev L�sis</td><td class=bc>-</td><td class=blW>La Ern�teina</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=bl>Re Apa�ko</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>Ar Voitkevi�s</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Al Puri��</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ra R�ders</td><td class=bc>-</td><td class=bl>El Vasi�jeva</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Pl Solovjovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Re Holod�aks</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>An Kova��uks</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Kudi��</td><td class=bc>-</td><td class=bl>La Ern�teina</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ed Liepi��</td><td class=bc>-</td><td class=bl>Re Apa�ko</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ev L�sis</td><td class=bc>-</td><td class=bl>Ar Voitkevi�s</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>El Vasi�jeva</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Al Puri��</td><td class=bc>-</td><td class=bl>Pl Solovjovs</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Re Holod�aks</td><td class=bc>-</td><td class=blW>La Ern�teina</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>An Kova��uks</td><td class=bc>-</td><td class=bl>Re Apa�ko</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Ma Kudi��</td><td class=bc>-</td><td class=bl>Ar Voitkevi�s</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Ed Liepi��</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ev L�sis</td><td class=bc>-</td><td class=bl>El Vasi�jeva</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Re Masulis</td><td class=bc>-</td><td class=bl>Pl Solovjovs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Al Puri��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=blW>La Ern�teina</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Re Apa�ko</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Re Holod�aks</td><td class=bc>-</td><td class=bl>Ar Voitkevi�s</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>An Kova��uks</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ma Kudi��</td><td class=bc>-</td><td class=bl>El Vasi�jeva</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ed Liepi��</td><td class=bc>-</td><td class=bl>Pl Solovjovs</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ev L�sis</td><td class=bc>-</td><td class=blW>Ra R�ders</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>Al Puri��</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ed Garan�s</td><td class=bc>-</td><td class=bl>Re Apa�ko</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=bl>Ar Voitkevi�s</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Re Holod�aks</td><td class=bc>-</td><td class=bl>El Vasi�jeva</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>An Kova��uks</td><td class=bc>-</td><td class=bl>Pl Solovjovs</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ma Kudi��</td><td class=bc>-</td><td class=blW>Ra R�ders</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Al Puri��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ev L�sis</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>La Ern�teina</td><td class=bc>-</td><td class=bl>Ar Voitkevi�s</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=blW>El Vasi�jeva</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Pl Solovjovs</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Re Holod�aks</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>An Kova��uks</td><td class=bc>-</td><td class=bl>Al Puri��</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ma Kudi��</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Re Masulis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ev L�sis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group AL B grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Gu Skapsts</td><td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>6:1</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>6:4</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>10:0</td>
<td class=br>80:26</td><td class=br>+54</td>
<td class=bc>16 - 0 - 1</td>
<td class=br><strong>32</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Kr S�manis</td><td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kW>7:0</td>
<td class=kW>11:0</td>
<td class=kW>6:0</td>
<td class=br>62:28</td><td class=br>+34</td>
<td class=bc>12 - 3 - 2</td>
<td class=br><strong>27</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>B</td><td class=d>3.</td><td class=kt>Ro Garda</td><td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>7:4</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>8:0</td>
<td class=kW>7:0</td>
<td class=kW>7:3</td>
<td class=br>63:29</td><td class=br>+34</td>
<td class=bc>11 - 4 - 2</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>B</td><td class=d>4.</td><td class=kt>Za Gordejs</td><td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kL>4:7</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>2:0</td>
<td class=kW>8:2</td>
<td class=kW>9:0</td>
<td class=kW>8:0</td>
<td class=kW>10:0</td>
<td class=kW>8:0</td>
<td class=kW>10:0</td>
<td class=br>90:24</td><td class=br>+66</td>
<td class=bc>13 - 0 - 4</td>
<td class=br><strong>26</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt>Na Kr�mi��</td><td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>7:5</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>9:0</td>
<td class=kW>13:0</td>
<td class=br>69:24</td><td class=br>+45</td>
<td class=bc>12 - 1 - 4</td>
<td class=br><strong>25</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt>Em Ka�s</td><td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>8:2</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>62:25</td><td class=br>+37</td>
<td class=bc>11 - 2 - 4</td>
<td class=br><strong>24</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>T� Gor�anova</td><td class=kL>4:6</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=br>57:30</td><td class=br>+27</td>
<td class=bc>10 - 4 - 3</td>
<td class=br><strong>24</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>�r Egl�tis</td><td class=kL>1:4</td>
<td class=kW>2:0</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>8:1</td>
<td class=kW>6:1</td>
<td class=kW>9:0</td>
<td class=kW>6:1</td>
<td class=kW>11:0</td>
<td class=br>69:33</td><td class=br>+36</td>
<td class=bc>10 - 1 - 6</td>
<td class=br><strong>21</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Da Vai�iul�ns</td><td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=br>50:39</td><td class=br>+11</td>
<td class=bc>8 - 3 - 6</td>
<td class=br><strong>19</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>J� Saverass</td><td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>5:7</td>
<td class=kL>2:5</td>
<td class=kL>3:6</td>
<td class=kL>0:3</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>7:3</td>
<td class=kW>8:0</td>
<td class=kW>6:0</td>
<td class=kW>10:0</td>
<td class=br>66:39</td><td class=br>+27</td>
<td class=bc>8 - 2 - 7</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>He Str�gelis</td><td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>9:0</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=br>36:45</td><td class=br>-9</td>
<td class=bc>7 - 2 - 8</td>
<td class=br><strong>16</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ri D�cis</td><td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=br>41:42</td><td class=br>-1</td>
<td class=bc>5 - 3 - 9</td>
<td class=br><strong>13</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ma Ju�ina</td><td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>2:8</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>34:57</td><td class=br>-23</td>
<td class=bc>4 - 4 - 9</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ni Baranovs</td><td class=kL>2:7</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>0:9</td>
<td class=kL>1:3</td>
<td class=kL>2:8</td>
<td class=kT>2:2</td>
<td class=kL>1:8</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=br>36:66</td><td class=br>-30</td>
<td class=bc>4 - 2 - 11</td>
<td class=br><strong>10</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>An Garan�a</td><td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>3:7</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>25:63</td><td class=br>-38</td>
<td class=bc>3 - 1 - 13</td>
<td class=br><strong>7</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt>Vi Gaveika</td><td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>0:8</td>
<td class=kL>0:10</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>0:9</td>
<td class=kL>2:5</td>
<td class=kL>0:8</td>
<td class=kL>0:9</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=br>10:94</td><td class=br>-84</td>
<td class=bc>2 - 0 - 15</td>
<td class=br><strong>4</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>C</td><td class=d>17.</td><td class=kt>Pa Bobakovs</td><td class=kL>0:5</td>
<td class=kL>0:11</td>
<td class=kL>0:7</td>
<td class=kL>0:8</td>
<td class=kL>0:9</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>7:88</td><td class=br>-81</td>
<td class=bc>1 - 0 - 16</td>
<td class=br><strong>2</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>C</td><td class=d>18.</td><td class=kt>Vl Bla�evi�s</td><td class=kL>0:10</td>
<td class=kL>0:6</td>
<td class=kL>3:7</td>
<td class=kL>0:10</td>
<td class=kL>0:13</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:11</td>
<td class=kL>0:5</td>
<td class=kL>0:10</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>5:110</td><td class=br>-105</td>
<td class=bc>0 - 0 - 17</td>
<td class=br><strong>0</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ni Baranovs</td><td class=bc>-</td><td class=blW>Da Vai�iul�ns</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vl Bla�evi�s</td><td class=bc>-</td><td class=blW>He Str�gelis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Pa Bobakovs</td><td class=bc>-</td><td class=blW>Gu Skapsts</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>�r Egl�tis</td><td class=bc>-</td><td class=bl>J� Saverass</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Na Kr�mi��</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ro Garda</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Vi Gaveika</td><td class=bc>-</td><td class=blW>Ma Ju�ina</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Za Gordejs</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>He Str�gelis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ni Baranovs</td><td class=bc>-</td><td class=blW>Gu Skapsts</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Vl Bla�evi�s</td><td class=bc>-</td><td class=blW>Kr S�manis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pa Bobakovs</td><td class=bc>-</td><td class=blW>J� Saverass</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>Na Kr�mi��</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=bl>Ma Ju�ina</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vi Gaveika</td><td class=bc>-</td><td class=blW>Za Gordejs</td><td class=bc>0 : 10</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>He Str�gelis</td><td class=bc>-</td><td class=blW>Gu Skapsts</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ni Baranovs</td><td class=bc>-</td><td class=blW>J� Saverass</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vl Bla�evi�s</td><td class=bc>-</td><td class=blW>Na Kr�mi��</td><td class=bc>0 : 13</tr></td>
<tr><td class=br>Pa Bobakovs</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>Ma Ju�ina</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Za Gordejs</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Ro Garda</td><td class=bc>-</td><td class=bl>Vi Gaveika</td><td class=bc>8 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Gu Skapsts</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>He Str�gelis</td><td class=bc>-</td><td class=blW>J� Saverass</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Vai�iul�ns</td><td class=bc>-</td><td class=blW>Na Kr�mi��</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ni Baranovs</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Vl Bla�evi�s</td><td class=bc>-</td><td class=blW>Ma Ju�ina</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Pa Bobakovs</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>Za Gordejs</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>�r Egl�tis</td><td class=bc>-</td><td class=bl>Vi Gaveika</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Ro Garda</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Kr S�manis</td><td class=bc>-</td><td class=bl>J� Saverass</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Gu Skapsts</td><td class=bc>-</td><td class=bl>Na Kr�mi��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>He Str�gelis</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>Ma Ju�ina</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ni Baranovs</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vl Bla�evi�s</td><td class=bc>-</td><td class=blW>Za Gordejs</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Pa Bobakovs</td><td class=bc>-</td><td class=blW>Vi Gaveika</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>Ro Garda</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>�r Egl�tis</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>J� Saverass</td><td class=bc>-</td><td class=blW>Na Kr�mi��</td><td class=bc>5 : 7</tr></td>
<tr><td class=brW>Kr S�manis</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Gu Skapsts</td><td class=bc>-</td><td class=bl>Ma Ju�ina</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>He Str�gelis</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>Za Gordejs</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ni Baranovs</td><td class=bc>-</td><td class=bl>Vi Gaveika</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Vl Bla�evi�s</td><td class=bc>-</td><td class=blW>Ro Garda</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Pa Bobakovs</td><td class=bc>-</td><td class=blW>An Garan�a</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>�r Egl�tis</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Na Kr�mi��</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>J� Saverass</td><td class=bc>-</td><td class=bl>Ma Ju�ina</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kr S�manis</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Gu Skapsts</td><td class=bc>-</td><td class=blW>Za Gordejs</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>He Str�gelis</td><td class=bc>-</td><td class=bl>Vi Gaveika</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ni Baranovs</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vl Bla�evi�s</td><td class=bc>-</td><td class=blW>�r Egl�tis</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Pa Bobakovs</td><td class=bc>-</td><td class=blW>Ri D�cis</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>Ma Ju�ina</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Na Kr�mi��</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>J� Saverass</td><td class=bc>-</td><td class=blW>Za Gordejs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kr S�manis</td><td class=bc>-</td><td class=bl>Vi Gaveika</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Gu Skapsts</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>He Str�gelis</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Vai�iul�ns</td><td class=bc>-</td><td class=blW>�r Egl�tis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ni Baranovs</td><td class=bc>-</td><td class=blW>Ri D�cis</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Vl Bla�evi�s</td><td class=bc>-</td><td class=blW>Pa Bobakovs</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ma Ju�ina</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>Za Gordejs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Na Kr�mi��</td><td class=bc>-</td><td class=bl>Vi Gaveika</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>J� Saverass</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr S�manis</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Gu Skapsts</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>He Str�gelis</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>Pa Bobakovs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ni Baranovs</td><td class=bc>-</td><td class=bl>Vl Bla�evi�s</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>T� Gor�anova</td><td class=bc>-</td><td class=bl>Vi Gaveika</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Ju�ina</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Na Kr�mi��</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>J� Saverass</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr S�manis</td><td class=bc>-</td><td class=bl>Pa Bobakovs</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Gu Skapsts</td><td class=bc>-</td><td class=bl>Vl Bla�evi�s</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>He Str�gelis</td><td class=bc>-</td><td class=bl>Ni Baranovs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Za Gordejs</td><td class=bc>-</td><td class=blW>Ro Garda</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>T� Gor�anova</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ma Ju�ina</td><td class=bc>-</td><td class=blW>�r Egl�tis</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Na Kr�mi��</td><td class=bc>-</td><td class=bl>Pa Bobakovs</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>J� Saverass</td><td class=bc>-</td><td class=bl>Vl Bla�evi�s</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Kr S�manis</td><td class=bc>-</td><td class=bl>Ni Baranovs</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Gu Skapsts</td><td class=bc>-</td><td class=bl>Da Vai�iul�ns</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>He Str�gelis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Vi Gaveika</td><td class=bc>-</td><td class=blW>An Garan�a</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Za Gordejs</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>T� Gor�anova</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ma Ju�ina</td><td class=bc>-</td><td class=bl>Pa Bobakovs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>Vl Bla�evi�s</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Na Kr�mi��</td><td class=bc>-</td><td class=bl>Ni Baranovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>J� Saverass</td><td class=bc>-</td><td class=bl>Da Vai�iul�ns</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kr S�manis</td><td class=bc>-</td><td class=bl>He Str�gelis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Gu Skapsts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ro Garda</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Vi Gaveika</td><td class=bc>-</td><td class=blW>Ri D�cis</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Za Gordejs</td><td class=bc>-</td><td class=bl>Pa Bobakovs</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>T� Gor�anova</td><td class=bc>-</td><td class=bl>Vl Bla�evi�s</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Ju�ina</td><td class=bc>-</td><td class=bl>Ni Baranovs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>Da Vai�iul�ns</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Na Kr�mi��</td><td class=bc>-</td><td class=bl>He Str�gelis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>J� Saverass</td><td class=bc>-</td><td class=blW>Gu Skapsts</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Ri D�cis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ro Garda</td><td class=bc>-</td><td class=bl>Pa Bobakovs</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Vi Gaveika</td><td class=bc>-</td><td class=bl>Vl Bla�evi�s</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Za Gordejs</td><td class=bc>-</td><td class=bl>Ni Baranovs</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>T� Gor�anova</td><td class=bc>-</td><td class=bl>Da Vai�iul�ns</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Ju�ina</td><td class=bc>-</td><td class=blW>He Str�gelis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Gu Skapsts</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Na Kr�mi��</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>J� Saverass</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>�r Egl�tis</td><td class=bc>-</td><td class=bl>Pa Bobakovs</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>An Garan�a</td><td class=bc>-</td><td class=bl>Vl Bla�evi�s</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ro Garda</td><td class=bc>-</td><td class=bl>Ni Baranovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vi Gaveika</td><td class=bc>-</td><td class=blW>Da Vai�iul�ns</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Za Gordejs</td><td class=bc>-</td><td class=bl>He Str�gelis</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Gu Skapsts</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ma Ju�ina</td><td class=bc>-</td><td class=blW>Kr S�manis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>J� Saverass</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Na Kr�mi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Ri D�cis</td><td class=bc>-</td><td class=bl>Vl Bla�evi�s</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>�r Egl�tis</td><td class=bc>-</td><td class=bl>Ni Baranovs</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Da Vai�iul�ns</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ro Garda</td><td class=bc>-</td><td class=bl>He Str�gelis</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Vi Gaveika</td><td class=bc>-</td><td class=blW>Gu Skapsts</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Za Gordejs</td><td class=bc>-</td><td class=blW>Kr S�manis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>T� Gor�anova</td><td class=bc>-</td><td class=bl>J� Saverass</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ma Ju�ina</td><td class=bc>-</td><td class=blW>Na Kr�mi��</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Pa Bobakovs</td><td class=bc>-</td><td class=blW>Ni Baranovs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>Da Vai�iul�ns</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=blW>He Str�gelis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Gu Skapsts</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=blW>Kr S�manis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vi Gaveika</td><td class=bc>-</td><td class=blW>J� Saverass</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Za Gordejs</td><td class=bc>-</td><td class=bl>Na Kr�mi��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Ju�ina</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Vl Bla�evi�s</td><td class=bc>-</td><td class=blW>Da Vai�iul�ns</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Pa Bobakovs</td><td class=bc>-</td><td class=blW>He Str�gelis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>Gu Skapsts</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>�r Egl�tis</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>J� Saverass</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Ro Garda</td><td class=bc>-</td><td class=bl>Na Kr�mi��</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Vi Gaveika</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Za Gordejs</td><td class=bc>-</td><td class=bl>Ma Ju�ina</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group AL 1.l�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Al Puri��</td><td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>8:2</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>6:0</td>
<td class=br>63:26</td><td class=br>+37</td>
<td class=bc>12 - 0 - 3</td>
<td class=br><strong>24</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Em Ka�s</td><td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>9:3</td>
<td class=kW>4:2</td>
<td class=br>55:29</td><td class=br>+26</td>
<td class=bc>11 - 1 - 3</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Za Gordejs</td><td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>9:2</td>
<td class=kL>0:4</td>
<td class=kW>3:0</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>10:3</td>
<td class=kW>7:1</td>
<td class=br>69:34</td><td class=br>+35</td>
<td class=bc>11 - 0 - 4</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Na Kr�mi��</td><td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kT>0:0</td>
<td class=kW>5:0</td>
<td class=kL>0:2</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=br>44:21</td><td class=br>+23</td>
<td class=bc>10 - 2 - 3</td>
<td class=br><strong>22</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ha V�veris</td><td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>2:9</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kW>7:0</td>
<td class=kW>7:3</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>8:0</td>
<td class=br>53:33</td><td class=br>+20</td>
<td class=bc>11 - 0 - 4</td>
<td class=br><strong>22</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>�r Egl�tis</td><td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>46:27</td><td class=br>+19</td>
<td class=bc>8 - 3 - 4</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>T� Gor�anova</td><td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=br>31:28</td><td class=br>+3</td>
<td class=bc>8 - 1 - 6</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ed Garan�s</td><td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kW>4:3</td>
<td class=kT>0:0</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kL>2:6</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=br>31:26</td><td class=br>+5</td>
<td class=bc>7 - 2 - 6</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>J� Saverass</td><td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>34:40</td><td class=br>-6</td>
<td class=bc>7 - 0 - 8</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ro Garda</td><td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=br>36:41</td><td class=br>-5</td>
<td class=bc>7 - 0 - 8</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ed Liepi��</td><td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kL>0:1</td>
<td class=br>25:31</td><td class=br>-6</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ma P�tersons</td><td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=br>36:44</td><td class=br>-8</td>
<td class=bc>4 - 3 - 8</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Da Vai�iul�ns</td><td class=kL>2:8</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>3:7</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=br>32:48</td><td class=br>-16</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Re Masulis</td><td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>1:0</td>
<td class=br>18:40</td><td class=br>-22</td>
<td class=bc>3 - 2 - 10</td>
<td class=br><strong>8</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Ra R�ders</td><td class=kL>0:7</td>
<td class=kL>3:9</td>
<td class=kL>3:10</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=br>21:66</td><td class=br>-45</td>
<td class=bc>2 - 0 - 13</td>
<td class=br><strong>4</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Re Apa�ko</td><td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kW>1:0</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=br>9:69</td><td class=br>-60</td>
<td class=bc>1 - 0 - 14</td>
<td class=br><strong>2</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Al Puri��</td><td class=bc>-</td><td class=bl>J� Saverass</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ro Garda</td><td class=bc>-</td><td class=bl>Re Apa�ko</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ed Liepi��</td><td class=bc>-</td><td class=bl>Da Vai�iul�ns</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Za Gordejs</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>10 : 3</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=blW>�r Egl�tis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Na Kr�mi��</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>J� Saverass</td><td class=bc>-</td><td class=bl>Re Apa�ko</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Al Puri��</td><td class=bc>-</td><td class=bl>Da Vai�iul�ns</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Ro Garda</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>�r Egl�tis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Za Gordejs</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Na Kr�mi��</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Re Apa�ko</td><td class=bc>-</td><td class=blW>Da Vai�iul�ns</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>J� Saverass</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Al Puri��</td><td class=bc>-</td><td class=blW>�r Egl�tis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=blW>Re Masulis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Za Gordejs</td><td class=bc>-</td><td class=blW>Ed Garan�s</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Na Kr�mi��</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Re Apa�ko</td><td class=bc>-</td><td class=blW>�r Egl�tis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>J� Saverass</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Al Puri��</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ro Garda</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Za Gordejs</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=bl>Na Kr�mi��</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>�r Egl�tis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Re Apa�ko</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>J� Saverass</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Al Puri��</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Na Kr�mi��</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Za Gordejs</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Re Apa�ko</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>J� Saverass</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Al Puri��</td><td class=bc>-</td><td class=bl>Na Kr�mi��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ro Garda</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Za Gordejs</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>Da Vai�iul�ns</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Re Apa�ko</td><td class=bc>-</td><td class=blW>Na Kr�mi��</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>J� Saverass</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Al Puri��</td><td class=bc>-</td><td class=bl>Za Gordejs</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Ed Garan�s</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>Na Kr�mi��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Vai�iul�ns</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Re Apa�ko</td><td class=bc>-</td><td class=blW>Za Gordejs</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>J� Saverass</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Al Puri��</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Na Kr�mi��</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Re Masulis</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>�r Egl�tis</td><td class=bc>-</td><td class=bl>Za Gordejs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Re Apa�ko</td><td class=bc>-</td><td class=blW>Al Puri��</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>J� Saverass</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Na Kr�mi��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ed Garan�s</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Za Gordejs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>�r Egl�tis</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>Al Puri��</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Da Vai�iul�ns</td><td class=bc>-</td><td class=blW>J� Saverass</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Re Apa�ko</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Za Gordejs</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ed Garan�s</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Ro Garda</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>Al Puri��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=blW>J� Saverass</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ra R�ders</td><td class=bc>-</td><td class=bl>Re Apa�ko</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Na Kr�mi��</td><td class=bc>-</td><td class=blW>Za Gordejs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=blW>Al Puri��</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>T� Gor�anova</td><td class=bc>-</td><td class=bl>J� Saverass</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Re Masulis</td><td class=bc>-</td><td class=bl>Re Apa�ko</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>�r Egl�tis</td><td class=bc>-</td><td class=bl>Da Vai�iul�ns</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Na Kr�mi��</td><td class=bc>-</td><td class=blW>Ro Garda</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>Al Puri��</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>J� Saverass</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ed Garan�s</td><td class=bc>-</td><td class=bl>Re Apa�ko</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Da Vai�iul�ns</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>Ra R�ders</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Za Gordejs</td><td class=bc>-</td><td class=blW>Ro Garda</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=blW>Al Puri��</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Na Kr�mi��</td><td class=bc>-</td><td class=bl>J� Saverass</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>Re Apa�ko</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>Da Vai�iul�ns</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ed Garan�s</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Al Puri��</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Za Gordejs</td><td class=bc>-</td><td class=bl>J� Saverass</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>Re Apa�ko</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Na Kr�mi��</td><td class=bc>-</td><td class=bl>Da Vai�iul�ns</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ed Garan�s</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=blW>J� Saverass</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Re Apa�ko</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Za Gordejs</td><td class=bc>-</td><td class=bl>Da Vai�iul�ns</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Na Kr�mi��</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group AL 2.l�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Ri D�cis</td><td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>72:7</td><td class=br>+65</td>
<td class=bc>14 - 1 - 0</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>He Str�gelis</td><td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>2:9</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kT>0:0</td>
<td class=kW>7:0</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>48:20</td><td class=br>+28</td>
<td class=bc>11 - 2 - 2</td>
<td class=br><strong>24</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Pl Solovjovs</td><td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>50:17</td><td class=br>+33</td>
<td class=bc>11 - 0 - 4</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Ma Ju�ina</td><td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>9:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>55:19</td><td class=br>+36</td>
<td class=bc>10 - 1 - 4</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>An Garan�a</td><td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kW>9:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kL>0:5</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>45:27</td><td class=br>+18</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ev L�sis</td><td class=kL>1:3</td>
<td class=kW>9:2</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kT>0:0</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>50:27</td><td class=br>+23</td>
<td class=bc>8 - 3 - 4</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>La Ern�teina</td><td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>2:0</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kL>0:5</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>42:25</td><td class=br>+17</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ni Baranovs</td><td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>38:25</td><td class=br>+13</td>
<td class=bc>8 - 1 - 6</td>
<td class=br><strong>17</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ma Kudi��</td><td class=kL>0:8</td>
<td class=kT>0:0</td>
<td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>41:32</td><td class=br>+9</td>
<td class=bc>6 - 4 - 5</td>
<td class=br><strong>16</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ar Voitkevi�s</td><td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>2:9</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>36:38</td><td class=br>-2</td>
<td class=bc>6 - 3 - 6</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Re Holod�aks</td><td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kW>3:0</td>
<td class=kL>1:4</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>31:29</td><td class=br>+2</td>
<td class=bc>6 - 1 - 8</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ne Giri�a</td><td class=kL>0:8</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:9</td>
<td class=kL>0:4</td>
<td class=kT>0:0</td>
<td class=kW>5:0</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>27:42</td><td class=br>-15</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Vl Bla�evi�s</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kW>5:0</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=br>5:55</td><td class=br>-50</td>
<td class=bc>1 - 0 - 11</td>
<td class=br><strong>2</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Pa Bobakovs</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=br>3:60</td><td class=br>-57</td>
<td class=bc>0 - 0 - 12</td>
<td class=br><strong>0</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>El Vasi�jeva</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=br>0:60</td><td class=br>-60</td>
<td class=bc>0 - 0 - 12</td>
<td class=br><strong>0</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Vi Gaveika</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=br>0:60</td><td class=br>-60</td>
<td class=bc>0 - 0 - 12</td>
<td class=br><strong>0</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>La Ern�teina</td><td class=bc>-</td><td class=bl>Vl Bla�evi�s</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>He Str�gelis</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ev L�sis</td><td class=bc>-</td><td class=bl>Pa Bobakovs</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ri D�cis</td><td class=bc>-</td><td class=bl>Ar Voitkevi�s</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ma Kudi��</td><td class=bc>-</td><td class=bl>Vi Gaveika</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ma Ju�ina</td><td class=bc>-</td><td class=bl>El Vasi�jeva</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pl Solovjovs</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ni Baranovs</td><td class=bc>-</td><td class=blW>Re Holod�aks</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Vl Bla�evi�s</td><td class=bc>-</td><td class=blW>Ne Giri�a</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>La Ern�teina</td><td class=bc>-</td><td class=bl>Pa Bobakovs</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>He Str�gelis</td><td class=bc>-</td><td class=bl>Ar Voitkevi�s</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ev L�sis</td><td class=bc>-</td><td class=bl>Vi Gaveika</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ri D�cis</td><td class=bc>-</td><td class=bl>El Vasi�jeva</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Kudi��</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Ju�ina</td><td class=bc>-</td><td class=bl>Re Holod�aks</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pl Solovjovs</td><td class=bc>-</td><td class=blW>Ni Baranovs</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ne Giri�a</td><td class=bc>-</td><td class=bl>Pa Bobakovs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vl Bla�evi�s</td><td class=bc>-</td><td class=blW>Ar Voitkevi�s</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>La Ern�teina</td><td class=bc>-</td><td class=bl>Vi Gaveika</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>He Str�gelis</td><td class=bc>-</td><td class=bl>El Vasi�jeva</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ev L�sis</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ri D�cis</td><td class=bc>-</td><td class=bl>Re Holod�aks</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Kudi��</td><td class=bc>-</td><td class=blW>Ni Baranovs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Ju�ina</td><td class=bc>-</td><td class=blW>Pl Solovjovs</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Pa Bobakovs</td><td class=bc>-</td><td class=blW>Ar Voitkevi�s</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ne Giri�a</td><td class=bc>-</td><td class=bl>Vi Gaveika</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vl Bla�evi�s</td><td class=bc>-</td><td class=bl>El Vasi�jeva</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>La Ern�teina</td><td class=bc>-</td><td class=blW>An Garan�a</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>He Str�gelis</td><td class=bc>-</td><td class=bl>Re Holod�aks</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ev L�sis</td><td class=bc>-</td><td class=bl>Ni Baranovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ri D�cis</td><td class=bc>-</td><td class=bl>Pl Solovjovs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ma Kudi��</td><td class=bc>-</td><td class=blW>Ma Ju�ina</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ar Voitkevi�s</td><td class=bc>-</td><td class=bl>Vi Gaveika</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Pa Bobakovs</td><td class=bc>-</td><td class=bl>El Vasi�jeva</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=blW>An Garan�a</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vl Bla�evi�s</td><td class=bc>-</td><td class=blW>Re Holod�aks</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>La Ern�teina</td><td class=bc>-</td><td class=bl>Ni Baranovs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>He Str�gelis</td><td class=bc>-</td><td class=bl>Pl Solovjovs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ev L�sis</td><td class=bc>-</td><td class=blW>Ma Ju�ina</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ri D�cis</td><td class=bc>-</td><td class=bl>Ma Kudi��</td><td class=bc>8 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Vi Gaveika</td><td class=bc>-</td><td class=bl>El Vasi�jeva</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ar Voitkevi�s</td><td class=bc>-</td><td class=blW>An Garan�a</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Pa Bobakovs</td><td class=bc>-</td><td class=blW>Re Holod�aks</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=blW>Ni Baranovs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vl Bla�evi�s</td><td class=bc>-</td><td class=blW>Pl Solovjovs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>La Ern�teina</td><td class=bc>-</td><td class=blW>Ma Ju�ina</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>He Str�gelis</td><td class=bc>-</td><td class=bl>Ma Kudi��</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ev L�sis</td><td class=bc>-</td><td class=blW>Ri D�cis</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>El Vasi�jeva</td><td class=bc>-</td><td class=blW>An Garan�a</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vi Gaveika</td><td class=bc>-</td><td class=blW>Re Holod�aks</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ar Voitkevi�s</td><td class=bc>-</td><td class=bl>Ni Baranovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pa Bobakovs</td><td class=bc>-</td><td class=blW>Pl Solovjovs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=blW>Ma Ju�ina</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Vl Bla�evi�s</td><td class=bc>-</td><td class=blW>Ma Kudi��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>La Ern�teina</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>He Str�gelis</td><td class=bc>-</td><td class=blW>Ev L�sis</td><td class=bc>2 : 9</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>An Garan�a</td><td class=bc>-</td><td class=bl>Re Holod�aks</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>El Vasi�jeva</td><td class=bc>-</td><td class=blW>Ni Baranovs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vi Gaveika</td><td class=bc>-</td><td class=blW>Pl Solovjovs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ar Voitkevi�s</td><td class=bc>-</td><td class=blW>Ma Ju�ina</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pa Bobakovs</td><td class=bc>-</td><td class=blW>Ma Kudi��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=blW>Ri D�cis</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Vl Bla�evi�s</td><td class=bc>-</td><td class=blW>Ev L�sis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>La Ern�teina</td><td class=bc>-</td><td class=blW>He Str�gelis</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Re Holod�aks</td><td class=bc>-</td><td class=blW>Pl Solovjovs</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>An Garan�a</td><td class=bc>-</td><td class=bl>Ma Ju�ina</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>El Vasi�jeva</td><td class=bc>-</td><td class=blW>Ma Kudi��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vi Gaveika</td><td class=bc>-</td><td class=blW>Ri D�cis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ar Voitkevi�s</td><td class=bc>-</td><td class=bl>Ev L�sis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pa Bobakovs</td><td class=bc>-</td><td class=blW>He Str�gelis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ne Giri�a</td><td class=bc>-</td><td class=bl>La Ern�teina</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vl Bla�evi�s</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ni Baranovs</td><td class=bc>-</td><td class=bl>Ma Ju�ina</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Re Holod�aks</td><td class=bc>-</td><td class=blW>Ma Kudi��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Ri D�cis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>El Vasi�jeva</td><td class=bc>-</td><td class=blW>Ev L�sis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vi Gaveika</td><td class=bc>-</td><td class=blW>He Str�gelis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ar Voitkevi�s</td><td class=bc>-</td><td class=blW>La Ern�teina</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pa Bobakovs</td><td class=bc>-</td><td class=bl>Vl Bla�evi�s</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Pl Solovjovs</td><td class=bc>-</td><td class=bl>Ma Kudi��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ni Baranovs</td><td class=bc>-</td><td class=blW>Ri D�cis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Re Holod�aks</td><td class=bc>-</td><td class=blW>Ev L�sis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>He Str�gelis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>El Vasi�jeva</td><td class=bc>-</td><td class=blW>La Ern�teina</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vi Gaveika</td><td class=bc>-</td><td class=bl>Vl Bla�evi�s</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ar Voitkevi�s</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pa Bobakovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ma Ju�ina</td><td class=bc>-</td><td class=blW>Ri D�cis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pl Solovjovs</td><td class=bc>-</td><td class=bl>Ev L�sis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ni Baranovs</td><td class=bc>-</td><td class=blW>He Str�gelis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Re Holod�aks</td><td class=bc>-</td><td class=blW>La Ern�teina</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Vl Bla�evi�s</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>El Vasi�jeva</td><td class=bc>-</td><td class=blW>Ne Giri�a</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vi Gaveika</td><td class=bc>-</td><td class=bl>Pa Bobakovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ar Voitkevi�s</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ma Kudi��</td><td class=bc>-</td><td class=bl>Ev L�sis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Ju�ina</td><td class=bc>-</td><td class=bl>He Str�gelis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pl Solovjovs</td><td class=bc>-</td><td class=blW>La Ern�teina</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ni Baranovs</td><td class=bc>-</td><td class=bl>Vl Bla�evi�s</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Re Holod�aks</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>An Garan�a</td><td class=bc>-</td><td class=bl>Pa Bobakovs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>El Vasi�jeva</td><td class=bc>-</td><td class=blW>Ar Voitkevi�s</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vi Gaveika</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ri D�cis</td><td class=bc>-</td><td class=bl>He Str�gelis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Kudi��</td><td class=bc>-</td><td class=blW>La Ern�teina</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ma Ju�ina</td><td class=bc>-</td><td class=bl>Vl Bla�evi�s</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pl Solovjovs</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ni Baranovs</td><td class=bc>-</td><td class=bl>Pa Bobakovs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Re Holod�aks</td><td class=bc>-</td><td class=bl>Ar Voitkevi�s</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>An Garan�a</td><td class=bc>-</td><td class=bl>Vi Gaveika</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>El Vasi�jeva</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ev L�sis</td><td class=bc>-</td><td class=bl>La Ern�teina</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ri D�cis</td><td class=bc>-</td><td class=bl>Vl Bla�evi�s</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ma Kudi��</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Ju�ina</td><td class=bc>-</td><td class=bl>Pa Bobakovs</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pl Solovjovs</td><td class=bc>-</td><td class=bl>Ar Voitkevi�s</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ni Baranovs</td><td class=bc>-</td><td class=bl>Vi Gaveika</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Re Holod�aks</td><td class=bc>-</td><td class=bl>El Vasi�jeva</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>He Str�gelis</td><td class=bc>-</td><td class=bl>Vl Bla�evi�s</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ev L�sis</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Ri D�cis</td><td class=bc>-</td><td class=bl>Pa Bobakovs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Kudi��</td><td class=bc>-</td><td class=bl>Ar Voitkevi�s</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Ju�ina</td><td class=bc>-</td><td class=bl>Vi Gaveika</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pl Solovjovs</td><td class=bc>-</td><td class=bl>El Vasi�jeva</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ni Baranovs</td><td class=bc>-</td><td class=blW>An Garan�a</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Re Holod�aks</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
