<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Latvijas Kauss 4.posms</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../25LK4/Latvijas_Kauss_4.posms_index.php">Latvijas Kauss 4.posms, 3. May 2025</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group LK A grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ra Kalni��</td><td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>4:7</td>
<td class=kW>7:2</td>
<td class=kW>6:4</td>
<td class=kW>13:4</td>
<td class=kW>5:0</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kW>8:2</td>
<td class=kW>7:4</td>
<td class=kW>6:2</td>
<td class=br>68:30</td><td class=br>+38</td>
<td class=bc>9 - 1 - 1</td>
<td class=br><strong>19</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>An Liepi��</td><td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>6:4</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kW>6:5</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=br>38:24</td><td class=br>+14</td>
<td class=bc>8 - 1 - 2</td>
<td class=br><strong>17</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Al Skudr�tis</td><td class=kW>7:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=br>41:29</td><td class=br>+12</td>
<td class=bc>7 - 2 - 2</td>
<td class=br><strong>16</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ri Kalni��</td><td class=kL>2:7</td>
<td class=kL>4:6</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=br>32:26</td><td class=br>+6</td>
<td class=bc>6 - 2 - 3</td>
<td class=br><strong>14</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Kr Zem�ickis</td><td class=kL>4:6</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>7:2</td>
<td class=kW>1:0</td>
<td class=br>32:23</td><td class=br>+9</td>
<td class=bc>5 - 3 - 3</td>
<td class=br><strong>13</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ed Ka�eps</td><td class=kL>4:13</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>5:4</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=br>42:35</td><td class=br>+7</td>
<td class=bc>6 - 1 - 4</td>
<td class=br><strong>13</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Sa Kalni��</td><td class=kL>0:5</td>
<td class=kL>5:6</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=br>25:24</td><td class=br>+1</td>
<td class=bc>5 - 1 - 5</td>
<td class=br><strong>11</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>El R�cen�ja</td><td class=kL>3:6</td>
<td class=kL>0:2</td>
<td class=kL>3:5</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=br>29:30</td><td class=br>-1</td>
<td class=bc>5 - 0 - 6</td>
<td class=br><strong>10</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ai Romals</td><td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=br>18:35</td><td class=br>-17</td>
<td class=bc>2 - 2 - 7</td>
<td class=br><strong>6</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ed Blument�ls</td><td class=kL>2:8</td>
<td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>3:0</td>
<td class=br>22:43</td><td class=br>-21</td>
<td class=bc>2 - 2 - 7</td>
<td class=br><strong>6</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Iv �irsis</td><td class=kL>4:7</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=br>23:45</td><td class=br>-22</td>
<td class=bc>2 - 1 - 8</td>
<td class=br><strong>5</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>�i Vazoli��</td><td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=br>11:37</td><td class=br>-26</td>
<td class=bc>1 - 0 - 10</td>
<td class=br><strong>2</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Blument�ls Eduards</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Blument�ls Eduards</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Liepi�� Andris</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kalni�� Rainers</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Blument�ls Eduards</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Blument�ls Eduards</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Blument�ls Eduards</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Blument�ls Eduards</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Blument�ls Eduards</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Blument�ls Eduards</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>4 : 13</tr></td>
<tr><td class=br>Liepi�� Andris</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Blument�ls Eduards</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Blument�ls Eduards</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>Blument�ls Eduards</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group LK B grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ed Naglis</td><td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>6:5</td>
<td class=kW>7:1</td>
<td class=kW>6:3</td>
<td class=br>52:24</td><td class=br>+28</td>
<td class=bc>9 - 1 - 1</td>
<td class=br><strong>19</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>He Prokuratovs</td><td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>7:6</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=br>42:25</td><td class=br>+17</td>
<td class=bc>8 - 1 - 2</td>
<td class=br><strong>17</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Fi Buhtujevs</td><td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kW>8:1</td>
<td class=br>37:25</td><td class=br>+12</td>
<td class=bc>6 - 2 - 3</td>
<td class=br><strong>14</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ra Kuha�skis</td><td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kL>0:1</td>
<td class=kW>7:1</td>
<td class=kW>1:0</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=br>41:27</td><td class=br>+14</td>
<td class=bc>6 - 2 - 3</td>
<td class=br><strong>14</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Kr Naglis</td><td class=kW>4:1</td>
<td class=kL>6:7</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>7:4</td>
<td class=kW>7:0</td>
<td class=br>49:34</td><td class=br>+15</td>
<td class=bc>7 - 0 - 4</td>
<td class=br><strong>14</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ro Rieksti��</td><td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=br>35:32</td><td class=br>+3</td>
<td class=bc>6 - 1 - 4</td>
<td class=br><strong>13</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Ra Martu��ns</td><td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>1:7</td>
<td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=br>33:34</td><td class=br>-1</td>
<td class=bc>5 - 1 - 5</td>
<td class=br><strong>11</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Ro Fa�ken�teins</td><td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>3:5</td>
<td class=br>25:28</td><td class=br>-3</td>
<td class=bc>4 - 2 - 5</td>
<td class=br><strong>10</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>L� Bezdel�ga</td><td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kW>1:0</td>
<td class=br>15:41</td><td class=br>-26</td>
<td class=bc>3 - 0 - 8</td>
<td class=br><strong>6</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>To Jakseboga</td><td class=kL>5:6</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=br>23:28</td><td class=br>-5</td>
<td class=bc>1 - 3 - 7</td>
<td class=br><strong>5</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Kr Kurzemnieks</td><td class=kL>1:7</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kL>4:7</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>25:48</td><td class=br>-23</td>
<td class=bc>2 - 1 - 8</td>
<td class=br><strong>5</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>J� Rekti��</td><td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kL>1:8</td>
<td class=kT>3:3</td>
<td class=kL>0:7</td>
<td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kW>5:3</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>21:52</td><td class=br>-31</td>
<td class=bc>1 - 2 - 8</td>
<td class=br><strong>4</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Buhtujevs Filips</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Buhtujevs Filips</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Buhtujevs Filips</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>6 : 7</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Buhtujevs Filips</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Buhtujevs Filips</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Buhtujevs Filips</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Buhtujevs Filips</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Buhtujevs Filips</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Rekti�� J�nis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Buhtujevs Filips</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Buhtujevs Filips</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Buhtujevs Filips</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group LK C grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Al Sili��</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>45:17</td><td class=br>+28</td>
<td class=bc>9 - 1 - 1</td>
<td class=br><strong>19</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Va Smagars</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kL>3:5</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kT>2:2</td>
<td class=br>40:23</td><td class=br>+17</td>
<td class=bc>6 - 3 - 2</td>
<td class=br><strong>15</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ma Jakseboga</td><td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=br>34:21</td><td class=br>+13</td>
<td class=bc>6 - 3 - 2</td>
<td class=br><strong>15</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Sa Skarainis</td><td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>6:4</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=br>33:26</td><td class=br>+7</td>
<td class=bc>6 - 2 - 3</td>
<td class=br><strong>14</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Se Mihejevs</td><td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=br>33:25</td><td class=br>+8</td>
<td class=bc>7 - 0 - 4</td>
<td class=br><strong>14</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Da Baumanis</td><td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=br>33:29</td><td class=br>+4</td>
<td class=bc>6 - 1 - 4</td>
<td class=br><strong>13</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Ro Verbi�s</td><td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=br>34:29</td><td class=br>+5</td>
<td class=bc>6 - 1 - 4</td>
<td class=br><strong>13</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Ar Zasurcevs</td><td class=kL>3:5</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kL>4:6</td>
<td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=br>32:35</td><td class=br>-3</td>
<td class=bc>4 - 1 - 6</td>
<td class=br><strong>9</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Fr Platons</td><td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=br>17:24</td><td class=br>-7</td>
<td class=bc>4 - 1 - 6</td>
<td class=br><strong>9</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ar Verbi�s</td><td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=br>15:40</td><td class=br>-25</td>
<td class=bc>1 - 2 - 8</td>
<td class=br><strong>4</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>J� Zem�ickis</td><td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kW>5:3</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>13:39</td><td class=br>-26</td>
<td class=bc>2 - 0 - 9</td>
<td class=br><strong>4</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Il �irse</td><td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kW>6:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>21:42</td><td class=br>-21</td>
<td class=bc>1 - 1 - 9</td>
<td class=br><strong>3</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Zem�ickis J�nis</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Zem�ickis J�nis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group LK D grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Em Liepi��</td><td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>5:4</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>6:0</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=br>40:24</td><td class=br>+16</td>
<td class=bc>9 - 1 - 1</td>
<td class=br><strong>19</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>K� Balodis</td><td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=br>42:22</td><td class=br>+20</td>
<td class=bc>7 - 3 - 1</td>
<td class=br><strong>17</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Re Vazoli��</td><td class=kL>4:5</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>7:3</td>
<td class=br>40:28</td><td class=br>+12</td>
<td class=bc>8 - 0 - 3</td>
<td class=br><strong>16</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Kr Lagzdi�a</td><td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>7:0</td>
<td class=kW>2:0</td>
<td class=kW>7:1</td>
<td class=br>33:14</td><td class=br>+19</td>
<td class=bc>6 - 2 - 3</td>
<td class=br><strong>14</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Sa Krasts</td><td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=br>29:26</td><td class=br>+3</td>
<td class=bc>6 - 1 - 4</td>
<td class=br><strong>13</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ri Felkers</td><td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=br>27:21</td><td class=br>+6</td>
<td class=bc>4 - 4 - 3</td>
<td class=br><strong>12</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>J� Re�is</td><td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=br>28:25</td><td class=br>+3</td>
<td class=bc>5 - 1 - 5</td>
<td class=br><strong>11</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Marg �bele</td><td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>0:0</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=br>23:26</td><td class=br>-3</td>
<td class=bc>4 - 1 - 6</td>
<td class=br><strong>9</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ka �iha�ova</td><td class=kL>0:6</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=br>23:35</td><td class=br>-12</td>
<td class=bc>2 - 4 - 5</td>
<td class=br><strong>8</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ro Aseri��</td><td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kT>0:0</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=br>12:29</td><td class=br>-17</td>
<td class=bc>1 - 4 - 6</td>
<td class=br><strong>6</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ro Kerns</td><td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=br>18:33</td><td class=br>-15</td>
<td class=bc>1 - 3 - 7</td>
<td class=br><strong>5</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>�v Vikmanis</td><td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>3:7</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=br>17:49</td><td class=br>-32</td>
<td class=bc>1 - 0 - 10</td>
<td class=br><strong>2</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Felkers Ritvars</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Balodis K�rlis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Balodis K�rlis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Felkers Ritvars</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Balodis K�rlis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Felkers Ritvars</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>Balodis K�rlis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Felkers Ritvars</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=blW>Balodis K�rlis</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>Felkers Ritvars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Balodis K�rlis</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Felkers Ritvars</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Vikmanis �ve</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Balodis K�rlis</td><td class=bc>-</td><td class=bl>Felkers Ritvars</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=bl>Felkers Ritvars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Balodis K�rlis</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kerns Roberts</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Balodis K�rlis</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Felkers Ritvars</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Balodis K�rlis</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=blW>Aseri�� Roberts</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Felkers Ritvars</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Balodis K�rlis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Felkers Ritvars</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=blW>Balodis K�rlis</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group LK 1.liga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Ra Kalni��</td><td class=kx>*</td>
<td class=kL>2:8</td>
<td class=kW>13:4 K</td>
<td class=kT>3:3</td>
<td class=kW>7:4</td>
<td class=kL>3:7</td>
<td class=kW>5:1</td>
<td class=kT>1:1 K</td>
<td class=kW>9:4</td>
<td class=kW>4:3</td>
<td class=kW>8:3</td>
<td class=kW>5:3</td>
<td class=kW>5:3</td>
<td class=kW>7:3</td>
<td class=kW>5:0</td>
<td class=kW>7:2</td>
<td class=kW>8:0</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>6:4 K</td>
<td class=kL>4:7 K</td>
<td class=kW>7:2 K</td>
<td class=kW>5:1</td>
<td class=kW>10:0</td>
<td class=br>135:65</td><td class=br>+70</td>
<td class=bc>18 - 2 - 3</td>
<td class=br><strong>38</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Ed Naglis</td><td class=kW>8:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>8:5</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=kL>2:3</td>
<td class=kW>5:1 K</td>
<td class=kL>1:4 K</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>8:4</td>
<td class=kL>0:4</td>
<td class=kW>7:4</td>
<td class=kT>2:2 K</td>
<td class=kW>5:2 K</td>
<td class=kW>5:2 K</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>95:55</td><td class=br>+40</td>
<td class=bc>15 - 3 - 5</td>
<td class=br><strong>33</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Ed Ka�eps</td><td class=kL>4:13 K</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kL>2:7</td>
<td class=kW>5:2 K</td>
<td class=kW>5:4</td>
<td class=kW>5:4</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kL>1:4</td>
<td class=kL>3:4 K</td>
<td class=kW>5:3 K</td>
<td class=kL>2:3 K</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=br>79:72</td><td class=br>+7</td>
<td class=bc>14 - 2 - 7</td>
<td class=br><strong>30</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>Re Vazoli��</td><td class=kT>3:3</td>
<td class=kL>5:8</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kL>4:5 K</td>
<td class=kL>1:6 K</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>1:4 K</td>
<td class=kW>3:2 K</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kW>6:4</td>
<td class=kW>4:2</td>
<td class=kW>5:1 K</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kL>0:5</td>
<td class=kW>5:1</td>
<td class=br>73:65</td><td class=br>+8</td>
<td class=bc>14 - 2 - 7</td>
<td class=br><strong>30</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Em Liepi��</td><td class=kL>4:7</td>
<td class=kW>5:4</td>
<td class=kL>1:6</td>
<td class=kW>5:4 K</td>
<td class=kx>*</td>
<td class=kL>4:5 K</td>
<td class=kL>3:7</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>2:8</td>
<td class=kL>2:4</td>
<td class=kW>3:2 K</td>
<td class=kW>3:2 K</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kW>2:1 K</td>
<td class=kW>5:2</td>
<td class=kW>5:4</td>
<td class=kW>9:0</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=br>91:80</td><td class=br>+11</td>
<td class=bc>13 - 3 - 7</td>
<td class=br><strong>29</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>K� Balodis</td><td class=kW>7:3</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kW>6:1 K</td>
<td class=kW>5:4 K</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>7:2</td>
<td class=kL>1:3 K</td>
<td class=kT>3:3 K</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>5:1 K</td>
<td class=kW>6:0</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>6:3</td>
<td class=br>82:55</td><td class=br>+27</td>
<td class=bc>12 - 4 - 7</td>
<td class=br><strong>28</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Va Smagars</td><td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>7:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kT>3:3 K</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kL>1:4 K</td>
<td class=kT>2:2 K</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>5:2 K</td>
<td class=kW>5:2 K</td>
<td class=br>74:63</td><td class=br>+11</td>
<td class=bc>11 - 6 - 6</td>
<td class=br><strong>28</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>An Liepi��</td><td class=kT>1:1 K</td>
<td class=kW>3:2</td>
<td class=kL>2:5 K</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2 K</td>
<td class=kL>2:3 K</td>
<td class=kW>6:4 K</td>
<td class=kT>0:0</td>
<td class=kT>3:3</td>
<td class=br>68:56</td><td class=br>+12</td>
<td class=bc>10 - 6 - 7</td>
<td class=br><strong>26</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>He Prokuratovs</td><td class=kL>4:9</td>
<td class=kL>1:5 K</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>7:6 K</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>2:3 K</td>
<td class=kW>6:1 K</td>
<td class=kW>4:1 K</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=br>69:65</td><td class=br>+4</td>
<td class=bc>12 - 1 - 10</td>
<td class=br><strong>25</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Kr Naglis</td><td class=kL>3:4</td>
<td class=kW>4:1 K</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kW>8:2</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>6:7 K</td>
<td class=kx>*</td>
<td class=kL>5:6</td>
<td class=kW>2:0</td>
<td class=kL>1:5</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kW>5:3 K</td>
<td class=kL>4:5 K</td>
<td class=kL>1:5 K</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>3:5</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=br>86:67</td><td class=br>+19</td>
<td class=bc>12 - 1 - 10</td>
<td class=br><strong>25</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Ma Jakseboga</td><td class=kL>3:8</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kL>2:7</td>
<td class=kT>3:3 K</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>6:5</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>4:1 K</td>
<td class=kL>3:4 K</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kL>0:5</td>
<td class=kW>3:1 K</td>
<td class=kW>3:2 K</td>
<td class=br>61:66</td><td class=br>-5</td>
<td class=bc>10 - 4 - 9</td>
<td class=br><strong>24</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>Kr Lagzdi�a</td><td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:1 K</td>
<td class=kL>2:3 K</td>
<td class=kW>3:1 K</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kW>10:0</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2 K</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=br>62:41</td><td class=br>+21</td>
<td class=bc>9 - 5 - 9</td>
<td class=br><strong>23</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>Ri Felkers</td><td class=kL>3:5</td>
<td class=kL>4:8</td>
<td class=kL>2:4</td>
<td class=kL>2:3 K</td>
<td class=kL>2:3 K</td>
<td class=kT>3:3 K</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>2:0 K</td>
<td class=kW>1:0</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=br>58:60</td><td class=br>-2</td>
<td class=bc>9 - 5 - 9</td>
<td class=br><strong>23</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>Sa Skarainis</td><td class=kL>3:7</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>4:1 K</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>1:4 K</td>
<td class=kL>0:10</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kL>1:5 K</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>6:3</td>
<td class=kW>3:0</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>2:0 K</td>
<td class=kT>3:3 K</td>
<td class=br>55:67</td><td class=br>-12</td>
<td class=bc>10 - 3 - 10</td>
<td class=br><strong>23</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>Al Sili��</td><td class=kL>0:5</td>
<td class=kL>4:7</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>3:6</td>
<td class=kW>3:1</td>
<td class=kT>2:2 K</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kW>4:3 K</td>
<td class=kT>0:0</td>
<td class=kW>4:3</td>
<td class=kW>5:1 K</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>3:4 K</td>
<td class=kW>3:1 K</td>
<td class=br>60:72</td><td class=br>-12</td>
<td class=bc>9 - 4 - 10</td>
<td class=br><strong>22</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>Ro Rieksti��</td><td class=kL>2:7</td>
<td class=kT>2:2 K</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kW>3:2 K</td>
<td class=kL>3:5 K</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kL>1:5 K</td>
<td class=kW>4:3 K</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=br>65:67</td><td class=br>-2</td>
<td class=bc>9 - 4 - 10</td>
<td class=br><strong>22</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ra Kuha�skis</td><td class=kL>0:8</td>
<td class=kL>2:5 K</td>
<td class=kL>3:4</td>
<td class=kL>4:6</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kL>1:6 K</td>
<td class=kW>5:4 K</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>5:1 K</td>
<td class=kx>*</td>
<td class=kT>4:4 K</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=br>64:81</td><td class=br>-17</td>
<td class=bc>8 - 5 - 10</td>
<td class=br><strong>21</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Fi Buhtujevs</td><td class=kL>1:6</td>
<td class=kL>2:5 K</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kW>6:3</td>
<td class=kL>3:4</td>
<td class=kL>1:4 K</td>
<td class=kW>5:1 K</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kL>3:4 K</td>
<td class=kT>4:4 K</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kL>1:7</td>
<td class=br>66:79</td><td class=br>-13</td>
<td class=bc>8 - 4 - 11</td>
<td class=br><strong>20</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Sa Krasts</td><td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kL>1:5 K</td>
<td class=kL>1:2 K</td>
<td class=kL>1:5 K</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kL>0:1</td>
<td class=kW>2:1 K</td>
<td class=kL>0:2 K</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=br>44:60</td><td class=br>-16</td>
<td class=bc>8 - 4 - 11</td>
<td class=br><strong>20</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Kr Zem�ickis</td><td class=kL>4:6 K</td>
<td class=kT>2:2</td>
<td class=kW>4:3 K</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>2:3 K</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kW>3:0</td>
<td class=kL>4:5</td>
<td class=kL>3:4</td>
<td class=kW>6:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=br>48:71</td><td class=br>-23</td>
<td class=bc>5 - 5 - 13</td>
<td class=br><strong>15</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>21.</td><td class=kt>Al Skudr�tis</td><td class=kW>7:4 K</td>
<td class=kT>2:2</td>
<td class=kL>3:5 K</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2 K</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kW>4:2 K</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=br>60:77</td><td class=br>-17</td>
<td class=bc>4 - 5 - 14</td>
<td class=br><strong>13</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>22.</td><td class=kt>Ri Kalni��</td><td class=kL>2:7 K</td>
<td class=kL>0:2</td>
<td class=kW>3:2 K</td>
<td class=kL>1:4</td>
<td class=kL>0:9</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>4:6 K</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>1:1 K</td>
<td class=kL>2:4 K</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=br>42:75</td><td class=br>-33</td>
<td class=bc>5 - 3 - 15</td>
<td class=br><strong>13</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>23.</td><td class=kt>Se Mihejevs</td><td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kW>5:0</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>2:5 K</td>
<td class=kT>0:0</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3 K</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>0:2 K</td>
<td class=kW>4:3 K</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>4:1 K</td>
<td class=br>35:67</td><td class=br>-32</td>
<td class=bc>5 - 3 - 15</td>
<td class=br><strong>13</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>24.</td><td class=kt>Da Baumanis</td><td class=kL>0:10</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kL>3:6</td>
<td class=kL>2:5 K</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>2:3 K</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kT>3:3 K</td>
<td class=kL>1:3 K</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>7:1</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>6:3</td>
<td class=kL>1:4</td>
<td class=kL>1:4 K</td>
<td class=kx>*</td>
<td class=br>45:91</td><td class=br>-46</td>
<td class=bc>3 - 2 - 18</td>
<td class=br><strong>8</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Felkers Ritvars</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Liepi�� Andris</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Buhtujevs Filips</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Balodis K�rlis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Buhtujevs Filips</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Balodis K�rlis</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Felkers Ritvars</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Buhtujevs Filips</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>9 : 4</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Balodis K�rlis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Felkers Ritvars</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Buhtujevs Filips</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Balodis K�rlis</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Kalni�� Rainers</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Felkers Ritvars</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Buhtujevs Filips</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Balodis K�rlis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Felkers Ritvars</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Liepi�� Andris</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=bl>Balodis K�rlis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Felkers Ritvars</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Buhtujevs Filips</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Balodis K�rlis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Buhtujevs Filips</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Felkers Ritvars</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Balodis K�rlis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>8 : 5</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Buhtujevs Filips</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Felkers Ritvars</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Felkers Ritvars</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Buhtujevs Filips</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Balodis K�rlis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Felkers Ritvars</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Buhtujevs Filips</td><td class=bc>-</td><td class=blW>Balodis K�rlis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Buhtujevs Filips</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Felkers Ritvars</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Balodis K�rlis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Buhtujevs Filips</td><td class=bc>-</td><td class=blW>Felkers Ritvars</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Balodis K�rlis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>7 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Balodis K�rlis</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Buhtujevs Filips</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Felkers Ritvars</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Felkers Ritvars</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Balodis K�rlis</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Buhtujevs Filips</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Felkers Ritvars</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Balodis K�rlis</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Buhtujevs Filips</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Kalni�� Rainers</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Felkers Ritvars</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Balodis K�rlis</td><td class=bc>-</td><td class=bl>Kalni�� Rainers</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Buhtujevs Filips</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Buhtujevs Filips</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Felkers Ritvars</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Balodis K�rlis</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Balodis K�rlis</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Buhtujevs Filips</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Felkers Ritvars</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>9 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group LK 2.liga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>J� Re�is</td><td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>5:4</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=br>73:35</td><td class=br>+38</td>
<td class=bc>13 - 2 - 4</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Sa Kalni��</td><td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>6:0</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>0:1</td>
<td class=kW>5:4</td>
<td class=kW>1:0</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=br>59:34</td><td class=br>+25</td>
<td class=bc>13 - 1 - 5</td>
<td class=br><strong>27</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Ar Zasurcevs</td><td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kL>5:6</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>74:42</td><td class=br>+32</td>
<td class=bc>12 - 2 - 5</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Ka �iha�ova</td><td class=kW>3:2</td>
<td class=kL>0:6</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=br>55:53</td><td class=br>+2</td>
<td class=bc>12 - 1 - 6</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Iv �irsis</td><td class=kL>3:6</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=br>67:45</td><td class=br>+22</td>
<td class=bc>11 - 2 - 6</td>
<td class=br><strong>24</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ro Kerns</td><td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kL>5:7</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kL>0:2</td>
<td class=br>60:43</td><td class=br>+17</td>
<td class=bc>10 - 4 - 5</td>
<td class=br><strong>24</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Kr Kurzemnieks</td><td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>6:5</td>
<td class=kW>4:1</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=br>59:48</td><td class=br>+11</td>
<td class=bc>11 - 2 - 6</td>
<td class=br><strong>24</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>El R�cen�ja</td><td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kW>6:3</td>
<td class=kL>3:5</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=br>64:40</td><td class=br>+24</td>
<td class=bc>10 - 4 - 5</td>
<td class=br><strong>24</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ro Fa�ken�teins</td><td class=kL>0:5</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=kT>0:0</td>
<td class=br>38:42</td><td class=br>-4</td>
<td class=bc>10 - 3 - 6</td>
<td class=br><strong>23</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ra Martu��ns</td><td class=kL>4:5</td>
<td class=kL>4:5</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kL>0:6</td>
<td class=kW>5:0</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=br>58:49</td><td class=br>+9</td>
<td class=bc>9 - 3 - 7</td>
<td class=br><strong>21</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ai Romals</td><td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=br>54:48</td><td class=br>+6</td>
<td class=bc>7 - 6 - 6</td>
<td class=br><strong>20</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ro Verbi�s</td><td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kW>7:1</td>
<td class=kL>2:5</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=br>56:57</td><td class=br>-1</td>
<td class=bc>8 - 3 - 8</td>
<td class=br><strong>19</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Marg �bele</td><td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kW>7:5</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=br>43:47</td><td class=br>-4</td>
<td class=bc>8 - 3 - 8</td>
<td class=br><strong>19</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>L� Bezdel�ga</td><td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>4:6</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=br>34:61</td><td class=br>-27</td>
<td class=bc>6 - 1 - 12</td>
<td class=br><strong>13</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>J� Zem�ickis</td><td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kL>1:3</td>
<td class=br>42:46</td><td class=br>-4</td>
<td class=bc>5 - 3 - 11</td>
<td class=br><strong>13</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Ed Blument�ls</td><td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>5:0</td>
<td class=k>&nbsp;</td>
<td class=kW>3:1</td>
<td class=br>29:63</td><td class=br>-34</td>
<td class=bc>4 - 2 - 12</td>
<td class=br><strong>10</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>17.</td><td class=kt>To Jakseboga</td><td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=br>31:48</td><td class=br>-17</td>
<td class=bc>3 - 4 - 12</td>
<td class=br><strong>10</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>18.</td><td class=kt>Ar Verbi�s</td><td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>6:4</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=br>34:67</td><td class=br>-33</td>
<td class=bc>4 - 2 - 13</td>
<td class=br><strong>10</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>19.</td><td class=kt>Fr Platons</td><td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=k>&nbsp;</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=br>24:57</td><td class=br>-33</td>
<td class=bc>4 - 1 - 13</td>
<td class=br><strong>9</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>20.</td><td class=kt>Ro Aseri��</td><td class=kW>1:0</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=br>18:47</td><td class=br>-29</td>
<td class=bc>3 - 3 - 13</td>
<td class=br><strong>9</strong></td><td class=d>20.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Kerns Roberts</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Blument�ls Eduards</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Kerns Roberts</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Blument�ls Eduards</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kerns Roberts</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Blument�ls Eduards</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Aseri�� Roberts</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kerns Roberts</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Blument�ls Eduards</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kerns Roberts</td><td class=bc>-</td><td class=bl>Blument�ls Eduards</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>Blument�ls Eduards</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kerns Roberts</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Romals Aigars</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Blument�ls Eduards</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kerns Roberts</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Blument�ls Eduards</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kerns Roberts</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Blument�ls Eduards</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Romals Aigars</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Zem�ickis J�nis</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Blument�ls Eduards</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Romals Aigars</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Blument�ls Eduards</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Blument�ls Eduards</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Blument�ls Eduards</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Blument�ls Eduards</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Zem�ickis J�nis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=blW>Kerns Roberts</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Blument�ls Eduards</td><td class=bc>-</td><td class=blW>Zem�ickis J�nis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Zem�ickis J�nis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Blument�ls Eduards</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>7 : 5</tr></td>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Blument�ls Eduards</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Kerns Roberts</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Blument�ls Eduards</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=bl>Blument�ls Eduards</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>Zem�ickis J�nis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>Blument�ls Eduards</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group LK 3.liga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>M� �irsis</td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>7:1</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>9:2</td>
<td class=br>72:32</td><td class=br>+40</td>
<td class=bc>16 - 3 - 0</td>
<td class=br><strong>35</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Il �irse</td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kL>3:6</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kW>8:0</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>7:2</td>
<td class=br>72:34</td><td class=br>+38</td>
<td class=bc>14 - 2 - 3</td>
<td class=br><strong>30</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Ma Krauze</td><td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=br>61:30</td><td class=br>+31</td>
<td class=bc>11 - 4 - 4</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>�i Vazoli��</td><td class=kL>1:3</td>
<td class=kW>6:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>7:0</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=br>51:28</td><td class=br>+23</td>
<td class=bc>11 - 3 - 5</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ma Kalni��</td><td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=br>52:32</td><td class=br>+20</td>
<td class=bc>11 - 2 - 6</td>
<td class=br><strong>24</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ed Jansons</td><td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kL>0:1</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=br>36:35</td><td class=br>+1</td>
<td class=bc>9 - 4 - 6</td>
<td class=br><strong>22</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Da Belkovs</td><td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kW>6:4</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kT>0:0</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kL>3:5</td>
<td class=kW>5:3</td>
<td class=br>55:47</td><td class=br>+8</td>
<td class=bc>10 - 1 - 8</td>
<td class=br><strong>21</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>M� Timbers</td><td class=kT>4:4</td>
<td class=kL>0:4</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=br>41:50</td><td class=br>-9</td>
<td class=bc>8 - 4 - 7</td>
<td class=br><strong>20</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Al Liepi��</td><td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kW>6:0</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=br>44:37</td><td class=br>+7</td>
<td class=bc>9 - 2 - 8</td>
<td class=br><strong>20</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>�v Vikmanis</td><td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=br>55:54</td><td class=br>+1</td>
<td class=bc>8 - 4 - 7</td>
<td class=br><strong>20</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ag Pav�rs</td><td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=br>49:46</td><td class=br>+3</td>
<td class=bc>6 - 7 - 6</td>
<td class=br><strong>19</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>El Reinfelds</td><td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>4:6</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kW>1:0</td>
<td class=br>51:52</td><td class=br>-1</td>
<td class=bc>8 - 2 - 9</td>
<td class=br><strong>18</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Gu Skapsts</td><td class=kL>1:7</td>
<td class=kL>0:8</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>2:0</td>
<td class=br>33:49</td><td class=br>-16</td>
<td class=bc>4 - 9 - 6</td>
<td class=br><strong>17</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Ge Jansons</td><td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=br>34:42</td><td class=br>-8</td>
<td class=bc>6 - 3 - 10</td>
<td class=br><strong>15</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>D� Vai�iul�ns</td><td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kW>4:2</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>0:0</td>
<td class=kW>6:5</td>
<td class=kW>4:2</td>
<td class=br>41:53</td><td class=br>-12</td>
<td class=bc>4 - 7 - 8</td>
<td class=br><strong>15</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>D� Vesele</td><td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kW>7:1</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=br>39:44</td><td class=br>-5</td>
<td class=bc>3 - 8 - 8</td>
<td class=br><strong>14</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>J� Rekti��</td><td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=br>34:55</td><td class=br>-21</td>
<td class=bc>5 - 3 - 11</td>
<td class=br><strong>13</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>An Kova��uks</td><td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kT>0:0</td>
<td class=kT>0:0</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kT>1:1</td>
<td class=br>24:52</td><td class=br>-28</td>
<td class=bc>3 - 6 - 10</td>
<td class=br><strong>12</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Br Gor�anovs</td><td class=kL>3:5</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kL>0:1</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>5:6</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=br>47:76</td><td class=br>-29</td>
<td class=bc>3 - 3 - 13</td>
<td class=br><strong>9</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>T� Gor�anova</td><td class=kL>2:9</td>
<td class=kL>2:7</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=br>23:66</td><td class=br>-43</td>
<td class=bc>2 - 1 - 16</td>
<td class=br><strong>5</strong></td><td class=d>20.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Vai�iul�ns D�vis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Gor�anova T�na</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>�irse Ilze</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Kova��uks Andris</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Jansons Edvards</td><td class=bc>-</td><td class=blW>Timbers M�rti��</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>�irse Ilze</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Jansons Edvards</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Gor�anova T�na</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>�irse Ilze</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Jansons Edvards</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Skapsts Gustavs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>Jansons Edvards</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Timbers M�rti��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=bl>Jansons Edvards</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Kova��uks Andris</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Jansons Edvards</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=blW>Timbers M�rti��</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Jansons Edvards</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>�irse Ilze</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Jansons Edvards</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>�irse Ilze</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>Timbers M�rti��</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=blW>Jansons Edvards</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Timbers M�rti��</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Jansons Edvards</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Vikmanis �ve</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Jansons Edvards</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>Rekti�� J�nis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=blW>Vai�iul�ns D�vis</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jansons Edvards</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>Rekti�� J�nis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Jansons Edvards</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Vikmanis �ve</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Jansons Edvards</td><td class=bc>-</td><td class=blW>Rekti�� J�nis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Jansons Edvards</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=blW>Rekti�� J�nis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Jansons Edvards</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Skapsts Gustavs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Jansons Edvards</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Skapsts Gustavs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Jansons Edvards</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Rekti�� J�nis</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>�irse Ilze</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jansons Edvards</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
