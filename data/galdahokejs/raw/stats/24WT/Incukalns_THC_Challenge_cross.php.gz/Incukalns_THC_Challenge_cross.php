<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Incukalns THC Challenge</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../24WT/Incukalns_THC_Challenge_index.php">Incukalns THC Challenge, 28. September 2024</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ra Kalni��</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=br>51:23</td><td class=br>+28</td>
<td class=bc>9 - 2 - 1</td>
<td class=br><strong>20</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>J� Kaln�vics</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=br>42:17</td><td class=br>+25</td>
<td class=bc>9 - 2 - 1</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>D� Apfelbaums</td><td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kL>0:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>8:1</td>
<td class=kW>7:0</td>
<td class=kW>7:2</td>
<td class=br>42:17</td><td class=br>+25</td>
<td class=bc>9 - 0 - 3</td>
<td class=br><strong>18</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ed Putni��</td><td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>6:3</td>
<td class=kW>3:0</td>
<td class=kW>8:3</td>
<td class=kW>6:0</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=br>47:30</td><td class=br>+17</td>
<td class=bc>7 - 1 - 4</td>
<td class=br><strong>15</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Kr Zem�ickis</td><td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>3:2</td>
<td class=br>42:31</td><td class=br>+11</td>
<td class=bc>7 - 0 - 5</td>
<td class=br><strong>14</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Am Fylling</td><td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=br>38:26</td><td class=br>+12</td>
<td class=bc>6 - 2 - 4</td>
<td class=br><strong>14</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ka �iha�ova</td><td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=br>26:27</td><td class=br>-1</td>
<td class=bc>7 - 0 - 5</td>
<td class=br><strong>14</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Il �irse</td><td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kL>0:2</td>
<td class=br>32:32</td><td class=br>0</td>
<td class=bc>6 - 1 - 5</td>
<td class=br><strong>13</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>In Garan�s</td><td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=br>29:27</td><td class=br>+2</td>
<td class=bc>5 - 1 - 6</td>
<td class=br><strong>11</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ro Aseri��</td><td class=kW>4:3</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>3:8</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=br>19:43</td><td class=br>-24</td>
<td class=bc>2 - 1 - 9</td>
<td class=br><strong>5</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Er Kalni��</td><td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=br>15:55</td><td class=br>-40</td>
<td class=bc>2 - 0 - 10</td>
<td class=br><strong>4</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>M� �irsis</td><td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>3:5</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=br>21:51</td><td class=br>-30</td>
<td class=bc>2 - 0 - 10</td>
<td class=br><strong>4</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ei G�ze</td><td class=kL>0:6</td>
<td class=kT>3:3</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=br>20:45</td><td class=br>-25</td>
<td class=bc>1 - 2 - 9</td>
<td class=br><strong>4</strong></td><td class=d>13.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>J� Kaln�vics</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Ka �iha�ova</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Er Kalni��</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Ka �iha�ova</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>J� Kaln�vics</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ka �iha�ova</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>J� Kaln�vics</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>J� Kaln�vics</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Er Kalni��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=blW>J� Kaln�vics</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>J� Kaln�vics</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ka �iha�ova</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>J� Kaln�vics</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Ka �iha�ova</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>J� Kaln�vics</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>J� Kaln�vics</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>J� Kaln�vics</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>Ka �iha�ova</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Ka �iha�ova</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>J� Kaln�vics</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>1 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>J� Re�is</td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>12:3</td>
<td class=kW>6:2</td>
<td class=kW>7:0</td>
<td class=kW>6:0</td>
<td class=kW>7:0</td>
<td class=br>64:24</td><td class=br>+40</td>
<td class=bc>10 - 1 - 2</td>
<td class=br><strong>21</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>An Liepi��</td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>6:0</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>7:0</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>7:0</td>
<td class=kW>11:0</td>
<td class=br>60:16</td><td class=br>+44</td>
<td class=bc>9 - 2 - 2</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Sa Kalni��</td><td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=br>39:21</td><td class=br>+18</td>
<td class=bc>8 - 4 - 1</td>
<td class=br><strong>20</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Se Mihejevs</td><td class=kW>4:3</td>
<td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=br>44:23</td><td class=br>+21</td>
<td class=bc>9 - 2 - 2</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Al Sili��</td><td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>6:3</td>
<td class=kW>10:1</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>6:4</td>
<td class=kW>8:0</td>
<td class=br>64:26</td><td class=br>+38</td>
<td class=bc>8 - 4 - 1</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>J� Bitmanis</td><td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=br>42:26</td><td class=br>+16</td>
<td class=bc>8 - 2 - 3</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Jo Pleikys</td><td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kL>0:2</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=br>31:28</td><td class=br>+3</td>
<td class=bc>7 - 0 - 6</td>
<td class=br><strong>14</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ro Fa�ken�teins</td><td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=br>32:19</td><td class=br>+13</td>
<td class=bc>6 - 1 - 6</td>
<td class=br><strong>13</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Kr Kurzemnieks</td><td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kL>3:6</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>6:3</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=br>40:31</td><td class=br>+9</td>
<td class=bc>6 - 1 - 6</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>El Reinfelds</td><td class=kL>3:12</td>
<td class=kL>0:7</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:10</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>8:1</td>
<td class=kW>4:2</td>
<td class=kW>7:3</td>
<td class=br>32:67</td><td class=br>-35</td>
<td class=bc>4 - 0 - 9</td>
<td class=br><strong>8</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Fr Platons</td><td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>8:2</td>
<td class=br>23:38</td><td class=br>-15</td>
<td class=bc>2 - 2 - 9</td>
<td class=br><strong>6</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Al Sili��</td><td class=kL>0:7</td>
<td class=kL>0:8</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kW>2:0</td>
<td class=kL>0:5</td>
<td class=kL>3:6</td>
<td class=kL>1:8</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=br>10:51</td><td class=br>-41</td>
<td class=bc>3 - 0 - 10</td>
<td class=br><strong>6</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ro Purmalis</td><td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>4:6</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=br>18:52</td><td class=br>-34</td>
<td class=bc>1 - 1 - 11</td>
<td class=br><strong>3</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>D� Ra�ko</td><td class=kL>0:7</td>
<td class=kL>0:11</td>
<td class=kL>2:5</td>
<td class=kL>0:8</td>
<td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>3:7</td>
<td class=kL>2:8</td>
<td class=kL>0:1</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=br>9:86</td><td class=br>-77</td>
<td class=bc>0 - 0 - 13</td>
<td class=br><strong>0</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>D� Ra�ko</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>D� Ra�ko</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>D� Ra�ko</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Jo Pleikys</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>D� Ra�ko</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Jo Pleikys</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>12 : 3</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>D� Ra�ko</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>El Reinfelds</td><td class=bc>-</td><td class=bl>D� Ra�ko</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>D� Ra�ko</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Jo Pleikys</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Jo Pleikys</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>D� Ra�ko</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Jo Pleikys</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>D� Ra�ko</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Kr Kurzemnieks</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Kr Kurzemnieks</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>D� Ra�ko</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Kr Kurzemnieks</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Jo Pleikys</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>D� Ra�ko</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Ra�ko</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 10</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>D� Ra�ko</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Jo Pleikys</td><td class=bc>-</td><td class=bl>D� Ra�ko</td><td class=bc>6 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Al Skudr�tis</td><td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kL>3:5</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>9:0</td>
<td class=kW>9:0</td>
<td class=kW>7:0</td>
<td class=br>67:23</td><td class=br>+44</td>
<td class=bc>10 - 2 - 1</td>
<td class=br><strong>22</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Kr Naglis</td><td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:7</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>8:2</td>
<td class=kW>7:4</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kW>12:1</td>
<td class=br>61:36</td><td class=br>+25</td>
<td class=bc>8 - 4 - 1</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Va Smagars</td><td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>3:5</td>
<td class=kW>6:0</td>
<td class=kL>1:2</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>10:1</td>
<td class=kW>10:1</td>
<td class=kW>7:3</td>
<td class=kW>9:0</td>
<td class=br>73:27</td><td class=br>+46</td>
<td class=bc>9 - 1 - 3</td>
<td class=br><strong>19</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Il Pavlovskis</td><td class=kL>1:6</td>
<td class=kW>7:2</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kW>8:0</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=br>53:23</td><td class=br>+30</td>
<td class=bc>8 - 3 - 2</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Je Zaharovs</td><td class=kW>5:3</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>8:1</td>
<td class=kW>9:1</td>
<td class=br>60:36</td><td class=br>+24</td>
<td class=bc>9 - 0 - 4</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ar Zasurcevs</td><td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kW>8:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=br>50:29</td><td class=br>+21</td>
<td class=bc>7 - 3 - 3</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ro Kerns</td><td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>7:2</td>
<td class=br>39:34</td><td class=br>+5</td>
<td class=bc>7 - 2 - 4</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Pa Strods</td><td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>8:2</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=br>46:37</td><td class=br>+9</td>
<td class=bc>6 - 1 - 6</td>
<td class=br><strong>13</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Em Reinfelds</td><td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>6:4</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=br>43:45</td><td class=br>-2</td>
<td class=bc>5 - 1 - 7</td>
<td class=br><strong>11</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Da Baumanis</td><td class=kL>2:3</td>
<td class=kL>2:8</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=k>&nbsp;</td>
<td class=br>25:38</td><td class=br>-13</td>
<td class=bc>5 - 0 - 7</td>
<td class=br><strong>10</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Br Gor�anovs</td><td class=kL>0:4</td>
<td class=kL>4:7</td>
<td class=kL>1:10</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kL>2:8</td>
<td class=kL>4:6</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=br>27:71</td><td class=br>-44</td>
<td class=bc>2 - 1 - 10</td>
<td class=br><strong>5</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>�v Vikmanis</td><td class=kL>0:9</td>
<td class=kL>0:1</td>
<td class=kL>1:10</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>9:1</td>
<td class=br>24:54</td><td class=br>-30</td>
<td class=bc>2 - 1 - 10</td>
<td class=br><strong>5</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ed Ern�teins</td><td class=kL>0:9</td>
<td class=kL>3:4</td>
<td class=kL>3:7</td>
<td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=br>22:58</td><td class=br>-36</td>
<td class=bc>2 - 1 - 10</td>
<td class=br><strong>5</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ju Jeme�janovs</td><td class=kL>0:7</td>
<td class=kL>1:12</td>
<td class=kL>0:9</td>
<td class=kL>1:6</td>
<td class=kL>1:9</td>
<td class=kL>0:8</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=k>&nbsp;</td>
<td class=kL>0:3</td>
<td class=kL>1:9</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=br>6:85</td><td class=br>-79</td>
<td class=bc>0 - 0 - 12</td>
<td class=br><strong>0</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Ern�teins</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ju Jeme�janovs</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ed Ern�teins</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Pa Strods</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ju Jeme�janovs</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Em Reinfelds</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Pa Strods</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ed Ern�teins</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ju Jeme�janovs</td><td class=bc>-</td><td class=blW>Em Reinfelds</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ed Ern�teins</td><td class=bc>-</td><td class=blW>Em Reinfelds</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Il Pavlovskis</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ju Jeme�janovs</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>1 : 12</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Pa Strods</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Em Reinfelds</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Il Pavlovskis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ed Ern�teins</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Em Reinfelds</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ed Ern�teins</td><td class=bc>-</td><td class=bl>Ju Jeme�janovs</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Pa Strods</td><td class=bc>-</td><td class=bl>Em Reinfelds</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Il Pavlovskis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ju Jeme�janovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Em Reinfelds</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Ju Jeme�janovs</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ed Ern�teins</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=blW>Il Pavlovskis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pa Strods</td><td class=bc>-</td><td class=bl>Ju Jeme�janovs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Ed Ern�teins</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Ju Jeme�janovs</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Pa Strods</td><td class=bc>-</td><td class=bl>Ed Ern�teins</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Ju Jeme�janovs</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Em Reinfelds</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Ed Ern�teins</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Ju Jeme�janovs</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Ed Ern�teins</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ju Jeme�janovs</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Ed Ern�teins</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Em Reinfelds</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>10 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Ed Ern�teins</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ju Jeme�janovs</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Em Reinfelds</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ed Ern�teins</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ju Jeme�janovs</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group D</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Kr Lagzdi�a</td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:4</td>
<td class=kL>1:4</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>11:1</td>
<td class=kW>5:1</td>
<td class=br>62:17</td><td class=br>+45</td>
<td class=bc>12 - 0 - 1</td>
<td class=br><strong>24</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Sa Krasts</td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=br>50:21</td><td class=br>+29</td>
<td class=bc>10 - 0 - 3</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ig Saveljev</td><td class=kL>4:6</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=kW>6:1</td>
<td class=kW>7:0</td>
<td class=kW>11:1</td>
<td class=br>59:26</td><td class=br>+33</td>
<td class=bc>9 - 2 - 2</td>
<td class=br><strong>20</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Au Pleikys</td><td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=br>37:22</td><td class=br>+15</td>
<td class=bc>9 - 0 - 4</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Al �ernovojs</td><td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kL>0:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=br>41:26</td><td class=br>+15</td>
<td class=bc>8 - 1 - 4</td>
<td class=br><strong>17</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ed Naglis</td><td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kT>5:5</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=br>50:25</td><td class=br>+25</td>
<td class=bc>7 - 2 - 4</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Marg �bele</td><td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kW>2:0</td>
<td class=kT>4:4</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>6:5</td>
<td class=kW>5:2</td>
<td class=kT>0:0</td>
<td class=kW>7:2</td>
<td class=kW>8:2</td>
<td class=kW>7:0</td>
<td class=br>45:29</td><td class=br>+16</td>
<td class=bc>7 - 2 - 4</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ra Martu��ns</td><td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kL>0:6</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=br>35:28</td><td class=br>+7</td>
<td class=bc>7 - 1 - 5</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ni Sviklis</td><td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kT>5:5</td>
<td class=kL>5:6</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>8:0</td>
<td class=br>48:38</td><td class=br>+10</td>
<td class=bc>6 - 1 - 6</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ai Romals</td><td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>9:1</td>
<td class=br>34:42</td><td class=br>-8</td>
<td class=bc>4 - 2 - 7</td>
<td class=br><strong>10</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ag Pav�rs</td><td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>0:7</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kT>0:0</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=br>20:46</td><td class=br>-26</td>
<td class=bc>2 - 2 - 9</td>
<td class=br><strong>6</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Re Saul�tis</td><td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=br>22:50</td><td class=br>-28</td>
<td class=bc>2 - 1 - 10</td>
<td class=br><strong>5</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>M� Timbers</td><td class=kL>1:11</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>2:8</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=br>18:74</td><td class=br>-56</td>
<td class=bc>1 - 0 - 12</td>
<td class=br><strong>2</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ti Gorsanova</td><td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:11</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>1:9</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=br>6:83</td><td class=br>-77</td>
<td class=bc>0 - 0 - 13</td>
<td class=br><strong>0</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ti Gorsanova</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ti Gorsanova</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ti Gorsanova</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ti Gorsanova</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ti Gorsanova</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Ra Martu��ns</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ti Gorsanova</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>Ra Martu��ns</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 11</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ti Gorsanova</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Ra Martu��ns</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>M� Timbers</td><td class=bc>-</td><td class=bl>Ti Gorsanova</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ti Gorsanova</td><td class=bc>11 : 1</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>Ti Gorsanova</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Ti Gorsanova</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Ti Gorsanova</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Ti Gorsanova</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ti Gorsanova</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>4 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group E</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ed Ka�eps</td><td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kL>4:6</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>8:3</td>
<td class=kW>9:1</td>
<td class=kW>5:1</td>
<td class=kW>9:0</td>
<td class=kW>8:2</td>
<td class=br>70:23</td><td class=br>+47</td>
<td class=bc>12 - 0 - 1</td>
<td class=br><strong>24</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Zy Remeika</td><td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>8:4</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>7:2</td>
<td class=br>54:25</td><td class=br>+29</td>
<td class=bc>10 - 1 - 2</td>
<td class=br><strong>21</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>K� Balodis</td><td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>9:1</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>8:1</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=br>51:24</td><td class=br>+27</td>
<td class=bc>10 - 0 - 3</td>
<td class=br><strong>20</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>R� Kamzols</td><td class=kL>2:5</td>
<td class=kL>4:8</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kL>3:4</td>
<td class=kW>6:3</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=br>62:30</td><td class=br>+32</td>
<td class=bc>9 - 1 - 3</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Sa Skarainis</td><td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>10:0</td>
<td class=br>45:23</td><td class=br>+22</td>
<td class=bc>8 - 1 - 4</td>
<td class=br><strong>17</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>He Prokuratovs</td><td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=br>41:25</td><td class=br>+16</td>
<td class=bc>7 - 2 - 4</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Gu Ern�teins</td><td class=kW>6:4</td>
<td class=kL>0:5</td>
<td class=kL>1:9</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>9:0</td>
<td class=br>41:38</td><td class=br>+3</td>
<td class=bc>7 - 1 - 5</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ni Lyksholm</td><td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>10:0</td>
<td class=br>40:32</td><td class=br>+8</td>
<td class=bc>6 - 2 - 5</td>
<td class=br><strong>14</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Al Kalni��</td><td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>11:1</td>
<td class=br>51:36</td><td class=br>+15</td>
<td class=bc>6 - 1 - 6</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Al Hermansson</td><td class=kL>3:8</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=br>32:39</td><td class=br>-7</td>
<td class=bc>5 - 1 - 7</td>
<td class=br><strong>11</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ju Tihomirovs</td><td class=kL>1:9</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=br>29:57</td><td class=br>-28</td>
<td class=bc>3 - 0 - 10</td>
<td class=br><strong>6</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>As Kocere</td><td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=br>26:55</td><td class=br>-29</td>
<td class=bc>2 - 0 - 11</td>
<td class=br><strong>4</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ra Meija</td><td class=kL>0:9</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=br>3:66</td><td class=br>-63</td>
<td class=bc>0 - 1 - 12</td>
<td class=br><strong>1</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ge Jansons</td><td class=kL>2:8</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>0:10</td>
<td class=kL>0:8</td>
<td class=kL>0:9</td>
<td class=kL>0:10</td>
<td class=kL>1:11</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=br>10:82</td><td class=br>-72</td>
<td class=bc>0 - 1 - 12</td>
<td class=br><strong>1</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Ju Tihomirovs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Hermansson</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Al Kalni��</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ju Tihomirovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Al Hermansson</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ju Tihomirovs</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Al Hermansson</td><td class=bc>-</td><td class=blW>Ni Lyksholm</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>As Kocere</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ju Tihomirovs</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Gu Ern�teins</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Al Hermansson</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ju Tihomirovs</td><td class=bc>-</td><td class=blW>Ni Lyksholm</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Hermansson</td><td class=bc>-</td><td class=bl>Al Kalni��</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ju Tihomirovs</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>Al Kalni��</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>9 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Ni Lyksholm</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ju Tihomirovs</td><td class=bc>-</td><td class=blW>Al Kalni��</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ni Lyksholm</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Al Kalni��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Ju Tihomirovs</td><td class=bc>-</td><td class=blW>Al Hermansson</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Al Kalni��</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ju Tihomirovs</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Al Kalni��</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Al Hermansson</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Al Kalni��</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Al Hermansson</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Ju Tihomirovs</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Al Kalni��</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>11 : 1</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>Gu Ern�teins</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Ju Tihomirovs</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Al Hermansson</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=blW>Gu Ern�teins</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Ju Tihomirovs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Al Hermansson</td><td class=bc>-</td><td class=blW>Gu Ern�teins</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Ju Tihomirovs</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Al Hermansson</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Ju Tihomirovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>4 : 8</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>4 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group F</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>El Sili��</td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=br>52:23</td><td class=br>+29</td>
<td class=bc>11 - 2 - 0</td>
<td class=br><strong>24</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ma Jakseboga</td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>8:1</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>9:0</td>
<td class=br>52:20</td><td class=br>+32</td>
<td class=bc>10 - 1 - 2</td>
<td class=br><strong>21</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Gu Hermansson</td><td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=kW>9:0</td>
<td class=br>55:26</td><td class=br>+29</td>
<td class=bc>9 - 3 - 1</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>El �delis</td><td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=br>42:19</td><td class=br>+23</td>
<td class=bc>8 - 4 - 1</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ra Kuha�skis</td><td class=kL>1:4</td>
<td class=kL>1:8</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>10:1</td>
<td class=br>47:37</td><td class=br>+10</td>
<td class=bc>7 - 1 - 5</td>
<td class=br><strong>15</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Iv �irsis</td><td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>6:4</td>
<td class=kW>6:2</td>
<td class=kW>8:1</td>
<td class=kW>7:1</td>
<td class=br>46:27</td><td class=br>+19</td>
<td class=bc>7 - 1 - 4</td>
<td class=br><strong>15</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Mi Saul�tis</td><td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=kW>7:0</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=br>42:31</td><td class=br>+11</td>
<td class=bc>6 - 3 - 3</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>To Jakseboga</td><td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>0:7</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=br>32:32</td><td class=br>0</td>
<td class=bc>5 - 3 - 5</td>
<td class=br><strong>13</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>J� Zem�ickis</td><td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=br>25:35</td><td class=br>-10</td>
<td class=bc>4 - 3 - 6</td>
<td class=br><strong>11</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>L� Bezdel�ga</td><td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>8:2</td>
<td class=br>25:38</td><td class=br>-13</td>
<td class=bc>4 - 1 - 8</td>
<td class=br><strong>9</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>D� Vesele</td><td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>4:5</td>
<td class=kL>4:6</td>
<td class=kL>3:6</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=br>30:44</td><td class=br>-14</td>
<td class=bc>2 - 2 - 9</td>
<td class=br><strong>6</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Gi Remeika</td><td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>5:0</td>
<td class=br>27:46</td><td class=br>-19</td>
<td class=bc>1 - 4 - 8</td>
<td class=br><strong>6</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ed Jansons</td><td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>13:45</td><td class=br>-32</td>
<td class=bc>2 - 0 - 11</td>
<td class=br><strong>4</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Au Liepi��</td><td class=kL>2:5</td>
<td class=kL>0:9</td>
<td class=kL>0:9</td>
<td class=kL>1:6</td>
<td class=kL>1:10</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>2:8</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>13:78</td><td class=br>-65</td>
<td class=bc>0 - 0 - 13</td>
<td class=br><strong>0</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>El �delis</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Ed Jansons</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Au Liepi��</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>El �delis</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Au Liepi��</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ed Jansons</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>El �delis</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Au Liepi��</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Au Liepi��</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>El �delis</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ed Jansons</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Au Liepi��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>El �delis</td><td class=bc>-</td><td class=bl>Ed Jansons</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Au Liepi��</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ed Jansons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>El �delis</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Gi Remeika</td><td class=bc>-</td><td class=bl>Au Liepi��</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Ed Jansons</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Au Liepi��</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ed Jansons</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Au Liepi��</td><td class=bc>-</td><td class=blW>Ed Jansons</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>El �delis</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Ed Jansons</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Au Liepi��</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ed Jansons</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Au Liepi��</td><td class=bc>-</td><td class=blW>El �delis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ed Jansons</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Au Liepi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>El �delis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ed Jansons</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Au Liepi��</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Jansons</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Au Liepi��</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>El �delis</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ed Jansons</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>3 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group 1.Liga A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/8</td><td class=d>1.</td><td class=kt>Jo Pleikys</td><td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>1/8</td><td class=d>2.</td><td class=kt>J� Kaln�vics</td><td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>1/8</td><td class=d>3.</td><td class=kt>An Liepi��</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>1/8</td><td class=d>4.</td><td class=kt>Am Fylling</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>1/8</td><td class=d>5.</td><td class=kt>Al Sili��</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>1/8</td><td class=d>6.</td><td class=kt>Ro Kerns</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>1/8</td><td class=d>7.</td><td class=kt>Va Smagars</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>1/8</td><td class=d>8.</td><td class=kt>Pa Strods</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>1/8</td><td class=d>9.</td><td class=kt>Ed Putni��</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>1/8</td><td class=d>10.</td><td class=kt>Al Skudr�tis</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>1/8</td><td class=d>11.</td><td class=kt>Ka �iha�ova</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>1/8</td><td class=d>12.</td><td class=kt>Se Mihejevs</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>1/8</td><td class=d>13.</td><td class=kt>Sa Kalni��</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>1/8</td><td class=d>14.</td><td class=kt>Ra Kalni��</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>1/8</td><td class=d>15.</td><td class=kt>D� Apfelbaums</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>1/8</td><td class=d>16.</td><td class=kt>J� Bitmanis</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ar Zasurcevs</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>J� Re�is</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Kr Naglis</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Il Pavlovskis</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Kr Zem�ickis</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Ro Fa�ken�teins</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Je Zaharovs</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Il �irse</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Kaln�vics</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Kaln�vics</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Kaln�vics</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Kaln�vics</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Kaln�vics</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Kaln�vics</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Kaln�vics</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Kaln�vics</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Kaln�vics</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Kaln�vics</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Kaln�vics</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=br>J� Kaln�vics</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 1.Liga B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Ni Lyksholm</td><td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Gu Hermansson</td><td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Ed Ka�eps</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>R� Kamzols</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Iv �irsis</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Au Pleikys</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Zy Remeika</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>To Jakseboga</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Sa Krasts</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Sa Skarainis</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Kr Lagzdi�a</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Gu Ern�teins</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Marg �bele</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Al �ernovojs</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>El Sili��</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Ma Jakseboga</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ra Kuha�skis</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>He Prokuratovs</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Ra Martu��ns</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Ed Naglis</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Ig Saveljev</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Mi Saul�tis</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>El �delis</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>K� Balodis</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>El �delis</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El �delis</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El �delis</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El �delis</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El �delis</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El �delis</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El �delis</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El �delis</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El �delis</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El �delis</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El �delis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El �delis</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 2.Liga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Em Reinfelds</td><td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Re Saul�tis</td><td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Ju Tihomirovs</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Er Kalni��</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ni Sviklis</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Da Baumanis</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>As Kocere</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ag Pav�rs</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Kr Kurzemnieks</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>El Reinfelds</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Gi Remeika</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ro Aseri��</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Br Gor�anovs</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Al Sili��</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Al Kalni��</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Al Hermansson</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ai Romals</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>J� Zem�ickis</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>�v Vikmanis</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>In Garan�s</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Fr Platons</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>L� Bezdel�ga</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>M� �irsis</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>D� Vesele</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>Ju Tihomirovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Hermansson</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Ju Tihomirovs</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Hermansson</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=bl>Ju Tihomirovs</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=bl>Ju Tihomirovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=bl>Ju Tihomirovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>Ju Tihomirovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>Ju Tihomirovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Ju Tihomirovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>Ju Tihomirovs</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ju Tihomirovs</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Al Hermansson</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=bl>Em Reinfelds</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>Ju Tihomirovs</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>26</td></tr>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>27</td></tr>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ju Tihomirovs</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=bl>Al Kalni��</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>28</td></tr>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Hermansson</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>29</td></tr>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>30</td></tr>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=bl>Ju Tihomirovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>31</td></tr>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>Em Reinfelds</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>Al Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>32</td></tr>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Hermansson</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>33</td></tr>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ju Tihomirovs</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>34</td></tr>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>35</td></tr>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Ju Tihomirovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>Al Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>36</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Em Reinfelds</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>37</td></tr>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Hermansson</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>38</td></tr>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ju Tihomirovs</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>39</td></tr>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>40</td></tr>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Em Reinfelds</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Ju Tihomirovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>Al Kalni��</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>41</td></tr>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>42</td></tr>
<tr><td class=br>Al Hermansson</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>43</td></tr>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ju Tihomirovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>44</td></tr>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=bl>Al Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>45</td></tr>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Em Reinfelds</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>46</td></tr>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>Ju Tihomirovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>47</td></tr>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Hermansson</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>48</td></tr>
<tr><td class=br>Ju Tihomirovs</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>49</td></tr>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Al Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>Em Reinfelds</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>50</td></tr>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>51</td></tr>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=bl>Ju Tihomirovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>52</td></tr>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Hermansson</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>53</td></tr>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Em Reinfelds</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>54</td></tr>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Al Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>55</td></tr>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>56</td></tr>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ju Tihomirovs</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>57</td></tr>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Hermansson</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>58</td></tr>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Em Reinfelds</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=bl>Ju Tihomirovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>59</td></tr>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>Al Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>60</td></tr>
<tr><td class=br>Ju Tihomirovs</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
