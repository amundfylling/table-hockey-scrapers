<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Latvijas Kauss 3.posms</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../25LK3/Latvijas_Kauss_3.posms_index.php">Latvijas Kauss 3.posms, 15. February 2025</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group LK A grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Al Skudr�tis</td><td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=br>46:23</td><td class=br>+23</td>
<td class=bc>8 - 3 - 1</td>
<td class=br><strong>19</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Kr Naglis</td><td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=br>47:34</td><td class=br>+13</td>
<td class=bc>9 - 1 - 2</td>
<td class=br><strong>19</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ed Ka�eps</td><td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kW>7:5</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kL>3:7</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=br>46:29</td><td class=br>+17</td>
<td class=bc>6 - 4 - 2</td>
<td class=br><strong>16</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Va Smagars</td><td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kL>5:7</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=br>48:35</td><td class=br>+13</td>
<td class=bc>6 - 4 - 2</td>
<td class=br><strong>16</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ro Kerns</td><td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=br>37:32</td><td class=br>+5</td>
<td class=bc>5 - 4 - 3</td>
<td class=br><strong>14</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ni Sviklis</td><td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=br>37:33</td><td class=br>+4</td>
<td class=bc>6 - 2 - 4</td>
<td class=br><strong>14</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Sa Krasts</td><td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kW>7:3</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=br>37:31</td><td class=br>+6</td>
<td class=bc>6 - 1 - 5</td>
<td class=br><strong>13</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Kr Zem�ickis</td><td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=br>29:25</td><td class=br>+4</td>
<td class=bc>5 - 2 - 5</td>
<td class=br><strong>12</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Sa Skarainis</td><td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=br>33:33</td><td class=br>0</td>
<td class=bc>5 - 1 - 6</td>
<td class=br><strong>11</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ei G�ze</td><td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kT>0:0</td>
<td class=br>23:30</td><td class=br>-7</td>
<td class=bc>2 - 5 - 5</td>
<td class=br><strong>9</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ka �iha�ova</td><td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=br>26:38</td><td class=br>-12</td>
<td class=bc>3 - 2 - 7</td>
<td class=br><strong>8</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ro Aseri��</td><td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>13:52</td><td class=br>-39</td>
<td class=bc>1 - 2 - 9</td>
<td class=br><strong>4</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>J� Zem�ickis</td><td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kT>0:0</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>13:40</td><td class=br>-27</td>
<td class=bc>0 - 1 - 11</td>
<td class=br><strong>1</strong></td><td class=d>13.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>Sviklis Nikl�vs P�teris</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Sviklis Nikl�vs P�teris</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>3 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Kerns Roberts</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Kerns Roberts</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>5 : 7</tr></td>
<tr><td class=brW>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Aseri�� Roberts</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Kerns Roberts</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kerns Roberts</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kerns Roberts</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Sviklis Nikl�vs P�teris</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>3 : 7</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group LK B grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Re Vazoli��</td><td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>6:5</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=br>40:25</td><td class=br>+15</td>
<td class=bc>8 - 3 - 1</td>
<td class=br><strong>19</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ar Zasurcevs</td><td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>5:4</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=br>40:32</td><td class=br>+8</td>
<td class=bc>8 - 0 - 4</td>
<td class=br><strong>16</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ma Jakseboga</td><td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=br>33:27</td><td class=br>+6</td>
<td class=bc>6 - 4 - 2</td>
<td class=br><strong>16</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>El Sili��</td><td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=br>27:16</td><td class=br>+11</td>
<td class=bc>6 - 3 - 3</td>
<td class=br><strong>15</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Il �irse</td><td class=kL>0:4</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=br>32:30</td><td class=br>+2</td>
<td class=bc>6 - 2 - 4</td>
<td class=br><strong>14</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Fi Buhtujevs</td><td class=kL>0:4</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=br>33:23</td><td class=br>+10</td>
<td class=bc>6 - 1 - 5</td>
<td class=br><strong>13</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Mi Saul�tis</td><td class=kL>5:6</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=br>36:36</td><td class=br>0</td>
<td class=bc>4 - 4 - 4</td>
<td class=br><strong>12</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Ra Kuha�skis</td><td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=kW>10:3</td>
<td class=br>42:40</td><td class=br>+2</td>
<td class=bc>4 - 4 - 4</td>
<td class=br><strong>12</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ka Vi�ums</td><td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kW>4:0</td>
<td class=br>24:24</td><td class=br>0</td>
<td class=bc>4 - 3 - 5</td>
<td class=br><strong>11</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>In Garan�s</td><td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=br>28:36</td><td class=br>-8</td>
<td class=bc>2 - 5 - 5</td>
<td class=br><strong>9</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ai Romals</td><td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=br>31:43</td><td class=br>-12</td>
<td class=bc>4 - 0 - 8</td>
<td class=br><strong>8</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>To Jakseboga</td><td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kL>4:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>27:34</td><td class=br>-7</td>
<td class=bc>3 - 2 - 7</td>
<td class=br><strong>8</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>�v Vikmanis</td><td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>0:0</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>3:10</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>17:44</td><td class=br>-27</td>
<td class=bc>0 - 3 - 9</td>
<td class=br><strong>3</strong></td><td class=d>13.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Buhtujevs Filips</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Vi�ums Kaspars</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>4 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Buhtujevs Filips</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>�irse Ilze</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Buhtujevs Filips</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Buhtujevs Filips</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=blW>Romals Aigars</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Buhtujevs Filips</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Garan�s Intars</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>3 : 10</tr></td>
<tr><td class=brW>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Buhtujevs Filips</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=blW>Buhtujevs Filips</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=blW>Garan�s Intars</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Buhtujevs Filips</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>�irse Ilze</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Buhtujevs Filips</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Buhtujevs Filips</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Buhtujevs Filips</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>�irse Ilze</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>5 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Buhtujevs Filips</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>�irse Ilze</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group LK C grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>An Liepi��</td><td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>8:1</td>
<td class=kW>5:1</td>
<td class=br>55:17</td><td class=br>+38</td>
<td class=bc>12 - 0 - 1</td>
<td class=br><strong>24</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>R� Kamzols</td><td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>8:1</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=br>49:25</td><td class=br>+24</td>
<td class=bc>10 - 2 - 1</td>
<td class=br><strong>22</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Em Liepi��</td><td class=kL>1:6</td>
<td class=kL>1:8</td>
<td class=kx>*</td>
<td class=kW>7:2</td>
<td class=kW>2:0</td>
<td class=kW>8:1</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=br>51:33</td><td class=br>+18</td>
<td class=bc>8 - 2 - 3</td>
<td class=br><strong>18</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Sa Kalni��</td><td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>2:7</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=br>40:27</td><td class=br>+13</td>
<td class=bc>8 - 2 - 3</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>He Prokuratovs</td><td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=br>44:37</td><td class=br>+7</td>
<td class=bc>7 - 2 - 4</td>
<td class=br><strong>16</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>El R�cen�ja</td><td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kW>6:3</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=br>46:43</td><td class=br>+3</td>
<td class=bc>7 - 1 - 5</td>
<td class=br><strong>15</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Al Sili��</td><td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>6:3</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>7:1</td>
<td class=kW>7:2</td>
<td class=br>53:41</td><td class=br>+12</td>
<td class=bc>7 - 0 - 6</td>
<td class=br><strong>14</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>J� Liepi��</td><td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=br>33:34</td><td class=br>-1</td>
<td class=bc>5 - 2 - 6</td>
<td class=br><strong>12</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Marg �bele</td><td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=br>33:34</td><td class=br>-1</td>
<td class=bc>5 - 2 - 6</td>
<td class=br><strong>12</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ed Putni��</td><td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=br>37:38</td><td class=br>-1</td>
<td class=bc>4 - 1 - 8</td>
<td class=br><strong>9</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Iv �irsis</td><td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=br>24:40</td><td class=br>-16</td>
<td class=bc>3 - 2 - 8</td>
<td class=br><strong>8</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ar Salmi��</td><td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kT>4:4</td>
<td class=kL>2:7</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=br>27:51</td><td class=br>-24</td>
<td class=bc>2 - 2 - 9</td>
<td class=br><strong>6</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ar Verbi�s</td><td class=kL>1:8</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=br>20:61</td><td class=br>-41</td>
<td class=bc>2 - 1 - 10</td>
<td class=br><strong>5</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>L� Bezdel�ga</td><td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=br>24:55</td><td class=br>-31</td>
<td class=bc>1 - 1 - 11</td>
<td class=br><strong>3</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Putni�� Edgars</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Liepi�� J�nis D�vis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Liepi�� J�nis D�vis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Liepi�� J�nis D�vis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Salmi�� Arnis</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Liepi�� J�nis D�vis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Liepi�� J�nis D�vis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Liepi�� J�nis D�vis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Salmi�� Arnis</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Liepi�� J�nis D�vis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Liepi�� J�nis D�vis</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Liepi�� J�nis D�vis</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Liepi�� J�nis D�vis</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Liepi�� J�nis D�vis</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Liepi�� J�nis D�vis</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Liepi�� J�nis D�vis</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Liepi�� J�nis D�vis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group LK D grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ed Naglis</td><td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>10:2</td>
<td class=kL>1:6</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>9:5</td>
<td class=br>57:33</td><td class=br>+24</td>
<td class=bc>9 - 3 - 1</td>
<td class=br><strong>21</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Kr Lagzdi�a</td><td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>8:1</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>7:0</td>
<td class=br>54:22</td><td class=br>+32</td>
<td class=bc>9 - 1 - 3</td>
<td class=br><strong>19</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>J� Re�is</td><td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>11:1</td>
<td class=br>50:23</td><td class=br>+27</td>
<td class=bc>8 - 2 - 3</td>
<td class=br><strong>18</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Se Mihejevs</td><td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>7:0</td>
<td class=br>35:19</td><td class=br>+16</td>
<td class=bc>9 - 0 - 4</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ro Rieksti��</td><td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kW>8:1</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=br>43:23</td><td class=br>+20</td>
<td class=bc>7 - 2 - 4</td>
<td class=br><strong>16</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ro Fa�ken�teins</td><td class=kL>2:4</td>
<td class=kL>1:8</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=br>39:34</td><td class=br>+5</td>
<td class=bc>8 - 0 - 5</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Al �ernovojs</td><td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>9:2</td>
<td class=kW>5:1</td>
<td class=br>37:25</td><td class=br>+12</td>
<td class=bc>7 - 2 - 4</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Ri Kalni��</td><td class=kL>2:10</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=br>37:37</td><td class=br>0</td>
<td class=bc>7 - 1 - 5</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ro Verbi�s</td><td class=kW>6:1</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>0:6</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=br>35:30</td><td class=br>+5</td>
<td class=bc>7 - 0 - 6</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Gu Ern�teins</td><td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kW>6:0</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>9:0</td>
<td class=br>39:39</td><td class=br>0</td>
<td class=bc>3 - 3 - 7</td>
<td class=br><strong>9</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Kr Kurzemnieks</td><td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>1:8</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=br>23:41</td><td class=br>-18</td>
<td class=bc>3 - 1 - 9</td>
<td class=br><strong>7</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>�i Vazoli��</td><td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=br>23:39</td><td class=br>-16</td>
<td class=bc>3 - 1 - 9</td>
<td class=br><strong>7</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ed Ern�teins</td><td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>2:9</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=br>19:61</td><td class=br>-42</td>
<td class=bc>2 - 0 - 11</td>
<td class=br><strong>4</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>J� Rekti��</td><td class=kL>5:9</td>
<td class=kL>0:7</td>
<td class=kL>1:11</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kL>0:9</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=br>18:83</td><td class=br>-65</td>
<td class=bc>1 - 0 - 12</td>
<td class=br><strong>2</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ern�teins Edgars</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>2 : 9</tr></td>
<tr><td class=brW>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Rekti�� J�nis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ern�teins Edgars</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ern�teins Edgars</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ern�teins Guntis</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ern�teins Edgars</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ern�teins Guntis</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ern�teins Edgars</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 11</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ern�teins Edgars</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ern�teins Guntis</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ern�teins Edgars</td><td class=bc>-</td><td class=bl>Ern�teins Guntis</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Ern�teins Guntis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>10 : 2</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Ern�teins Guntis</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=bl>Ern�teins Guntis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Ern�teins Guntis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Ern�teins Guntis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>9 : 5</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ern�teins Guntis</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group LK 1.l�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>An Liepi��</td><td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>3:1 K</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kL>1:3</td>
<td class=kW>6:1 K</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kL>1:2 K</td>
<td class=kT>4:4</td>
<td class=kW>4:0 K</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>6:2 K</td>
<td class=kW>5:0</td>
<td class=kW>6:4</td>
<td class=kW>7:1</td>
<td class=br>90:36</td><td class=br>+54</td>
<td class=bc>16 - 4 - 3</td>
<td class=br><strong>36</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Kr Lagzdi�a</td><td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>3:4 K</td>
<td class=kL>2:5</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>9:3</td>
<td class=kL>1:2 K</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>3:2 K</td>
<td class=kW>8:4</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kW>3:1 K</td>
<td class=kW>4:2</td>
<td class=kW>8:1 K</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>10:2</td>
<td class=br>100:56</td><td class=br>+44</td>
<td class=bc>17 - 0 - 6</td>
<td class=br><strong>34</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Ed Naglis</td><td class=kL>1:5</td>
<td class=kW>4:3 K</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>5:6</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kW>3:1 K</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kT>3:3 K</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>4:1 K</td>
<td class=kW>5:2</td>
<td class=kW>4:2 K</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>7:2</td>
<td class=kT>3:3</td>
<td class=kW>9:1</td>
<td class=br>85:63</td><td class=br>+22</td>
<td class=bc>14 - 5 - 4</td>
<td class=br><strong>33</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>Re Vazoli��</td><td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kT>4:4</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3 K</td>
<td class=kW>5:3</td>
<td class=kL>4:5</td>
<td class=kW>2:1</td>
<td class=kW>4:0 K</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:4 K</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kW>4:0 K</td>
<td class=kW>3:2</td>
<td class=br>76:46</td><td class=br>+30</td>
<td class=bc>14 - 5 - 4</td>
<td class=br><strong>33</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Ed Ka�eps</td><td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kW>6:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kT>1:1 K</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>6:2 K</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=kW>7:5 K</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kT>4:4 K</td>
<td class=kW>6:1</td>
<td class=kL>2:3 K</td>
<td class=br>87:61</td><td class=br>+26</td>
<td class=bc>12 - 6 - 5</td>
<td class=br><strong>30</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>El Sili��</td><td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kL>1:3 K</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1 K</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>6:0</td>
<td class=kW>3:2 K</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>4:1 K</td>
<td class=kT>3:3</td>
<td class=br>65:45</td><td class=br>+20</td>
<td class=bc>11 - 8 - 4</td>
<td class=br><strong>30</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>R� Kamzols</td><td class=kL>1:3 K</td>
<td class=kL>3:9</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>7:4</td>
<td class=kT>2:2</td>
<td class=kL>4:6</td>
<td class=kW>8:1 K</td>
<td class=kW>5:1</td>
<td class=kW>7:4</td>
<td class=kT>3:3 K</td>
<td class=kT>3:3</td>
<td class=kW>6:2 K</td>
<td class=kW>5:2</td>
<td class=kW>6:3</td>
<td class=kW>5:2 K</td>
<td class=kW>6:5</td>
<td class=kW>6:5</td>
<td class=kW>5:4</td>
<td class=br>102:80</td><td class=br>+22</td>
<td class=bc>12 - 5 - 6</td>
<td class=br><strong>29</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Ro Rieksti��</td><td class=kL>1:5</td>
<td class=kW>2:1 K</td>
<td class=kL>1:3 K</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3 K</td>
<td class=kW>5:0</td>
<td class=kW>6:4</td>
<td class=kL>3:5</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kL>0:2 K</td>
<td class=kL>1:3</td>
<td class=kW>4:1 K</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=br>69:51</td><td class=br>+18</td>
<td class=bc>13 - 3 - 7</td>
<td class=br><strong>29</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>Al Skudr�tis</td><td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1 K</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kW>7:3 K</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>4:4 K</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kW>4:1 K</td>
<td class=kW>6:3</td>
<td class=kT>3:3 K</td>
<td class=br>70:55</td><td class=br>+15</td>
<td class=bc>10 - 8 - 5</td>
<td class=br><strong>28</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Ma Jakseboga</td><td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kT>3:3 K</td>
<td class=kW>4:1</td>
<td class=kW>3:1 K</td>
<td class=kL>4:7</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kW>2:1 K</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>3:6 K</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>5:4 K</td>
<td class=kW>5:4</td>
<td class=br>72:64</td><td class=br>+8</td>
<td class=bc>12 - 4 - 7</td>
<td class=br><strong>28</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>J� Re�is</td><td class=kL>0:4</td>
<td class=kL>2:3 K</td>
<td class=kT>3:3 K</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kT>3:3 K</td>
<td class=kW>4:3</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0 K</td>
<td class=kW>4:1</td>
<td class=kL>3:4 K</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>11:4</td>
<td class=br>78:59</td><td class=br>+19</td>
<td class=bc>11 - 4 - 8</td>
<td class=br><strong>26</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>Kr Naglis</td><td class=kW>3:1</td>
<td class=kL>4:8</td>
<td class=kL>2:5</td>
<td class=kW>5:4</td>
<td class=kL>2:6 K</td>
<td class=kT>2:2</td>
<td class=kW>6:4</td>
<td class=kL>0:5</td>
<td class=kL>3:7 K</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kW>3:1 K</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3 K</td>
<td class=kW>4:0</td>
<td class=kW>4:3 K</td>
<td class=br>69:71</td><td class=br>-2</td>
<td class=bc>10 - 4 - 9</td>
<td class=br><strong>24</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>Em Liepi��</td><td class=kL>1:6 K</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kL>1:8 K</td>
<td class=kL>4:6</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>7:2 K</td>
<td class=kT>2:2</td>
<td class=kW>2:0 K</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>8:1 K</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kL>3:5</td>
<td class=br>71:62</td><td class=br>+9</td>
<td class=bc>10 - 4 - 9</td>
<td class=br><strong>24</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>Fi Buhtujevs</td><td class=kL>2:7</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kL>0:4 K</td>
<td class=kL>0:5</td>
<td class=kL>1:3 K</td>
<td class=kL>1:5</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kL>1:2 K</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>6:4</td>
<td class=kW>3:2</td>
<td class=kL>4:5 K</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2 K</td>
<td class=kW>3:1</td>
<td class=br>63:69</td><td class=br>-6</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>Va Smagars</td><td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>5:7 K</td>
<td class=kL>3:4</td>
<td class=kL>4:7</td>
<td class=kL>4:5</td>
<td class=kT>4:4 K</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>1:3 K</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>7:0</td>
<td class=kW>5:3 K</td>
<td class=kW>7:1</td>
<td class=kW>5:2 K</td>
<td class=br>83:77</td><td class=br>+6</td>
<td class=bc>8 - 4 - 11</td>
<td class=br><strong>20</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>Sa Kalni��</td><td class=kW>2:1 K</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kT>3:3 K</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>2:7 K</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>2:4 K</td>
<td class=kW>3:0</td>
<td class=kL>4:8</td>
<td class=kW>4:2 K</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=br>46:65</td><td class=br>-19</td>
<td class=bc>7 - 5 - 11</td>
<td class=br><strong>19</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Se Mihejevs</td><td class=kT>4:4</td>
<td class=kL>1:3 K</td>
<td class=kL>1:4 K</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>2:0 K</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>0:5 K</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:0 K</td>
<td class=kL>1:5</td>
<td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=br>45:58</td><td class=br>-13</td>
<td class=bc>7 - 4 - 12</td>
<td class=br><strong>18</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>He Prokuratovs</td><td class=kL>0:4 K</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>2:6 K</td>
<td class=kW>3:1</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kL>0:2 K</td>
<td class=kL>4:6</td>
<td class=kT>2:2</td>
<td class=kW>4:2 K</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kT>5:5</td>
<td class=kL>3:6 K</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=br>56:80</td><td class=br>-24</td>
<td class=bc>4 - 7 - 12</td>
<td class=br><strong>15</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Ro Fa�ken�teins</td><td class=kL>1:2</td>
<td class=kL>1:8 K</td>
<td class=kL>2:4 K</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>1:4 K</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:3 K</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>0:2 K</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=br>46:80</td><td class=br>-34</td>
<td class=bc>6 - 2 - 15</td>
<td class=br><strong>14</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Ar Zasurcevs</td><td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>4:5 K</td>
<td class=kL>3:5</td>
<td class=kL>2:3 K</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kW>6:3 K</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kW>5:4 K</td>
<td class=kL>1:6</td>
<td class=kW>8:4</td>
<td class=kW>5:1</td>
<td class=kT>5:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3 K</td>
<td class=kW>11:3</td>
<td class=br>76:88</td><td class=br>-12</td>
<td class=bc>6 - 2 - 15</td>
<td class=br><strong>14</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>21.</td><td class=kt>El R�cen�ja</td><td class=kL>2:6 K</td>
<td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>2:5 K</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kL>1:8 K</td>
<td class=kL>2:4</td>
<td class=kL>0:7</td>
<td class=kL>2:4 K</td>
<td class=kL>0:5</td>
<td class=kW>6:3 K</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>8:2</td>
<td class=kL>1:2</td>
<td class=br>57:95</td><td class=br>-38</td>
<td class=bc>5 - 3 - 15</td>
<td class=br><strong>13</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>22.</td><td class=kt>Ro Kerns</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kT>4:4 K</td>
<td class=kL>1:6</td>
<td class=kL>5:6</td>
<td class=kL>0:3</td>
<td class=kL>1:4 K</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kT>3:3 K</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kL>3:5 K</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>4:3 K</td>
<td class=br>44:85</td><td class=br>-41</td>
<td class=bc>5 - 3 - 15</td>
<td class=br><strong>13</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>23.</td><td class=kt>Il �irse</td><td class=kL>4:6</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>0:4 K</td>
<td class=kL>1:6</td>
<td class=kL>1:4 K</td>
<td class=kL>5:6</td>
<td class=kL>2:5</td>
<td class=kL>3:6</td>
<td class=kL>4:5 K</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>1:7</td>
<td class=kW>2:1 K</td>
<td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1 K</td>
<td class=kL>2:8</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=br>45:94</td><td class=br>-49</td>
<td class=bc>4 - 1 - 18</td>
<td class=br><strong>9</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>24.</td><td class=kt>Ni Sviklis</td><td class=kL>1:7</td>
<td class=kL>2:10</td>
<td class=kL>1:9</td>
<td class=kL>2:3</td>
<td class=kW>3:2 K</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kT>3:3 K</td>
<td class=kL>4:5</td>
<td class=kL>4:11</td>
<td class=kL>3:4 K</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kL>2:5 K</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>3:11</td>
<td class=kW>2:1</td>
<td class=kL>3:4 K</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=br>55:110</td><td class=br>-55</td>
<td class=bc>3 - 3 - 17</td>
<td class=br><strong>9</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Buhtujevs Filips</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kerns Roberts</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kerns Roberts</td><td class=bc>-</td><td class=bl>Buhtujevs Filips</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Liepi�� Andris</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Buhtujevs Filips</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>3 : 11</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Buhtujevs Filips</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>4 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Buhtujevs Filips</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Buhtujevs Filips</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Buhtujevs Filips</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kerns Roberts</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Buhtujevs Filips</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Buhtujevs Filips</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>4 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Buhtujevs Filips</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Buhtujevs Filips</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Buhtujevs Filips</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Buhtujevs Filips</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Buhtujevs Filips</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Buhtujevs Filips</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>10 : 2</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Buhtujevs Filips</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Kerns Roberts</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Buhtujevs Filips</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>11 : 4</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Buhtujevs Filips</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>5 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group LK 2.l�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Al �ernovojs</td><td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kT>0:0</td>
<td class=kW>5:4</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kT>5:5</td>
<td class=kT>1:1</td>
<td class=br>56:35</td><td class=br>+21</td>
<td class=bc>12 - 6 - 1</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Sa Skarainis</td><td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>7:3</td>
<td class=kT>4:4</td>
<td class=kL>4:6</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=br>72:40</td><td class=br>+32</td>
<td class=bc>12 - 4 - 3</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Mi Saul�tis</td><td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kL>4:8</td>
<td class=kW>5:4</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kW>6:3</td>
<td class=kW>3:0</td>
<td class=kW>8:4</td>
<td class=kW>6:0</td>
<td class=br>77:48</td><td class=br>+29</td>
<td class=bc>11 - 3 - 5</td>
<td class=br><strong>25</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Ra Kuha�skis</td><td class=kL>3:5</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>9:1</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=br>62:51</td><td class=br>+11</td>
<td class=bc>11 - 2 - 6</td>
<td class=br><strong>24</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Sa Krasts</td><td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>8:1</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>7:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=br>55:36</td><td class=br>+19</td>
<td class=bc>9 - 5 - 5</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Gu Ern�teins</td><td class=kT>1:1</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kW>1:0</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kW>6:1</td>
<td class=kW>7:5</td>
<td class=kW>1:0</td>
<td class=br>53:51</td><td class=br>+2</td>
<td class=bc>9 - 5 - 5</td>
<td class=br><strong>23</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Iv �irsis</td><td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kL>0:6</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=br>48:49</td><td class=br>-1</td>
<td class=bc>8 - 6 - 5</td>
<td class=br><strong>22</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ka Vi�ums</td><td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>1:9</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=br>42:55</td><td class=br>-13</td>
<td class=bc>8 - 5 - 6</td>
<td class=br><strong>21</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Al Sili��</td><td class=kL>4:5</td>
<td class=kL>3:7</td>
<td class=kW>8:4</td>
<td class=kW>4:3</td>
<td class=kL>1:8</td>
<td class=kW>6:3</td>
<td class=kL>2:5</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kL>3:7</td>
<td class=kW>7:5</td>
<td class=kW>8:3</td>
<td class=kW>11:3</td>
<td class=kW>7:6</td>
<td class=kW>8:3</td>
<td class=kW>10:6</td>
<td class=kW>7:3</td>
<td class=kL>8:11</td>
<td class=kL>2:5</td>
<td class=br>106:97</td><td class=br>+9</td>
<td class=bc>10 - 0 - 9</td>
<td class=br><strong>20</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Kr Zem�ickis</td><td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kL>4:5</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=br>51:50</td><td class=br>+1</td>
<td class=bc>8 - 3 - 8</td>
<td class=br><strong>19</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ed Putni��</td><td class=kL>2:3</td>
<td class=kW>6:4</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kL>4:5</td>
<td class=kW>6:1</td>
<td class=kW>7:3</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kT>8:8</td>
<td class=kL>2:3</td>
<td class=kT>7:7</td>
<td class=kW>5:2</td>
<td class=br>81:69</td><td class=br>+12</td>
<td class=bc>8 - 2 - 9</td>
<td class=br><strong>18</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ri Kalni��</td><td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kL>5:7</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kW>4:2</td>
<td class=br>54:49</td><td class=br>+5</td>
<td class=bc>8 - 2 - 9</td>
<td class=br><strong>18</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Kr Kurzemnieks</td><td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>3:8</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=br>49:61</td><td class=br>-12</td>
<td class=bc>7 - 3 - 9</td>
<td class=br><strong>17</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>In Garan�s</td><td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kL>3:11</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=br>53:56</td><td class=br>-3</td>
<td class=bc>7 - 3 - 9</td>
<td class=br><strong>17</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Ai Romals</td><td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kL>6:7</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=br>46:58</td><td class=br>-12</td>
<td class=bc>6 - 4 - 9</td>
<td class=br><strong>16</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Marg �bele</td><td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>3:8</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kW>5:4</td>
<td class=br>51:66</td><td class=br>-15</td>
<td class=bc>7 - 1 - 11</td>
<td class=br><strong>15</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>17.</td><td class=kt>Ro Verbi�s</td><td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>6:10</td>
<td class=kW>3:2</td>
<td class=kT>8:8</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=br>64:69</td><td class=br>-5</td>
<td class=bc>6 - 3 - 10</td>
<td class=br><strong>15</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>18.</td><td class=kt>J� Liepi��</td><td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kL>3:7</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=br>32:58</td><td class=br>-26</td>
<td class=bc>4 - 3 - 12</td>
<td class=br><strong>11</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>19.</td><td class=kt>Ka �iha�ova</td><td class=kT>5:5</td>
<td class=kT>1:1</td>
<td class=kL>4:8</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>5:7</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>11:8</td>
<td class=kL>1:3</td>
<td class=kT>7:7</td>
<td class=kL>0:7</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=br>58:80</td><td class=br>-22</td>
<td class=bc>3 - 4 - 12</td>
<td class=br><strong>10</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>20.</td><td class=kt>Ei G�ze</td><td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>4:5</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=br>38:70</td><td class=br>-32</td>
<td class=bc>2 - 4 - 13</td>
<td class=br><strong>8</strong></td><td class=d>20.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>7 : 6</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Ern�teins Guntis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Putni�� Edgars</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Liepi�� J�nis D�vis</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Romals Aigars</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Ern�teins Guntis</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Liepi�� J�nis D�vis</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=bl>Ern�teins Guntis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>11 : 3</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Liepi�� J�nis D�vis</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=bl>Ern�teins Guntis</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>10 : 6</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Vi�ums Kaspars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Liepi�� J�nis D�vis</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=blW>Ern�teins Guntis</td><td class=bc>5 : 7</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Putni�� Edgars</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Vi�ums Kaspars</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Liepi�� J�nis D�vis</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=blW>Garan�s Intars</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>7 : 5</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Liepi�� J�nis D�vis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=blW>Garan�s Intars</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Liepi�� J�nis D�vis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Garan�s Intars</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>8 : 8</tr></td>
<tr><td class=brW>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=blW>Vi�ums Kaspars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>Liepi�� J�nis D�vis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Garan�s Intars</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ern�teins Guntis</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Liepi�� J�nis D�vis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>4 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Vi�ums Kaspars</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>Liepi�� J�nis D�vis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Liepi�� J�nis D�vis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>11 : 8</tr></td>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Liepi�� J�nis D�vis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ern�teins Guntis</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Liepi�� J�nis D�vis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Garan�s Intars</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Liepi�� J�nis D�vis</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>7 : 7</tr></td>
<tr><td class=br>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Liepi�� J�nis D�vis</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Ern�teins Guntis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Liepi�� J�nis D�vis</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Ern�teins Guntis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Putni�� Edgars</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Liepi�� J�nis D�vis</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Ern�teins Guntis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>Garan�s Intars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Liepi�� J�nis D�vis</td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Ern�teins Guntis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Putni�� Edgars</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=blW>Garan�s Intars</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Ern�teins Guntis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Liepi�� J�nis D�vis</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group LK 3.l�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>D� Vesele</td><td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>7:1</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=br>53:25</td><td class=br>+28</td>
<td class=bc>14 - 3 - 3</td>
<td class=br><strong>31</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Ar Salmi��</td><td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=br>54:38</td><td class=br>+16</td>
<td class=bc>11 - 6 - 3</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>�v Vikmanis</td><td class=kL>0:4</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>61:41</td><td class=br>+20</td>
<td class=bc>11 - 5 - 4</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>L� Bezdel�ga</td><td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kL>0:5</td>
<td class=kW>7:2</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=br>60:43</td><td class=br>+17</td>
<td class=bc>11 - 5 - 4</td>
<td class=br><strong>27</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ma Krauze</td><td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>47:34</td><td class=br>+13</td>
<td class=bc>11 - 5 - 4</td>
<td class=br><strong>27</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>�i Vazoli��</td><td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=br>54:30</td><td class=br>+24</td>
<td class=bc>13 - 1 - 6</td>
<td class=br><strong>27</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>M� �irsis</td><td class=kL>1:6</td>
<td class=kW>5:0</td>
<td class=kL>3:4</td>
<td class=kW>6:3</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>5:4</td>
<td class=kL>0:2</td>
<td class=kW>5:0</td>
<td class=br>52:37</td><td class=br>+15</td>
<td class=bc>11 - 4 - 5</td>
<td class=br><strong>26</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ed Ern�teins</td><td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kW>7:0</td>
<td class=kL>0:6</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>50:38</td><td class=br>+12</td>
<td class=bc>10 - 3 - 7</td>
<td class=br><strong>23</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Al Liepi��</td><td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>5:4</td>
<td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>10:3</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>61:47</td><td class=br>+14</td>
<td class=bc>9 - 4 - 7</td>
<td class=br><strong>22</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>To Jakseboga</td><td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=br>49:42</td><td class=br>+7</td>
<td class=bc>8 - 5 - 7</td>
<td class=br><strong>21</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ma Kalni��</td><td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kT>0:0</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=br>37:32</td><td class=br>+5</td>
<td class=bc>6 - 8 - 6</td>
<td class=br><strong>20</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Al Pimenovs</td><td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=br>40:40</td><td class=br>0</td>
<td class=bc>8 - 3 - 9</td>
<td class=br><strong>19</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ar Verbi�s</td><td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kL>0:1</td>
<td class=kW>6:1</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=br>50:50</td><td class=br>0</td>
<td class=bc>6 - 5 - 9</td>
<td class=br><strong>17</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Ra St�lmanis</td><td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=kW>6:0</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>3:0</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=br>46:52</td><td class=br>-6</td>
<td class=bc>7 - 2 - 11</td>
<td class=br><strong>16</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>As Kocere</td><td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kW>1:0</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=br>41:40</td><td class=br>+1</td>
<td class=bc>7 - 2 - 11</td>
<td class=br><strong>16</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>J� Rekti��</td><td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>37:55</td><td class=br>-18</td>
<td class=bc>7 - 2 - 11</td>
<td class=br><strong>16</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ag Pav�rs</td><td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>37:43</td><td class=br>-6</td>
<td class=bc>6 - 4 - 10</td>
<td class=br><strong>16</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>J� Zem�ickis</td><td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kL>3:10</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>40:53</td><td class=br>-13</td>
<td class=bc>6 - 3 - 11</td>
<td class=br><strong>15</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Gu Skapsts</td><td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=br>47:69</td><td class=br>-22</td>
<td class=bc>5 - 3 - 12</td>
<td class=br><strong>13</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Ro Aseri��</td><td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=br>39:46</td><td class=br>-7</td>
<td class=bc>4 - 5 - 11</td>
<td class=br><strong>13</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Er Kalni��</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=br>0:100</td><td class=br>-100</td>
<td class=bc>0 - 0 - 20</td>
<td class=br><strong>0</strong></td><td class=d>21.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>Pimenovs Alekss</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Skapsts Gustavs</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ern�teins Edgars</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Pimenovs Alekss</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ern�teins Edgars</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Pimenovs Alekss</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ern�teins Edgars</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pimenovs Alekss</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Skapsts Gustavs</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Zem�ickis J�nis</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pimenovs Alekss</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Zem�ickis J�nis</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pimenovs Alekss</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Salmi�� Arnis</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Ern�teins Edgars</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pimenovs Alekss</td><td class=bc>-</td><td class=blW>Rekti�� J�nis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pimenovs Alekss</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Pimenovs Alekss</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Zem�ickis J�nis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>Rekti�� J�nis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>10 : 3</tr></td>
<tr><td class=br>Pimenovs Alekss</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Rekti�� J�nis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>Ern�teins Edgars</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=blW>Salmi�� Arnis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pimenovs Alekss</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Ern�teins Edgars</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Vikmanis �ve</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Zem�ickis J�nis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=blW>Aseri�� Roberts</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Pimenovs Alekss</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Ern�teins Edgars</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Vikmanis �ve</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Salmi�� Arnis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Pimenovs Alekss</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ern�teins Edgars</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Rekti�� J�nis</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Aseri�� Roberts</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>Pimenovs Alekss</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ern�teins Edgars</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Salmi�� Arnis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Pimenovs Alekss</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ern�teins Edgars</td><td class=bc>-</td><td class=blW>Salmi�� Arnis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Rekti�� J�nis</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Pimenovs Alekss</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ern�teins Edgars</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Pimenovs Alekss</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Salmi�� Arnis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Zem�ickis J�nis</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Pimenovs Alekss</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ern�teins Edgars</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Rekti�� J�nis</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Aseri�� Roberts</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Pimenovs Alekss</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ern�teins Edgars</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>Pimenovs Alekss</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Zem�ickis J�nis</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ern�teins Edgars</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Rekti�� J�nis</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>3 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
