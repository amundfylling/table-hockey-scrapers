<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Kids(U13) Individual (K)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Kids(U13)_Individual_(K)_list.php">Final Ranking</a></span></h2></div></div></div></div><h3 align="right">Kids(U13) Individual (K)&nbsp;&nbsp;</h3>
<p><div align="center">
<p class=v><br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0 class="rnk">
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">M</th>
<th align="center">+</th>
<th align="center">=</th>
<th align="center">-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">P</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al><a href="stats.php?idpl=36&x=-63&p=Verbi%C4%8Ds%20Roberts">Verbi�s Roberts</a></td>
<td class=al>LAT</td>
<td class=ar>31</td>
<td class=ar>25</td>
<td class=ar>1</td>
<td class=ar>5</td>
<td class=ar>131</td>
<td class=al>&nbsp;:&nbsp;55</td>
<td class=ar>51</td>
</tr><tr><td class=br>2.</td>
<td class=bl><a href="stats.php?idpl=82&x=-63&p=Neija%20Rainers">Neija Rainers</a></td>
<td class=bl>LAT</td>
<td class=br>30</td>
<td class=br>24</td>
<td class=br>1</td>
<td class=br>5</td>
<td class=br>130</td>
<td class=bl>&nbsp;:&nbsp;68</td>
<td class=br>49</td>
</tr><tr><td class=ar>3.</td>
<td class=al><a href="stats.php?idpl=421&x=-63&p=Nilsson%20Gustav">Nilsson Gustav</a></td>
<td class=al>SWE</td>
<td class=ar>30</td>
<td class=ar>24</td>
<td class=ar>1</td>
<td class=ar>5</td>
<td class=ar>86</td>
<td class=al>&nbsp;:&nbsp;36</td>
<td class=ar>49</td>
</tr><tr><td class=br>4.</td>
<td class=bl><a href="stats.php?idpl=367&x=-63&p=Pylypenko%20Oleksandr">Pylypenko Oleksandr</a></td>
<td class=bl>UKR</td>
<td class=br>31</td>
<td class=br>15</td>
<td class=br>3</td>
<td class=br>13</td>
<td class=br>73</td>
<td class=bl>&nbsp;:&nbsp;75</td>
<td class=br>33</td>
</tr><tr><td class=ar>5.</td>
<td class=al><a href="stats.php?idpl=77&x=-63&p=G%C5%ABze%20Ein%C4%81rs">G�ze Ein�rs</a></td>
<td class=al>LAT</td>
<td class=ar>25</td>
<td class=ar>15</td>
<td class=ar>4</td>
<td class=ar>6</td>
<td class=ar>66</td>
<td class=al>&nbsp;:&nbsp;37</td>
<td class=ar>34</td>
</tr><tr><td class=br>6.</td>
<td class=bl><a href="stats.php?idpl=84&x=-63&p=Vazoli%C5%86%C5%A1%20%C4%A2irts">Vazoli�� �irts</a></td>
<td class=bl>LAT</td>
<td class=br>23</td>
<td class=br>12</td>
<td class=br>2</td>
<td class=br>9</td>
<td class=br>65</td>
<td class=bl>&nbsp;:&nbsp;51</td>
<td class=br>26</td>
</tr><tr><td class=ar>7.</td>
<td class=al><a href="stats.php?idpl=242&x=-63&p=Janouskovec%20Jan">Janouskovec Jan</a></td>
<td class=al>CZE</td>
<td class=ar>23</td>
<td class=ar>13</td>
<td class=ar>0</td>
<td class=ar>10</td>
<td class=ar>60</td>
<td class=al>&nbsp;:&nbsp;50</td>
<td class=ar>26</td>
</tr><tr><td class=br>8.</td>
<td class=bl><a href="stats.php?idpl=161&x=-63&p=Martu%C5%BE%C4%81ns%20Rainers">Martu��ns Rainers</a></td>
<td class=bl>LAT</td>
<td class=br>23</td>
<td class=br>9</td>
<td class=br>4</td>
<td class=br>10</td>
<td class=br>51</td>
<td class=bl>&nbsp;:&nbsp;52</td>
<td class=br>22</td>
</tr><tr><td class=ar>9.</td>
<td class=al><a href="stats.php?idpl=197&x=-63&p=Vikmanis%20%C5%AAve">Vikmanis �ve</a></td>
<td class=al>LAT</td>
<td class=ar>20</td>
<td class=ar>8</td>
<td class=ar>5</td>
<td class=ar>7</td>
<td class=ar>41</td>
<td class=al>&nbsp;:&nbsp;47</td>
<td class=ar>21</td>
</tr><tr><td class=br>10.</td>
<td class=bl><a href="stats.php?idpl=198&x=-63&p=Verbi%C4%8Ds%20Art%C5%ABrs">Verbi�s Art�rs</a></td>
<td class=bl>LAT</td>
<td class=br>20</td>
<td class=br>8</td>
<td class=br>3</td>
<td class=br>9</td>
<td class=br>41</td>
<td class=bl>&nbsp;:&nbsp;52</td>
<td class=br>19</td>
</tr><tr><td class=ar>11.</td>
<td class=al><a href="stats.php?idpl=220&x=-63&p=Pleikys%20Jonas">Pleikys Jonas</a></td>
<td class=al>LTU</td>
<td class=ar>20</td>
<td class=ar>8</td>
<td class=ar>2</td>
<td class=ar>10</td>
<td class=ar>29</td>
<td class=al>&nbsp;:&nbsp;44</td>
<td class=ar>18</td>
</tr><tr><td class=br>12.</td>
<td class=bl><a href="stats.php?idpl=394&x=-63&p=Uimonen%20Emil">Uimonen Emil</a></td>
<td class=bl>FIN</td>
<td class=br>20</td>
<td class=br>7</td>
<td class=br>3</td>
<td class=br>10</td>
<td class=br>37</td>
<td class=bl>&nbsp;:&nbsp;45</td>
<td class=br>17</td>
</tr><tr><td class=ar>13.</td>
<td class=al><a href="stats.php?idpl=93&x=-63&p=G%C5%ABtmanis%20Kristers">G�tmanis Kristers</a></td>
<td class=al>LAT</td>
<td class=ar>20</td>
<td class=ar>7</td>
<td class=ar>2</td>
<td class=ar>11</td>
<td class=ar>41</td>
<td class=al>&nbsp;:&nbsp;55</td>
<td class=ar>16</td>
</tr><tr><td class=br>14.</td>
<td class=bl><a href="stats.php?idpl=353&x=-63&p=Pav%C4%81rs%20Agris">Pav�rs Agris</a></td>
<td class=bl>LAT</td>
<td class=br>20</td>
<td class=br>6</td>
<td class=br>3</td>
<td class=br>11</td>
<td class=br>40</td>
<td class=bl>&nbsp;:&nbsp;59</td>
<td class=br>15</td>
</tr><tr><td class=ar>15.</td>
<td class=al><a href="stats.php?idpl=410&x=-63&p=Moravec%20Michael">Moravec Michael</a></td>
<td class=al>CZE</td>
<td class=ar>20</td>
<td class=ar>6</td>
<td class=ar>3</td>
<td class=ar>11</td>
<td class=ar>36</td>
<td class=al>&nbsp;:&nbsp;57</td>
<td class=ar>15</td>
</tr><tr><td class=br>16.</td>
<td class=bl><a href="stats.php?idpl=89&x=-63&p=Vesele%20D%C4%81rta">Vesele D�rta</a></td>
<td class=bl>LAT</td>
<td class=br>20</td>
<td class=br>6</td>
<td class=br>2</td>
<td class=br>12</td>
<td class=br>36</td>
<td class=bl>&nbsp;:&nbsp;47</td>
<td class=br>14</td>
</tr><tr><td class=ar>17.</td>
<td class=al><a href="stats.php?idpl=253&x=-63&p=St%C4%81lmanis%20Raimonds">St�lmanis Raimonds</a></td>
<td class=al>LAT</td>
<td class=ar>20</td>
<td class=ar>5</td>
<td class=ar>3</td>
<td class=ar>12</td>
<td class=ar>33</td>
<td class=al>&nbsp;:&nbsp;52</td>
<td class=ar>13</td>
</tr><tr><td class=br>18.</td>
<td class=bl><a href="stats.php?idpl=355&x=-63&p=Kocere%20Asnate">Kocere Asnate</a></td>
<td class=bl>LAT</td>
<td class=br>20</td>
<td class=br>4</td>
<td class=br>4</td>
<td class=br>12</td>
<td class=br>45</td>
<td class=bl>&nbsp;:&nbsp;74</td>
<td class=br>12</td>
</tr><tr><td class=ar>19.</td>
<td class=al><a href="stats.php?idpl=159&x=-63&p=Saul%C4%ABtis%20Ren%C4%81rs">Saul�tis Ren�rs</a></td>
<td class=al>LAT</td>
<td class=ar>20</td>
<td class=ar>5</td>
<td class=ar>1</td>
<td class=ar>14</td>
<td class=ar>38</td>
<td class=al>&nbsp;:&nbsp;60</td>
<td class=ar>11</td>
</tr><tr><td class=br>20.</td>
<td class=bl><a href="stats.php?idpl=199&x=-63&p=Purmalis%20Roberts">Purmalis Roberts</a></td>
<td class=bl>LAT</td>
<td class=br>20</td>
<td class=br>4</td>
<td class=br>3</td>
<td class=br>13</td>
<td class=br>40</td>
<td class=bl>&nbsp;:&nbsp;63</td>
<td class=br>11</td>
</tr><tr><td class=ar>21.</td>
<td class=al><a href="stats.php?idpl=189&x=-63&p=Reinfelds%20Elvis%20Gustavs%20">Reinfelds Elvis Gustavs </a></td>
<td class=al>LAT</td>
<td class=ar>20</td>
<td class=ar>0</td>
<td class=ar>4</td>
<td class=ar>16</td>
<td class=ar>32</td>
<td class=al>&nbsp;:&nbsp;72</td>
<td class=ar>4</td>
</tr></table></td></tr></table></div></p>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
