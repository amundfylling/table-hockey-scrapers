<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Kids(U13) Individual (K)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Kids(U13)_Individual_(K)_list.php">Kids(U13) Individual (K) - play-off </a></span></h2></div></div></div></div><p><div align="center">
<table border=0 cellpadding=2 cellspacing=0>
<tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>Finals</strong></font></th></tr>
<tr><td class=br><a href="stats.php?idpl=82&x=-63&p=Neija%20Rainers">Neija Rainers</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=36&x=-63&p=Verbi%C4%8Ds%20Roberts"><b>Verbi�s Roberts</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;1 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>1:5&nbsp;&nbsp;</td>
<td class=bl>2:4&nbsp;&nbsp;</td>
<td class=bl>3:7&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>1/2</strong></font></th></tr>
<tr><td class=ar><a href="stats.php?idpl=82&x=-63&p=Neija%20Rainers"><b>Neija Rainers</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=367&x=-63&p=Pylypenko%20Oleksandr">Pylypenko Oleksandr</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:1&nbsp;&nbsp;</td>
<td class=al>6:2&nbsp;&nbsp;</td>
<td class=al>4:0&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="stats.php?idpl=36&x=-63&p=Verbi%C4%8Ds%20Roberts"><b>Verbi�s Roberts</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=421&x=-63&p=Nilsson%20Gustav">Nilsson Gustav</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>3:2 P&nbsp;&nbsp;</td>
<td class=bl>3:4&nbsp;&nbsp;</td>
<td class=bl>6:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>3rd</strong></font></th></tr>
<tr><td class=ar><a href="stats.php?idpl=367&x=-63&p=Pylypenko%20Oleksandr">Pylypenko Oleksandr</a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=421&x=-63&p=Nilsson%20Gustav"><b>Nilsson Gustav</b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>0:3&nbsp;&nbsp;</td>
<td class=al>0:3&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>1/4</strong></font></th></tr>
<tr><td class=br><a href="stats.php?idpl=82&x=-63&p=Neija%20Rainers%20%281%29"><b>Neija Rainers (1)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=161&x=-63&p=Martu%C5%BE%C4%81ns%20Rainers%20%288%29">Martu��ns Rainers (8)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:0&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="stats.php?idpl=77&x=-63&p=G%C5%ABze%20Ein%C4%81rs%20%284%29">G�ze Ein�rs (4)</a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=367&x=-63&p=Pylypenko%20Oleksandr%20%285%29"><b>Pylypenko Oleksandr (5)</b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:0&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
<td class=al>0:4&nbsp;&nbsp;</td>
<td class=al>1:3&nbsp;&nbsp;</td>
<td class=al>1:4&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="stats.php?idpl=36&x=-63&p=Verbi%C4%8Ds%20Roberts%20%283%29"><b>Verbi�s Roberts (3)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=84&x=-63&p=Vazoli%C5%86%C5%A1%20%C4%A2irts%20%286%29">Vazoli�� �irts (6)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>1:0&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="stats.php?idpl=421&x=-63&p=Nilsson%20Gustav%20%282%29"><b>Nilsson Gustav (2)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=242&x=-63&p=Janouskovec%20Jan%20%287%29">Janouskovec Jan (7)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:1&nbsp;&nbsp;</td>
<td class=al>2:0&nbsp;&nbsp;</td>
<td class=al>5:0&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
