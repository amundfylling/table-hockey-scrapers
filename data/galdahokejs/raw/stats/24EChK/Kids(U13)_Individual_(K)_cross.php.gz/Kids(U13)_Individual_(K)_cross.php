<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Kids(U13) Individual (K)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../24EChK/Kids(U13)_Individual_(K)_index.php">Kids(U13) Individual (K), 15. June 2024</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<p class=v>Group Kids</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Ra Neija</td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kW>7:1</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>8:4</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>5:4</td>
<td class=br>94:41</td><td class=br>+53</td>
<td class=bc>17 - 1 - 2</td>
<td class=br><strong>35</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Gu Nilsson</td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=br>56:18</td><td class=br>+38</td>
<td class=bc>17 - 1 - 2</td>
<td class=br><strong>35</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Ro Verbi�s</td><td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kL>4:5</td>
<td class=kW>10:2</td>
<td class=kW>7:1</td>
<td class=kW>8:0</td>
<td class=kW>5:3</td>
<td class=br>89:30</td><td class=br>+59</td>
<td class=bc>16 - 1 - 3</td>
<td class=br><strong>33</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Ei G�ze</td><td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=br>58:25</td><td class=br>+33</td>
<td class=bc>13 - 4 - 3</td>
<td class=br><strong>30</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>5.</td><td class=kt>Ol Pylypenko</td><td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kT>5:5</td>
<td class=kW>2:0</td>
<td class=br>56:45</td><td class=br>+11</td>
<td class=bc>12 - 3 - 5</td>
<td class=br><strong>27</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>6.</td><td class=kt>�i Vazoli��</td><td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=br>62:43</td><td class=br>+19</td>
<td class=bc>12 - 2 - 6</td>
<td class=br><strong>26</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>7.</td><td class=kt>Ja Janouskovec</td><td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=br>59:40</td><td class=br>+19</td>
<td class=bc>13 - 0 - 7</td>
<td class=br><strong>26</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>8.</td><td class=kt>Ra Martu��ns</td><td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=br>46:40</td><td class=br>+6</td>
<td class=bc>9 - 4 - 7</td>
<td class=br><strong>22</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>�v Vikmanis</td><td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>0:0</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=br>41:47</td><td class=br>-6</td>
<td class=bc>8 - 5 - 7</td>
<td class=br><strong>21</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ar Verbi�s</td><td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kW>5:2</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=br>41:52</td><td class=br>-11</td>
<td class=bc>8 - 3 - 9</td>
<td class=br><strong>19</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Jo Pleikys</td><td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kT>0:0</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=br>29:44</td><td class=br>-15</td>
<td class=bc>8 - 2 - 10</td>
<td class=br><strong>18</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Em Uimonen</td><td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=br>37:45</td><td class=br>-8</td>
<td class=bc>7 - 3 - 10</td>
<td class=br><strong>17</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Kr G�tmanis</td><td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>5:0</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=br>41:55</td><td class=br>-14</td>
<td class=bc>7 - 2 - 11</td>
<td class=br><strong>16</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Ag Pav�rs</td><td class=kL>4:8</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=br>40:59</td><td class=br>-19</td>
<td class=bc>6 - 3 - 11</td>
<td class=br><strong>15</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Mi Moravec</td><td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=br>36:57</td><td class=br>-21</td>
<td class=bc>6 - 3 - 11</td>
<td class=br><strong>15</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>D� Vesele</td><td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=br>36:47</td><td class=br>-11</td>
<td class=bc>6 - 2 - 12</td>
<td class=br><strong>14</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ra St�lmanis</td><td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kW>5:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=br>33:52</td><td class=br>-19</td>
<td class=bc>5 - 3 - 12</td>
<td class=br><strong>13</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>As Kocere</td><td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kL>2:10</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kL>2:6</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=br>45:74</td><td class=br>-29</td>
<td class=bc>4 - 4 - 12</td>
<td class=br><strong>12</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Re Saul�tis</td><td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=br>38:60</td><td class=br>-22</td>
<td class=bc>5 - 1 - 14</td>
<td class=br><strong>11</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Ro Purmalis</td><td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:8</td>
<td class=kL>0:3</td>
<td class=kT>5:5</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>40:63</td><td class=br>-23</td>
<td class=bc>4 - 3 - 13</td>
<td class=br><strong>11</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>El Reinfelds</td><td class=kL>4:5</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>32:72</td><td class=br>-40</td>
<td class=bc>0 - 4 - 16</td>
<td class=br><strong>4</strong></td><td class=d>21.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Janouskovec Jan</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Nilsson Gustav</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Pylypenko Oleksandr</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Uimonen Emil</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>G�tmanis Kristers</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Neija Rainers</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Nilsson Gustav</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Janouskovec Jan</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>G�tmanis Kristers</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Nilsson Gustav</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Janouskovec Jan</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Uimonen Emil</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Vikmanis �ve</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Pleikys Jonas</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>G�tmanis Kristers</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Neija Rainers</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Pylypenko Oleksandr</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Nilsson Gustav</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Janouskovec Jan</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Pleikys Jonas</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=bl>G�tmanis Kristers</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Neija Rainers</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Uimonen Emil</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Nilsson Gustav</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Janouskovec Jan</td><td class=bc>-</td><td class=bl>G�tmanis Kristers</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Neija Rainers</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>Uimonen Emil</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Pleikys Jonas</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Nilsson Gustav</td><td class=bc>-</td><td class=bl>G�tmanis Kristers</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Janouskovec Jan</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Neija Rainers</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Uimonen Emil</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>G�tmanis Kristers</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Nilsson Gustav</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Neija Rainers</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Janouskovec Jan</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>G�tmanis Kristers</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Neija Rainers</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Nilsson Gustav</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Janouskovec Jan</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>G�tmanis Kristers</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=bl>Neija Rainers</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Nilsson Gustav</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Janouskovec Jan</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>G�tmanis Kristers</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Neija Rainers</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Nilsson Gustav</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Janouskovec Jan</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>10 : 2</tr></td>
<tr><td class=br>G�tmanis Kristers</td><td class=bc>-</td><td class=blW>Neija Rainers</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Nilsson Gustav</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Purmalis Roberts</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Neija Rainers</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>5 : 3</tr></td>
<tr><td class=br>G�tmanis Kristers</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Nilsson Gustav</td><td class=bc>-</td><td class=bl>Janouskovec Jan</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Neija Rainers</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>G�tmanis Kristers</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>Purmalis Roberts</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Janouskovec Jan</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Neija Rainers</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>G�tmanis Kristers</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Uimonen Emil</td><td class=bc>-</td><td class=bl>Janouskovec Jan</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>Nilsson Gustav</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Neija Rainers</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>G�tmanis Kristers</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Janouskovec Jan</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Nilsson Gustav</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Neija Rainers</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Janouskovec Jan</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>G�tmanis Kristers</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Nilsson Gustav</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Pylypenko Oleksandr</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Purmalis Roberts</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Neija Rainers</td><td class=bc>-</td><td class=bl>Janouskovec Jan</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Nilsson Gustav</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>G�tmanis Kristers</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Pylypenko Oleksandr</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Janouskovec Jan</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Neija Rainers</td><td class=bc>-</td><td class=bl>Nilsson Gustav</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>G�tmanis Kristers</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Purmalis Roberts</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Janouskovec Jan</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Nilsson Gustav</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Neija Rainers</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>G�tmanis Kristers</td><td class=bc>-</td><td class=blW>Vikmanis �ve</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Janouskovec Jan</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Nilsson Gustav</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Neija Rainers</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Vikmanis �ve</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Janouskovec Jan</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Nilsson Gustav</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Pylypenko Oleksandr</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Uimonen Emil</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Neija Rainers</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>G�tmanis Kristers</td><td class=bc>2 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
