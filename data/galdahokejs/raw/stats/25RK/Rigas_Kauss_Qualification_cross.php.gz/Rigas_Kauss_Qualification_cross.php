<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Rigas Kauss Qualification</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../25RK/Rigas_Kauss_Qualification_index.php">Rigas Kauss Qualification, 6. December 2025</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group Q A Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ra Stern�ts</td><td class=kx>*</td>
<td class=kW>8:2</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>9:2</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>12:1</td>
<td class=br>66:13</td><td class=br>+53</td>
<td class=bc>10 - 0 - 0</td>
<td class=br><strong>20</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ed Liepi��</td><td class=kL>2:8</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>8:3</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=br>36:15</td><td class=br>+21</td>
<td class=bc>8 - 0 - 2</td>
<td class=br><strong>16</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ed Garan�s</td><td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>7:2</td>
<td class=kW>7:0</td>
<td class=kL>1:2</td>
<td class=kW>7:0</td>
<td class=kW>10:1</td>
<td class=br>49:15</td><td class=br>+34</td>
<td class=bc>7 - 0 - 3</td>
<td class=br><strong>14</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ra R�ders</td><td class=kL>3:6</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kW>9:0</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=br>31:17</td><td class=br>+14</td>
<td class=bc>6 - 0 - 4</td>
<td class=br><strong>12</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ju Forsberg</td><td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>1:4</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kT>0:0</td>
<td class=br>21:22</td><td class=br>-1</td>
<td class=bc>5 - 1 - 4</td>
<td class=br><strong>11</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>An Garan�a</td><td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>1:7</td>
<td class=kW>1:0</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=br>16:20</td><td class=br>-4</td>
<td class=bc>5 - 1 - 4</td>
<td class=br><strong>11</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Ma Jur�ina</td><td class=kL>2:9</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kL>0:9</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=br>21:35</td><td class=br>-14</td>
<td class=bc>4 - 1 - 5</td>
<td class=br><strong>9</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ol Aizpurietis</td><td class=kL>1:6</td>
<td class=kL>3:8</td>
<td class=kL>0:7</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=br>13:32</td><td class=br>-19</td>
<td class=bc>3 - 1 - 6</td>
<td class=br><strong>7</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ro K�avi��</td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>19:23</td><td class=br>-4</td>
<td class=bc>3 - 1 - 6</td>
<td class=br><strong>7</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>To Kazakevicius</td><td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>0:7</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=br>3:34</td><td class=br>-31</td>
<td class=bc>1 - 0 - 9</td>
<td class=br><strong>2</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ar Suhi�ins</td><td class=kL>1:12</td>
<td class=kL>0:6</td>
<td class=kL>1:10</td>
<td class=kL>0:5</td>
<td class=kT>0:0</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=br>2:51</td><td class=br>-49</td>
<td class=bc>0 - 1 - 9</td>
<td class=br><strong>1</strong></td><td class=d>11.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ol Aizpurietis</td><td class=bc>-</td><td class=bl>Ar Suhi�ins</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>An Garan�a</td><td class=bc>-</td><td class=bl>Ma Jur�ina</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ra Stern�ts</td><td class=bc>-</td><td class=bl>Ro K�avi��</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ju Forsberg</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>To Kazakevicius</td><td class=bc>-</td><td class=blW>Ed Garan�s</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ar Suhi�ins</td><td class=bc>-</td><td class=blW>Ma Jur�ina</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ol Aizpurietis</td><td class=bc>-</td><td class=bl>Ro K�avi��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>An Garan�a</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ra Stern�ts</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ju Forsberg</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ma Jur�ina</td><td class=bc>-</td><td class=bl>Ro K�avi��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ar Suhi�ins</td><td class=bc>-</td><td class=blW>Ra R�ders</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ol Aizpurietis</td><td class=bc>-</td><td class=blW>Ed Garan�s</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ra Stern�ts</td><td class=bc>-</td><td class=bl>To Kazakevicius</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ro K�avi��</td><td class=bc>-</td><td class=blW>Ra R�ders</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Jur�ina</td><td class=bc>-</td><td class=blW>Ed Garan�s</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ar Suhi�ins</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ol Aizpurietis</td><td class=bc>-</td><td class=bl>To Kazakevicius</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Ju Forsberg</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>Ed Garan�s</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro K�avi��</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Jur�ina</td><td class=bc>-</td><td class=bl>To Kazakevicius</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ar Suhi�ins</td><td class=bc>-</td><td class=bl>Ju Forsberg</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ol Aizpurietis</td><td class=bc>-</td><td class=blW>Ra Stern�ts</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ra R�ders</td><td class=bc>-</td><td class=bl>To Kazakevicius</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ro K�avi��</td><td class=bc>-</td><td class=blW>Ju Forsberg</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma Jur�ina</td><td class=bc>-</td><td class=blW>Ra Stern�ts</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Ar Suhi�ins</td><td class=bc>-</td><td class=blW>An Garan�a</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ed Liepi��</td><td class=bc>-</td><td class=bl>To Kazakevicius</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ed Garan�s</td><td class=bc>-</td><td class=bl>Ju Forsberg</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>Ra Stern�ts</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ro K�avi��</td><td class=bc>-</td><td class=blW>An Garan�a</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Jur�ina</td><td class=bc>-</td><td class=bl>Ol Aizpurietis</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>To Kazakevicius</td><td class=bc>-</td><td class=blW>Ju Forsberg</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Ra Stern�ts</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Ed Garan�s</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ra R�ders</td><td class=bc>-</td><td class=bl>Ol Aizpurietis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ro K�avi��</td><td class=bc>-</td><td class=bl>Ar Suhi�ins</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ju Forsberg</td><td class=bc>-</td><td class=blW>Ra Stern�ts</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>To Kazakevicius</td><td class=bc>-</td><td class=blW>An Garan�a</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ed Liepi��</td><td class=bc>-</td><td class=bl>Ol Aizpurietis</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Ed Garan�s</td><td class=bc>-</td><td class=bl>Ar Suhi�ins</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Ra R�ders</td><td class=bc>-</td><td class=bl>Ma Jur�ina</td><td class=bc>9 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ra Stern�ts</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ju Forsberg</td><td class=bc>-</td><td class=bl>Ol Aizpurietis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>To Kazakevicius</td><td class=bc>-</td><td class=bl>Ar Suhi�ins</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ed Liepi��</td><td class=bc>-</td><td class=bl>Ma Jur�ina</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=blW>Ro K�avi��</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=bl>Ol Aizpurietis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Stern�ts</td><td class=bc>-</td><td class=bl>Ar Suhi�ins</td><td class=bc>12 : 1</tr></td>
<tr><td class=br>Ju Forsberg</td><td class=bc>-</td><td class=blW>Ma Jur�ina</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Kazakevicius</td><td class=bc>-</td><td class=blW>Ro K�avi��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Ra R�ders</td><td class=bc>1 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group Q B Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>La Karlsson</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kW>11:0</td>
<td class=kW>7:1</td>
<td class=kW>8:1</td>
<td class=br>59:7</td><td class=br>+52</td>
<td class=bc>10 - 1 - 0</td>
<td class=br><strong>21</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ma P�tersons</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>7:0</td>
<td class=kL>1:2</td>
<td class=kW>8:0</td>
<td class=br>38:13</td><td class=br>+25</td>
<td class=bc>8 - 2 - 1</td>
<td class=br><strong>18</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Em Vi��akovs</td><td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=br>39:16</td><td class=br>+23</td>
<td class=bc>7 - 1 - 3</td>
<td class=br><strong>15</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ro Garda</td><td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>7:4</td>
<td class=br>34:23</td><td class=br>+11</td>
<td class=bc>6 - 2 - 3</td>
<td class=br><strong>14</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ri D�cis</td><td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=br>32:20</td><td class=br>+12</td>
<td class=bc>6 - 2 - 3</td>
<td class=br><strong>14</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ma Zimba</td><td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=kW>4:0</td>
<td class=br>39:16</td><td class=br>+23</td>
<td class=bc>6 - 2 - 3</td>
<td class=br><strong>14</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Os Zaharovs</td><td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=kT>4:4</td>
<td class=br>29:26</td><td class=br>+3</td>
<td class=bc>6 - 1 - 4</td>
<td class=br><strong>13</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Pl Miha��uks</td><td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=br>19:35</td><td class=br>-16</td>
<td class=bc>3 - 1 - 7</td>
<td class=br><strong>7</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ti Suhi�ins</td><td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=br>15:39</td><td class=br>-24</td>
<td class=bc>3 - 0 - 8</td>
<td class=br><strong>6</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>So Golubecka</td><td class=kL>0:11</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=br>13:54</td><td class=br>-41</td>
<td class=bc>2 - 0 - 9</td>
<td class=br><strong>4</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Gu Ma�ikenas</td><td class=kL>1:7</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>0:8</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>11:42</td><td class=br>-31</td>
<td class=bc>2 - 0 - 9</td>
<td class=br><strong>4</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Al Doni��</td><td class=kL>1:8</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>4:7</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>15:52</td><td class=br>-37</td>
<td class=bc>0 - 2 - 9</td>
<td class=br><strong>2</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>So Golubecka</td><td class=bc>-</td><td class=blW>Ti Suhi�ins</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Os Zaharovs</td><td class=bc>-</td><td class=bl>Pl Miha��uks</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>La Karlsson</td><td class=bc>-</td><td class=bl>Al Doni��</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Em Vi��akovs</td><td class=bc>-</td><td class=bl>Gu Ma�ikenas</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=bl>Ma Zimba</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ti Suhi�ins</td><td class=bc>-</td><td class=blW>Pl Miha��uks</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>So Golubecka</td><td class=bc>-</td><td class=bl>Al Doni��</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Os Zaharovs</td><td class=bc>-</td><td class=bl>Gu Ma�ikenas</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>La Karlsson</td><td class=bc>-</td><td class=bl>Ma Zimba</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Pl Miha��uks</td><td class=bc>-</td><td class=bl>Al Doni��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ti Suhi�ins</td><td class=bc>-</td><td class=bl>Gu Ma�ikenas</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>So Golubecka</td><td class=bc>-</td><td class=blW>Ma Zimba</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Os Zaharovs</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>La Karlsson</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Ri D�cis</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Al Doni��</td><td class=bc>-</td><td class=blW>Gu Ma�ikenas</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pl Miha��uks</td><td class=bc>-</td><td class=blW>Ma Zimba</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ti Suhi�ins</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>So Golubecka</td><td class=bc>-</td><td class=blW>Ro Garda</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Os Zaharovs</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>La Karlsson</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Gu Ma�ikenas</td><td class=bc>-</td><td class=blW>Ma Zimba</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Al Doni��</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Pl Miha��uks</td><td class=bc>-</td><td class=blW>Ro Garda</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ti Suhi�ins</td><td class=bc>-</td><td class=blW>Ri D�cis</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>So Golubecka</td><td class=bc>-</td><td class=blW>Em Vi��akovs</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Os Zaharovs</td><td class=bc>-</td><td class=blW>La Karlsson</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ma Zimba</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gu Ma�ikenas</td><td class=bc>-</td><td class=blW>Ro Garda</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Al Doni��</td><td class=bc>-</td><td class=blW>Ri D�cis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pl Miha��uks</td><td class=bc>-</td><td class=blW>Em Vi��akovs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ti Suhi�ins</td><td class=bc>-</td><td class=blW>La Karlsson</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>So Golubecka</td><td class=bc>-</td><td class=blW>Os Zaharovs</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Zimba</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Gu Ma�ikenas</td><td class=bc>-</td><td class=blW>La Karlsson</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Al Doni��</td><td class=bc>-</td><td class=bl>Os Zaharovs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Pl Miha��uks</td><td class=bc>-</td><td class=bl>So Golubecka</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ti Suhi�ins</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=blW>Em Vi��akovs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=bl>La Karlsson</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Zimba</td><td class=bc>-</td><td class=bl>Os Zaharovs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Gu Ma�ikenas</td><td class=bc>-</td><td class=blW>So Golubecka</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Al Doni��</td><td class=bc>-</td><td class=blW>Ti Suhi�ins</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pl Miha��uks</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>La Karlsson</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=blW>Os Zaharovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>So Golubecka</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ma Zimba</td><td class=bc>-</td><td class=bl>Ti Suhi�ins</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Gu Ma�ikenas</td><td class=bc>-</td><td class=blW>Pl Miha��uks</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Al Doni��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Em Vi��akovs</td><td class=bc>-</td><td class=bl>Os Zaharovs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ri D�cis</td><td class=bc>-</td><td class=bl>So Golubecka</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ro Garda</td><td class=bc>-</td><td class=bl>Ti Suhi�ins</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>Pl Miha��uks</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ma Zimba</td><td class=bc>-</td><td class=bl>Al Doni��</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Gu Ma�ikenas</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>La Karlsson</td><td class=bc>-</td><td class=bl>So Golubecka</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Em Vi��akovs</td><td class=bc>-</td><td class=bl>Ti Suhi�ins</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ri D�cis</td><td class=bc>-</td><td class=bl>Pl Miha��uks</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ro Garda</td><td class=bc>-</td><td class=bl>Al Doni��</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=blW>Gu Ma�ikenas</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Zimba</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Os Zaharovs</td><td class=bc>-</td><td class=bl>Ti Suhi�ins</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>La Karlsson</td><td class=bc>-</td><td class=bl>Pl Miha��uks</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Em Vi��akovs</td><td class=bc>-</td><td class=bl>Al Doni��</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ri D�cis</td><td class=bc>-</td><td class=bl>Gu Ma�ikenas</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ro Garda</td><td class=bc>-</td><td class=bl>Ma Zimba</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group Q C Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ha V�veris</td><td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>8:0</td>
<td class=kW>8:0</td>
<td class=kW>6:0</td>
<td class=kW>7:0</td>
<td class=kW>10:2</td>
<td class=br>62:15</td><td class=br>+47</td>
<td class=bc>9 - 2 - 0</td>
<td class=br><strong>20</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Kr Timbers</td><td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=br>35:11</td><td class=br>+24</td>
<td class=bc>9 - 2 - 0</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>T� Gor�anova</td><td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kT>0:0</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>8:0</td>
<td class=br>37:10</td><td class=br>+27</td>
<td class=bc>8 - 2 - 1</td>
<td class=br><strong>18</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ro Zygelis</td><td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=br>24:20</td><td class=br>+4</td>
<td class=bc>5 - 3 - 3</td>
<td class=br><strong>13</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ma Ru�manis</td><td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=br>23:22</td><td class=br>+1</td>
<td class=bc>4 - 4 - 3</td>
<td class=br><strong>12</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>An Israelsson</td><td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=br>25:28</td><td class=br>-3</td>
<td class=bc>4 - 3 - 4</td>
<td class=br><strong>11</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Re Masulis</td><td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kT>0:0</td>
<td class=kL>1:5</td>
<td class=kT>0:0</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=br>16:20</td><td class=br>-4</td>
<td class=bc>3 - 3 - 5</td>
<td class=br><strong>9</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Em V�tols</td><td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>6:3</td>
<td class=br>19:31</td><td class=br>-12</td>
<td class=bc>4 - 1 - 6</td>
<td class=br><strong>9</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>La Ern�teina</td><td class=kL>0:8</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=br>15:29</td><td class=br>-14</td>
<td class=bc>3 - 2 - 6</td>
<td class=br><strong>8</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Je Vezan</td><td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=br>12:31</td><td class=br>-19</td>
<td class=bc>1 - 2 - 8</td>
<td class=br><strong>4</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ri Karavics</td><td class=kL>0:7</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=br>13:33</td><td class=br>-20</td>
<td class=bc>1 - 2 - 8</td>
<td class=br><strong>4</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ar Voitkevi�s</td><td class=kL>2:10</td>
<td class=kL>0:2</td>
<td class=kL>0:8</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=br>18:49</td><td class=br>-31</td>
<td class=bc>1 - 2 - 8</td>
<td class=br><strong>4</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ri Karavics</td><td class=bc>-</td><td class=blW>Ma Ru�manis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>La Ern�teina</td><td class=bc>-</td><td class=blW>Em V�tols</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Je Vezan</td><td class=bc>-</td><td class=blW>Re Masulis</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Israelsson</td><td class=bc>-</td><td class=bl>Ar Voitkevi�s</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Zygelis</td><td class=bc>-</td><td class=blW>Kr Timbers</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ma Ru�manis</td><td class=bc>-</td><td class=bl>Em V�tols</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ri Karavics</td><td class=bc>-</td><td class=blW>Re Masulis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>La Ern�teina</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Je Vezan</td><td class=bc>-</td><td class=bl>Ar Voitkevi�s</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=bl>Kr Timbers</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>An Israelsson</td><td class=bc>-</td><td class=blW>Ro Zygelis</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Em V�tols</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Ru�manis</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ri Karavics</td><td class=bc>-</td><td class=bl>Ar Voitkevi�s</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>La Ern�teina</td><td class=bc>-</td><td class=blW>Kr Timbers</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Je Vezan</td><td class=bc>-</td><td class=blW>Ro Zygelis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>An Israelsson</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Em V�tols</td><td class=bc>-</td><td class=bl>Ar Voitkevi�s</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ma Ru�manis</td><td class=bc>-</td><td class=blW>Kr Timbers</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ri Karavics</td><td class=bc>-</td><td class=bl>Ro Zygelis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>La Ern�teina</td><td class=bc>-</td><td class=bl>An Israelsson</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Je Vezan</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>T� Gor�anova</td><td class=bc>-</td><td class=bl>Ar Voitkevi�s</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>Kr Timbers</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Em V�tols</td><td class=bc>-</td><td class=blW>Ro Zygelis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ma Ru�manis</td><td class=bc>-</td><td class=blW>An Israelsson</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ri Karavics</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>La Ern�teina</td><td class=bc>-</td><td class=bl>Je Vezan</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ar Voitkevi�s</td><td class=bc>-</td><td class=blW>Kr Timbers</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>T� Gor�anova</td><td class=bc>-</td><td class=bl>Ro Zygelis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>An Israelsson</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Em V�tols</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ma Ru�manis</td><td class=bc>-</td><td class=bl>Je Vezan</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ri Karavics</td><td class=bc>-</td><td class=blW>La Ern�teina</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Kr Timbers</td><td class=bc>-</td><td class=bl>An Israelsson</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ar Voitkevi�s</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>2 : 10</tr></td>
<tr><td class=brW>T� Gor�anova</td><td class=bc>-</td><td class=bl>Je Vezan</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Re Masulis</td><td class=bc>-</td><td class=bl>La Ern�teina</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Em V�tols</td><td class=bc>-</td><td class=bl>Ri Karavics</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ma Ru�manis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ro Zygelis</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Kr Timbers</td><td class=bc>-</td><td class=bl>Je Vezan</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ar Voitkevi�s</td><td class=bc>-</td><td class=blW>La Ern�teina</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>T� Gor�anova</td><td class=bc>-</td><td class=bl>Ri Karavics</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=bl>Ma Ru�manis</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Em V�tols</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>An Israelsson</td><td class=bc>-</td><td class=bl>Je Vezan</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ro Zygelis</td><td class=bc>-</td><td class=bl>La Ern�teina</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Timbers</td><td class=bc>-</td><td class=bl>Ri Karavics</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ar Voitkevi�s</td><td class=bc>-</td><td class=blW>Ma Ru�manis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>T� Gor�anova</td><td class=bc>-</td><td class=bl>Em V�tols</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>La Ern�teina</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>An Israelsson</td><td class=bc>-</td><td class=bl>Ri Karavics</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Zygelis</td><td class=bc>-</td><td class=bl>Ma Ru�manis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Timbers</td><td class=bc>-</td><td class=bl>Em V�tols</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ar Voitkevi�s</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Je Vezan</td><td class=bc>-</td><td class=bl>Ri Karavics</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=bl>Ma Ru�manis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>An Israelsson</td><td class=bc>-</td><td class=bl>Em V�tols</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ro Zygelis</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kr Timbers</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ar Voitkevi�s</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>La Ern�teina</td><td class=bc>-</td><td class=blW>Ma Ru�manis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Je Vezan</td><td class=bc>-</td><td class=blW>Em V�tols</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Israelsson</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ro Zygelis</td><td class=bc>-</td><td class=bl>Ar Voitkevi�s</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kr Timbers</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
