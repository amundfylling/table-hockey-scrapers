<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Latvijas cempionats 2024</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../24LCh/Latvijas_cempionats_2024_index.php">Latvijas cempionats 2024, 2. March 2024</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group LC A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Em Liepi��</td><td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kL>1:4</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>7:3</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=br>63:28</td><td class=br>+35</td>
<td class=bc>12 - 1 - 1</td>
<td class=br><strong>25</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ra Kalni��</td><td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>10:4</td>
<td class=kW>3:2</td>
<td class=kW>9:2</td>
<td class=kW>3:2</td>
<td class=br>62:34</td><td class=br>+28</td>
<td class=bc>11 - 2 - 1</td>
<td class=br><strong>24</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Re Vazoli��</td><td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>0:5</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=br>56:23</td><td class=br>+33</td>
<td class=bc>12 - 0 - 2</td>
<td class=br><strong>24</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Di Ziemelis</td><td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>7:1</td>
<td class=kW>7:1</td>
<td class=br>47:30</td><td class=br>+17</td>
<td class=bc>8 - 1 - 5</td>
<td class=br><strong>17</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Kr Lagzdi�a</td><td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=br>35:19</td><td class=br>+16</td>
<td class=bc>7 - 1 - 6</td>
<td class=br><strong>15</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Sa Kalni��</td><td class=kL>3:7</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>6:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kT>3:3</td>
<td class=br>38:39</td><td class=br>-1</td>
<td class=bc>5 - 4 - 5</td>
<td class=br><strong>14</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Sa Krasts</td><td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>0:3</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=br>30:34</td><td class=br>-4</td>
<td class=bc>6 - 1 - 7</td>
<td class=br><strong>13</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>D� Apfelbaums</td><td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>1:0</td>
<td class=br>28:34</td><td class=br>-6</td>
<td class=bc>5 - 3 - 6</td>
<td class=br><strong>13</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ro Kerns</td><td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=br>30:39</td><td class=br>-9</td>
<td class=bc>6 - 1 - 7</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>J� Bitmanis</td><td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>4:6</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=br>30:35</td><td class=br>-5</td>
<td class=bc>5 - 3 - 6</td>
<td class=br><strong>13</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ra Kuha�skis</td><td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=br>38:42</td><td class=br>-4</td>
<td class=bc>6 - 1 - 7</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Ed Putni��</td><td class=kL>2:7</td>
<td class=kL>4:10</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=br>31:50</td><td class=br>-19</td>
<td class=bc>5 - 1 - 8</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Ri Kalni��</td><td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=br>23:41</td><td class=br>-18</td>
<td class=bc>4 - 0 - 10</td>
<td class=br><strong>8</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ka �iha�ova</td><td class=kL>2:5</td>
<td class=kL>2:9</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=br>27:62</td><td class=br>-35</td>
<td class=bc>2 - 0 - 12</td>
<td class=br><strong>4</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>Marg �bele</td><td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=br>22:50</td><td class=br>-28</td>
<td class=bc>1 - 1 - 12</td>
<td class=br><strong>3</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=blW>Ri Kalni��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Ri Kalni��</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>9 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Ka �iha�ova</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>4 : 10</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ri Kalni��</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Ka �iha�ova</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ri Kalni��</td><td class=bc>2 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group LC B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ed Caics</td><td class=kx>*</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>10:0</td>
<td class=kW>9:2</td>
<td class=kW>4:2</td>
<td class=kW>9:0</td>
<td class=br>76:15</td><td class=br>+61</td>
<td class=bc>14 - 0 - 0</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Kr Rieksti��</td><td class=kL>0:7</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=br>53:31</td><td class=br>+22</td>
<td class=bc>12 - 1 - 1</td>
<td class=br><strong>25</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ed Naglis</td><td class=kL>2:5</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>7:4</td>
<td class=kW>4:3</td>
<td class=kW>6:3</td>
<td class=kT>4:4</td>
<td class=kT>4:4</td>
<td class=kW>6:4</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=br>65:48</td><td class=br>+17</td>
<td class=bc>9 - 3 - 2</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ma Jakseboga</td><td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>4:6</td>
<td class=kW>7:4</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>5:0</td>
<td class=kW>6:4</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=br>55:42</td><td class=br>+13</td>
<td class=bc>7 - 2 - 5</td>
<td class=br><strong>16</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Sa Skarainis</td><td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kL>1:6</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>9:0</td>
<td class=br>52:37</td><td class=br>+15</td>
<td class=bc>7 - 1 - 6</td>
<td class=br><strong>15</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ni Sviklis</td><td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kW>6:4</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>2:0</td>
<td class=br>40:39</td><td class=br>+1</td>
<td class=bc>5 - 5 - 4</td>
<td class=br><strong>15</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>R� Kamzols</td><td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>4:7</td>
<td class=kL>4:7</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kL>3:6</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=br>52:43</td><td class=br>+9</td>
<td class=bc>6 - 2 - 6</td>
<td class=br><strong>14</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Kr Markus</td><td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=br>33:37</td><td class=br>-4</td>
<td class=bc>5 - 4 - 5</td>
<td class=br><strong>14</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Je Zaharovs</td><td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kL>3:6</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>9:0</td>
<td class=kW>10:0</td>
<td class=br>58:43</td><td class=br>+15</td>
<td class=bc>6 - 1 - 7</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Pa Strods</td><td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=br>42:45</td><td class=br>-3</td>
<td class=bc>5 - 2 - 7</td>
<td class=br><strong>12</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>J� Z�l�te</td><td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kL>4:6</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=br>34:46</td><td class=br>-12</td>
<td class=bc>5 - 1 - 8</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Ar Zasurcevs</td><td class=kL>0:10</td>
<td class=kL>1:4</td>
<td class=kL>4:6</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=br>39:56</td><td class=br>-17</td>
<td class=bc>5 - 1 - 8</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Ro Verbi�s</td><td class=kL>2:9</td>
<td class=kL>3:6</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>6:3</td>
<td class=br>38:55</td><td class=br>-17</td>
<td class=bc>4 - 1 - 9</td>
<td class=br><strong>9</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Mark �bele</td><td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:7</td>
<td class=kL>0:7</td>
<td class=kT>3:3</td>
<td class=kL>0:9</td>
<td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=br>24:56</td><td class=br>-32</td>
<td class=bc>2 - 2 - 10</td>
<td class=br><strong>6</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>Ja Rektins</td><td class=kL>0:9</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>0:6</td>
<td class=kL>0:9</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>0:10</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=br>10:78</td><td class=br>-68</td>
<td class=bc>0 - 0 - 14</td>
<td class=br><strong>0</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=blW>Pa Strods</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ja Rektins</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>0 : 9</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Markus</td><td class=bc>-</td><td class=bl>Ja Rektins</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Pa Strods</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Ja Rektins</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Mark �bele</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ja Rektins</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Mark �bele</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>Kr Markus</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ja Rektins</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Mark �bele</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Kr Markus</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>Ja Rektins</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Mark �bele</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Kr Markus</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pa Strods</td><td class=bc>-</td><td class=bl>Ja Rektins</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Mark �bele</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>Kr Markus</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>0 : 10</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Ja Rektins</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Mark �bele</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=blW>Kr Markus</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>4 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ja Rektins</td><td class=bc>-</td><td class=blW>Mark �bele</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Kr Markus</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pa Strods</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=bl>Kr Markus</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Rektins</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>4 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mark �bele</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ja Rektins</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ja Rektins</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Pa Strods</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Rektins</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Kr Markus</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ja Rektins</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>3 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group LC C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>El Sili��</td><td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>1:0</td>
<td class=kW>5:3</td>
<td class=kW>8:0</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=br>48:19</td><td class=br>+29</td>
<td class=bc>10 - 3 - 0</td>
<td class=br><strong>23</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ro Rieksti��</td><td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=br>44:17</td><td class=br>+27</td>
<td class=bc>9 - 3 - 1</td>
<td class=br><strong>21</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ra Miglinieks</td><td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>5:4</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=br>47:27</td><td class=br>+20</td>
<td class=bc>8 - 3 - 2</td>
<td class=br><strong>19</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>To Baumanis</td><td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=br>37:28</td><td class=br>+9</td>
<td class=bc>8 - 2 - 3</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ro L�vmanis</td><td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kL>5:6</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=br>36:24</td><td class=br>+12</td>
<td class=bc>6 - 4 - 3</td>
<td class=br><strong>16</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>In Garan�s</td><td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kT>2:2</td>
<td class=br>38:28</td><td class=br>+10</td>
<td class=bc>6 - 3 - 4</td>
<td class=br><strong>15</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>J� Kaln�vics</td><td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=br>41:33</td><td class=br>+8</td>
<td class=bc>5 - 4 - 4</td>
<td class=br><strong>14</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Se Mihejevs</td><td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=br>32:28</td><td class=br>+4</td>
<td class=bc>6 - 1 - 6</td>
<td class=br><strong>13</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>J� Re�is</td><td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kT>0:0</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=br>22:25</td><td class=br>-3</td>
<td class=bc>4 - 4 - 5</td>
<td class=br><strong>12</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ra Stern�ts</td><td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kW>6:5</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=br>33:47</td><td class=br>-14</td>
<td class=bc>4 - 2 - 7</td>
<td class=br><strong>10</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ro Fa�ken�teins</td><td class=kL>0:8</td>
<td class=kL>1:7</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=br>18:45</td><td class=br>-27</td>
<td class=bc>4 - 0 - 9</td>
<td class=br><strong>8</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>He Prokuratovs</td><td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kT>0:0</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=br>29:38</td><td class=br>-9</td>
<td class=bc>3 - 2 - 8</td>
<td class=br><strong>8</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Ar Salmi��</td><td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>4:5</td>
<td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>17:51</td><td class=br>-34</td>
<td class=bc>2 - 0 - 11</td>
<td class=br><strong>4</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>To Jakseboga</td><td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>14:46</td><td class=br>-32</td>
<td class=bc>0 - 1 - 12</td>
<td class=br><strong>1</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Ra Stern�ts</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>J� Kaln�vics</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ro L�vmanis</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>J� Kaln�vics</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Ar Salmi��</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ro L�vmanis</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ro L�vmanis</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>J� Kaln�vics</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ra Stern�ts</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Ro L�vmanis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>J� Kaln�vics</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro L�vmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>J� Kaln�vics</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>Ro L�vmanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ra Stern�ts</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Ro L�vmanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>J� Kaln�vics</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Ro L�vmanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Ar Salmi��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>J� Kaln�vics</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ro L�vmanis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>J� Kaln�vics</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ro L�vmanis</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Kaln�vics</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ro L�vmanis</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ro L�vmanis</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro L�vmanis</td><td class=bc>-</td><td class=blW>Ra Stern�ts</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ro L�vmanis</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>2 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group LC D</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Sa Lagzdi��</td><td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>7:0</td>
<td class=kW>7:2</td>
<td class=br>54:26</td><td class=br>+28</td>
<td class=bc>9 - 3 - 1</td>
<td class=br><strong>21</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Al Sili��</td><td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>7:0</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=br>47:25</td><td class=br>+22</td>
<td class=bc>8 - 3 - 2</td>
<td class=br><strong>19</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ha Gals</td><td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kW>7:2</td>
<td class=br>43:32</td><td class=br>+11</td>
<td class=bc>9 - 0 - 4</td>
<td class=br><strong>18</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Va Smagars</td><td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>8:4</td>
<td class=br>52:31</td><td class=br>+21</td>
<td class=bc>9 - 0 - 4</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>An Liepi��</td><td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=br>34:20</td><td class=br>+14</td>
<td class=bc>8 - 2 - 3</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Al Skudr�tis</td><td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kW>5:4</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=br>43:32</td><td class=br>+11</td>
<td class=bc>8 - 1 - 4</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Kr Naglis</td><td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kW>7:1</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>3:4</td>
<td class=kW>9:1</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=br>51:33</td><td class=br>+18</td>
<td class=bc>8 - 0 - 5</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ed Ka�eps</td><td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kW>6:1</td>
<td class=br>41:34</td><td class=br>+7</td>
<td class=bc>7 - 1 - 5</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Mi Saul�tis</td><td class=kW>4:3</td>
<td class=kL>0:7</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=br>33:42</td><td class=br>-9</td>
<td class=bc>6 - 1 - 6</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ka Vi�ums</td><td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kW>4:3</td>
<td class=kL>1:9</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=br>35:42</td><td class=br>-7</td>
<td class=bc>5 - 1 - 7</td>
<td class=br><strong>11</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ni L�cis</td><td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=br>28:46</td><td class=br>-18</td>
<td class=bc>3 - 1 - 9</td>
<td class=br><strong>7</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Kr Zem�ickis</td><td class=kL>3:4</td>
<td class=kL>2:7</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=br>25:53</td><td class=br>-28</td>
<td class=bc>2 - 0 - 11</td>
<td class=br><strong>4</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Fr Platons</td><td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>13:46</td><td class=br>-33</td>
<td class=bc>2 - 0 - 11</td>
<td class=br><strong>4</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Gu Buls</td><td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kL>4:8</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>25:62</td><td class=br>-37</td>
<td class=bc>0 - 1 - 12</td>
<td class=br><strong>1</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ha Gals</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Ni L�cis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Ni L�cis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ka Vi�ums</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ni L�cis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ka Vi�ums</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ha Gals</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ha Gals</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ha Gals</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ha Gals</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ha Gals</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ha Gals</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group 1.L�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>31</td>
<td class=ic>32</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Ra Kalni��</td><td class=kx>*</td>
<td class=kW>6:5</td>
<td class=kW>4:3 K</td>
<td class=kW>9:3</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kL>4:6 K</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>5:3 K</td>
<td class=kW>6:3</td>
<td class=kW>6:1</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kW>3:1 K</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kT>2:2 K</td>
<td class=kW>5:2 K</td>
<td class=kT>3:3 K</td>
<td class=kW>3:2</td>
<td class=kW>7:5</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=kW>6:2</td>
<td class=kW>7:1</td>
<td class=br>142:78</td><td class=br>+64</td>
<td class=bc>22 - 8 - 1</td>
<td class=br><strong>52</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Ed Caics</td><td class=kL>5:6</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>5:2 K</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>7:0 K</td>
<td class=kW>3:1</td>
<td class=kW>4:1 K</td>
<td class=kW>7:1</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kW>3:1 K</td>
<td class=kW>3:1</td>
<td class=kW>6:4</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2 K</td>
<td class=kW>10:1</td>
<td class=kW>6:2</td>
<td class=kW>4:1 K</td>
<td class=kW>4:0 K</td>
<td class=br>123:60</td><td class=br>+63</td>
<td class=bc>24 - 3 - 4</td>
<td class=br><strong>51</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Re Vazoli��</td><td class=kL>3:4 K</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>4:6</td>
<td class=kW>4:2</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kW>4:1 K</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>3:1 K</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kL>0:5 K</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kW>5:1</td>
<td class=kW>4:0 K</td>
<td class=kW>3:2 K</td>
<td class=kW>4:0 K</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=br>100:64</td><td class=br>+36</td>
<td class=bc>20 - 1 - 10</td>
<td class=br><strong>41</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>El Sili��</td><td class=kL>3:9</td>
<td class=kL>2:5</td>
<td class=kW>6:4</td>
<td class=kx>*</td>
<td class=kW>3:2 K</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2 K</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kW>4:1 K</td>
<td class=kT>3:3 K</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>4:1 K</td>
<td class=kW>4:3</td>
<td class=kT>1:1 K</td>
<td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kW>4:3 K</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=br>90:80</td><td class=br>+10</td>
<td class=bc>16 - 7 - 8</td>
<td class=br><strong>39</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>To Baumanis</td><td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>2:3 K</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>6:4</td>
<td class=kW>4:2 K</td>
<td class=kW>6:4</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kL>0:3 K</td>
<td class=kW>2:0 K</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kT>3:3 K</td>
<td class=kW>6:2</td>
<td class=kT>3:3 K</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2 K</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=br>102:75</td><td class=br>+27</td>
<td class=bc>16 - 6 - 9</td>
<td class=br><strong>38</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>Va Smagars</td><td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>3:4 K</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2 K</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kW>5:3 K</td>
<td class=kW>6:1</td>
<td class=kL>1:3</td>
<td class=kW>5:3 K</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>7:3</td>
<td class=kW>2:0</td>
<td class=kL>3:4 K</td>
<td class=kW>3:0</td>
<td class=kW>6:3</td>
<td class=kW>4:1 K</td>
<td class=kL>2:3 K</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=br>97:78</td><td class=br>+19</td>
<td class=bc>18 - 2 - 11</td>
<td class=br><strong>38</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Ed Naglis</td><td class=kL>3:6</td>
<td class=kL>2:5 K</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>4:6</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kW>7:4</td>
<td class=kL>3:6 K</td>
<td class=kL>2:5</td>
<td class=kW>7:4 K</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>7:4</td>
<td class=kW>4:3 K</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kW>6:4 K</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>4:3 K</td>
<td class=kT>4:4 K</td>
<td class=br>121:98</td><td class=br>+23</td>
<td class=bc>16 - 6 - 9</td>
<td class=br><strong>38</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Ra Miglinieks</td><td class=kL>1:2</td>
<td class=kL>4:5</td>
<td class=kL>0:5</td>
<td class=kT>2:2 K</td>
<td class=kL>2:4 K</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kL>2:7</td>
<td class=kW>7:2</td>
<td class=kT>3:3 K</td>
<td class=kW>6:2 K</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>3:4 K</td>
<td class=kW>3:2</td>
<td class=kW>4:1 K</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kT>1:1 K</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kW>8:2</td>
<td class=kW>3:1</td>
<td class=br>92:70</td><td class=br>+22</td>
<td class=bc>17 - 4 - 10</td>
<td class=br><strong>38</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>Em Liepi��</td><td class=kW>6:4 K</td>
<td class=kL>3:4</td>
<td class=kL>1:4 K</td>
<td class=kW>5:3</td>
<td class=kL>4:6</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>5:0 K</td>
<td class=kT>5:5</td>
<td class=kW>6:4</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>2:1 K</td>
<td class=kL>0:3</td>
<td class=kL>2:7</td>
<td class=kW>7:3</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kW>7:3 K</td>
<td class=kW>4:1 K</td>
<td class=kT>3:3 K</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=br>112:90</td><td class=br>+22</td>
<td class=bc>16 - 4 - 11</td>
<td class=br><strong>36</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Sa Lagzdi��</td><td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>4:3 K</td>
<td class=kL>4:7</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kT>3:3 K</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>7:1 K</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2 K</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>4:1 K</td>
<td class=kW>4:1 K</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=br>91:70</td><td class=br>+21</td>
<td class=bc>15 - 6 - 10</td>
<td class=br><strong>36</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Kr Rieksti��</td><td class=kT>2:2</td>
<td class=kL>0:7 K</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>6:3 K</td>
<td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2 K</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>3:1 K</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>4:4 K</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>4:1 K</td>
<td class=kW>3:1 K</td>
<td class=br>85:78</td><td class=br>+7</td>
<td class=bc>14 - 8 - 9</td>
<td class=br><strong>36</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>Di Ziemelis</td><td class=kL>3:5 K</td>
<td class=kL>1:3</td>
<td class=kL>1:3 K</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kL>0:5 K</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1 K</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kL>3:4</td>
<td class=kW>6:1</td>
<td class=kL>2:5</td>
<td class=kW>4:2 K</td>
<td class=kT>2:2 K</td>
<td class=kW>3:0 K</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=br>89:71</td><td class=br>+18</td>
<td class=bc>15 - 5 - 11</td>
<td class=br><strong>35</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>R� Kamzols</td><td class=kL>3:6</td>
<td class=kL>1:4 K</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>4:7 K</td>
<td class=kW>7:2</td>
<td class=kT>5:5</td>
<td class=kW>2:1</td>
<td class=kL>2:3 K</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kL>3:4 K</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>4:7 K</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1 K</td>
<td class=kT>3:3 K</td>
<td class=br>92:83</td><td class=br>+9</td>
<td class=bc>14 - 7 - 10</td>
<td class=br><strong>35</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>Al Sili��</td><td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kW>2:1 K</td>
<td class=kT>3:3</td>
<td class=kL>2:7</td>
<td class=kL>4:6</td>
<td class=kT>3:3 K</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>7:2</td>
<td class=kW>4:3</td>
<td class=kL>1:5 K</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>2:1 K</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3 K</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kL>3:4 K</td>
<td class=kW>3:1 K</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=br>92:96</td><td class=br>-4</td>
<td class=bc>15 - 4 - 12</td>
<td class=br><strong>34</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>Ro Rieksti��</td><td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kL>1:4 K</td>
<td class=kW>3:0 K</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3 K</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kT>3:3 K</td>
<td class=kW>5:3</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0 K</td>
<td class=kW>3:0</td>
<td class=kT>1:1 K</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1 K</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=br>81:72</td><td class=br>+9</td>
<td class=bc>14 - 6 - 11</td>
<td class=br><strong>34</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>J� Kaln�vics</td><td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kT>3:3 K</td>
<td class=kL>0:2 K</td>
<td class=kW>4:1</td>
<td class=kL>2:5</td>
<td class=kL>2:6 K</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>2:7</td>
<td class=kT>3:3 K</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kW>3:2 K</td>
<td class=kW>4:0</td>
<td class=kL>1:2 K</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2 K</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=br>87:77</td><td class=br>+10</td>
<td class=bc>14 - 5 - 12</td>
<td class=br><strong>33</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Kr Lagzdi�a</td><td class=kL>1:3 K</td>
<td class=kW>3:2</td>
<td class=kW>5:0 K</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>1:2 K</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>1:3 K</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kW>5:1</td>
<td class=kL>1:3 K</td>
<td class=kW>5:0 K</td>
<td class=kW>3:0 K</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kL>0:1</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=br>86:65</td><td class=br>+21</td>
<td class=bc>15 - 2 - 14</td>
<td class=br><strong>32</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>An Liepi��</td><td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kL>3:5 K</td>
<td class=kL>4:7</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kT>2:2 K</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kW>5:1 K</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>1:3 K</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1 K</td>
<td class=kL>1:2</td>
<td class=kW>6:1</td>
<td class=kT>1:1 K</td>
<td class=kL>1:3 K</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=br>76:70</td><td class=br>+6</td>
<td class=bc>12 - 6 - 13</td>
<td class=br><strong>30</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Sa Skarainis</td><td class=kT>3:3</td>
<td class=kL>1:3 K</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>3:4 K</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kL>3:5</td>
<td class=kL>1:3 K</td>
<td class=kL>0:4</td>
<td class=kW>4:3 K</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kL>1:4 K</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>6:2 K</td>
<td class=kW>6:1 K</td>
<td class=br>82:83</td><td class=br>-1</td>
<td class=bc>12 - 5 - 14</td>
<td class=br><strong>29</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>In Garan�s</td><td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>1:4 K</td>
<td class=kT>3:3 K</td>
<td class=kW>3:1</td>
<td class=kL>0:5</td>
<td class=kW>4:3 K</td>
<td class=kL>3:7</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>0:3 K</td>
<td class=kL>2:3 K</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kW>4:1 K</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>0:4 K</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>11:1</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=br>82:91</td><td class=br>-9</td>
<td class=bc>13 - 3 - 15</td>
<td class=br><strong>29</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Kr Naglis</td><td class=kL>2:3</td>
<td class=kL>4:6</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kL>3:5 K</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>1:7 K</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>1:2 K</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kW>3:0</td>
<td class=kW>3:1 K</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0 K</td>
<td class=kT>2:2</td>
<td class=kL>3:6</td>
<td class=kL>2:4 K</td>
<td class=kW>7:1 K</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=br>84:87</td><td class=br>-3</td>
<td class=bc>13 - 2 - 16</td>
<td class=br><strong>28</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Ro L�vmanis</td><td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kT>1:1 K</td>
<td class=kT>3:3 K</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:4 K</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kT>1:1 K</td>
<td class=kW>2:1 K</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4 K</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kW>6:1 K</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=br>67:87</td><td class=br>-20</td>
<td class=bc>10 - 6 - 15</td>
<td class=br><strong>26</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Sa Kalni��</td><td class=kT>2:2 K</td>
<td class=kL>1:3</td>
<td class=kL>0:4 K</td>
<td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kW>4:3</td>
<td class=kL>3:7 K</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>2:4 K</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kW>3:1 K</td>
<td class=kW>4:2</td>
<td class=kT>0:0</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>0:3 K</td>
<td class=kW>2:1 K</td>
<td class=kT>0:0</td>
<td class=kW>1:0</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=br>63:80</td><td class=br>-17</td>
<td class=bc>11 - 4 - 16</td>
<td class=br><strong>26</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Sa Krasts</td><td class=kL>2:5 K</td>
<td class=kL>1:3</td>
<td class=kL>2:3 K</td>
<td class=kW>6:1</td>
<td class=kL>1:7</td>
<td class=kL>3:7</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>1:4 K</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kT>2:2 K</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kL>0:5 K</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>3:0 K</td>
<td class=kx>*</td>
<td class=kW>5:2 K</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=br>62:83</td><td class=br>-21</td>
<td class=bc>10 - 5 - 16</td>
<td class=br><strong>25</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt>D� Apfelbaums</td><td class=kT>3:3 K</td>
<td class=kL>2:3</td>
<td class=kL>0:4 K</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kT>3:3 K</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>0:3 K</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>0:3 K</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kW>1:0</td>
<td class=kL>1:2 K</td>
<td class=kL>2:5 K</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>6:3</td>
<td class=br>63:87</td><td class=br>-24</td>
<td class=bc>8 - 7 - 16</td>
<td class=br><strong>23</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt>Ed Ka�eps</td><td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kW>4:3 K</td>
<td class=kW>6:1</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>2:3 K</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kT>3:3 K</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>1:3 K</td>
<td class=kL>4:5</td>
<td class=kW>5:2</td>
<td class=kL>0:3 K</td>
<td class=kW>4:0</td>
<td class=kT>0:0</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>3:6 K</td>
<td class=kW>2:1 K</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=br>73:85</td><td class=br>-12</td>
<td class=bc>9 - 5 - 17</td>
<td class=br><strong>23</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt>Se Mihejevs</td><td class=kL>5:7</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>3:4 K</td>
<td class=kL>2:3 K</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kT>1:1 K</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3 K</td>
<td class=kW>2:1 K</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>4:0 K</td>
<td class=kT>2:2</td>
<td class=kL>1:6 K</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>3:6</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=br>61:84</td><td class=br>-23</td>
<td class=bc>8 - 7 - 16</td>
<td class=br><strong>23</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt>Ma Jakseboga</td><td class=kL>3:4</td>
<td class=kL>2:3 K</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kL>4:6 K</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kT>4:4 K</td>
<td class=kL>2:4</td>
<td class=kW>7:4 K</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kW>1:0</td>
<td class=kL>1:6</td>
<td class=kW>4:1 K</td>
<td class=kL>0:4</td>
<td class=kW>6:3</td>
<td class=kL>0:1</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kW>6:3</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3 K</td>
<td class=kL>4:6 K</td>
<td class=br>80:105</td><td class=br>-25</td>
<td class=bc>9 - 3 - 19</td>
<td class=br><strong>21</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt>Al Skudr�tis</td><td class=kL>0:6</td>
<td class=kL>1:10</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>1:4 K</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>1:4 K</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kW>4:3 K</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kT>1:1 K</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>4:2 K</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>6:3 K</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kL>1:3 K</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=br>62:98</td><td class=br>-36</td>
<td class=bc>9 - 3 - 19</td>
<td class=br><strong>21</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt>Ha Gals</td><td class=kL>0:8</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kW>3:2 K</td>
<td class=kL>1:6</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>1:4 K</td>
<td class=kL>3:5</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>1:3 K</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>3:1 K</td>
<td class=kL>2:6</td>
<td class=kL>1:11</td>
<td class=kL>1:7 K</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2 K</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>3:1 K</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>5:6</td>
<td class=br>56:111</td><td class=br>-55</td>
<td class=bc>7 - 4 - 20</td>
<td class=br><strong>18</strong></td><td class=d>30.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>31.</td><td class=kt>Kr Markus</td><td class=kL>2:6</td>
<td class=kL>1:4 K</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>3:4 K</td>
<td class=kL>2:8</td>
<td class=kT>4:4</td>
<td class=kL>0:5</td>
<td class=kL>1:4 K</td>
<td class=kL>1:2</td>
<td class=kT>1:1 K</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>2:6 K</td>
<td class=kL>0:3</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2 K</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=br>46:107</td><td class=br>-61</td>
<td class=bc>2 - 8 - 21</td>
<td class=br><strong>12</strong></td><td class=d>31.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>32.</td><td class=kt>Ni Sviklis</td><td class=kL>1:7</td>
<td class=kL>0:4 K</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kT>4:4 K</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>1:3 K</td>
<td class=kW>4:3</td>
<td class=kT>3:3 K</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kW>4:2</td>
<td class=kL>1:6 K</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kT>4:4</td>
<td class=kL>0:1</td>
<td class=kW>6:4 K</td>
<td class=kL>1:7</td>
<td class=kW>6:5</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=br>57:133</td><td class=br>-76</td>
<td class=bc>4 - 4 - 23</td>
<td class=br><strong>12</strong></td><td class=d>32.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=bl>Kr Markus</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ro L�vmanis</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>11 : 1</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>J� Kaln�vics</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ro L�vmanis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Kr Markus</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>J� Kaln�vics</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>J� Kaln�vics</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Kr Markus</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ro L�vmanis</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>J� Kaln�vics</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Kr Markus</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ro L�vmanis</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro L�vmanis</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>J� Kaln�vics</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Kr Markus</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>J� Kaln�vics</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Kr Markus</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ro L�vmanis</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ro L�vmanis</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Kr Markus</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>J� Kaln�vics</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Kr Markus</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro L�vmanis</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>J� Kaln�vics</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kr Markus</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ro L�vmanis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>J� Kaln�vics</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ro L�vmanis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ro L�vmanis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ro L�vmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>7 : 5</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ro L�vmanis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>9 : 3</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Ro L�vmanis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>J� Kaln�vics</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>J� Kaln�vics</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ro L�vmanis</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ro L�vmanis</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ha Gals</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ro L�vmanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>J� Kaln�vics</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ro L�vmanis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ha Gals</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>J� Kaln�vics</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=bl>Ro L�vmanis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ha Gals</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Ro L�vmanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=blW>J� Kaln�vics</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ha Gals</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ro L�vmanis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=blW>J� Kaln�vics</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ha Gals</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Ro L�vmanis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>J� Kaln�vics</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ha Gals</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ha Gals</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>J� Kaln�vics</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=blW>Ro L�vmanis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>J� Kaln�vics</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ha Gals</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=bl>Ro L�vmanis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>3 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 2.L�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>33.</td><td class=kt>Mi Saul�tis</td><td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>5:1</td>
<td class=kL>1:4</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=br>66:37</td><td class=br>+29</td>
<td class=bc>14 - 2 - 3</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>34.</td><td class=kt>Je Zaharovs</td><td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kL>2:8</td>
<td class=kW>7:3</td>
<td class=kW>5:1</td>
<td class=kW>5:4</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=br>78:49</td><td class=br>+29</td>
<td class=bc>13 - 2 - 4</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>35.</td><td class=kt>Ra Kuha�skis</td><td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=kW>7:3</td>
<td class=kW>5:1</td>
<td class=br>70:52</td><td class=br>+18</td>
<td class=bc>14 - 0 - 5</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>36.</td><td class=kt>Ar Zasurcevs</td><td class=kW>4:1</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>4:7</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kW>5:2</td>
<td class=kW>6:4</td>
<td class=kW>6:3</td>
<td class=kW>7:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>4:1</td>
<td class=br>78:52</td><td class=br>+26</td>
<td class=bc>11 - 3 - 5</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>37.</td><td class=kt>Ni L�cis</td><td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kW>5:4</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kL>5:6</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=k>&nbsp;</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=br>58:49</td><td class=br>+9</td>
<td class=bc>11 - 3 - 4</td>
<td class=br><strong>25</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>38.</td><td class=kt>Pa Strods</td><td class=kL>2:3</td>
<td class=kW>8:2</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>8:3</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=br>66:41</td><td class=br>+25</td>
<td class=bc>12 - 1 - 6</td>
<td class=br><strong>25</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>39.</td><td class=kt>J� Re�is</td><td class=kW>2:1</td>
<td class=kL>3:7</td>
<td class=kL>4:5</td>
<td class=kW>7:4</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kL>1:6</td>
<td class=kW>6:3</td>
<td class=kW>6:2</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>6:3</td>
<td class=br>66:53</td><td class=br>+13</td>
<td class=bc>10 - 4 - 5</td>
<td class=br><strong>24</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>40.</td><td class=kt>He Prokuratovs</td><td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kW>5:1</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=br>44:47</td><td class=br>-3</td>
<td class=bc>8 - 4 - 7</td>
<td class=br><strong>20</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>41.</td><td class=kt>J� Bitmanis</td><td class=kT>1:1</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=br>52:55</td><td class=br>-3</td>
<td class=bc>9 - 2 - 8</td>
<td class=br><strong>20</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>42.</td><td class=kt>Kr Zem�ickis</td><td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>7:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kT>5:5</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=br>58:50</td><td class=br>+8</td>
<td class=bc>6 - 7 - 6</td>
<td class=br><strong>19</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>43.</td><td class=kt>Ro Kerns</td><td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=br>35:35</td><td class=br>0</td>
<td class=bc>6 - 7 - 6</td>
<td class=br><strong>19</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>44.</td><td class=kt>Ri Kalni��</td><td class=kL>3:5</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kT>0:0</td>
<td class=kW>5:4</td>
<td class=br>46:45</td><td class=br>+1</td>
<td class=bc>7 - 4 - 8</td>
<td class=br><strong>18</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>45.</td><td class=kt>Ro Verbi�s</td><td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kW>6:5</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>6:4</td>
<td class=kT>5:5</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=br>54:57</td><td class=br>-3</td>
<td class=bc>6 - 6 - 7</td>
<td class=br><strong>18</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>46.</td><td class=kt>J� Z�l�te</td><td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>4:6</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=br>47:47</td><td class=br>0</td>
<td class=bc>8 - 2 - 9</td>
<td class=br><strong>18</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>47.</td><td class=kt>Ed Putni��</td><td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kL>3:8</td>
<td class=kL>2:6</td>
<td class=kW>6:1</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>5:7</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=br>52:62</td><td class=br>-10</td>
<td class=bc>6 - 3 - 10</td>
<td class=br><strong>15</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>48.</td><td class=kt>Ka Vi�ums</td><td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kL>3:6</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=br>47:61</td><td class=br>-14</td>
<td class=bc>5 - 3 - 11</td>
<td class=br><strong>13</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>49.</td><td class=kt>Ro Fa�ken�teins</td><td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kT>5:5</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kL>4:6</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=br>40:59</td><td class=br>-19</td>
<td class=bc>4 - 3 - 12</td>
<td class=br><strong>11</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>50.</td><td class=kt>Ra Stern�ts</td><td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=k>&nbsp;</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kT>5:5</td>
<td class=kW>4:3</td>
<td class=kW>7:5</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=br>39:66</td><td class=br>-27</td>
<td class=bc>4 - 3 - 11</td>
<td class=br><strong>11</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>51.</td><td class=kt>Fr Platons</td><td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kL>3:7</td>
<td class=kL>0:7</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kL>0:5</td>
<td class=kL>0:1</td>
<td class=kT>0:0</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=br>20:56</td><td class=br>-36</td>
<td class=bc>2 - 4 - 13</td>
<td class=br><strong>8</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>52.</td><td class=kt>Ar Salmi��</td><td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=br>26:69</td><td class=br>-43</td>
<td class=bc>1 - 1 - 17</td>
<td class=br><strong>3</strong></td><td class=d>20.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pa Strods</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ra Stern�ts</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>7 : 5</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Ni L�cis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=blW>Ni L�cis</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pa Strods</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>Ri Kalni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pa Strods</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ri Kalni��</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Ni L�cis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Ni L�cis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=blW>Pa Strods</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ri Kalni��</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ri Kalni��</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Pa Strods</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ni L�cis</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Pa Strods</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ni L�cis</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Pa Strods</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Ra Stern�ts</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Pa Strods</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ni L�cis</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ka Vi�ums</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Pa Strods</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ni L�cis</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ri Kalni��</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>Pa Strods</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ni L�cis</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ka Vi�ums</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ni L�cis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Ar Salmi��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Ri Kalni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Pa Strods</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ka Vi�ums</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Ri Kalni��</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ni L�cis</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pa Strods</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Stern�ts</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ka Vi�ums</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ra Stern�ts</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>2 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 3.L�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>53.</td><td class=kt>Da Baumanis</td><td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>10:0</td>
<td class=br>61:26</td><td class=br>+35</td>
<td class=bc>14 - 3 - 2</td>
<td class=br><strong>31</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>54.</td><td class=kt>Re Stac�vi�s</td><td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=br>57:32</td><td class=br>+25</td>
<td class=bc>14 - 2 - 3</td>
<td class=br><strong>30</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>55.</td><td class=kt>Mark �bele</td><td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>10:0</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=br>66:32</td><td class=br>+34</td>
<td class=bc>13 - 3 - 3</td>
<td class=br><strong>29</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>56.</td><td class=kt>Ka �iha�ova</td><td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kT>5:5</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>8:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>11:0</td>
<td class=br>79:38</td><td class=br>+41</td>
<td class=bc>13 - 2 - 4</td>
<td class=br><strong>28</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>57.</td><td class=kt>Ro Aseri��</td><td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>7:3</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=br>42:27</td><td class=br>+15</td>
<td class=bc>12 - 2 - 5</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>58.</td><td class=kt>Marg �bele</td><td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>6:0</td>
<td class=br>55:35</td><td class=br>+20</td>
<td class=bc>12 - 0 - 7</td>
<td class=br><strong>24</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>59.</td><td class=kt>Ei G�ze</td><td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kT>5:5</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>10:0</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>10:0</td>
<td class=br>57:30</td><td class=br>+27</td>
<td class=bc>10 - 4 - 5</td>
<td class=br><strong>24</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>60.</td><td class=kt>Gu Buls</td><td class=kL>2:7</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>6:4</td>
<td class=kT>2:2</td>
<td class=kW>10:0</td>
<td class=kW>6:1</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>10:0</td>
<td class=br>58:39</td><td class=br>+19</td>
<td class=bc>10 - 2 - 7</td>
<td class=br><strong>22</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>61.</td><td class=kt>Il �irse</td><td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kT>5:5</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kT>5:5</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>5:5</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>10:0</td>
<td class=br>63:45</td><td class=br>+18</td>
<td class=bc>9 - 4 - 6</td>
<td class=br><strong>22</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>62.</td><td class=kt>An Zi�icka</td><td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=br>37:36</td><td class=br>+1</td>
<td class=bc>8 - 5 - 6</td>
<td class=br><strong>21</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>63.</td><td class=kt>Iv �irsis</td><td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>3:7</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=kT>5:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=kW>4:0</td>
<td class=kW>8:4</td>
<td class=kW>3:2</td>
<td class=kW>10:0</td>
<td class=br>67:52</td><td class=br>+15</td>
<td class=bc>8 - 3 - 8</td>
<td class=br><strong>19</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>64.</td><td class=kt>Ja Rektins</td><td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>10:0</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>10:0</td>
<td class=br>47:42</td><td class=br>+5</td>
<td class=bc>7 - 2 - 10</td>
<td class=br><strong>16</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>65.</td><td class=kt>L� Bezdel�ga</td><td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>4:6</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=br>44:59</td><td class=br>-15</td>
<td class=bc>7 - 1 - 11</td>
<td class=br><strong>15</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>66.</td><td class=kt>Ra Talbergs</td><td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kW>10:2</td>
<td class=kW>5:4</td>
<td class=br>51:55</td><td class=br>-4</td>
<td class=bc>7 - 1 - 11</td>
<td class=br><strong>15</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>67.</td><td class=kt>To Jakseboga</td><td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>0:10</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>0:10</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>0:10</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kW>7:3</td>
<td class=kT>2:2</td>
<td class=br>36:85</td><td class=br>-49</td>
<td class=bc>6 - 2 - 11</td>
<td class=br><strong>14</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>68.</td><td class=kt>�v Vikmanis</td><td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kT>0:0</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>10:0</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kW>10:0</td>
<td class=br>39:42</td><td class=br>-3</td>
<td class=bc>5 - 2 - 12</td>
<td class=br><strong>12</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>69.</td><td class=kt>D� Vesele</td><td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=br>34:45</td><td class=br>-11</td>
<td class=bc>4 - 3 - 12</td>
<td class=br><strong>11</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>70.</td><td class=kt>J� Zem�ickis</td><td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>4:8</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kW>2:0</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>10:0</td>
<td class=br>35:53</td><td class=br>-18</td>
<td class=bc>4 - 3 - 12</td>
<td class=br><strong>11</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>71.</td><td class=kt>Re Saul�tis</td><td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:10</td>
<td class=kL>3:7</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>10:0</td>
<td class=br>40:72</td><td class=br>-32</td>
<td class=bc>4 - 1 - 14</td>
<td class=br><strong>9</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>72.</td><td class=kt>As Kocere</td><td class=kL>0:10</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>0:11</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>1:3</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>3:5</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kL>0:10</td>
<td class=kL>2:7</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kx>*</td>
<td class=br>16:139</td><td class=br>-123</td>
<td class=bc>0 - 1 - 18</td>
<td class=br><strong>1</strong></td><td class=d>20.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Mark �bele</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Ra Talbergs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>An Zi�icka</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ja Rektins</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ka �iha�ova</td><td class=bc>-</td><td class=bl>Ra Talbergs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mark �bele</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>An Zi�icka</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ja Rektins</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Ra Talbergs</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ka �iha�ova</td><td class=bc>-</td><td class=bl>An Zi�icka</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Mark �bele</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ja Rektins</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ra Talbergs</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>An Zi�icka</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ja Rektins</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>An Zi�icka</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Talbergs</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ka �iha�ova</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ja Rektins</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>An Zi�icka</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Talbergs</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>10 : 2</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>An Zi�icka</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ra Talbergs</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ka �iha�ova</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Ja Rektins</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>An Zi�icka</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ra Talbergs</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ka �iha�ova</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Mark �bele</td><td class=bc>-</td><td class=bl>Ja Rektins</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>An Zi�icka</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ra Talbergs</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ja Rektins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ka �iha�ova</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mark �bele</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>An Zi�icka</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ra Talbergs</td><td class=bc>-</td><td class=blW>Ja Rektins</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ka �iha�ova</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>An Zi�icka</td><td class=bc>-</td><td class=bl>Ja Rektins</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ra Talbergs</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Mark �bele</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Ja Rektins</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>An Zi�icka</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ra Talbergs</td><td class=bc>-</td><td class=blW>Mark �bele</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Ka �iha�ova</td><td class=bc>0 : 11</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>Ja Rektins</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>An Zi�icka</td><td class=bc>-</td><td class=bl>Mark �bele</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Ra Talbergs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Ja Rektins</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Mark �bele</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Ka �iha�ova</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Zi�icka</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>10 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Ja Rektins</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Mark �bele</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Ka �iha�ova</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>An Zi�icka</td><td class=bc>-</td><td class=blW>Ra Talbergs</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Ja Rektins</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>Mark �bele</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Ra Talbergs</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>5 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ja Rektins</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Mark �bele</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Ka �iha�ova</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Ra Talbergs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>An Zi�icka</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ja Rektins</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Mark �bele</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Ra Talbergs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>An Zi�icka</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Mark �bele</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ja Rektins</td><td class=bc>-</td><td class=blW>Ka �iha�ova</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Ra Talbergs</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>An Zi�icka</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Mark �bele</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Ka �iha�ova</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ja Rektins</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Ra Talbergs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>An Zi�icka</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Mark �bele</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Ra Talbergs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ja Rektins</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>An Zi�icka</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>2 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 4.L�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>73.</td><td class=kt>Ar Pavlovs</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>7:2</td>
<td class=kT>4:4</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>1:0</td>
<td class=kW>6:0</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kW>9:1</td>
<td class=kW>6:0</td>
<td class=br>78:18</td><td class=br>+60</td>
<td class=bc>15 - 2 - 0</td>
<td class=br><strong>32</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>74.</td><td class=kt>Ar Verbi�s</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=kW>9:0</td>
<td class=br>70:16</td><td class=br>+54</td>
<td class=bc>15 - 2 - 0</td>
<td class=br><strong>32</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>75.</td><td class=kt>Al Liepi��</td><td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=kW>10:0</td>
<td class=kW>2:0</td>
<td class=kT>4:4</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>7:0</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=br>60:25</td><td class=br>+35</td>
<td class=bc>12 - 2 - 3</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>76.</td><td class=kt>Ro Purmalis</td><td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>7:3</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=br>66:28</td><td class=br>+38</td>
<td class=bc>11 - 4 - 2</td>
<td class=br><strong>26</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>77.</td><td class=kt>Ra St�lmanis</td><td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>10:0</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kT>2:2</td>
<td class=br>56:24</td><td class=br>+32</td>
<td class=bc>9 - 5 - 3</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>78.</td><td class=kt>Ag Pav�rs</td><td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kL>3:7</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>10:0</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=br>53:24</td><td class=br>+29</td>
<td class=bc>11 - 0 - 6</td>
<td class=br><strong>22</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>79.</td><td class=kt>Ed Jansons</td><td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>10:0</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kT>0:0</td>
<td class=kW>9:0</td>
<td class=kW>3:0</td>
<td class=br>41:33</td><td class=br>+8</td>
<td class=bc>8 - 3 - 6</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>80.</td><td class=kt>Kr G�tmanis</td><td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kL>0:10</td>
<td class=kL>2:3</td>
<td class=kL>0:10</td>
<td class=kL>1:2</td>
<td class=kL>0:10</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kL>0:10</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=br>39:60</td><td class=br>-21</td>
<td class=bc>9 - 0 - 8</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>81.</td><td class=kt>Al Sili��</td><td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=br>24:32</td><td class=br>-8</td>
<td class=bc>8 - 2 - 7</td>
<td class=br><strong>18</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>82.</td><td class=kt>Em Ka�s</td><td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>10:0</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kL>0:8</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=br>34:41</td><td class=br>-7</td>
<td class=bc>7 - 3 - 7</td>
<td class=br><strong>17</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>83.</td><td class=kt>J� T�ns</td><td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>0:10</td>
<td class=kx>*</td>
<td class=kL>0:10</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kL>0:10</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=br>34:54</td><td class=br>-20</td>
<td class=bc>6 - 4 - 7</td>
<td class=br><strong>16</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>84.</td><td class=kt>M� Timbers</td><td class=kL>3:4</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kW>10:0</td>
<td class=kx>*</td>
<td class=kW>10:0</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=br>48:42</td><td class=br>+6</td>
<td class=bc>6 - 1 - 10</td>
<td class=br><strong>13</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>85.</td><td class=kt>Kr Kl�vi��</td><td class=kL>0:1</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kW>2:0</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kL>0:10</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=br>18:40</td><td class=br>-22</td>
<td class=bc>6 - 0 - 11</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>86.</td><td class=kt>Br Gor�anovs</td><td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>10:1</td>
<td class=kW>6:1</td>
<td class=br>39:50</td><td class=br>-11</td>
<td class=bc>5 - 0 - 12</td>
<td class=br><strong>10</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>87.</td><td class=kt>Da Mergins</td><td class=kL>0:7</td>
<td class=kL>0:3</td>
<td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>0:10</td>
<td class=kL>0:2</td>
<td class=kW>10:0</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>10:0</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kT>0:0</td>
<td class=kW>2:1</td>
<td class=br>31:57</td><td class=br>-26</td>
<td class=bc>4 - 2 - 11</td>
<td class=br><strong>10</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>88.</td><td class=kt>Ra Meija</td><td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kT>0:0</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kW>8:0</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=br>21:48</td><td class=br>-27</td>
<td class=bc>2 - 3 - 12</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>89.</td><td class=kt>De Heidemanis</td><td class=kL>1:9</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>0:9</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:10</td>
<td class=kT>0:0</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=br>8:72</td><td class=br>-64</td>
<td class=bc>0 - 3 - 14</td>
<td class=br><strong>3</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>90.</td><td class=kt>Mi Birzgalis</td><td class=kL>0:6</td>
<td class=kL>0:9</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=br>10:66</td><td class=br>-56</td>
<td class=bc>0 - 2 - 15</td>
<td class=br><strong>2</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ra St�lmanis</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>Da Mergins</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Kr G�tmanis</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ed Jansons</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Birzgalis</td><td class=bc>-</td><td class=blW>J� T�ns</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ar Pavlovs</td><td class=bc>-</td><td class=bl>Da Mergins</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ra St�lmanis</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kr G�tmanis</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ed Jansons</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Ar Verbi�s</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Kr Kl�vi��</td><td class=bc>-</td><td class=bl>Da Mergins</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ar Pavlovs</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ra St�lmanis</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Kr G�tmanis</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ed Jansons</td><td class=bc>-</td><td class=blW>Ar Verbi�s</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Mi Birzgalis</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>M� Timbers</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ar Pavlovs</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ra St�lmanis</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Ar Verbi�s</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kr G�tmanis</td><td class=bc>-</td><td class=bl>Mi Birzgalis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ed Jansons</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>M� Timbers</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ar Pavlovs</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ra St�lmanis</td><td class=bc>-</td><td class=blW>Ar Verbi�s</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>Mi Birzgalis</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr G�tmanis</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>J� T�ns</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ar Verbi�s</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ar Pavlovs</td><td class=bc>-</td><td class=bl>Mi Birzgalis</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ra St�lmanis</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Ed Jansons</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>J� T�ns</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=blW>Ar Verbi�s</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kr Kl�vi��</td><td class=bc>-</td><td class=bl>Mi Birzgalis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ar Pavlovs</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ra St�lmanis</td><td class=bc>-</td><td class=bl>Ed Jansons</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>J� T�ns</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Ar Verbi�s</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=bl>Mi Birzgalis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ed Jansons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ar Pavlovs</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ra St�lmanis</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Ar Verbi�s</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Mi Birzgalis</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>M� Timbers</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=blW>Ed Jansons</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>Kr G�tmanis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=bl>Ar Verbi�s</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Mi Birzgalis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Ra Meija</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Ed Jansons</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>Kr G�tmanis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ra St�lmanis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ar Verbi�s</td><td class=bc>-</td><td class=bl>Mi Birzgalis</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>J� T�ns</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Ed Jansons</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Kr G�tmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=blW>Ra St�lmanis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>Ar Pavlovs</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Mi Birzgalis</td><td class=bc>-</td><td class=blW>Ra Meija</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ar Verbi�s</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=bl>Ed Jansons</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Ra St�lmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>Ar Pavlovs</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Birzgalis</td><td class=bc>-</td><td class=blW>Ed Jansons</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ar Verbi�s</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>J� T�ns</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Ra St�lmanis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Ar Pavlovs</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>Kr Kl�vi��</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Ed Jansons</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Kr G�tmanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Birzgalis</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ar Verbi�s</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=bl>Ra St�lmanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Ar Pavlovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Kr Kl�vi��</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>M� Timbers</td><td class=bc>-</td><td class=bl>Da Mergins</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ed Jansons</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Birzgalis</td><td class=bc>-</td><td class=bl>Ra St�lmanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ar Verbi�s</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Da Mergins</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>10 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ed Jansons</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Ra St�lmanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Ar Pavlovs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Birzgalis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ar Verbi�s</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=blW>Da Mergins</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=blW>Ra St�lmanis</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ed Jansons</td><td class=bc>-</td><td class=blW>Ar Pavlovs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Kr Kl�vi��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Birzgalis</td><td class=bc>-</td><td class=blW>Da Mergins</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ar Verbi�s</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=blW>M� Timbers</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=bl>Ra St�lmanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Ar Pavlovs</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Jansons</td><td class=bc>-</td><td class=blW>Kr Kl�vi��</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Da Mergins</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Birzgalis</td><td class=bc>-</td><td class=blW>M� Timbers</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ar Verbi�s</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>0 : 10</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Ra St�lmanis</td><td class=bc>-</td><td class=blW>Ar Pavlovs</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=blW>Da Mergins</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ed Jansons</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Birzgalis</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ar Verbi�s</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>1 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
