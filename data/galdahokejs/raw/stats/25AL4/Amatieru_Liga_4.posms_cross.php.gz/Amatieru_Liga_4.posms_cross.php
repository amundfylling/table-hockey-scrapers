<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Amatieru Liga 4.posms</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Amatieru_Liga_4.posms_list.php">Amatieru Liga 4.posms, 15. February 2025</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group AL A grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>As Kocere</td><td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=br>52:19</td><td class=br>+33</td>
<td class=bc>13 - 2 - 1</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ma Krauze</td><td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>51:22</td><td class=br>+29</td>
<td class=bc>12 - 2 - 2</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ag Pav�rs</td><td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kT>4:4</td>
<td class=kW>6:0</td>
<td class=kT>0:0</td>
<td class=kW>8:0</td>
<td class=kW>6:1</td>
<td class=kL>0:1</td>
<td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=br>53:20</td><td class=br>+33</td>
<td class=bc>9 - 5 - 2</td>
<td class=br><strong>23</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Er Kalni��</td><td class=kL>0:3</td>
<td class=kW>5:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>5:5</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=br>44:23</td><td class=br>+21</td>
<td class=bc>9 - 4 - 3</td>
<td class=br><strong>22</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Gu Skapsts</td><td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=br>43:27</td><td class=br>+16</td>
<td class=bc>9 - 4 - 3</td>
<td class=br><strong>22</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Al Pimenovs</td><td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>0:6</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=br>49:34</td><td class=br>+15</td>
<td class=bc>10 - 1 - 5</td>
<td class=br><strong>21</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ge Jansons</td><td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=br>38:27</td><td class=br>+11</td>
<td class=bc>9 - 2 - 5</td>
<td class=br><strong>20</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Na Kr�mi��</td><td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>0:8</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=br>45:41</td><td class=br>+4</td>
<td class=bc>9 - 1 - 6</td>
<td class=br><strong>19</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Br Gor�anovs</td><td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kT>5:5</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=br>41:40</td><td class=br>+1</td>
<td class=bc>6 - 3 - 7</td>
<td class=br><strong>15</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>Em Ka�s</td><td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=br>22:28</td><td class=br>-6</td>
<td class=bc>6 - 3 - 7</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>A</td><td class=d>11.</td><td class=kt>�r Egl�tis</td><td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kW>5:4</td>
<td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>5:3</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>28:31</td><td class=br>-3</td>
<td class=bc>5 - 3 - 8</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Kr Jansons</td><td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kL>0:10</td>
<td class=kW>2:1</td>
<td class=br>22:48</td><td class=br>-26</td>
<td class=bc>6 - 0 - 10</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ed Liepi��</td><td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=br>32:40</td><td class=br>-8</td>
<td class=bc>5 - 1 - 10</td>
<td class=br><strong>11</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>T� Gor�anova</td><td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=br>29:43</td><td class=br>-14</td>
<td class=bc>4 - 2 - 10</td>
<td class=br><strong>10</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Da Vai�iul�ns</td><td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=br>28:54</td><td class=br>-26</td>
<td class=bc>2 - 4 - 10</td>
<td class=br><strong>8</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Kr S�manis</td><td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>10:0</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=br>32:48</td><td class=br>-16</td>
<td class=bc>2 - 3 - 11</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ra Meija</td><td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=br>9:73</td><td class=br>-64</td>
<td class=bc>0 - 0 - 16</td>
<td class=br><strong>0</strong></td><td class=d>17.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Skapsts Gustavs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Pimenovs Alekss</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Jansons Kristaps</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Liepi�� Edgars</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Kr�mi�� Nauris</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>Skapsts Gustavs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Pimenovs Alekss</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Jansons Kristaps</td><td class=bc>-</td><td class=blW>Liepi�� Edgars</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Kr�mi�� Nauris</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>Pimenovs Alekss</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Gor�anova T�na</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Liepi�� Edgars</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Kr�mi�� Nauris</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Jansons Kristaps</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Pimenovs Alekss</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Liepi�� Edgars</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Kr�mi�� Nauris</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Jansons Kristaps</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Pimenovs Alekss</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Liepi�� Edgars</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>Kr�mi�� Nauris</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Pimenovs Alekss</td><td class=bc>-</td><td class=bl>Liepi�� Edgars</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Kr�mi�� Nauris</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=blW>Jansons Kristaps</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Liepi�� Edgars</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Kr�mi�� Nauris</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Pimenovs Alekss</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Jansons Kristaps</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=blW>Kr�mi�� Nauris</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pimenovs Alekss</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Jansons Kristaps</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Kr�mi�� Nauris</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Pimenovs Alekss</td><td class=bc>-</td><td class=bl>Jansons Kristaps</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr�mi�� Nauris</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Jansons Kristaps</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Pimenovs Alekss</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=blW>Gor�anova T�na</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kr�mi�� Nauris</td><td class=bc>-</td><td class=bl>Jansons Kristaps</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pimenovs Alekss</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Jansons Kristaps</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr�mi�� Nauris</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Pimenovs Alekss</td><td class=bc>-</td><td class=blW>Skapsts Gustavs</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Jansons Kristaps</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kr�mi�� Nauris</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Skapsts Gustavs</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Jansons Kristaps</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kr�mi�� Nauris</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Pimenovs Alekss</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Jansons Kristaps</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr�mi�� Nauris</td><td class=bc>-</td><td class=blW>Pimenovs Alekss</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=blW>Gor�anova T�na</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Jansons Kristaps</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Pimenovs Alekss</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr�mi�� Nauris</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Gor�anova T�na</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Skapsts Gustavs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Jansons Kristaps</td><td class=bc>-</td><td class=blW>S�manis Kri�j�nis</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Pimenovs Alekss</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Liepi�� Edgars</td><td class=bc>5 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group AL B grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>D� Vesele</td><td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>7:0</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>7:0</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kT>0:0</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=br>59:17</td><td class=br>+42</td>
<td class=bc>12 - 2 - 1</td>
<td class=br><strong>26</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>M� �irsis</td><td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kW>6:0</td>
<td class=br>58:26</td><td class=br>+32</td>
<td class=bc>12 - 2 - 1</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ra St�lmanis</td><td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=br>48:30</td><td class=br>+18</td>
<td class=bc>11 - 0 - 4</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Al Liepi��</td><td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kT>0:0</td>
<td class=br>36:20</td><td class=br>+16</td>
<td class=bc>9 - 3 - 3</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ma Kalni��</td><td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=br>38:20</td><td class=br>+18</td>
<td class=bc>10 - 1 - 4</td>
<td class=br><strong>21</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ed Jansons</td><td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=br>34:24</td><td class=br>+10</td>
<td class=bc>7 - 4 - 4</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Al Sili��</td><td class=kL>0:7</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=br>32:33</td><td class=br>-1</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Kr Rudz�tis</td><td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kL>2:7</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=br>34:40</td><td class=br>-6</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>D� Vai�iul�ns</td><td class=kL>0:5</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kW>7:2</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=br>30:38</td><td class=br>-8</td>
<td class=bc>6 - 1 - 8</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>An Kova��uks</td><td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=br>30:40</td><td class=br>-10</td>
<td class=bc>5 - 3 - 7</td>
<td class=br><strong>13</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>A</td><td class=d>11.</td><td class=kt>Ar Vasks</td><td class=kL>0:7</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=br>26:42</td><td class=br>-16</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Re Saul�tis</td><td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=br>21:38</td><td class=br>-17</td>
<td class=bc>5 - 0 - 10</td>
<td class=br><strong>10</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Re Tomsons</td><td class=kW>3:0</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=br>23:45</td><td class=br>-22</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>M� Timbers</td><td class=kT>0:0</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=br>30:40</td><td class=br>-10</td>
<td class=bc>3 - 2 - 10</td>
<td class=br><strong>8</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Kr Kl�vi��</td><td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>19:32</td><td class=br>-13</td>
<td class=bc>3 - 1 - 11</td>
<td class=br><strong>7</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Ma Isakovs</td><td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>3:6</td>
<td class=kT>0:0</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>0:5</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>12:45</td><td class=br>-33</td>
<td class=bc>2 - 3 - 10</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Isakovs Marks</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Jansons Edvards</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Tomsons Reinolds</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kl�vi�� Kristaps</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Vasks Artis</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Isakovs Marks</td><td class=bc>-</td><td class=blW>Vai�iul�ns D�vis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Jansons Edvards</td><td class=bc>-</td><td class=bl>Tomsons Reinolds</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kl�vi�� Kristaps</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=blW>Rudz�tis Kristaps</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Vasks Artis</td><td class=bc>-</td><td class=blW>Vai�iul�ns D�vis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>Tomsons Reinolds</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Isakovs Marks</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Jansons Edvards</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kl�vi�� Kristaps</td><td class=bc>-</td><td class=blW>Rudz�tis Kristaps</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>Tomsons Reinolds</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Isakovs Marks</td><td class=bc>-</td><td class=blW>Sili�� Alberts</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Jansons Edvards</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kl�vi�� Kristaps</td><td class=bc>-</td><td class=blW>Kova��uks Andris</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Tomsons Reinolds</td><td class=bc>-</td><td class=blW>Timbers M�rti��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vasks Artis</td><td class=bc>-</td><td class=blW>Sili�� Alberts</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Isakovs Marks</td><td class=bc>-</td><td class=blW>Rudz�tis Kristaps</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Jansons Edvards</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Kl�vi�� Kristaps</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Tomsons Reinolds</td><td class=bc>-</td><td class=blW>Sili�� Alberts</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Vasks Artis</td><td class=bc>-</td><td class=blW>Rudz�tis Kristaps</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Isakovs Marks</td><td class=bc>-</td><td class=blW>Kova��uks Andris</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Jansons Edvards</td><td class=bc>-</td><td class=bl>Kl�vi�� Kristaps</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Tomsons Reinolds</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vasks Artis</td><td class=bc>-</td><td class=blW>Kova��uks Andris</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Kl�vi�� Kristaps</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Isakovs Marks</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Jansons Edvards</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Tomsons Reinolds</td><td class=bc>-</td><td class=blW>Kova��uks Andris</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>Kl�vi�� Kristaps</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vasks Artis</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Isakovs Marks</td><td class=bc>-</td><td class=blW>Jansons Edvards</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Kl�vi�� Kristaps</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Tomsons Reinolds</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=blW>Jansons Edvards</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Isakovs Marks</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Kl�vi�� Kristaps</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Jansons Edvards</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Tomsons Reinolds</td><td class=bc>-</td><td class=blW>Isakovs Marks</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vasks Artis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Kl�vi�� Kristaps</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Jansons Edvards</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Isakovs Marks</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Tomsons Reinolds</td><td class=bc>-</td><td class=bl>Vasks Artis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Jansons Edvards</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Isakovs Marks</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Vasks Artis</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Tomsons Reinolds</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Kl�vi�� Kristaps</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Jansons Edvards</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Isakovs Marks</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Tomsons Reinolds</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>Jansons Edvards</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kl�vi�� Kristaps</td><td class=bc>-</td><td class=bl>Isakovs Marks</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Vasks Artis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Vai�iul�ns D�vis</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Tomsons Reinolds</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Isakovs Marks</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Kl�vi�� Kristaps</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Tomsons Reinolds</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Jansons Edvards</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Vasks Artis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Kl�vi�� Kristaps</td><td class=bc>-</td><td class=blW>Tomsons Reinolds</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group AL 1.l�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/8</td><td class=d>1.</td><td class=kt>Ar Vasks</td><td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>6:4</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>65:27</td><td class=br>+38</td>
<td class=bc>17 - 2 - 2</td>
<td class=br><strong>36</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/8</td><td class=d>2.</td><td class=kt>Br Gor�anovs</td><td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>7:1</td>
<td class=kT>5:5</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=br>76:41</td><td class=br>+35</td>
<td class=bc>15 - 4 - 2</td>
<td class=br><strong>34</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/8</td><td class=d>3.</td><td class=kt>Ge Jansons</td><td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=br>44:23</td><td class=br>+21</td>
<td class=bc>15 - 4 - 2</td>
<td class=br><strong>34</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/8</td><td class=d>4.</td><td class=kt>Re Saul�tis</td><td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kT>5:5</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kW>5:0</td>
<td class=br>59:38</td><td class=br>+21</td>
<td class=bc>12 - 5 - 4</td>
<td class=br><strong>29</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/8</td><td class=d>5.</td><td class=kt>Ed Jansons</td><td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=br>57:28</td><td class=br>+29</td>
<td class=bc>12 - 4 - 5</td>
<td class=br><strong>28</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/8</td><td class=d>6.</td><td class=kt>M� Timbers</td><td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>9:0</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=br>64:41</td><td class=br>+23</td>
<td class=bc>13 - 1 - 7</td>
<td class=br><strong>27</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/8</td><td class=d>7.</td><td class=kt>An Kova��uks</td><td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=br>45:30</td><td class=br>+15</td>
<td class=bc>10 - 4 - 7</td>
<td class=br><strong>24</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/8</td><td class=d>8.</td><td class=kt>Em Ka�s</td><td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=br>46:42</td><td class=br>+4</td>
<td class=bc>9 - 5 - 7</td>
<td class=br><strong>23</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/8</td><td class=d>9.</td><td class=kt>�r Egl�tis</td><td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kL>1:4</td>
<td class=kW>1:0</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=br>34:34</td><td class=br>0</td>
<td class=bc>9 - 4 - 8</td>
<td class=br><strong>22</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/8</td><td class=d>10.</td><td class=kt>Ed Liepi��</td><td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=br>49:43</td><td class=br>+6</td>
<td class=bc>8 - 5 - 8</td>
<td class=br><strong>21</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/8</td><td class=d>11.</td><td class=kt>Kr S�manis</td><td class=kW>3:2</td>
<td class=kL>1:7</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>3:6</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:8</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=br>42:55</td><td class=br>-13</td>
<td class=bc>8 - 5 - 8</td>
<td class=br><strong>21</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/8</td><td class=d>12.</td><td class=kt>D� Vai�iul�ns</td><td class=kL>2:4</td>
<td class=kT>5:5</td>
<td class=kL>2:3</td>
<td class=kT>5:5</td>
<td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kW>3:0</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=br>55:44</td><td class=br>+11</td>
<td class=bc>8 - 5 - 8</td>
<td class=br><strong>21</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/8</td><td class=d>13.</td><td class=kt>Na Kr�mi��</td><td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>7:0</td>
<td class=br>46:42</td><td class=br>+4</td>
<td class=bc>9 - 2 - 10</td>
<td class=br><strong>20</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/8</td><td class=d>14.</td><td class=kt>Ma Isakovs</td><td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=br>36:35</td><td class=br>+1</td>
<td class=bc>8 - 4 - 9</td>
<td class=br><strong>20</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/8</td><td class=d>15.</td><td class=kt>Da Vai�iul�ns</td><td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>8:1</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=br>52:47</td><td class=br>+5</td>
<td class=bc>8 - 4 - 9</td>
<td class=br><strong>20</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/8</td><td class=d>16.</td><td class=kt>Re Tomsons</td><td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=br>43:55</td><td class=br>-12</td>
<td class=bc>8 - 3 - 10</td>
<td class=br><strong>19</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Kr Rudz�tis</td><td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=br>30:53</td><td class=br>-23</td>
<td class=bc>5 - 5 - 11</td>
<td class=br><strong>15</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Kr Jansons</td><td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=br>33:50</td><td class=br>-17</td>
<td class=bc>4 - 6 - 11</td>
<td class=br><strong>14</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Kr Kl�vi��</td><td class=kL>4:6</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>9:0</td>
<td class=br>37:50</td><td class=br>-13</td>
<td class=bc>5 - 1 - 15</td>
<td class=br><strong>11</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>T� Gor�anova</td><td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kL>0:9</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=br>25:66</td><td class=br>-41</td>
<td class=bc>3 - 5 - 13</td>
<td class=br><strong>11</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Al Sili��</td><td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>0:1</td>
<td class=kW>3:0</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>27:55</td><td class=br>-28</td>
<td class=bc>3 - 3 - 15</td>
<td class=br><strong>9</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Ra Meija</td><td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>0:7</td>
<td class=kL>0:7</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>0:9</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>13:79</td><td class=br>-66</td>
<td class=bc>1 - 1 - 19</td>
<td class=br><strong>3</strong></td><td class=d>22.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Isakovs Marks</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Vai�iul�ns D�vis</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Kl�vi�� Kristaps</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Jansons Edvards</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Kr�mi�� Nauris</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Jansons Kristaps</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Tomsons Reinolds</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Isakovs Marks</td><td class=bc>-</td><td class=blW>Vai�iul�ns D�vis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Gor�anova T�na</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Kl�vi�� Kristaps</td><td class=bc>-</td><td class=blW>Jansons Edvards</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Kr�mi�� Nauris</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=bl>Jansons Kristaps</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Tomsons Reinolds</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Isakovs Marks</td><td class=bc>-</td><td class=blW>Sili�� Alberts</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>Jansons Edvards</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Kr�mi�� Nauris</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kl�vi�� Kristaps</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Jansons Kristaps</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Tomsons Reinolds</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Jansons Edvards</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Isakovs Marks</td><td class=bc>-</td><td class=bl>Kr�mi�� Nauris</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=bl>Jansons Kristaps</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kl�vi�� Kristaps</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Tomsons Reinolds</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>Jansons Edvards</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>Kr�mi�� Nauris</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Isakovs Marks</td><td class=bc>-</td><td class=bl>Jansons Kristaps</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kl�vi�� Kristaps</td><td class=bc>-</td><td class=bl>Tomsons Reinolds</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Timbers M�rti��</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Jansons Edvards</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Kr�mi�� Nauris</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>Jansons Kristaps</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Isakovs Marks</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=blW>Tomsons Reinolds</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>S�manis Kri�j�nis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kl�vi�� Kristaps</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Jansons Edvards</td><td class=bc>-</td><td class=bl>Kr�mi�� Nauris</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Jansons Kristaps</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Tomsons Reinolds</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Isakovs Marks</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kl�vi�� Kristaps</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Vai�iul�ns Daniels</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Kr�mi�� Nauris</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Jansons Edvards</td><td class=bc>-</td><td class=bl>Jansons Kristaps</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=blW>Tomsons Reinolds</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kova��uks Andris</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Vasks Artis</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Isakovs Marks</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Gor�anova T�na</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kl�vi�� Kristaps</td><td class=bc>-</td><td class=blW>Timbers M�rti��</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Jansons Kristaps</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr�mi�� Nauris</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Jansons Edvards</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Tomsons Reinolds</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>S�manis Kri�j�nis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vasks Artis</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Isakovs Marks</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=blW>Timbers M�rti��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Kl�vi�� Kristaps</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Jansons Kristaps</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr�mi�� Nauris</td><td class=bc>-</td><td class=bl>Tomsons Reinolds</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Jansons Edvards</td><td class=bc>-</td><td class=blW>S�manis Kri�j�nis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Isakovs Marks</td><td class=bc>-</td><td class=bl>Kl�vi�� Kristaps</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jansons Kristaps</td><td class=bc>-</td><td class=blW>Tomsons Reinolds</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kr�mi�� Nauris</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Jansons Edvards</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=blW>Timbers M�rti��</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Kl�vi�� Kristaps</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Isakovs Marks</td><td class=bc>-</td><td class=blW>Liepi�� Edgars</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jansons Kristaps</td><td class=bc>-</td><td class=blW>Meija Ralfs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Kr�mi�� Nauris</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Jansons Edvards</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Kl�vi�� Kristaps</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=blW>Liepi�� Edgars</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Isakovs Marks</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vasks Artis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Tomsons Reinolds</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Jansons Kristaps</td><td class=bc>-</td><td class=blW>Vai�iul�ns Daniels</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kr�mi�� Nauris</td><td class=bc>-</td><td class=bl>Kl�vi�� Kristaps</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Jansons Edvards</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Liepi�� Edgars</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Isakovs Marks</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Tomsons Reinolds</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Timbers M�rti��</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Jansons Kristaps</td><td class=bc>-</td><td class=bl>Kl�vi�� Kristaps</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Gor�anova T�na</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kr�mi�� Nauris</td><td class=bc>-</td><td class=blW>Liepi�� Edgars</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Jansons Edvards</td><td class=bc>-</td><td class=bl>Isakovs Marks</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=blW>Vai�iul�ns Daniels</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Tomsons Reinolds</td><td class=bc>-</td><td class=blW>Timbers M�rti��</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Kl�vi�� Kristaps</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Jansons Kristaps</td><td class=bc>-</td><td class=blW>Liepi�� Edgars</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Isakovs Marks</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kr�mi�� Nauris</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Jansons Edvards</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Vai�iul�ns Daniels</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Kl�vi�� Kristaps</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Tomsons Reinolds</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Liepi�� Edgars</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Isakovs Marks</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Jansons Kristaps</td><td class=bc>-</td><td class=bl>Vasks Artis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr�mi�� Nauris</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Jansons Edvards</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Kl�vi�� Kristaps</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Liepi�� Edgars</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Tomsons Reinolds</td><td class=bc>-</td><td class=bl>Isakovs Marks</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Kova��uks Andris</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Jansons Kristaps</td><td class=bc>-</td><td class=blW>Vai�iul�ns D�vis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kr�mi�� Nauris</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Jansons Edvards</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Kl�vi�� Kristaps</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Liepi�� Edgars</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=blW>Isakovs Marks</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Vasks Artis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Tomsons Reinolds</td><td class=bc>-</td><td class=blW>Kova��uks Andris</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jansons Kristaps</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Jansons Edvards</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Kr�mi�� Nauris</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Liepi�� Edgars</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Isakovs Marks</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Tomsons Reinolds</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Sili�� Alberts</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Jansons Edvards</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Jansons Kristaps</td><td class=bc>-</td><td class=bl>Kr�mi�� Nauris</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Kl�vi�� Kristaps</td><td class=bc>-</td><td class=blW>Liepi�� Edgars</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Isakovs Marks</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Vai�iul�ns D�vis</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Tomsons Reinolds</td><td class=bc>-</td><td class=blW>Jansons Edvards</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Kr�mi�� Nauris</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Jansons Kristaps</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Isakovs Marks</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Kl�vi�� Kristaps</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>Vai�iul�ns D�vis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Sili�� Alberts</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Jansons Edvards</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=blW>Kr�mi�� Nauris</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Tomsons Reinolds</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Jansons Kristaps</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Kova��uks Andris</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Kl�vi�� Kristaps</td><td class=bc>-</td><td class=blW>Vai�iul�ns D�vis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Jansons Edvards</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Kr�mi�� Nauris</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Jansons Kristaps</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Tomsons Reinolds</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
