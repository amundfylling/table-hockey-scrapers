<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>WCC</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="WCC_list.php">WCC, 28. September 2025</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group A Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>THC Nertus</td><td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_530_542.php">12:2</a></td>
<td class=kW><a target="_blank" href="t_92_530_537.php">10:4</a></td>
<td class=kW><a target="_blank" href="t_92_530_536.php">10:5</a></td>
<td class=kW><a target="_blank" href="t_92_530_543.php">8:5</a></td>
<td class=br>40:16</td><td class=br>+24</td>
<td class=bc>4 - 0 - 0</td>
<td class=br><strong>8</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Incukalns THC JUN 1</td><td class=kL><a target="_blank" href="t_92_530_542.php">2:12</a></td>
<td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_537_542.php">7:6</a></td>
<td class=kT><a target="_blank" href="t_92_536_542.php">6:6</a></td>
<td class=kW><a target="_blank" href="t_92_542_543.php">12:2</a></td>
<td class=br>27:26</td><td class=br>+1</td>
<td class=bc>2 - 1 - 1</td>
<td class=br><strong>5</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Incukalns THC 2</td><td class=kL><a target="_blank" href="t_92_530_537.php">4:10</a></td>
<td class=kL><a target="_blank" href="t_92_537_542.php">6:7</a></td>
<td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_536_537.php">11:5</a></td>
<td class=kW><a target="_blank" href="t_92_537_543.php">15:1</a></td>
<td class=br>36:23</td><td class=br>+13</td>
<td class=bc>2 - 0 - 2</td>
<td class=br><strong>4</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Gladiators Plzen</td><td class=kL><a target="_blank" href="t_92_530_536.php">5:10</a></td>
<td class=kT><a target="_blank" href="t_92_536_542.php">6:6</a></td>
<td class=kL><a target="_blank" href="t_92_536_537.php">5:11</a></td>
<td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_536_543.php">12:4</a></td>
<td class=br>28:31</td><td class=br>-3</td>
<td class=bc>1 - 1 - 2</td>
<td class=br><strong>3</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Valmieras nov. GHK 2</td><td class=kL><a target="_blank" href="t_92_530_543.php">5:8</a></td>
<td class=kL><a target="_blank" href="t_92_542_543.php">2:12</a></td>
<td class=kL><a target="_blank" href="t_92_537_543.php">1:15</a></td>
<td class=kL><a target="_blank" href="t_92_536_543.php">4:12</a></td>
<td class=kx>*</td>
<td class=br>12:47</td><td class=br>-35</td>
<td class=bc>0 - 0 - 4</td>
<td class=br><strong>0</strong></td><td class=d>5.</td>
</tr></table></div></p>
<p class=v>Group B Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>BJC Laimite</td><td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_473_531.php">8:6</a></td>
<td class=kW><a target="_blank" href="t_92_531_538.php">7:6</a></td>
<td class=kW><a target="_blank" href="t_92_475_531.php">10:5</a></td>
<td class=kW><a target="_blank" href="t_92_531_544.php">10:6</a></td>
<td class=br>35:23</td><td class=br>+12</td>
<td class=bc>4 - 0 - 0</td>
<td class=br><strong>8</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Jurmalas GHK</td><td class=kL><a target="_blank" href="t_92_473_531.php">6:8</a></td>
<td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_473_538.php">9:4</a></td>
<td class=kW><a target="_blank" href="t_92_473_475.php">10:4</a></td>
<td class=kW><a target="_blank" href="t_92_473_544.php">15:0</a></td>
<td class=br>40:16</td><td class=br>+24</td>
<td class=bc>3 - 0 - 1</td>
<td class=br><strong>6</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Brent Plast BHK</td><td class=kL><a target="_blank" href="t_92_531_538.php">6:7</a></td>
<td class=kL><a target="_blank" href="t_92_473_538.php">4:9</a></td>
<td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_475_538.php">8:4</a></td>
<td class=kW><a target="_blank" href="t_92_538_544.php">13:2</a></td>
<td class=br>31:22</td><td class=br>+9</td>
<td class=bc>2 - 0 - 2</td>
<td class=br><strong>4</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Valmieras nov. GHK JUN</td><td class=kL><a target="_blank" href="t_92_475_531.php">5:10</a></td>
<td class=kL><a target="_blank" href="t_92_473_475.php">4:10</a></td>
<td class=kL><a target="_blank" href="t_92_475_538.php">4:8</a></td>
<td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_475_544.php">10:3</a></td>
<td class=br>23:31</td><td class=br>-8</td>
<td class=bc>1 - 0 - 3</td>
<td class=br><strong>2</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Incukalns THC 3</td><td class=kL><a target="_blank" href="t_92_531_544.php">6:10</a></td>
<td class=kL><a target="_blank" href="t_92_473_544.php">0:15</a></td>
<td class=kL><a target="_blank" href="t_92_538_544.php">2:13</a></td>
<td class=kL><a target="_blank" href="t_92_475_544.php">3:10</a></td>
<td class=kx>*</td>
<td class=br>11:48</td><td class=br>-37</td>
<td class=bc>0 - 0 - 4</td>
<td class=br><strong>0</strong></td><td class=d>5.</td>
</tr></table></div></p>
<p class=v>Group C Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Incukalns THC 1</td><td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_532_535.php">6:5</a></td>
<td class=kW><a target="_blank" href="t_92_532_539.php">10:5</a></td>
<td class=kW><a target="_blank" href="t_92_334_532.php">10:4</a></td>
<td class=kW><a target="_blank" href="t_92_532_545.php">14:2</a></td>
<td class=kW><a target="_blank" href="t_92_335_532.php">16:0</a></td>
<td class=br>56:16</td><td class=br>+40</td>
<td class=bc>5 - 0 - 0</td>
<td class=br><strong>10</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Valmieras nov. GHK 1</td><td class=kL><a target="_blank" href="t_92_532_535.php">5:6</a></td>
<td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_535_539.php">13:1</a></td>
<td class=kW><a target="_blank" href="t_92_334_535.php">9:2</a></td>
<td class=kW><a target="_blank" href="t_92_535_545.php">13:3</a></td>
<td class=kW><a target="_blank" href="t_92_335_535.php">16:0</a></td>
<td class=br>56:12</td><td class=br>+44</td>
<td class=bc>4 - 0 - 1</td>
<td class=br><strong>8</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Big Band Praha</td><td class=kL><a target="_blank" href="t_92_532_539.php">5:10</a></td>
<td class=kL><a target="_blank" href="t_92_535_539.php">1:13</a></td>
<td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_334_539.php">7:4</a></td>
<td class=kW><a target="_blank" href="t_92_539_545.php">10:4</a></td>
<td class=kW><a target="_blank" href="t_92_335_539.php">16:0</a></td>
<td class=br>39:31</td><td class=br>+8</td>
<td class=bc>3 - 0 - 2</td>
<td class=br><strong>6</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>GHK Altona JUN 1</td><td class=kL><a target="_blank" href="t_92_334_532.php">4:10</a></td>
<td class=kL><a target="_blank" href="t_92_334_535.php">2:9</a></td>
<td class=kL><a target="_blank" href="t_92_334_539.php">4:7</a></td>
<td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_334_545.php">11:3</a></td>
<td class=kW><a target="_blank" href="t_92_334_335.php">14:2</a></td>
<td class=br>35:31</td><td class=br>+4</td>
<td class=bc>2 - 0 - 3</td>
<td class=br><strong>4</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Incukalns THC JUN 2</td><td class=kL><a target="_blank" href="t_92_532_545.php">2:14</a></td>
<td class=kL><a target="_blank" href="t_92_535_545.php">3:13</a></td>
<td class=kL><a target="_blank" href="t_92_539_545.php">4:10</a></td>
<td class=kL><a target="_blank" href="t_92_334_545.php">3:11</a></td>
<td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_335_545.php">8:6</a></td>
<td class=br>20:54</td><td class=br>-34</td>
<td class=bc>1 - 0 - 4</td>
<td class=br><strong>2</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>GHK Altona JUN 2</td><td class=kL><a target="_blank" href="t_92_335_532.php">0:16</a></td>
<td class=kL><a target="_blank" href="t_92_335_535.php">0:16</a></td>
<td class=kL><a target="_blank" href="t_92_335_539.php">0:16</a></td>
<td class=kL><a target="_blank" href="t_92_334_335.php">2:14</a></td>
<td class=kL><a target="_blank" href="t_92_335_545.php">6:8</a></td>
<td class=kx>*</td>
<td class=br>8:70</td><td class=br>-62</td>
<td class=bc>0 - 0 - 5</td>
<td class=br><strong>0</strong></td><td class=d>6.</td>
</tr></table></div></p>
<p class=v>Group D Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>VJN Ventspils 1</td><td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_476_533.php">8:3</a></td>
<td class=kW><a target="_blank" href="t_92_533_541.php">9:4</a></td>
<td class=kW><a target="_blank" href="t_92_533_540.php">9:4</a></td>
<td class=kW><a target="_blank" href="t_92_483_533.php">15:0</a></td>
<td class=kW><a target="_blank" href="t_92_481_533.php">16:0</a></td>
<td class=br>57:11</td><td class=br>+46</td>
<td class=bc>5 - 0 - 0</td>
<td class=br><strong>10</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>GHK Altona 1</td><td class=kL><a target="_blank" href="t_92_476_533.php">3:8</a></td>
<td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_476_541.php">7:6</a></td>
<td class=kW><a target="_blank" href="t_92_476_540.php">7:5</a></td>
<td class=kW><a target="_blank" href="t_92_476_483.php">13:1</a></td>
<td class=kW><a target="_blank" href="t_92_476_481.php">14:0</a></td>
<td class=br>44:20</td><td class=br>+24</td>
<td class=bc>4 - 0 - 1</td>
<td class=br><strong>8</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>THC Black Forest Werewolves</td><td class=kL><a target="_blank" href="t_92_533_541.php">4:9</a></td>
<td class=kL><a target="_blank" href="t_92_476_541.php">6:7</a></td>
<td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_540_541.php">9:6</a></td>
<td class=kW><a target="_blank" href="t_92_483_541.php">13:1</a></td>
<td class=kW><a target="_blank" href="t_92_481_541.php">14:2</a></td>
<td class=br>46:25</td><td class=br>+21</td>
<td class=bc>3 - 0 - 2</td>
<td class=br><strong>6</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>VJN Ventspils 2</td><td class=kL><a target="_blank" href="t_92_533_540.php">4:9</a></td>
<td class=kL><a target="_blank" href="t_92_476_540.php">5:7</a></td>
<td class=kL><a target="_blank" href="t_92_540_541.php">6:9</a></td>
<td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_483_540.php">11:5</a></td>
<td class=kW><a target="_blank" href="t_92_481_540.php">15:0</a></td>
<td class=br>41:30</td><td class=br>+11</td>
<td class=bc>2 - 0 - 3</td>
<td class=br><strong>4</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>GHK Altona 2</td><td class=kL><a target="_blank" href="t_92_483_533.php">0:15</a></td>
<td class=kL><a target="_blank" href="t_92_476_483.php">1:13</a></td>
<td class=kL><a target="_blank" href="t_92_483_541.php">1:13</a></td>
<td class=kL><a target="_blank" href="t_92_483_540.php">5:11</a></td>
<td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_481_483.php">9:3</a></td>
<td class=br>16:55</td><td class=br>-39</td>
<td class=bc>1 - 0 - 4</td>
<td class=br><strong>2</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>GHK Altona JUN 3</td><td class=kL><a target="_blank" href="t_92_481_533.php">0:16</a></td>
<td class=kL><a target="_blank" href="t_92_476_481.php">0:14</a></td>
<td class=kL><a target="_blank" href="t_92_481_541.php">2:14</a></td>
<td class=kL><a target="_blank" href="t_92_481_540.php">0:15</a></td>
<td class=kL><a target="_blank" href="t_92_481_483.php">3:9</a></td>
<td class=kx>*</td>
<td class=br>5:68</td><td class=br>-63</td>
<td class=bc>0 - 0 - 5</td>
<td class=br><strong>0</strong></td><td class=d>6.</td>
</tr></table></div></p>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group Final 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>THC Nertus</td><td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_530_533.php">10:4</a></td>
<td class=kW><a target="_blank" href="t_92_476_530.php">9:5</a></td>
<td class=kW><a target="_blank" href="t_92_530_542.php">12:2 K</a></td>
<td class=kW><a target="_blank" href="t_92_530_541.php">9:4</a></td>
<td class=kW><a target="_blank" href="t_92_530_537.php">10:4 K</a></td>
<td class=br>50:19</td><td class=br>+31</td>
<td class=bc>5 - 0 - 0</td>
<td class=br><strong>10</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>VJN Ventspils 1</td><td class=kL><a target="_blank" href="t_92_530_533.php">4:10</a></td>
<td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_476_533.php">8:3 K</a></td>
<td class=kW><a target="_blank" href="t_92_533_542.php">11:4</a></td>
<td class=kW><a target="_blank" href="t_92_533_541.php">9:4 K</a></td>
<td class=kW><a target="_blank" href="t_92_533_537.php">12:4</a></td>
<td class=br>44:25</td><td class=br>+19</td>
<td class=bc>4 - 0 - 1</td>
<td class=br><strong>8</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>GHK Altona 1</td><td class=kL><a target="_blank" href="t_92_476_530.php">5:9</a></td>
<td class=kL><a target="_blank" href="t_92_476_533.php">3:8 K</a></td>
<td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_476_542.php">13:3</a></td>
<td class=kW><a target="_blank" href="t_92_476_541.php">7:6 K</a></td>
<td class=kW><a target="_blank" href="t_92_476_537.php">9:6</a></td>
<td class=br>37:32</td><td class=br>+5</td>
<td class=bc>3 - 0 - 2</td>
<td class=br><strong>6</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Incukalns THC JUN 1</td><td class=kL><a target="_blank" href="t_92_530_542.php">2:12 K</a></td>
<td class=kL><a target="_blank" href="t_92_533_542.php">4:11</a></td>
<td class=kL><a target="_blank" href="t_92_476_542.php">3:13</a></td>
<td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_541_542.php">10:6</a></td>
<td class=kW><a target="_blank" href="t_92_537_542.php">7:6 K</a></td>
<td class=br>26:48</td><td class=br>-22</td>
<td class=bc>2 - 0 - 3</td>
<td class=br><strong>4</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>THC Black Forest Werewolves</td><td class=kL><a target="_blank" href="t_92_530_541.php">4:9</a></td>
<td class=kL><a target="_blank" href="t_92_533_541.php">4:9 K</a></td>
<td class=kL><a target="_blank" href="t_92_476_541.php">6:7 K</a></td>
<td class=kL><a target="_blank" href="t_92_541_542.php">6:10</a></td>
<td class=kx>*</td>
<td class=kT><a target="_blank" href="t_92_537_541.php">7:7</a></td>
<td class=br>27:42</td><td class=br>-15</td>
<td class=bc>0 - 1 - 4</td>
<td class=br><strong>1</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Incukalns THC 2</td><td class=kL><a target="_blank" href="t_92_530_537.php">4:10 K</a></td>
<td class=kL><a target="_blank" href="t_92_533_537.php">4:12</a></td>
<td class=kL><a target="_blank" href="t_92_476_537.php">6:9</a></td>
<td class=kL><a target="_blank" href="t_92_537_542.php">6:7 K</a></td>
<td class=kT><a target="_blank" href="t_92_537_541.php">7:7</a></td>
<td class=kx>*</td>
<td class=br>27:45</td><td class=br>-18</td>
<td class=bc>0 - 1 - 4</td>
<td class=br><strong>1</strong></td><td class=d>6.</td>
</tr></table></div></p>
<p class=v>Group Final 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>BJC Laimite</td><td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_473_531.php">8:6 K</a></td>
<td class=kW><a target="_blank" href="t_92_531_532.php">7:6</a></td>
<td class=kW><a target="_blank" href="t_92_531_535.php">8:6</a></td>
<td class=kW><a target="_blank" href="t_92_531_539.php">9:5</a></td>
<td class=kW><a target="_blank" href="t_92_531_538.php">7:6 K</a></td>
<td class=br>39:29</td><td class=br>+10</td>
<td class=bc>5 - 0 - 0</td>
<td class=br><strong>10</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Jurmalas GHK</td><td class=kL><a target="_blank" href="t_92_473_531.php">6:8 K</a></td>
<td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_473_532.php">7:6</a></td>
<td class=kW><a target="_blank" href="t_92_473_535.php">7:6</a></td>
<td class=kW><a target="_blank" href="t_92_473_539.php">9:4</a></td>
<td class=kW><a target="_blank" href="t_92_473_538.php">9:4 K</a></td>
<td class=br>38:28</td><td class=br>+10</td>
<td class=bc>4 - 0 - 1</td>
<td class=br><strong>8</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Incukalns THC 1</td><td class=kL><a target="_blank" href="t_92_531_532.php">6:7</a></td>
<td class=kL><a target="_blank" href="t_92_473_532.php">6:7</a></td>
<td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_532_535.php">6:5 K</a></td>
<td class=kW><a target="_blank" href="t_92_532_539.php">10:5 K</a></td>
<td class=kW><a target="_blank" href="t_92_532_538.php">14:1</a></td>
<td class=br>42:25</td><td class=br>+17</td>
<td class=bc>3 - 0 - 2</td>
<td class=br><strong>6</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Valmieras nov. GHK 1</td><td class=kL><a target="_blank" href="t_92_531_535.php">6:8</a></td>
<td class=kL><a target="_blank" href="t_92_473_535.php">6:7</a></td>
<td class=kL><a target="_blank" href="t_92_532_535.php">5:6 K</a></td>
<td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_535_539.php">13:1 K</a></td>
<td class=kW><a target="_blank" href="t_92_535_538.php">10:3</a></td>
<td class=br>40:25</td><td class=br>+15</td>
<td class=bc>2 - 0 - 3</td>
<td class=br><strong>4</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Big Band Praha</td><td class=kL><a target="_blank" href="t_92_531_539.php">5:9</a></td>
<td class=kL><a target="_blank" href="t_92_473_539.php">4:9</a></td>
<td class=kL><a target="_blank" href="t_92_532_539.php">5:10 K</a></td>
<td class=kL><a target="_blank" href="t_92_535_539.php">1:13 K</a></td>
<td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_538_539.php">11:4</a></td>
<td class=br>26:45</td><td class=br>-19</td>
<td class=bc>1 - 0 - 4</td>
<td class=br><strong>2</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Brent Plast BHK</td><td class=kL><a target="_blank" href="t_92_531_538.php">6:7 K</a></td>
<td class=kL><a target="_blank" href="t_92_473_538.php">4:9 K</a></td>
<td class=kL><a target="_blank" href="t_92_532_538.php">1:14</a></td>
<td class=kL><a target="_blank" href="t_92_535_538.php">3:10</a></td>
<td class=kL><a target="_blank" href="t_92_538_539.php">4:11</a></td>
<td class=kx>*</td>
<td class=br>18:51</td><td class=br>-33</td>
<td class=bc>0 - 0 - 5</td>
<td class=br><strong>0</strong></td><td class=d>6.</td>
</tr></table></div></p>
<p class=v>Group 2.league</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>GHK Altona JUN 1</td><td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_334_540.php">7:6</a></td>
<td class=kL><a target="_blank" href="t_92_334_536.php">4:9</a></td>
<td class=kW><a target="_blank" href="t_92_334_475.php">9:5</a></td>
<td class=br>20:20</td><td class=br>0</td>
<td class=bc>2 - 0 - 1</td>
<td class=br><strong>4</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>VJN Ventspils 2</td><td class=kL><a target="_blank" href="t_92_334_540.php">6:7</a></td>
<td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_536_540.php">8:5</a></td>
<td class=kW><a target="_blank" href="t_92_475_540.php">7:4</a></td>
<td class=br>21:16</td><td class=br>+5</td>
<td class=bc>2 - 0 - 1</td>
<td class=br><strong>4</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Gladiators Plzen</td><td class=kW><a target="_blank" href="t_92_334_536.php">9:4</a></td>
<td class=kL><a target="_blank" href="t_92_536_540.php">5:8</a></td>
<td class=kx>*</td>
<td class=kT><a target="_blank" href="t_92_475_536.php">6:6</a></td>
<td class=br>20:18</td><td class=br>+2</td>
<td class=bc>1 - 1 - 1</td>
<td class=br><strong>3</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Valmieras nov. GHK JUN</td><td class=kL><a target="_blank" href="t_92_334_475.php">5:9</a></td>
<td class=kL><a target="_blank" href="t_92_475_540.php">4:7</a></td>
<td class=kT><a target="_blank" href="t_92_475_536.php">6:6</a></td>
<td class=kx>*</td>
<td class=br>15:22</td><td class=br>-7</td>
<td class=bc>0 - 1 - 2</td>
<td class=br><strong>1</strong></td><td class=d>4.</td>
</tr></table></div></p>
<p class=v>Group 3.league</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Incukalns THC JUN 2</td><td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_543_545.php">12:2</a></td>
<td class=kW><a target="_blank" href="t_92_544_545.php">11:4</a></td>
<td class=kL><a target="_blank" href="t_92_483_545.php">6:9</a></td>
<td class=br>29:15</td><td class=br>+14</td>
<td class=bc>2 - 0 - 1</td>
<td class=br><strong>4</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Valmieras nov. GHK 2</td><td class=kL><a target="_blank" href="t_92_543_545.php">2:12</a></td>
<td class=kx>*</td>
<td class=kT><a target="_blank" href="t_92_543_544.php">8:8</a></td>
<td class=kW><a target="_blank" href="t_92_483_543.php">11:2</a></td>
<td class=br>21:22</td><td class=br>-1</td>
<td class=bc>1 - 1 - 1</td>
<td class=br><strong>3</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Incukalns THC 3</td><td class=kL><a target="_blank" href="t_92_544_545.php">4:11</a></td>
<td class=kT><a target="_blank" href="t_92_543_544.php">8:8</a></td>
<td class=kx>*</td>
<td class=kW><a target="_blank" href="t_92_483_544.php">6:5</a></td>
<td class=br>18:24</td><td class=br>-6</td>
<td class=bc>1 - 1 - 1</td>
<td class=br><strong>3</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>GHK Altona 2</td><td class=kW><a target="_blank" href="t_92_483_545.php">9:6</a></td>
<td class=kL><a target="_blank" href="t_92_483_543.php">2:11</a></td>
<td class=kL><a target="_blank" href="t_92_483_544.php">5:6</a></td>
<td class=kx>*</td>
<td class=br>16:23</td><td class=br>-7</td>
<td class=bc>1 - 0 - 2</td>
<td class=br><strong>2</strong></td><td class=d>4.</td>
</tr></table></div></p>
<p class=v>Group 4.league</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>GHK Altona JUN 3</td><td class=kx>*</td>
<td class=kL><a target="_blank" href="t_92_335_481.php">6:8 + 10:4</a></td>
<td class=br>16:12</td><td class=br>+4</td>
<td class=bc>1 - 0 - 1</td>
<td class=br><strong>2</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>GHK Altona JUN 2</td><td class=kW><a target="_blank" href="t_92_335_481.php">8:6 + 4:10</a></td>
<td class=kx>*</td>
<td class=br>12:16</td><td class=br>-4</td>
<td class=bc>1 - 0 - 1</td>
<td class=br><strong>2</strong></td><td class=d>2.</td>
</tr></table></div></p>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
