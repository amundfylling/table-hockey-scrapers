<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Superveterans (O55) Individual (SV)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../24EChSV/Superveterans_(O55)_Individual_(SV)_index.php">Superveterans (O55) Individual (SV), 15. June 2024</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<p class=v>Group O55</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=117&x=-62&p=Tr%20M%C3%A5nsson">Tr M�nsson</a></td><td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kL>0:2</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>9:0</td>
<td class=kW>5:2</td>
<td class=br>55:16</td><td class=br>+39</td>
<td class=bc>11 - 2 - 2</td>
<td class=br><strong>24</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=65&x=-62&p=Ig%20Saveljev">Ig Saveljev</a></td><td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kT>5:5</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=br>55:26</td><td class=br>+29</td>
<td class=bc>11 - 2 - 2</td>
<td class=br><strong>24</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=241&x=-62&p=Pa%20Plesak">Pa Plesak</a></td><td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>4:6</td>
<td class=kW>6:5</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=br>52:38</td><td class=br>+14</td>
<td class=bc>9 - 4 - 2</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=405&x=-62&p=Va%20Pikl">Va Pikl</a></td><td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>9:1</td>
<td class=kW>5:1</td>
<td class=br>51:25</td><td class=br>+26</td>
<td class=bc>11 - 0 - 4</td>
<td class=br><strong>22</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=32&x=-62&p=Sa%20Skarainis">Sa Skarainis</a></td><td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>6:0</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>10:2</td>
<td class=kW>5:2</td>
<td class=br>49:32</td><td class=br>+17</td>
<td class=bc>8 - 3 - 4</td>
<td class=br><strong>19</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=127&x=-62&p=Mi%20Sevr">Mi Sevr</a></td><td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=br>40:32</td><td class=br>+8</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=396&x=-62&p=Va%20Hamdamov">Va Hamdamov</a></td><td class=kL>2:5</td>
<td class=kT>5:5</td>
<td class=kW>6:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=br>48:40</td><td class=br>+8</td>
<td class=bc>7 - 4 - 4</td>
<td class=br><strong>18</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=416&x=-62&p=He%20Petuch">He Petuch</a></td><td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>5:6</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>8:2</td>
<td class=br>46:38</td><td class=br>+8</td>
<td class=bc>6 - 3 - 6</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=202&x=-62&p=Vl%20Voronov">Vl Voronov</a></td><td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=br>40:47</td><td class=br>-7</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=144&x=-62&p=Il%20Pavlovskis">Il Pavlovskis</a></td><td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kL>0:5</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>8:2</td>
<td class=br>40:43</td><td class=br>-3</td>
<td class=bc>6 - 1 - 8</td>
<td class=br><strong>13</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=162&x=-62&p=Gi%20Remeika">Gi Remeika</a></td><td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=br>36:47</td><td class=br>-11</td>
<td class=bc>5 - 3 - 7</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=424&x=-62&p=La%20Ulfvensj%C3%B6">La Ulfvensj�</a></td><td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kW>5:0</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=br>31:40</td><td class=br>-9</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="stats.php?idpl=413&x=-62&p=Fr%20Bruneske">Fr Bruneske</a></td><td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kW>5:4</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>7:0</td>
<td class=br>31:46</td><td class=br>-15</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt><a href="stats.php?idpl=35&x=-62&p=Gu%20Buls">Gu Buls</a></td><td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=br>33:45</td><td class=br>-12</td>
<td class=bc>3 - 2 - 10</td>
<td class=br><strong>8</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt><a href="stats.php?idpl=210&x=-62&p=J%C4%81%20Rekti%C5%86%C5%A1">J� Rekti��</a></td><td class=kL>0:9</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>1:9</td>
<td class=kL>2:10</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>26:63</td><td class=br>-37</td>
<td class=bc>2 - 2 - 11</td>
<td class=br><strong>6</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt><a href="stats.php?idpl=433&x=-62&p=Su%20P%C3%B6ssl">Su P�ssl</a></td><td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kL>2:8</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>22:77</td><td class=br>-55</td>
<td class=bc>0 - 1 - 14</td>
<td class=br><strong>1</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=bl>Hamdamov Vafa</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ulfvensj� Lars</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Sevr Milos</td><td class=bc>-</td><td class=blW>Voronov Vladimir</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Buls Gun�rs</td><td class=bc>-</td><td class=blW>Bruneske Frank</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Hamdamov Vafa</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ulfvensj� Lars</td><td class=bc>-</td><td class=blW>Voronov Vladimir</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Bruneske Frank</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Sevr Milos</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Buls Gun�rs</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pikl Vaclav</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Hamdamov Vafa</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ulfvensj� Lars</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>Sevr Milos</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Buls Gun�rs</td><td class=bc>-</td><td class=blW>Pavlovskis Ilgvars</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Hamdamov Vafa</td><td class=bc>-</td><td class=blW>Voronov Vladimir</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ulfvensj� Lars</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Pavlovskis Ilgvars</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Sevr Milos</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Petuch Hermann</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Hamdamov Vafa</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ulfvensj� Lars</td><td class=bc>-</td><td class=blW>Pikl Vaclav</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Buls Gun�rs</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Bruneske Frank</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Hamdamov Vafa</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=blW>Pikl Vaclav</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Buls Gun�rs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ulfvensj� Lars</td><td class=bc>-</td><td class=blW>Sevr Milos</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Hamdamov Vafa</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Buls Gun�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=blW>Sevr Milos</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Pikl Vaclav</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Buls Gun�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Hamdamov Vafa</td><td class=bc>-</td><td class=blW>Sevr Milos</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=blW>Ulfvensj� Lars</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=blW>Pikl Vaclav</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Buls Gun�rs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Sevr Milos</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Hamdamov Vafa</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Pavlovskis Ilgvars</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Pikl Vaclav</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Buls Gun�rs</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Bruneske Frank</td><td class=bc>-</td><td class=bl>Sevr Milos</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Rekti�� J�nis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Petuch Hermann</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Hamdamov Vafa</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=blW>Pikl Vaclav</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Buls Gun�rs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Sevr Milos</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=blW>Ulfvensj� Lars</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Saveljev Igor</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Petuch Hermann</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Pikl Vaclav</td><td class=bc>-</td><td class=bl>Buls Gun�rs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=blW>Sevr Milos</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Bruneske Frank</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Petuch Hermann</td><td class=bc>-</td><td class=bl>Hamdamov Vafa</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Buls Gun�rs</td><td class=bc>-</td><td class=blW>Sevr Milos</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pikl Vaclav</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=blW>Ulfvensj� Lars</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Saveljev Igor</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=blW>Hamdamov Vafa</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Sevr Milos</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Buls Gun�rs</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pikl Vaclav</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Hamdamov Vafa</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Ulfvensj� Lars</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Sevr Milos</td><td class=bc>-</td><td class=blW>Saveljev Igor</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Buls Gun�rs</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=blW>Hamdamov Vafa</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Voronov Vladimir</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ulfvensj� Lars</td><td class=bc>-</td><td class=blW>Saveljev Igor</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Rekti�� J�nis</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sevr Milos</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Buls Gun�rs</td><td class=bc>-</td><td class=blW>Hamdamov Vafa</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ulfvensj� Lars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=bl>Hamdamov Vafa</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Sevr Milos</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Buls Gun�rs</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pikl Vaclav</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>1 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
