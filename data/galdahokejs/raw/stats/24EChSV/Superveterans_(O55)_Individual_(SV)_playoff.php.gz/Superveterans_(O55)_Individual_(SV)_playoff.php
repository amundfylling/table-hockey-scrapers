<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Superveterans (O55) Individual (SV)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Superveterans_(O55)_Individual_(SV)_list.php">Superveterans (O55) Individual (SV) - play-off </a></span></h2></div></div></div></div><p><div align="center">
<table border=0 cellpadding=2 cellspacing=0>
<tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>Finals</strong></font></th></tr>
<tr><td class=br><a href="stats.php?idpl=405&x=-62&p=Pikl%20Vaclav">Pikl Vaclav</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=65&x=-62&p=Saveljev%20Igor"><b>Saveljev Igor</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>0:3&nbsp;&nbsp;</td>
<td class=bl>3:0&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>0:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>1/2</strong></font></th></tr>
<tr><td class=ar><a href="stats.php?idpl=117&x=-62&p=M%C3%A5nsson%20Truls">M�nsson Truls</a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=405&x=-62&p=Pikl%20Vaclav"><b>Pikl Vaclav</b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;1 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>0:3&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
<td class=al>1:2 P&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="stats.php?idpl=241&x=-62&p=Plesak%20Pavel">Plesak Pavel</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=65&x=-62&p=Saveljev%20Igor"><b>Saveljev Igor</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>0:4&nbsp;&nbsp;</td>
<td class=bl>1:4&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>3rd</strong></font></th></tr>
<tr><td class=ar><a href="stats.php?idpl=117&x=-62&p=M%C3%A5nsson%20Truls"><b>M�nsson Truls</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=241&x=-62&p=Plesak%20Pavel">Plesak Pavel</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>1:0&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>1/4</strong></font></th></tr>
<tr><td class=br><a href="stats.php?idpl=117&x=-62&p=M%C3%A5nsson%20Truls%20%281%29"><b>M�nsson Truls (1)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=416&x=-62&p=Petuch%20Hermann%20%288%29">Petuch Hermann (8)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>1:0&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="stats.php?idpl=405&x=-62&p=Pikl%20Vaclav%20%284%29"><b>Pikl Vaclav (4)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=32&x=-62&p=Skarainis%20Salvis%20%285%29">Skarainis Salvis (5)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:0&nbsp;&nbsp;</td>
<td class=al>1:4&nbsp;&nbsp;</td>
<td class=al>1:2&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="stats.php?idpl=241&x=-62&p=Plesak%20Pavel%20%283%29"><b>Plesak Pavel (3)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=127&x=-62&p=Sevr%20Milos%20%286%29">Sevr Milos (6)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>1:4&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>5:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="stats.php?idpl=65&x=-62&p=Saveljev%20Igor%20%282%29"><b>Saveljev Igor (2)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=396&x=-62&p=Hamdamov%20Vafa%20%287%29">Hamdamov Vafa (7)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>5:2&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>2:1 P&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
