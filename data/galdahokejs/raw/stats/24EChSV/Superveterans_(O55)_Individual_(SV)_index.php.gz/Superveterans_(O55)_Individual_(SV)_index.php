<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Superveterans (O55) Individual (SV)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span>Superveterans (O55) Individual (SV)</span></h2></div></div></div></div><p><div align="center">
<h2 class="page-title">Superveterans (O55) Individual (SV), 15. June 2024</h2>
<div align=center>
<a href="Superveterans_(O55)_Individual_(SV)_cross.php">Basic and placement groups</a><br>
<a href="Superveterans_(O55)_Individual_(SV)_playoff.php">Placement matches</a><br>
<a href="Superveterans_(O55)_Individual_(SV)_offence.php">Best forwards</a><br>
<a href="Superveterans_(O55)_Individual_(SV)_defence.php">Best defenders</a><br>
</div>
<p class=v>Final table<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0 class="rnk">
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">M</th>
<th align="center">+</th>
<th align="center">=</th>
<th align="center">-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">Pts</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al>Saveljev Igor</td>
<td class=al>EST</td>
<td class=ar>26</td>
<td class=ar>20</td>
<td class=ar>2</td>
<td class=ar>4</td>
<td class=ar>83</td>
<td class=al>&nbsp;:&nbsp;40</td>
<td class=ar>42</td>
</tr><tr><td class=br>2.</td>
<td class=bl>Pikl Vaclav</td>
<td class=bl>CZE</td>
<td class=br>29</td>
<td class=br>19</td>
<td class=br>0</td>
<td class=br>10</td>
<td class=br>77</td>
<td class=bl>&nbsp;:&nbsp;48</td>
<td class=br>38</td>
</tr><tr><td class=ar>3.</td>
<td class=al>M�nsson Truls</td>
<td class=al>SWE</td>
<td class=ar>25</td>
<td class=ar>18</td>
<td class=ar>2</td>
<td class=ar>5</td>
<td class=ar>79</td>
<td class=al>&nbsp;:&nbsp;33</td>
<td class=ar>38</td>
</tr><tr><td class=br>4.</td>
<td class=bl>Plesak Pavel</td>
<td class=bl>CZE</td>
<td class=br>25</td>
<td class=br>12</td>
<td class=br>4</td>
<td class=br>9</td>
<td class=br>73</td>
<td class=bl>&nbsp;:&nbsp;65</td>
<td class=br>28</td>
</tr><tr><td class=ar>5.</td>
<td class=al>Skarainis Salvis</td>
<td class=al>LAT</td>
<td class=ar>20</td>
<td class=ar>10</td>
<td class=ar>3</td>
<td class=ar>7</td>
<td class=ar>57</td>
<td class=al>&nbsp;:&nbsp;42</td>
<td class=ar>23</td>
</tr><tr><td class=br>6.</td>
<td class=bl>Sevr Milos</td>
<td class=bl>CZE</td>
<td class=br>19</td>
<td class=br>9</td>
<td class=br>2</td>
<td class=br>8</td>
<td class=br>48</td>
<td class=bl>&nbsp;:&nbsp;45</td>
<td class=br>20</td>
</tr><tr><td class=ar>7.</td>
<td class=al>Hamdamov Vafa</td>
<td class=al>EST</td>
<td class=ar>18</td>
<td class=ar>7</td>
<td class=ar>4</td>
<td class=ar>7</td>
<td class=ar>52</td>
<td class=al>&nbsp;:&nbsp;49</td>
<td class=ar>18</td>
</tr><tr><td class=br>8.</td>
<td class=bl>Petuch Hermann</td>
<td class=bl>GER</td>
<td class=br>18</td>
<td class=br>6</td>
<td class=br>3</td>
<td class=br>9</td>
<td class=br>49</td>
<td class=bl>&nbsp;:&nbsp;47</td>
<td class=br>15</td>
</tr><tr><td class=ar>9.</td>
<td class=al>Voronov Vladimir</td>
<td class=al>LTU</td>
<td class=ar>15</td>
<td class=ar>6</td>
<td class=ar>2</td>
<td class=ar>7</td>
<td class=ar>40</td>
<td class=al>&nbsp;:&nbsp;47</td>
<td class=ar>14</td>
</tr><tr><td class=br>10.</td>
<td class=bl>Pavlovskis Ilgvars</td>
<td class=bl>LAT</td>
<td class=br>15</td>
<td class=br>6</td>
<td class=br>1</td>
<td class=br>8</td>
<td class=br>40</td>
<td class=bl>&nbsp;:&nbsp;43</td>
<td class=br>13</td>
</tr><tr><td class=ar>11.</td>
<td class=al>Remeika Gintautas</td>
<td class=al>LTU</td>
<td class=ar>15</td>
<td class=ar>5</td>
<td class=ar>3</td>
<td class=ar>7</td>
<td class=ar>36</td>
<td class=al>&nbsp;:&nbsp;47</td>
<td class=ar>13</td>
</tr><tr><td class=br>12.</td>
<td class=bl>Ulfvensj� Lars</td>
<td class=bl>SWE</td>
<td class=br>15</td>
<td class=br>5</td>
<td class=br>2</td>
<td class=br>8</td>
<td class=br>31</td>
<td class=bl>&nbsp;:&nbsp;40</td>
<td class=br>12</td>
</tr><tr><td class=ar>13.</td>
<td class=al>Bruneske Frank</td>
<td class=al>GER</td>
<td class=ar>15</td>
<td class=ar>5</td>
<td class=ar>1</td>
<td class=ar>9</td>
<td class=ar>31</td>
<td class=al>&nbsp;:&nbsp;46</td>
<td class=ar>11</td>
</tr><tr><td class=br>14.</td>
<td class=bl>Buls Gun�rs</td>
<td class=bl>LAT</td>
<td class=br>15</td>
<td class=br>3</td>
<td class=br>2</td>
<td class=br>10</td>
<td class=br>33</td>
<td class=bl>&nbsp;:&nbsp;45</td>
<td class=br>8</td>
</tr><tr><td class=ar>15.</td>
<td class=al>Rekti�� J�nis</td>
<td class=al>LAT</td>
<td class=ar>15</td>
<td class=ar>2</td>
<td class=ar>2</td>
<td class=ar>11</td>
<td class=ar>26</td>
<td class=al>&nbsp;:&nbsp;63</td>
<td class=ar>6</td>
</tr><tr><td class=br>16.</td>
<td class=bl>P�ssl Susanna</td>
<td class=bl>SWE</td>
<td class=br>15</td>
<td class=br>0</td>
<td class=br>1</td>
<td class=br>14</td>
<td class=br>22</td>
<td class=bl>&nbsp;:&nbsp;77</td>
<td class=br>1</td>
</tr></table></td></tr></table></div></p>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
