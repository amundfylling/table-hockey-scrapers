<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Amatieru Liga 1.posms</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../24AL1/Amatieru_Liga_1.posms_index.php">Amatieru Liga 1.posms, 19. October 2024</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group AL A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>D� Vesele</td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>12:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=br>62:9</td><td class=br>+53</td>
<td class=bc>13 - 0 - 0</td>
<td class=br><strong>26</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>M� �irsis</td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>10:3</td>
<td class=kW>7:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>9:0</td>
<td class=kW>6:0</td>
<td class=kW>7:0</td>
<td class=br>69:10</td><td class=br>+59</td>
<td class=bc>11 - 1 - 1</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Br Gor�anovs</td><td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>7:4</td>
<td class=kW>5:2</td>
<td class=kW>8:0</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>49:18</td><td class=br>+31</td>
<td class=bc>11 - 0 - 2</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ar Bozovi�s</td><td class=kL>2:5</td>
<td class=kL>3:10</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kL>3:5</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>9:0</td>
<td class=br>53:26</td><td class=br>+27</td>
<td class=bc>9 - 0 - 4</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>M� Timbers</td><td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>8:1</td>
<td class=kW>3:1</td>
<td class=kW>8:0</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=kW>5:0</td>
<td class=br>54:31</td><td class=br>+23</td>
<td class=bc>8 - 1 - 4</td>
<td class=br><strong>17</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Em Ka�s</td><td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>6:0</td>
<td class=kT>1:1</td>
<td class=kW>6:0</td>
<td class=kW>7:0</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=kW>7:0</td>
<td class=br>47:23</td><td class=br>+24</td>
<td class=bc>6 - 4 - 3</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Ri Stivri��</td><td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>4:7</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>9:1</td>
<td class=kW>11:1</td>
<td class=br>51:33</td><td class=br>+18</td>
<td class=bc>7 - 1 - 5</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Re Dani�evskis</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>1:8</td>
<td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=br>26:41</td><td class=br>-15</td>
<td class=bc>6 - 0 - 7</td>
<td class=br><strong>12</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ti Gorsanova</td><td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:8</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>0:3</td>
<td class=kT>0:0</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=br>15:32</td><td class=br>-17</td>
<td class=bc>4 - 2 - 7</td>
<td class=br><strong>10</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Em Prodniece</td><td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kT>0:0</td>
<td class=kW>4:0</td>
<td class=br>10:36</td><td class=br>-26</td>
<td class=bc>2 - 2 - 9</td>
<td class=br><strong>6</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ev �alkovska</td><td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=br>17:40</td><td class=br>-23</td>
<td class=bc>2 - 2 - 9</td>
<td class=br><strong>6</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ot �v��eris</td><td class=kL>1:12</td>
<td class=kL>0:9</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kT>0:0</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=br>9:47</td><td class=br>-38</td>
<td class=bc>2 - 2 - 9</td>
<td class=br><strong>6</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Kr K�avi��</td><td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kL>0:7</td>
<td class=kL>1:9</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kT>0:0</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>11:59</td><td class=br>-48</td>
<td class=bc>2 - 1 - 10</td>
<td class=br><strong>5</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Dm Kolbass</td><td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>0:9</td>
<td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kL>1:11</td>
<td class=kL>0:7</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>4:72</td><td class=br>-68</td>
<td class=bc>0 - 0 - 13</td>
<td class=br><strong>0</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ar Bozovi�s</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Re Dani�evskis</td><td class=bc>-</td><td class=blW>M� Timbers</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ti Gorsanova</td><td class=bc>-</td><td class=bl>Ot �v��eris</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Ev �alkovska</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=bl>Ri Stivri��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Em Prodniece</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kr K�avi��</td><td class=bc>-</td><td class=bl>Dm Kolbass</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ar Bozovi�s</td><td class=bc>-</td><td class=bl>Ot �v��eris</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Re Dani�evskis</td><td class=bc>-</td><td class=bl>Ev �alkovska</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ti Gorsanova</td><td class=bc>-</td><td class=bl>Ri Stivri��</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Em Prodniece</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>Dm Kolbass</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Kr K�avi��</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>M� Timbers</td><td class=bc>-</td><td class=bl>Ot �v��eris</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Ev �alkovska</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ar Bozovi�s</td><td class=bc>-</td><td class=blW>Ri Stivri��</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Re Dani�evskis</td><td class=bc>-</td><td class=bl>Em Prodniece</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ti Gorsanova</td><td class=bc>-</td><td class=bl>Dm Kolbass</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Kr K�avi��</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ot �v��eris</td><td class=bc>-</td><td class=bl>Ev �alkovska</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>M� Timbers</td><td class=bc>-</td><td class=bl>Ri Stivri��</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Em Prodniece</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ar Bozovi�s</td><td class=bc>-</td><td class=bl>Dm Kolbass</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Re Dani�evskis</td><td class=bc>-</td><td class=bl>Kr K�avi��</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ti Gorsanova</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ev �alkovska</td><td class=bc>-</td><td class=blW>Ri Stivri��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ot �v��eris</td><td class=bc>-</td><td class=blW>Em Prodniece</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>M� Timbers</td><td class=bc>-</td><td class=bl>Dm Kolbass</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Kr K�avi��</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ar Bozovi�s</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>3 : 10</tr></td>
<tr><td class=br>Re Dani�evskis</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ti Gorsanova</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ri Stivri��</td><td class=bc>-</td><td class=bl>Em Prodniece</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ev �alkovska</td><td class=bc>-</td><td class=bl>Dm Kolbass</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ot �v��eris</td><td class=bc>-</td><td class=bl>Kr K�avi��</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ar Bozovi�s</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Re Dani�evskis</td><td class=bc>-</td><td class=bl>Ti Gorsanova</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Em Prodniece</td><td class=bc>-</td><td class=bl>Dm Kolbass</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ri Stivri��</td><td class=bc>-</td><td class=bl>Kr K�avi��</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Ev �alkovska</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ot �v��eris</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Ti Gorsanova</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ar Bozovi�s</td><td class=bc>-</td><td class=bl>Re Dani�evskis</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Dm Kolbass</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Em Prodniece</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ri Stivri��</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Ev �alkovska</td><td class=bc>-</td><td class=bl>Ti Gorsanova</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ot �v��eris</td><td class=bc>-</td><td class=blW>Re Dani�evskis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Ar Bozovi�s</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Kr K�avi��</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Dm Kolbass</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Em Prodniece</td><td class=bc>-</td><td class=blW>Ti Gorsanova</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ri Stivri��</td><td class=bc>-</td><td class=bl>Re Dani�evskis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ev �alkovska</td><td class=bc>-</td><td class=blW>Ar Bozovi�s</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ot �v��eris</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>1 : 12</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kr K�avi��</td><td class=bc>-</td><td class=blW>Ti Gorsanova</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Dm Kolbass</td><td class=bc>-</td><td class=blW>Re Dani�evskis</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Em Prodniece</td><td class=bc>-</td><td class=blW>Ar Bozovi�s</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ri Stivri��</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ev �alkovska</td><td class=bc>-</td><td class=blW>M� Timbers</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ot �v��eris</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=bl>Ti Gorsanova</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Re Dani�evskis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kr K�avi��</td><td class=bc>-</td><td class=blW>Ar Bozovi�s</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Dm Kolbass</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Em Prodniece</td><td class=bc>-</td><td class=blW>M� Timbers</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Ri Stivri��</td><td class=bc>-</td><td class=bl>Ot �v��eris</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ev �alkovska</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Re Dani�evskis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Ar Bozovi�s</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr K�avi��</td><td class=bc>-</td><td class=blW>M� Timbers</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Dm Kolbass</td><td class=bc>-</td><td class=blW>Ot �v��eris</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Em Prodniece</td><td class=bc>-</td><td class=bl>Ev �alkovska</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ri Stivri��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ti Gorsanova</td><td class=bc>-</td><td class=blW>Ar Bozovi�s</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Ot �v��eris</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Kr K�avi��</td><td class=bc>-</td><td class=bl>Ev �alkovska</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Dm Kolbass</td><td class=bc>-</td><td class=blW>Ri Stivri��</td><td class=bc>1 : 11</tr></td>
<tr><td class=br>Em Prodniece</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Re Dani�evskis</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ti Gorsanova</td><td class=bc>-</td><td class=blW>M� Timbers</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Ot �v��eris</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>Ev �alkovska</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Ri Stivri��</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kr K�avi��</td><td class=bc>-</td><td class=bl>Em Prodniece</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Dm Kolbass</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group AL B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>As Kocere</td><td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>7:2</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kW>9:0</td>
<td class=kW>10:0</td>
<td class=br>70:21</td><td class=br>+49</td>
<td class=bc>10 - 3 - 0</td>
<td class=br><strong>23</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Re Saul�tis</td><td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>11:0</td>
<td class=kW>8:0</td>
<td class=br>63:16</td><td class=br>+47</td>
<td class=bc>9 - 4 - 0</td>
<td class=br><strong>22</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Er Kalni��</td><td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>9:0</td>
<td class=kW>2:1</td>
<td class=kW>8:0</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=br>51:17</td><td class=br>+34</td>
<td class=bc>10 - 1 - 2</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Kr Kl�vi��</td><td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=kW>6:1</td>
<td class=kW>12:0</td>
<td class=br>57:21</td><td class=br>+36</td>
<td class=bc>9 - 2 - 2</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>D� Vai�iul�ns</td><td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=br>46:22</td><td class=br>+24</td>
<td class=bc>9 - 1 - 3</td>
<td class=br><strong>19</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Al Sili��</td><td class=kL>2:7</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>11:0</td>
<td class=br>47:22</td><td class=br>+25</td>
<td class=bc>7 - 3 - 3</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Da Belkovs</td><td class=kT>4:4</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kW>5:2</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>8:1</td>
<td class=kW>8:0</td>
<td class=kW>3:2</td>
<td class=kW>9:0</td>
<td class=kW>6:0</td>
<td class=br>53:34</td><td class=br>+19</td>
<td class=bc>7 - 2 - 4</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Gu Kaveckis</td><td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>8:1</td>
<td class=br>32:23</td><td class=br>+9</td>
<td class=bc>6 - 1 - 6</td>
<td class=br><strong>13</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Em Vi��akovs</td><td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>7:0</td>
<td class=kW>2:0</td>
<td class=kL>0:2</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=br>20:34</td><td class=br>-14</td>
<td class=bc>4 - 1 - 8</td>
<td class=br><strong>9</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Kl Lange</td><td class=kL>2:6</td>
<td class=kL>0:7</td>
<td class=kL>0:9</td>
<td class=kL>1:7</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>1:8</td>
<td class=kL>1:3</td>
<td class=kL>0:7</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kT>0:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>19:61</td><td class=br>-42</td>
<td class=bc>3 - 1 - 9</td>
<td class=br><strong>7</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>�i Carenko</td><td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=br>7:48</td><td class=br>-41</td>
<td class=bc>2 - 1 - 10</td>
<td class=br><strong>5</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Kr Egl�tis</td><td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:8</td>
<td class=kL>0:8</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kW>2:0</td>
<td class=kT>0:0</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=br>9:39</td><td class=br>-30</td>
<td class=bc>2 - 1 - 10</td>
<td class=br><strong>5</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ra Greb�evs</td><td class=kL>0:9</td>
<td class=kL>0:11</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kL>0:9</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=br>4:51</td><td class=br>-47</td>
<td class=bc>1 - 1 - 11</td>
<td class=br><strong>3</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Ne Giri�a</td><td class=kL>0:10</td>
<td class=kL>0:8</td>
<td class=kL>1:3</td>
<td class=kL>0:12</td>
<td class=kL>1:3</td>
<td class=kL>0:11</td>
<td class=kL>0:6</td>
<td class=kL>1:8</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=br>4:73</td><td class=br>-69</td>
<td class=bc>0 - 2 - 11</td>
<td class=br><strong>2</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>�i Carenko</td><td class=bc>-</td><td class=blW>D� Vai�iul�ns</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr Egl�tis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ra Greb�evs</td><td class=bc>-</td><td class=blW>Kl Lange</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>As Kocere</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Gu Kaveckis</td><td class=bc>-</td><td class=blW>Kr Kl�vi��</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>D� Vai�iul�ns</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>�i Carenko</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Kr Egl�tis</td><td class=bc>-</td><td class=bl>Kl Lange</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=blW>As Kocere</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ra Greb�evs</td><td class=bc>-</td><td class=blW>Kr Kl�vi��</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>Gu Kaveckis</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>D� Vai�iul�ns</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Kl Lange</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>�i Carenko</td><td class=bc>-</td><td class=blW>As Kocere</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Kr Egl�tis</td><td class=bc>-</td><td class=blW>Kr Kl�vi��</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=blW>Gu Kaveckis</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ra Greb�evs</td><td class=bc>-</td><td class=blW>Er Kalni��</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>D� Vai�iul�ns</td><td class=bc>-</td><td class=bl>Kl Lange</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>As Kocere</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>�i Carenko</td><td class=bc>-</td><td class=blW>Gu Kaveckis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kr Egl�tis</td><td class=bc>-</td><td class=blW>Er Kalni��</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=bl>Ra Greb�evs</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>Kl Lange</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>As Kocere</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>D� Vai�iul�ns</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Gu Kaveckis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>Er Kalni��</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>�i Carenko</td><td class=bc>-</td><td class=bl>Ra Greb�evs</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Kr Egl�tis</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Kl Lange</td><td class=bc>-</td><td class=blW>As Kocere</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Gu Kaveckis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>D� Vai�iul�ns</td><td class=bc>-</td><td class=blW>Er Kalni��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Em Vi��akovs</td><td class=bc>-</td><td class=bl>Ra Greb�evs</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>�i Carenko</td><td class=bc>-</td><td class=bl>Kr Egl�tis</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kl Lange</td><td class=bc>-</td><td class=blW>Gu Kaveckis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ra Greb�evs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>D� Vai�iul�ns</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Kr Egl�tis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>�i Carenko</td><td class=bc>8 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Kr Kl�vi��</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>Ra Greb�evs</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Kl Lange</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>Kr Egl�tis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>�i Carenko</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>D� Vai�iul�ns</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Gu Kaveckis</td><td class=bc>-</td><td class=bl>Ra Greb�evs</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Kr Kl�vi��</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>12 : 0</tr></td>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>Kr Egl�tis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kl Lange</td><td class=bc>-</td><td class=bl>�i Carenko</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>D� Vai�iul�ns</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Gu Kaveckis</td><td class=bc>-</td><td class=bl>Kr Egl�tis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Kr Kl�vi��</td><td class=bc>-</td><td class=bl>�i Carenko</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kl Lange</td><td class=bc>-</td><td class=blW>Em Vi��akovs</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>D� Vai�iul�ns</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ra Greb�evs</td><td class=bc>-</td><td class=bl>Kr Egl�tis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>�i Carenko</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Gu Kaveckis</td><td class=bc>-</td><td class=blW>Da Belkovs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kr Kl�vi��</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>D� Vai�iul�ns</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kl Lange</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=bl>�i Carenko</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ra Greb�evs</td><td class=bc>-</td><td class=blW>Da Belkovs</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Gu Kaveckis</td><td class=bc>-</td><td class=blW>D� Vai�iul�ns</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Kr Kl�vi��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kl Lange</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Kr Egl�tis</td><td class=bc>-</td><td class=blW>Da Belkovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=blW>Em Vi��akovs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ra Greb�evs</td><td class=bc>-</td><td class=blW>D� Vai�iul�ns</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Gu Kaveckis</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Kl�vi��</td><td class=bc>-</td><td class=bl>Kl Lange</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>�i Carenko</td><td class=bc>-</td><td class=blW>Em Vi��akovs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kr Egl�tis</td><td class=bc>-</td><td class=blW>D� Vai�iul�ns</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Ra Greb�evs</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>0 : 11</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>Kl Lange</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Gu Kaveckis</td><td class=bc>-</td><td class=blW>As Kocere</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group AL C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Al Liepi��</td><td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kW>10:2</td>
<td class=kW>7:0</td>
<td class=br>63:16</td><td class=br>+47</td>
<td class=bc>10 - 2 - 1</td>
<td class=br><strong>22</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ag Pav�rs</td><td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=kW>10:0</td>
<td class=kW>4:0</td>
<td class=br>53:10</td><td class=br>+43</td>
<td class=bc>11 - 0 - 2</td>
<td class=br><strong>22</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ma Kalni��</td><td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>7:3</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>9:0</td>
<td class=kW>14:0</td>
<td class=kW>6:0</td>
<td class=br>64:14</td><td class=br>+50</td>
<td class=bc>10 - 1 - 2</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ma Krauze</td><td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>4:7</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=br>41:21</td><td class=br>+20</td>
<td class=bc>9 - 3 - 1</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>El Reinfelds</td><td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kW>7:4</td>
<td class=kx>*</td>
<td class=kW>11:4</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kW>9:3</td>
<td class=kW>8:0</td>
<td class=kW>12:1</td>
<td class=kW>7:2</td>
<td class=kW>10:2</td>
<td class=kW>6:0</td>
<td class=br>83:32</td><td class=br>+51</td>
<td class=bc>10 - 0 - 3</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Af Zahars</td><td class=kT>4:4</td>
<td class=kL>1:6</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kL>4:11</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=br>48:36</td><td class=br>+12</td>
<td class=bc>7 - 2 - 4</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Da Vai�iul�ns</td><td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>9:1</td>
<td class=kW>6:0</td>
<td class=br>38:26</td><td class=br>+12</td>
<td class=bc>6 - 2 - 5</td>
<td class=br><strong>14</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ma P�tersons</td><td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=br>34:29</td><td class=br>+5</td>
<td class=bc>6 - 0 - 7</td>
<td class=br><strong>12</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Al Jakob�ns</td><td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>3:9</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=br>22:39</td><td class=br>-17</td>
<td class=bc>3 - 3 - 7</td>
<td class=br><strong>9</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Kr Rudz�tis</td><td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>0:8</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=br>21:43</td><td class=br>-22</td>
<td class=bc>4 - 1 - 8</td>
<td class=br><strong>9</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Er Stivri��</td><td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>1:12</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kT>0:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=br>13:40</td><td class=br>-27</td>
<td class=bc>3 - 2 - 8</td>
<td class=br><strong>8</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ar S�rs</td><td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>0:9</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>0:8</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=br>8:58</td><td class=br>-50</td>
<td class=bc>2 - 1 - 10</td>
<td class=br><strong>5</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>J� Ustups</td><td class=kL>2:10</td>
<td class=kL>0:10</td>
<td class=kL>0:14</td>
<td class=kL>1:4</td>
<td class=kL>2:10</td>
<td class=kL>0:5</td>
<td class=kL>1:9</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=br>16:82</td><td class=br>-66</td>
<td class=bc>1 - 1 - 11</td>
<td class=br><strong>3</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Ed K�avi��</td><td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=br>3:61</td><td class=br>-58</td>
<td class=bc>0 - 0 - 13</td>
<td class=br><strong>0</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Al Jakob�ns</td><td class=bc>-</td><td class=blW>Af Zahars</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>Da Vai�iul�ns</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ed K�avi��</td><td class=bc>-</td><td class=blW>J� Ustups</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=bl>Er Stivri��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Ar S�rs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Kr Rudz�tis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Af Zahars</td><td class=bc>-</td><td class=bl>Da Vai�iul�ns</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Jakob�ns</td><td class=bc>-</td><td class=bl>J� Ustups</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>Er Stivri��</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ed K�avi��</td><td class=bc>-</td><td class=blW>Ar S�rs</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>Kr Rudz�tis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>J� Ustups</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Af Zahars</td><td class=bc>-</td><td class=bl>Er Stivri��</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Al Jakob�ns</td><td class=bc>-</td><td class=bl>Ar S�rs</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>Kr Rudz�tis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ed K�avi��</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>J� Ustups</td><td class=bc>-</td><td class=blW>Er Stivri��</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>Ar S�rs</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Af Zahars</td><td class=bc>-</td><td class=bl>Kr Rudz�tis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Jakob�ns</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ed K�avi��</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Er Stivri��</td><td class=bc>-</td><td class=blW>Ar S�rs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>J� Ustups</td><td class=bc>-</td><td class=blW>Kr Rudz�tis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Af Zahars</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Al Jakob�ns</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ed K�avi��</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ar S�rs</td><td class=bc>-</td><td class=blW>Kr Rudz�tis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Er Stivri��</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>1 : 12</tr></td>
<tr><td class=br>J� Ustups</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Da Vai�iul�ns</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Af Zahars</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Al Jakob�ns</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>Ed K�avi��</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Kr Rudz�tis</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ar S�rs</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Er Stivri��</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>J� Ustups</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>Da Vai�iul�ns</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Af Zahars</td><td class=bc>-</td><td class=bl>Ed K�avi��</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Al Jakob�ns</td><td class=bc>-</td><td class=blW>Ma Kalni��</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Rudz�tis</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ar S�rs</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Er Stivri��</td><td class=bc>-</td><td class=bl>Ed K�avi��</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>J� Ustups</td><td class=bc>-</td><td class=blW>Ma Kalni��</td><td class=bc>0 : 14</tr></td>
<tr><td class=br>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>Al Jakob�ns</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Af Zahars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>El Reinfelds</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Kr Rudz�tis</td><td class=bc>-</td><td class=bl>Ed K�avi��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ar S�rs</td><td class=bc>-</td><td class=blW>Ma Kalni��</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Er Stivri��</td><td class=bc>-</td><td class=bl>Al Jakob�ns</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>J� Ustups</td><td class=bc>-</td><td class=blW>Af Zahars</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>Ed K�avi��</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ma Kalni��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kr Rudz�tis</td><td class=bc>-</td><td class=bl>Al Jakob�ns</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ar S�rs</td><td class=bc>-</td><td class=blW>Af Zahars</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Er Stivri��</td><td class=bc>-</td><td class=bl>Da Vai�iul�ns</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>J� Ustups</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Ed K�avi��</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>Al Jakob�ns</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>El Reinfelds</td><td class=bc>-</td><td class=bl>Af Zahars</td><td class=bc>11 : 4</tr></td>
<tr><td class=br>Kr Rudz�tis</td><td class=bc>-</td><td class=blW>Da Vai�iul�ns</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ar S�rs</td><td class=bc>-</td><td class=bl>J� Ustups</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Er Stivri��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Al Jakob�ns</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Af Zahars</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=blW>Da Vai�iul�ns</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>El Reinfelds</td><td class=bc>-</td><td class=bl>J� Ustups</td><td class=bc>10 : 2</tr></td>
<tr><td class=brW>Kr Rudz�tis</td><td class=bc>-</td><td class=bl>Er Stivri��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ar S�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ed K�avi��</td><td class=bc>-</td><td class=blW>Al Jakob�ns</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>Af Zahars</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Da Vai�iul�ns</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>J� Ustups</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>Er Stivri��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>El Reinfelds</td><td class=bc>-</td><td class=bl>Ar S�rs</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Kr Rudz�tis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>Af Zahars</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ed K�avi��</td><td class=bc>-</td><td class=blW>Da Vai�iul�ns</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>J� Ustups</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Er Stivri��</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Ar S�rs</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>Kr Rudz�tis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group AL 1.l�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/8</td><td class=d>1.</td><td class=kt>D� Vai�iul�ns</td><td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kW>9:0</td>
<td class=br>68:14</td><td class=br>+54</td>
<td class=bc>13 - 1 - 1</td>
<td class=br><strong>27</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/8</td><td class=d>2.</td><td class=kt>M� Timbers</td><td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>8:1</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=br>60:20</td><td class=br>+40</td>
<td class=bc>11 - 3 - 1</td>
<td class=br><strong>25</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/8</td><td class=d>3.</td><td class=kt>Da Belkovs</td><td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=br>56:31</td><td class=br>+25</td>
<td class=bc>9 - 4 - 2</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/8</td><td class=d>4.</td><td class=kt>Af Zahars</td><td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=br>45:26</td><td class=br>+19</td>
<td class=bc>10 - 2 - 3</td>
<td class=br><strong>22</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/8</td><td class=d>5.</td><td class=kt>Da Vai�iul�ns</td><td class=kL>1:6</td>
<td class=kT>4:4</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>7:3</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=br>46:28</td><td class=br>+18</td>
<td class=bc>10 - 2 - 3</td>
<td class=br><strong>22</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/8</td><td class=d>6.</td><td class=kt>Ri Stivri��</td><td class=kL>1:8</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>8:1</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>7:0</td>
<td class=br>52:22</td><td class=br>+30</td>
<td class=bc>9 - 3 - 3</td>
<td class=br><strong>21</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/8</td><td class=d>7.</td><td class=kt>Ma P�tersons</td><td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kL>0:1</td>
<td class=kW>2:0</td>
<td class=kW>11:0</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=br>46:25</td><td class=br>+21</td>
<td class=bc>8 - 0 - 7</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/8</td><td class=d>8.</td><td class=kt>Al Sili��</td><td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>3:7</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=br>39:32</td><td class=br>+7</td>
<td class=bc>6 - 4 - 5</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/8</td><td class=d>9.</td><td class=kt>Em Ka�s</td><td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=br>35:35</td><td class=br>0</td>
<td class=bc>6 - 1 - 8</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/8</td><td class=d>10.</td><td class=kt>Al Jakob�ns</td><td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=br>19:46</td><td class=br>-27</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/8</td><td class=d>11.</td><td class=kt>Em Vi��akovs</td><td class=kL>0:5</td>
<td class=kL>1:8</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=br>15:38</td><td class=br>-23</td>
<td class=bc>3 - 3 - 9</td>
<td class=br><strong>9</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/8</td><td class=d>12.</td><td class=kt>Kr Rudz�tis</td><td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>1:8</td>
<td class=kL>0:2</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=br>17:38</td><td class=br>-21</td>
<td class=bc>3 - 2 - 8</td>
<td class=br><strong>8</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/8</td><td class=d>13.</td><td class=kt>Gu Kaveckis</td><td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>0:11</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=k>&nbsp;</td>
<td class=kW>2:0</td>
<td class=br>16:37</td><td class=br>-21</td>
<td class=bc>3 - 2 - 8</td>
<td class=br><strong>8</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/8</td><td class=d>14.</td><td class=kt>Re Dani�evskis</td><td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=k>&nbsp;</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kL>0:2</td>
<td class=br>12:46</td><td class=br>-34</td>
<td class=bc>1 - 3 - 10</td>
<td class=br><strong>5</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/8</td><td class=d>15.</td><td class=kt>Kl Lange</td><td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>1:7</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=k>&nbsp;</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=br>12:48</td><td class=br>-36</td>
<td class=bc>1 - 3 - 10</td>
<td class=br><strong>5</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/8</td><td class=d>16.</td><td class=kt>Ti Gorsanova</td><td class=kL>0:9</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kW>2:0</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=br>9:61</td><td class=br>-52</td>
<td class=bc>2 - 0 - 13</td>
<td class=br><strong>4</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>D� Vai�iul�ns</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Kl Lange</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Af Zahars</td><td class=bc>-</td><td class=bl>Kr Rudz�tis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ri Stivri��</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>M� Timbers</td><td class=bc>-</td><td class=bl>Al Jakob�ns</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Re Dani�evskis</td><td class=bc>-</td><td class=blW>Ti Gorsanova</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Gu Kaveckis</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>0 : 11</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>D� Vai�iul�ns</td><td class=bc>-</td><td class=bl>Kl Lange</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Kr Rudz�tis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Af Zahars</td><td class=bc>-</td><td class=bl>Al Jakob�ns</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ri Stivri��</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>M� Timbers</td><td class=bc>-</td><td class=bl>Ti Gorsanova</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Re Dani�evskis</td><td class=bc>-</td><td class=blW>Gu Kaveckis</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Kl Lange</td><td class=bc>-</td><td class=blW>Kr Rudz�tis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>D� Vai�iul�ns</td><td class=bc>-</td><td class=blW>Da Belkovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>Al Jakob�ns</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Em Vi��akovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Af Zahars</td><td class=bc>-</td><td class=bl>Ti Gorsanova</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ri Stivri��</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>M� Timbers</td><td class=bc>-</td><td class=bl>Gu Kaveckis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>Re Dani�evskis</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Kr Rudz�tis</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kl Lange</td><td class=bc>-</td><td class=bl>Al Jakob�ns</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>D� Vai�iul�ns</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>Ti Gorsanova</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Af Zahars</td><td class=bc>-</td><td class=bl>Gu Kaveckis</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ri Stivri��</td><td class=bc>-</td><td class=bl>Re Dani�evskis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=bl>Da Vai�iul�ns</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Al Jakob�ns</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Kr Rudz�tis</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Kl Lange</td><td class=bc>-</td><td class=bl>Ti Gorsanova</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>D� Vai�iul�ns</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>Gu Kaveckis</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Re Dani�evskis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Af Zahars</td><td class=bc>-</td><td class=bl>Da Vai�iul�ns</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ri Stivri��</td><td class=bc>-</td><td class=blW>M� Timbers</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Al Jakob�ns</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Ti Gorsanova</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Kr Rudz�tis</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kl Lange</td><td class=bc>-</td><td class=bl>Gu Kaveckis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>D� Vai�iul�ns</td><td class=bc>-</td><td class=bl>Re Dani�evskis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Da Vai�iul�ns</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Af Zahars</td><td class=bc>-</td><td class=blW>Ri Stivri��</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Ti Gorsanova</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Jakob�ns</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Gu Kaveckis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Rudz�tis</td><td class=bc>-</td><td class=bl>Re Dani�evskis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kl Lange</td><td class=bc>-</td><td class=bl>Da Vai�iul�ns</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>D� Vai�iul�ns</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Ri Stivri��</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Af Zahars</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ti Gorsanova</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=bl>Gu Kaveckis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Al Jakob�ns</td><td class=bc>-</td><td class=bl>Re Dani�evskis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Da Vai�iul�ns</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Kr Rudz�tis</td><td class=bc>-</td><td class=blW>M� Timbers</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Kl Lange</td><td class=bc>-</td><td class=blW>Ri Stivri��</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>D� Vai�iul�ns</td><td class=bc>-</td><td class=bl>Af Zahars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>Re Dani�evskis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ti Gorsanova</td><td class=bc>-</td><td class=blW>Da Vai�iul�ns</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>M� Timbers</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Al Jakob�ns</td><td class=bc>-</td><td class=blW>Ri Stivri��</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Af Zahars</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kr Rudz�tis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kl Lange</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>D� Vai�iul�ns</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Gu Kaveckis</td><td class=bc>-</td><td class=blW>Da Vai�iul�ns</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=blW>M� Timbers</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ti Gorsanova</td><td class=bc>-</td><td class=blW>Ri Stivri��</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Af Zahars</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Al Jakob�ns</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Rudz�tis</td><td class=bc>-</td><td class=blW>D� Vai�iul�ns</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kl Lange</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Re Dani�evskis</td><td class=bc>-</td><td class=blW>M� Timbers</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Gu Kaveckis</td><td class=bc>-</td><td class=bl>Ri Stivri��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=blW>Af Zahars</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ti Gorsanova</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al Jakob�ns</td><td class=bc>-</td><td class=blW>D� Vai�iul�ns</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Kl Lange</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kr Rudz�tis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>Ri Stivri��</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Re Dani�evskis</td><td class=bc>-</td><td class=blW>Af Zahars</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Gu Kaveckis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ti Gorsanova</td><td class=bc>-</td><td class=blW>D� Vai�iul�ns</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Em Vi��akovs</td><td class=bc>-</td><td class=bl>Kl Lange</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Al Jakob�ns</td><td class=bc>-</td><td class=bl>Kr Rudz�tis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>M� Timbers</td><td class=bc>-</td><td class=bl>Af Zahars</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Re Dani�evskis</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Gu Kaveckis</td><td class=bc>-</td><td class=blW>D� Vai�iul�ns</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>Kl Lange</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ti Gorsanova</td><td class=bc>-</td><td class=blW>Kr Rudz�tis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Da Belkovs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Al Jakob�ns</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ri Stivri��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>M� Timbers</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Da Vai�iul�ns</td><td class=bc>-</td><td class=blW>D� Vai�iul�ns</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Re Dani�evskis</td><td class=bc>-</td><td class=bl>Kl Lange</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Gu Kaveckis</td><td class=bc>-</td><td class=bl>Kr Rudz�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=blW>Da Belkovs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ti Gorsanova</td><td class=bc>-</td><td class=blW>Al Jakob�ns</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Af Zahars</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ri Stivri��</td><td class=bc>-</td><td class=blW>D� Vai�iul�ns</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>M� Timbers</td><td class=bc>-</td><td class=bl>Kl Lange</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>Kr Rudz�tis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Re Dani�evskis</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Gu Kaveckis</td><td class=bc>-</td><td class=bl>Al Jakob�ns</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=blW>Em Vi��akovs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ti Gorsanova</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>D� Vai�iul�ns</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Af Zahars</td><td class=bc>-</td><td class=bl>Kl Lange</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ri Stivri��</td><td class=bc>-</td><td class=bl>Kr Rudz�tis</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Da Vai�iul�ns</td><td class=bc>-</td><td class=bl>Al Jakob�ns</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Re Dani�evskis</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Gu Kaveckis</td><td class=bc>-</td><td class=bl>Ti Gorsanova</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group AL 2.liga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Er Stivri��</td><td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>38:9</td><td class=br>+29</td>
<td class=bc>10 - 2 - 0</td>
<td class=br><strong>22</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>�i Carenko</td><td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>29:7</td><td class=br>+22</td>
<td class=bc>10 - 1 - 1</td>
<td class=br><strong>21</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Ev �alkovska</td><td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>7:0</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>40:9</td><td class=br>+31</td>
<td class=bc>9 - 2 - 1</td>
<td class=br><strong>20</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Ot �v��eris</td><td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kT>0:0</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>30:9</td><td class=br>+21</td>
<td class=bc>7 - 3 - 2</td>
<td class=br><strong>17</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>J� Ustups</td><td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>29:12</td><td class=br>+17</td>
<td class=bc>8 - 0 - 4</td>
<td class=br><strong>16</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Em Prodniece</td><td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>27:9</td><td class=br>+18</td>
<td class=bc>6 - 2 - 4</td>
<td class=br><strong>14</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Kr K�avi��</td><td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>28:24</td><td class=br>+4</td>
<td class=bc>6 - 1 - 5</td>
<td class=br><strong>13</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ne Giri�a</td><td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>22:15</td><td class=br>+7</td>
<td class=bc>4 - 2 - 6</td>
<td class=br><strong>10</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ed K�avi��</td><td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kT>0:0</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>20:18</td><td class=br>+2</td>
<td class=bc>3 - 3 - 6</td>
<td class=br><strong>9</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Dm Kolbass</td><td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>20:21</td><td class=br>-1</td>
<td class=bc>4 - 0 - 8</td>
<td class=br><strong>8</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ra Greb�evs</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kT>0:0</td>
<td class=br>0:50</td><td class=br>-50</td>
<td class=bc>0 - 2 - 10</td>
<td class=br><strong>2</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Kr Egl�tis</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=br>0:50</td><td class=br>-50</td>
<td class=bc>0 - 2 - 10</td>
<td class=br><strong>2</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ar S�rs</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kT>0:0</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=br>0:50</td><td class=br>-50</td>
<td class=bc>0 - 2 - 10</td>
<td class=br><strong>2</strong></td><td class=d>13.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ot �v��eris</td><td class=bc>-</td><td class=bl>Er Stivri��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ne Giri�a</td><td class=bc>-</td><td class=bl>Ra Greb�evs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Dm Kolbass</td><td class=bc>-</td><td class=blW>Em Prodniece</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>J� Ustups</td><td class=bc>-</td><td class=blW>Ev �alkovska</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>�i Carenko</td><td class=bc>-</td><td class=bl>Kr Egl�tis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kr K�avi��</td><td class=bc>-</td><td class=bl>Ar S�rs</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Er Stivri��</td><td class=bc>-</td><td class=bl>Ra Greb�evs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ot �v��eris</td><td class=bc>-</td><td class=bl>Em Prodniece</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=bl>Ev �alkovska</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Dm Kolbass</td><td class=bc>-</td><td class=bl>Kr Egl�tis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>J� Ustups</td><td class=bc>-</td><td class=bl>Ar S�rs</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>�i Carenko</td><td class=bc>-</td><td class=bl>Ed K�avi��</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ra Greb�evs</td><td class=bc>-</td><td class=blW>Em Prodniece</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Er Stivri��</td><td class=bc>-</td><td class=bl>Ev �alkovska</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ot �v��eris</td><td class=bc>-</td><td class=bl>Kr Egl�tis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ne Giri�a</td><td class=bc>-</td><td class=bl>Ar S�rs</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Dm Kolbass</td><td class=bc>-</td><td class=bl>Ed K�avi��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>J� Ustups</td><td class=bc>-</td><td class=bl>Kr K�avi��</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Em Prodniece</td><td class=bc>-</td><td class=blW>Ev �alkovska</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ra Greb�evs</td><td class=bc>-</td><td class=bl>Kr Egl�tis</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Er Stivri��</td><td class=bc>-</td><td class=bl>Ar S�rs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ot �v��eris</td><td class=bc>-</td><td class=bl>Ed K�avi��</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=blW>Kr K�avi��</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Dm Kolbass</td><td class=bc>-</td><td class=blW>�i Carenko</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ev �alkovska</td><td class=bc>-</td><td class=bl>Kr Egl�tis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Em Prodniece</td><td class=bc>-</td><td class=bl>Ar S�rs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ra Greb�evs</td><td class=bc>-</td><td class=blW>Ed K�avi��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Er Stivri��</td><td class=bc>-</td><td class=bl>Kr K�avi��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ot �v��eris</td><td class=bc>-</td><td class=blW>�i Carenko</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=blW>J� Ustups</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Kr Egl�tis</td><td class=bc>-</td><td class=bl>Ar S�rs</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Ev �alkovska</td><td class=bc>-</td><td class=bl>Ed K�avi��</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Em Prodniece</td><td class=bc>-</td><td class=bl>Kr K�avi��</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ra Greb�evs</td><td class=bc>-</td><td class=blW>�i Carenko</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Er Stivri��</td><td class=bc>-</td><td class=bl>J� Ustups</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ot �v��eris</td><td class=bc>-</td><td class=bl>Dm Kolbass</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ar S�rs</td><td class=bc>-</td><td class=blW>Ed K�avi��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr Egl�tis</td><td class=bc>-</td><td class=blW>Kr K�avi��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ev �alkovska</td><td class=bc>-</td><td class=bl>�i Carenko</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Em Prodniece</td><td class=bc>-</td><td class=blW>J� Ustups</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ra Greb�evs</td><td class=bc>-</td><td class=blW>Dm Kolbass</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Er Stivri��</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ed K�avi��</td><td class=bc>-</td><td class=blW>Kr K�avi��</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ar S�rs</td><td class=bc>-</td><td class=blW>�i Carenko</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr Egl�tis</td><td class=bc>-</td><td class=blW>J� Ustups</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ev �alkovska</td><td class=bc>-</td><td class=bl>Dm Kolbass</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Em Prodniece</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ra Greb�evs</td><td class=bc>-</td><td class=blW>Ot �v��eris</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Kr K�avi��</td><td class=bc>-</td><td class=blW>�i Carenko</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ed K�avi��</td><td class=bc>-</td><td class=blW>J� Ustups</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ar S�rs</td><td class=bc>-</td><td class=blW>Dm Kolbass</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr Egl�tis</td><td class=bc>-</td><td class=blW>Ne Giri�a</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ev �alkovska</td><td class=bc>-</td><td class=bl>Ot �v��eris</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Em Prodniece</td><td class=bc>-</td><td class=blW>Er Stivri��</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>�i Carenko</td><td class=bc>-</td><td class=bl>J� Ustups</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Kr K�avi��</td><td class=bc>-</td><td class=bl>Dm Kolbass</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ed K�avi��</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ar S�rs</td><td class=bc>-</td><td class=blW>Ot �v��eris</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr Egl�tis</td><td class=bc>-</td><td class=blW>Er Stivri��</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ev �alkovska</td><td class=bc>-</td><td class=bl>Ra Greb�evs</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>J� Ustups</td><td class=bc>-</td><td class=bl>Dm Kolbass</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>�i Carenko</td><td class=bc>-</td><td class=bl>Ne Giri�a</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Kr K�avi��</td><td class=bc>-</td><td class=blW>Ot �v��eris</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ed K�avi��</td><td class=bc>-</td><td class=blW>Er Stivri��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ar S�rs</td><td class=bc>-</td><td class=bl>Ra Greb�evs</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Kr Egl�tis</td><td class=bc>-</td><td class=blW>Em Prodniece</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Dm Kolbass</td><td class=bc>-</td><td class=blW>Ne Giri�a</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>J� Ustups</td><td class=bc>-</td><td class=blW>Ot �v��eris</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>�i Carenko</td><td class=bc>-</td><td class=blW>Er Stivri��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kr K�avi��</td><td class=bc>-</td><td class=bl>Ra Greb�evs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ed K�avi��</td><td class=bc>-</td><td class=bl>Em Prodniece</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ar S�rs</td><td class=bc>-</td><td class=blW>Ev �alkovska</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ne Giri�a</td><td class=bc>-</td><td class=blW>Ot �v��eris</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Dm Kolbass</td><td class=bc>-</td><td class=blW>Er Stivri��</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>J� Ustups</td><td class=bc>-</td><td class=bl>Ra Greb�evs</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>�i Carenko</td><td class=bc>-</td><td class=bl>Em Prodniece</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Kr K�avi��</td><td class=bc>-</td><td class=blW>Ev �alkovska</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Ed K�avi��</td><td class=bc>-</td><td class=bl>Kr Egl�tis</td><td class=bc>5 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
