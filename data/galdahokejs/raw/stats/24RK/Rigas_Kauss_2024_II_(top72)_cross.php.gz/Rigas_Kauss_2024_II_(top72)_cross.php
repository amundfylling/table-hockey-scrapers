<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Rigas Kauss 2024 II (top72)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Rigas_Kauss_2024_II_(top72)_list.php">Rigas Kauss 2024 II (top72), 1. December 2024</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group SF Group A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>R� Kamzols</td><td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>7:5</td>
<td class=kW>7:2</td>
<td class=kL>3:4</td>
<td class=kL>4:6</td>
<td class=kW>2:1</td>
<td class=kW>9:0</td>
<td class=kW>8:2</td>
<td class=kW>2:1</td>
<td class=kW>6:4</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=br>67:40</td><td class=br>+27</td>
<td class=bc>10 - 2 - 3</td>
<td class=br><strong>22</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Kr Lagzdi�a</td><td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>4:7</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kT>0:0</td>
<td class=kW>4:1</td>
<td class=br>45:31</td><td class=br>+14</td>
<td class=bc>8 - 5 - 2</td>
<td class=br><strong>21</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ed Nilsson</td><td class=kL>5:7</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=br>55:31</td><td class=br>+24</td>
<td class=bc>9 - 3 - 3</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ed Naglis</td><td class=kL>2:7</td>
<td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kT>5:5</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=br>53:46</td><td class=br>+7</td>
<td class=bc>7 - 6 - 2</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ti Rimski</td><td class=kW>4:3</td>
<td class=kL>0:4</td>
<td class=kW>5:1</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=br>45:30</td><td class=br>+15</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Kr Naglis</td><td class=kW>6:4</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kT>5:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>7:3</td>
<td class=kW>4:1</td>
<td class=br>49:35</td><td class=br>+14</td>
<td class=bc>7 - 5 - 3</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Se Mihejevs</td><td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=br>39:28</td><td class=br>+11</td>
<td class=bc>6 - 4 - 5</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>An Jarvinen</td><td class=kL>0:9</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kL>1:4</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=br>32:37</td><td class=br>-5</td>
<td class=bc>7 - 2 - 6</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Mi Tous</td><td class=kL>2:8</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=kL>3:6</td>
<td class=kW>4:1</td>
<td class=br>47:46</td><td class=br>+1</td>
<td class=bc>6 - 3 - 6</td>
<td class=br><strong>15</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>Tr M�nsson</td><td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=br>24:35</td><td class=br>-11</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>In Garan�s</td><td class=kL>4:6</td>
<td class=kW>7:4</td>
<td class=kL>0:6</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=br>34:51</td><td class=br>-17</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ro Fa�ken�teins</td><td class=kW>4:0</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kL>1:6</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=br>30:38</td><td class=br>-8</td>
<td class=bc>3 - 4 - 8</td>
<td class=br><strong>10</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Gu Fagerberg</td><td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kL>1:4</td>
<td class=br>29:41</td><td class=br>-12</td>
<td class=bc>3 - 3 - 9</td>
<td class=br><strong>9</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Da Hrustaljova</td><td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=br>29:45</td><td class=br>-16</td>
<td class=bc>3 - 3 - 9</td>
<td class=br><strong>9</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Si Pleikys</td><td class=kL>1:5</td>
<td class=kT>0:0</td>
<td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=kL>0:4</td>
<td class=kL>3:7</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kW>6:3</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=br>25:53</td><td class=br>-28</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Ma Zenisek</td><td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=br>37:53</td><td class=br>-16</td>
<td class=bc>3 - 2 - 10</td>
<td class=br><strong>8</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Tous Michal</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=blW>Rimski Timur</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Jarvinen Anssi</td><td class=bc>-</td><td class=bl>Pleikys Simonas</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Tous Michal</td><td class=bc>-</td><td class=bl>Rimski Timur</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Pleikys Simonas</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Jarvinen Anssi</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Zenisek Martin</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Rimski Timur</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Fagerberg Gustaf</td><td class=bc>-</td><td class=bl>Pleikys Simonas</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Garan�s Intars</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Jarvinen Anssi</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Rimski Timur</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Pleikys Simonas</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Garan�s Intars</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jarvinen Anssi</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Rimski Timur</td><td class=bc>-</td><td class=bl>Pleikys Simonas</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Zenisek Martin</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Fagerberg Gustaf</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Garan�s Intars</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Pleikys Simonas</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Rimski Timur</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zenisek Martin</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Tous Michal</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Garan�s Intars</td><td class=bc>-</td><td class=bl>Jarvinen Anssi</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pleikys Simonas</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Rimski Timur</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Zenisek Martin</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Jarvinen Anssi</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Tous Michal</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pleikys Simonas</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Rimski Timur</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Jarvinen Anssi</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pleikys Simonas</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Rimski Timur</td><td class=bc>-</td><td class=bl>Jarvinen Anssi</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Zenisek Martin</td><td class=bc>-</td><td class=blW>Garan�s Intars</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Tous Michal</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Jarvinen Anssi</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pleikys Simonas</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Rimski Timur</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Tous Michal</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Jarvinen Anssi</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Pleikys Simonas</td><td class=bc>-</td><td class=bl>Tous Michal</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Rimski Timur</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Jarvinen Anssi</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Tous Michal</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Pleikys Simonas</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Rimski Timur</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Jarvinen Anssi</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Tous Michal</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Pleikys Simonas</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Jarvinen Anssi</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Tous Michal</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=blW>Rimski Timur</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Jarvinen Anssi</td><td class=bc>-</td><td class=bl>Tous Michal</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Rimski Timur</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Pleikys Simonas</td><td class=bc>7 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=bl>Tous Michal</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=blW>Fagerberg Gustaf</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jarvinen Anssi</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Rimski Timur</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Pleikys Simonas</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Tous Michal</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Jarvinen Anssi</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Rimski Timur</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Pleikys Simonas</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>7 : 5</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>3 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group SF Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ed Ka�eps</td><td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=br>51:35</td><td class=br>+16</td>
<td class=bc>8 - 6 - 1</td>
<td class=br><strong>22</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>J� Re�is</td><td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>7:3</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kW>6:3</td>
<td class=br>51:35</td><td class=br>+16</td>
<td class=bc>10 - 1 - 4</td>
<td class=br><strong>21</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Va Smagars</td><td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>9:0</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kW>6:4</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=br>56:30</td><td class=br>+26</td>
<td class=bc>10 - 1 - 4</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>El Sili��</td><td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kL>0:2</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=br>38:24</td><td class=br>+14</td>
<td class=bc>9 - 3 - 3</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Al Sili��</td><td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kW>6:4</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=br>49:39</td><td class=br>+10</td>
<td class=bc>7 - 5 - 3</td>
<td class=br><strong>19</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ra Kuha�skis</td><td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=br>48:33</td><td class=br>+15</td>
<td class=bc>8 - 3 - 4</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ja Zalokar Obadi�</td><td class=kL>2:5</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=br>51:38</td><td class=br>+13</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Jo Thyzell</td><td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>0:9</td>
<td class=kL>0:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=br>45:45</td><td class=br>0</td>
<td class=bc>7 - 3 - 5</td>
<td class=br><strong>17</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Mi Saul�tis</td><td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>4:6</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=br>46:42</td><td class=br>+4</td>
<td class=bc>7 - 2 - 6</td>
<td class=br><strong>16</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>Em Larsson</td><td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>7:3</td>
<td class=br>42:43</td><td class=br>-1</td>
<td class=bc>7 - 0 - 8</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Gu Hermansson</td><td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=br>38:51</td><td class=br>-13</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Sa Kalni��</td><td class=kT>2:2</td>
<td class=kL>3:7</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>7:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>36:39</td><td class=br>-3</td>
<td class=bc>4 - 3 - 8</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Bi Karlsson</td><td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>4:6</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kL>2:7</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=br>39:53</td><td class=br>-14</td>
<td class=bc>4 - 3 - 8</td>
<td class=br><strong>11</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Ne �krlep</td><td class=kL>3:6</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kW>5:1</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=br>40:57</td><td class=br>-17</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Zy Remeika</td><td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>23:50</td><td class=br>-27</td>
<td class=bc>3 - 0 - 12</td>
<td class=br><strong>6</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Marg �bele</td><td class=kL>3:6</td>
<td class=kL>3:6</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>24:63</td><td class=br>-39</td>
<td class=bc>0 - 0 - 15</td>
<td class=br><strong>0</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�krlep Nejc</td><td class=bc>-</td><td class=blW>Zalokar Obadi� Jakob</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Karlsson Bie</td><td class=bc>-</td><td class=blW>Thyzell Joachim</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Zalokar Obadi� Jakob</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Thyzell Joachim</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>�krlep Nejc</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Karlsson Bie</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=bl>Thyzell Joachim</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>�krlep Nejc</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Karlsson Bie</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Thyzell Joachim</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>�krlep Nejc</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Karlsson Bie</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Thyzell Joachim</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�krlep Nejc</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Karlsson Bie</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Thyzell Joachim</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>�krlep Nejc</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Karlsson Bie</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Thyzell Joachim</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�krlep Nejc</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Thyzell Joachim</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Karlsson Bie</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Thyzell Joachim</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=blW>Karlsson Bie</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>�krlep Nejc</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Thyzell Joachim</td><td class=bc>-</td><td class=bl>�krlep Nejc</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>�krlep Nejc</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Thyzell Joachim</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>�krlep Nejc</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Zalokar Obadi� Jakob</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>�krlep Nejc</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Zalokar Obadi� Jakob</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Thyzell Joachim</td><td class=bc>9 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>�krlep Nejc</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Zalokar Obadi� Jakob</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Thyzell Joachim</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>�krlep Nejc</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Zalokar Obadi� Jakob</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Thyzell Joachim</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Karlsson Bie</td><td class=bc>-</td><td class=bl>�krlep Nejc</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Zalokar Obadi� Jakob</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Thyzell Joachim</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>�krlep Nejc</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Karlsson Bie</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Zalokar Obadi� Jakob</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Thyzell Joachim</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>0 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group SF Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>An Umanskyy</td><td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kL>3:6</td>
<td class=kT>4:4</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=br>60:32</td><td class=br>+28</td>
<td class=bc>12 - 2 - 1</td>
<td class=br><strong>26</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Re Vazoli��</td><td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=br>46:30</td><td class=br>+16</td>
<td class=bc>12 - 0 - 3</td>
<td class=br><strong>24</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ma Madera</td><td class=kW>6:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>6:5</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>5:5</td>
<td class=kW>7:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=br>61:41</td><td class=br>+20</td>
<td class=bc>10 - 2 - 3</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Em Liepi��</td><td class=kT>4:4</td>
<td class=kL>1:7</td>
<td class=kL>5:6</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=br>59:47</td><td class=br>+12</td>
<td class=bc>8 - 3 - 4</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>My Shalomayev</td><td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kL>3:4</td>
<td class=br>42:36</td><td class=br>+6</td>
<td class=bc>8 - 1 - 6</td>
<td class=br><strong>17</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ol Korabel</td><td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>7:4</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=kL>4:5</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=br>63:41</td><td class=br>+22</td>
<td class=bc>7 - 3 - 5</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>An Kimberg</td><td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=br>31:34</td><td class=br>-3</td>
<td class=bc>6 - 4 - 5</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>He Prokuratovs</td><td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>8:1</td>
<td class=kW>4:3</td>
<td class=kL>4:7</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kW>6:3</td>
<td class=kW>8:2</td>
<td class=kW>6:3</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kW>6:4</td>
<td class=br>58:49</td><td class=br>+9</td>
<td class=bc>8 - 0 - 7</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>An Bo�i�</td><td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=br>33:38</td><td class=br>-5</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>Ha Ivantsova</td><td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>3:6</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>34:39</td><td class=br>-5</td>
<td class=bc>6 - 1 - 8</td>
<td class=br><strong>13</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Go Lonnqvist</td><td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kT>5:5</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kL>3:6</td>
<td class=kL>3:5</td>
<td class=kW>6:3</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>7:3</td>
<td class=kL>2:5</td>
<td class=kW>5:4</td>
<td class=kT>1:1</td>
<td class=br>50:62</td><td class=br>-12</td>
<td class=bc>4 - 4 - 7</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ma Satkus</td><td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kL>1:7</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kL>2:8</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=br>35:58</td><td class=br>-23</td>
<td class=bc>5 - 0 - 10</td>
<td class=br><strong>10</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ro Verbi�s</td><td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=br>31:51</td><td class=br>-20</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Al �ernovojs</td><td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>5:4</td>
<td class=kL>1:2</td>
<td class=kW>6:0</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kL>0:3</td>
<td class=br>37:44</td><td class=br>-7</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Jo �str�m</td><td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kL>4:5</td>
<td class=kW>6:3</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=br>34:46</td><td class=br>-12</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Pa Strods</td><td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kL>1:6</td>
<td class=kW>5:3</td>
<td class=kL>4:6</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=br>27:53</td><td class=br>-26</td>
<td class=bc>3 - 1 - 11</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>�str�m Joakim</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Strods Patriks</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Umanskyy Anton</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=bl>Lonnqvist Goran</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Madera Martin</td><td class=bc>-</td><td class=bl>Satkus Mazvydas</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�str�m Joakim</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Strods Patriks</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Lonnqvist Goran</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Satkus Mazvydas</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�str�m Joakim</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Strods Patriks</td><td class=bc>-</td><td class=bl>Lonnqvist Goran</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Satkus Mazvydas</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Lonnqvist Goran</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�str�m Joakim</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Strods Patriks</td><td class=bc>-</td><td class=blW>Satkus Mazvydas</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Lonnqvist Goran</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Satkus Mazvydas</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�str�m Joakim</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Strods Patriks</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Lonnqvist Goran</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Satkus Mazvydas</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�str�m Joakim</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Strods Patriks</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Korabel Oleksii</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Lonnqvist Goran</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Satkus Mazvydas</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�str�m Joakim</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Strods Patriks</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>Satkus Mazvydas</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Lonnqvist Goran</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Umanskyy Anton</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Korabel Oleksii</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�str�m Joakim</td><td class=bc>-</td><td class=blW>Ivantsova Hanna</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Satkus Mazvydas</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Lonnqvist Goran</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Korabel Oleksii</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=blW>Ivantsova Hanna</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Strods Patriks</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Satkus Mazvydas</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Lonnqvist Goran</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Strods Patriks</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>�str�m Joakim</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Madera Martin</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Satkus Mazvydas</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Lonnqvist Goran</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Strods Patriks</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>�str�m Joakim</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Madera Martin</td><td class=bc>-</td><td class=bl>Korabel Oleksii</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Satkus Mazvydas</td><td class=bc>-</td><td class=blW>Ivantsova Hanna</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Strods Patriks</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Lonnqvist Goran</td><td class=bc>-</td><td class=bl>�str�m Joakim</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Umanskyy Anton</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=bl>Korabel Oleksii</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Strods Patriks</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Satkus Mazvydas</td><td class=bc>-</td><td class=blW>�str�m Joakim</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Lonnqvist Goran</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Ivantsova Hanna</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Strods Patriks</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Madera Martin</td><td class=bc>-</td><td class=bl>�str�m Joakim</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Satkus Mazvydas</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Lonnqvist Goran</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Strods Patriks</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>�str�m Joakim</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Madera Martin</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Satkus Mazvydas</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Strods Patriks</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>�str�m Joakim</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Satkus Mazvydas</td><td class=bc>-</td><td class=blW>Lonnqvist Goran</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Strods Patriks</td><td class=bc>-</td><td class=blW>�str�m Joakim</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=bl>Lonnqvist Goran</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>6 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group SF Group D</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Hu L�nnqvist</td><td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=br>45:32</td><td class=br>+13</td>
<td class=bc>10 - 3 - 2</td>
<td class=br><strong>23</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ar Matantsev</td><td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=br>64:31</td><td class=br>+33</td>
<td class=bc>10 - 3 - 2</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>An Liepi��</td><td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=br>47:24</td><td class=br>+23</td>
<td class=bc>10 - 2 - 3</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ro Rieksti��</td><td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=br>49:27</td><td class=br>+22</td>
<td class=bc>8 - 5 - 2</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Gi Lasmanis</td><td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=br>44:35</td><td class=br>+9</td>
<td class=bc>7 - 4 - 4</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Pa Plesak</td><td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>0:6</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kL>3:5</td>
<td class=kW>6:1</td>
<td class=kL>4:6</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=br>52:43</td><td class=br>+9</td>
<td class=bc>6 - 3 - 6</td>
<td class=br><strong>15</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Sa Skarainis</td><td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kW>7:2</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>4:0</td>
<td class=kW>10:0</td>
<td class=kT>3:3</td>
<td class=br>48:39</td><td class=br>+9</td>
<td class=bc>6 - 3 - 6</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Al Skudr�tis</td><td class=kL>3:4</td>
<td class=kL>2:7</td>
<td class=kW>6:1</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=br>41:48</td><td class=br>-7</td>
<td class=bc>5 - 4 - 6</td>
<td class=br><strong>14</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Ma Jakseboga</td><td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=br>37:38</td><td class=br>-1</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>Be Rjavec</td><td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=br>31:42</td><td class=br>-11</td>
<td class=bc>5 - 4 - 6</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ar Zasurcevs</td><td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>6:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>8:4</td>
<td class=kW>7:4</td>
<td class=br>45:51</td><td class=br>-6</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Sa Krasts</td><td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>0:6</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kT>0:0</td>
<td class=br>28:43</td><td class=br>-15</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ig Saveljev</td><td class=kL>0:3</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=br>32:45</td><td class=br>-13</td>
<td class=bc>4 - 3 - 8</td>
<td class=br><strong>11</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>My Verbytskyy</td><td class=kL>0:3</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=br>26:48</td><td class=br>-22</td>
<td class=bc>4 - 2 - 9</td>
<td class=br><strong>10</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Bj Axelsen</td><td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>0:10</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>4:8</td>
<td class=kL>1:6</td>
<td class=kW>6:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=br>33:58</td><td class=br>-25</td>
<td class=bc>2 - 4 - 9</td>
<td class=br><strong>8</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>El R�cen�ja</td><td class=kL>1:4</td>
<td class=kL>3:7</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>4:7</td>
<td class=kT>0:0</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=br>32:50</td><td class=br>-18</td>
<td class=bc>1 - 6 - 8</td>
<td class=br><strong>8</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Rjavec Bernard</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Rjavec Bernard</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>Saveljev Igor</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>7 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>Rjavec Bernard</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Verbytskyy Mykola</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=bl>L�nnqvist Hugo</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Saveljev Igor</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Rjavec Bernard</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>L�nnqvist Hugo</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Verbytskyy Mykola</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Rjavec Bernard</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>L�nnqvist Hugo</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Matantsev Artem</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Rjavec Bernard</td><td class=bc>-</td><td class=blW>L�nnqvist Hugo</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>L�nnqvist Hugo</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Liepi�� Andris</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>L�nnqvist Hugo</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Rjavec Bernard</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>8 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>L�nnqvist Hugo</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Rjavec Bernard</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=blW>L�nnqvist Hugo</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Axelsen Bjarne</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>L�nnqvist Hugo</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>1 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group A FINAL</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/8</td><td class=d>1.</td><td class=kt>Ra Miglinieks</td><td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>7:1</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>8:1</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=br>106:37</td><td class=br>+69</td>
<td class=bc>21 - 1 - 1</td>
<td class=br><strong>43</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/8</td><td class=d>2.</td><td class=kt>Ra Kalni��</td><td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>7:3</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>7:3</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kW>6:1</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kW>8:1</td>
<td class=br>101:46</td><td class=br>+55</td>
<td class=bc>19 - 1 - 3</td>
<td class=br><strong>39</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/8</td><td class=d>3.</td><td class=kt>Ar Matantsev</td><td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kL>1:6</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=br>77:44</td><td class=br>+33</td>
<td class=bc>17 - 2 - 4</td>
<td class=br><strong>36</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/8</td><td class=d>4.</td><td class=kt>Pa Petr</td><td class=kT>3:3</td>
<td class=kL>3:7</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>7:3</td>
<td class=kL>2:6</td>
<td class=kL>4:6</td>
<td class=kW>6:3</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kW>7:4</td>
<td class=kW>5:3</td>
<td class=kW>7:4</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>8:3</td>
<td class=br>99:62</td><td class=br>+37</td>
<td class=bc>15 - 3 - 5</td>
<td class=br><strong>33</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Mi Kobrle</td><td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>6:4</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kL>0:2</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=kW>4:0</td>
<td class=kW>9:4</td>
<td class=br>89:56</td><td class=br>+33</td>
<td class=bc>15 - 3 - 5</td>
<td class=br><strong>33</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>Hu L�nnqvist</td><td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>3:7</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>7:1</td>
<td class=br>81:50</td><td class=br>+31</td>
<td class=bc>15 - 2 - 6</td>
<td class=br><strong>32</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Kr Lagzdi�a</td><td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kL>4:6</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kW>8:0</td>
<td class=kW>4:3</td>
<td class=kW>7:2</td>
<td class=br>72:57</td><td class=br>+15</td>
<td class=bc>10 - 7 - 6</td>
<td class=br><strong>27</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Ed Naglis</td><td class=kL>3:4</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kW>6:4</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>6:4</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kL>3:5</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=br>82:71</td><td class=br>+11</td>
<td class=bc>11 - 5 - 7</td>
<td class=br><strong>27</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>R� Kamzols</td><td class=kL>1:5</td>
<td class=kW>5:2</td>
<td class=kL>3:5</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kT>5:5</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=br>69:58</td><td class=br>+11</td>
<td class=bc>11 - 4 - 8</td>
<td class=br><strong>26</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Ti Rimski</td><td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kT>4:4</td>
<td class=kW>6:4</td>
<td class=br>62:54</td><td class=br>+8</td>
<td class=bc>9 - 7 - 7</td>
<td class=br><strong>25</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Ro Rieksti��</td><td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>7:0</td>
<td class=br>57:50</td><td class=br>+7</td>
<td class=bc>10 - 5 - 8</td>
<td class=br><strong>25</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>Sa Lagzdi��</td><td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>8:1</td>
<td class=kW>2:1</td>
<td class=kW>7:2</td>
<td class=kW>6:4</td>
<td class=kW>5:0</td>
<td class=br>67:58</td><td class=br>+9</td>
<td class=bc>10 - 4 - 9</td>
<td class=br><strong>24</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>An Liepi��</td><td class=kL>0:4</td>
<td class=kL>3:7</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=br>58:57</td><td class=br>+1</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Gi Lasmanis</td><td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kT>5:5</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=br>49:67</td><td class=br>-18</td>
<td class=bc>10 - 2 - 11</td>
<td class=br><strong>22</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Sa Skarainis</td><td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kW>2:0</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kW>8:2</td>
<td class=kL>3:5</td>
<td class=kW>2:0</td>
<td class=br>57:62</td><td class=br>-5</td>
<td class=bc>8 - 2 - 13</td>
<td class=br><strong>18</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Tr M�nsson</td><td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kL>5:6</td>
<td class=br>47:71</td><td class=br>-24</td>
<td class=bc>8 - 1 - 14</td>
<td class=br><strong>17</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ra Kuha�skis</td><td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>4:6</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kL>1:7</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kL>0:4</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=br>56:87</td><td class=br>-31</td>
<td class=bc>7 - 3 - 13</td>
<td class=br><strong>17</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>He Prokuratovs</td><td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>4:7</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kT>5:5</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kL>3:5</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=br>65:79</td><td class=br>-14</td>
<td class=bc>7 - 3 - 13</td>
<td class=br><strong>17</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Ma Jakseboga</td><td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>3:5</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kL>0:1</td>
<td class=kW>5:1</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>7:5</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=br>49:66</td><td class=br>-17</td>
<td class=bc>6 - 3 - 14</td>
<td class=br><strong>15</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Kr Naglis</td><td class=kL>1:8</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kL>4:7</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kT>5:5</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>1:8</td>
<td class=kW>4:1</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kL>5:7</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>4:0</td>
<td class=kW>10:1</td>
<td class=br>72:95</td><td class=br>-23</td>
<td class=bc>5 - 4 - 14</td>
<td class=br><strong>14</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>An Kimberg</td><td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=br>36:60</td><td class=br>-24</td>
<td class=bc>5 - 3 - 15</td>
<td class=br><strong>13</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>My Shalomayev</td><td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>2:8</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kL>3:6</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=br>47:93</td><td class=br>-46</td>
<td class=bc>5 - 2 - 16</td>
<td class=br><strong>12</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Pa Plesak</td><td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kT>4:4</td>
<td class=kL>3:6</td>
<td class=kL>4:6</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=br>49:94</td><td class=br>-45</td>
<td class=bc>1 - 5 - 17</td>
<td class=br><strong>7</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Mi Tous</td><td class=kL>1:6</td>
<td class=kL>1:8</td>
<td class=kL>1:5</td>
<td class=kL>3:8</td>
<td class=kL>4:9</td>
<td class=kL>1:7</td>
<td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>4:6</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kW>6:5</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:10</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=br>42:115</td><td class=br>-73</td>
<td class=bc>2 - 2 - 19</td>
<td class=br><strong>6</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Tous Michal</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Rimski Timur</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Liepi�� Andris</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Tous Michal</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Rimski Timur</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Liepi�� Andris</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>L�nnqvist Hugo</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Rimski Timur</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Liepi�� Andris</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=blW>Rimski Timur</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Matantsev Artem</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>L�nnqvist Hugo</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Rimski Timur</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>L�nnqvist Hugo</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Rimski Timur</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Miglinieks Raivis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>L�nnqvist Hugo</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Rimski Timur</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Miglinieks Raivis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Matantsev Artem</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>L�nnqvist Hugo</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Rimski Timur</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>L�nnqvist Hugo</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>6 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Rimski Timur</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=blW>L�nnqvist Hugo</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Matantsev Artem</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Rimski Timur</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>L�nnqvist Hugo</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=bl>Miglinieks Raivis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>L�nnqvist Hugo</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Rimski Timur</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=bl>L�nnqvist Hugo</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Rimski Timur</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>4 : 9</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Matantsev Artem</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>L�nnqvist Hugo</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Rimski Timur</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kalni�� Rainers</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>L�nnqvist Hugo</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Rimski Timur</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>L�nnqvist Hugo</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Rimski Timur</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Rimski Timur</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Tous Michal</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Tous Michal</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Rimski Timur</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>5 : 7</tr></td>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=bl>Tous Michal</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Kalni�� Rainers</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Tous Michal</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Rimski Timur</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>L�nnqvist Hugo</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Tous Michal</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=blW>Rimski Timur</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Kalni�� Rainers</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Tous Michal</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=bl>Rimski Timur</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>7 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Tous Michal</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=blW>Rimski Timur</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Tous Michal</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>Rimski Timur</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>6 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Kalni�� Rainers</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Tous Michal</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>Rimski Timur</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Tous Michal</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Rimski Timur</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>L�nnqvist Hugo</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>4 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group B FINAL</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/8</td><td class=d>1.</td><td class=kt>Ed Caics</td><td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=kL>3:4</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=br>83:51</td><td class=br>+32</td>
<td class=bc>15 - 4 - 4</td>
<td class=br><strong>34</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/8</td><td class=d>2.</td><td class=kt>Ol Korabel</td><td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kW>9:0</td>
<td class=kW>3:0</td>
<td class=kL>3:4</td>
<td class=kT>5:5</td>
<td class=kW>5:1</td>
<td class=kW>7:4</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>8:2</td>
<td class=kW>6:0</td>
<td class=br>102:53</td><td class=br>+49</td>
<td class=bc>15 - 3 - 5</td>
<td class=br><strong>33</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/8</td><td class=d>3.</td><td class=kt>Os Henriksson</td><td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kL>3:4</td>
<td class=kW>6:0</td>
<td class=kW>4:3</td>
<td class=kL>0:6</td>
<td class=kW>4:2</td>
<td class=kW>8:1</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>6:4</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>8:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=br>88:48</td><td class=br>+40</td>
<td class=bc>16 - 1 - 6</td>
<td class=br><strong>33</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/8</td><td class=d>4.</td><td class=kt>Re Vazoli��</td><td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>6:4</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=br>74:49</td><td class=br>+25</td>
<td class=bc>14 - 5 - 4</td>
<td class=br><strong>33</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>An Umanskyy</td><td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>7:2</td>
<td class=kT>0:0</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=br>77:45</td><td class=br>+32</td>
<td class=bc>14 - 3 - 6</td>
<td class=br><strong>31</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>J� Re�is</td><td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kW>4:2</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=br>64:61</td><td class=br>+3</td>
<td class=bc>14 - 2 - 7</td>
<td class=br><strong>30</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Ev Matantsev</td><td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kW>6:2</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>7:3</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kT>5:5</td>
<td class=kW>5:1</td>
<td class=br>83:71</td><td class=br>+12</td>
<td class=bc>12 - 3 - 8</td>
<td class=br><strong>27</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Ed Ka�eps</td><td class=kL>0:6</td>
<td class=kL>3:6</td>
<td class=kW>6:0</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kL>1:4</td>
<td class=kL>4:6</td>
<td class=kL>3:4</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=br>67:57</td><td class=br>+10</td>
<td class=bc>11 - 5 - 7</td>
<td class=br><strong>27</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>An Jarvinen</td><td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=br>49:48</td><td class=br>+1</td>
<td class=bc>12 - 1 - 10</td>
<td class=br><strong>25</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Al Sili��</td><td class=kL>3:6</td>
<td class=kW>3:1</td>
<td class=kL>1:8</td>
<td class=kT>3:3</td>
<td class=kL>2:7</td>
<td class=kW>3:0</td>
<td class=kL>3:5</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>6:4</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kL>4:5</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=br>70:72</td><td class=br>-2</td>
<td class=bc>10 - 4 - 9</td>
<td class=br><strong>24</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>El Sili��</td><td class=kL>2:3</td>
<td class=kL>0:9</td>
<td class=kW>1:0</td>
<td class=kL>0:3</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=br>49:57</td><td class=br>-8</td>
<td class=bc>8 - 8 - 7</td>
<td class=br><strong>24</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>Ed Nilsson</td><td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kL>4:6</td>
<td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>4:3</td>
<td class=br>59:56</td><td class=br>+3</td>
<td class=bc>10 - 4 - 9</td>
<td class=br><strong>24</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ma Madera</td><td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kL>0:6</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kL>0:6</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=br>60:70</td><td class=br>-10</td>
<td class=bc>9 - 5 - 9</td>
<td class=br><strong>23</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Va Smagars</td><td class=kL>1:4</td>
<td class=kT>5:5</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>5:4</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kL>4:6</td>
<td class=kW>2:0</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>7:1</td>
<td class=kL>5:7</td>
<td class=kL>4:6</td>
<td class=kW>3:2</td>
<td class=br>74:72</td><td class=br>+2</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Em Liepi��</td><td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kL>4:6</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kW>8:4</td>
<td class=kW>5:3</td>
<td class=br>65:75</td><td class=br>-10</td>
<td class=bc>7 - 7 - 9</td>
<td class=br><strong>21</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Al Skudr�tis</td><td class=kL>2:4</td>
<td class=kL>4:7</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kT>6:6</td>
<td class=kW>3:2</td>
<td class=kW>11:1</td>
<td class=kW>3:2</td>
<td class=br>75:70</td><td class=br>+5</td>
<td class=bc>9 - 2 - 12</td>
<td class=br><strong>20</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ha Ivantsova</td><td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kW>6:4</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=br>67:78</td><td class=br>-11</td>
<td class=bc>9 - 2 - 12</td>
<td class=br><strong>20</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Se Mihejevs</td><td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kL>0:6</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kW>7:2</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=br>56:68</td><td class=br>-12</td>
<td class=bc>7 - 5 - 11</td>
<td class=br><strong>19</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Ja Zalokar Obadi�</td><td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>6:1</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=br>64:70</td><td class=br>-6</td>
<td class=bc>8 - 2 - 13</td>
<td class=br><strong>18</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Mi Saul�tis</td><td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>1:8</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>3:7</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=br>44:69</td><td class=br>-25</td>
<td class=bc>6 - 4 - 13</td>
<td class=br><strong>16</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Be Rjavec</td><td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>2:7</td>
<td class=kW>5:3</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kL>1:7</td>
<td class=kT>4:4</td>
<td class=kT>6:6</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kL>0:5</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=br>61:89</td><td class=br>-28</td>
<td class=bc>4 - 7 - 12</td>
<td class=br><strong>15</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Em Larsson</td><td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>7:5</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kL>2:7</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=br>63:82</td><td class=br>-19</td>
<td class=bc>5 - 4 - 14</td>
<td class=br><strong>14</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Jo Thyzell</td><td class=kL>2:3</td>
<td class=kL>2:8</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kT>5:5</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kL>2:7</td>
<td class=kW>5:2</td>
<td class=kW>6:4</td>
<td class=kL>4:8</td>
<td class=kL>1:11</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=br>58:104</td><td class=br>-46</td>
<td class=bc>4 - 3 - 16</td>
<td class=br><strong>11</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>An Bo�i�</td><td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=br>49:86</td><td class=br>-37</td>
<td class=bc>2 - 5 - 16</td>
<td class=br><strong>9</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Thyzell Joachim</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Henriksson Oscar</td><td class=bc>-</td><td class=blW>Zalokar Obadi� Jakob</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Rjavec Bernard</td><td class=bc>-</td><td class=blW>Jarvinen Anssi</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Umanskyy Anton</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Matantsev Evgeniy</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=bl>Thyzell Joachim</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=blW>Zalokar Obadi� Jakob</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Jarvinen Anssi</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Henriksson Oscar</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Thyzell Joachim</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Zalokar Obadi� Jakob</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=bl>Jarvinen Anssi</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Henriksson Oscar</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Umanskyy Anton</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Thyzell Joachim</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Zalokar Obadi� Jakob</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Jarvinen Anssi</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Henriksson Oscar</td><td class=bc>-</td><td class=bl>Caics Edgars</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Madera Martin</td><td class=bc>-</td><td class=bl>Matantsev Evgeniy</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Thyzell Joachim</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Zalokar Obadi� Jakob</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Jarvinen Anssi</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Henriksson Oscar</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Rjavec Bernard</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Thyzell Joachim</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=blW>Zalokar Obadi� Jakob</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Jarvinen Anssi</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Henriksson Oscar</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Thyzell Joachim</td><td class=bc>-</td><td class=blW>Zalokar Obadi� Jakob</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=blW>Jarvinen Anssi</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Madera Martin</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=blW>Jarvinen Anssi</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Thyzell Joachim</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>4 : 8</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Caics Edgars</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Henriksson Oscar</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Jarvinen Anssi</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Thyzell Joachim</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Henriksson Oscar</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jarvinen Anssi</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Thyzell Joachim</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Umanskyy Anton</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=blW>Henriksson Oscar</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Korabel Oleksii</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Jarvinen Anssi</td><td class=bc>-</td><td class=bl>Caics Edgars</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Thyzell Joachim</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>1 : 11</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Madera Martin</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Henriksson Oscar</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Korabel Oleksii</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Caics Edgars</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Jarvinen Anssi</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Thyzell Joachim</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=blW>Henriksson Oscar</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Caics Edgars</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Jarvinen Anssi</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Thyzell Joachim</td><td class=bc>-</td><td class=blW>Henriksson Oscar</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Korabel Oleksii</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Umanskyy Anton</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Jarvinen Anssi</td><td class=bc>-</td><td class=blW>Henriksson Oscar</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Thyzell Joachim</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Madera Martin</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Ivantsova Hanna</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Henriksson Oscar</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Jarvinen Anssi</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Thyzell Joachim</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=blW>Ivantsova Hanna</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Caics Edgars</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>Henriksson Oscar</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jarvinen Anssi</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=blW>Ivantsova Hanna</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Thyzell Joachim</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=bl>Umanskyy Anton</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>6 : 6</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Henriksson Oscar</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Korabel Oleksii</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Jarvinen Anssi</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Thyzell Joachim</td><td class=bc>-</td><td class=bl>Umanskyy Anton</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>7 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Henriksson Oscar</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Jarvinen Anssi</td><td class=bc>-</td><td class=bl>Umanskyy Anton</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Thyzell Joachim</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Rjavec Bernard</td><td class=bc>-</td><td class=blW>Henriksson Oscar</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=bl>Korabel Oleksii</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Jarvinen Anssi</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Henriksson Oscar</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>5 : 7</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Caics Edgars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Umanskyy Anton</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Matantsev Evgeniy</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Jarvinen Anssi</td><td class=bc>-</td><td class=bl>Thyzell Joachim</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Henriksson Oscar</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Rjavec Bernard</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Matantsev Evgeniy</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Thyzell Joachim</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Zalokar Obadi� Jakob</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Henriksson Oscar</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Caics Edgars</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Thyzell Joachim</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=blW>Zalokar Obadi� Jakob</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Jarvinen Anssi</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=blW>Ivantsova Hanna</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Henriksson Oscar</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Rjavec Bernard</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Thyzell Joachim</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Zalokar Obadi� Jakob</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>Jarvinen Anssi</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>Ivantsova Hanna</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Henriksson Oscar</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Matantsev Evgeniy</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Thyzell Joachim</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Zalokar Obadi� Jakob</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Jarvinen Anssi</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Caics Edgars</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Henriksson Oscar</td><td class=bc>-</td><td class=bl>Matantsev Evgeniy</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Thyzell Joachim</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Zalokar Obadi� Jakob</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Jarvinen Anssi</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>3 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
