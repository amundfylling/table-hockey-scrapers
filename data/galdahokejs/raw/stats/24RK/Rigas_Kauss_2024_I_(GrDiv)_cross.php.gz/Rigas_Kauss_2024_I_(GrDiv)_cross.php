<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Rigas Kauss 2024 I (Gr+Div)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../24RK/Rigas_Kauss_2024_I_(GrDiv)_index.php">Rigas Kauss 2024 I (Gr+Div), 30. November 2024</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group A Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Kr Lagzdi�a</td><td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>6:4</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kW>10:0</td>
<td class=br>72:25</td><td class=br>+47</td>
<td class=bc>14 - 1 - 1</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ed Nilsson</td><td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>7:1</td>
<td class=kL>3:6</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>8:1</td>
<td class=kW>10:0</td>
<td class=kW>6:0</td>
<td class=kW>8:1</td>
<td class=kW>9:0</td>
<td class=br>83:27</td><td class=br>+56</td>
<td class=bc>12 - 1 - 3</td>
<td class=br><strong>25</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Kr Naglis</td><td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>4:6</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kW>6:4</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>8:1</td>
<td class=kW>5:1</td>
<td class=kW>8:3</td>
<td class=kW>15:3</td>
<td class=br>87:44</td><td class=br>+43</td>
<td class=bc>12 - 1 - 3</td>
<td class=br><strong>25</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>An Jarvinen</td><td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kW>6:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>8:1</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>57:25</td><td class=br>+32</td>
<td class=bc>10 - 4 - 2</td>
<td class=br><strong>24</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Da Hrustaljova</td><td class=kL>0:2</td>
<td class=kW>6:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=br>48:25</td><td class=br>+23</td>
<td class=bc>9 - 3 - 4</td>
<td class=br><strong>21</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ro Verbi�s</td><td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kL>3:6</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>12:1</td>
<td class=kW>8:1</td>
<td class=br>59:37</td><td class=br>+22</td>
<td class=bc>8 - 4 - 4</td>
<td class=br><strong>20</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Zy Remeika</td><td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=br>51:32</td><td class=br>+19</td>
<td class=bc>9 - 1 - 6</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Gu Fagerberg</td><td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>3:6</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kL>3:6</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=br>46:33</td><td class=br>+13</td>
<td class=bc>7 - 4 - 5</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>To Jakseboga</td><td class=kL>4:5</td>
<td class=kL>1:7</td>
<td class=kT>4:4</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=br>42:41</td><td class=br>+1</td>
<td class=bc>6 - 5 - 5</td>
<td class=br><strong>17</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Il �irse</td><td class=kL>2:7</td>
<td class=kW>6:3</td>
<td class=kL>2:6</td>
<td class=kL>1:8</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=br>45:53</td><td class=br>-8</td>
<td class=bc>6 - 3 - 7</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>He Petuch</td><td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>4:6</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kW>6:3</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=br>45:48</td><td class=br>-3</td>
<td class=bc>6 - 2 - 8</td>
<td class=br><strong>14</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Dm St�kailo</td><td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=br>39:40</td><td class=br>-1</td>
<td class=bc>6 - 1 - 9</td>
<td class=br><strong>13</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Gi Remeika</td><td class=kL>4:6</td>
<td class=kL>1:8</td>
<td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=br>33:50</td><td class=br>-17</td>
<td class=bc>5 - 2 - 9</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>�v Vikmanis</td><td class=kL>1:4</td>
<td class=kL>0:10</td>
<td class=kL>1:8</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>8:3</td>
<td class=br>32:59</td><td class=br>-27</td>
<td class=bc>5 - 2 - 9</td>
<td class=br><strong>12</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>To Ulis</td><td class=kL>1:7</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=br>21:70</td><td class=br>-49</td>
<td class=bc>2 - 1 - 13</td>
<td class=br><strong>5</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Ma P�tersons</td><td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kL>3:8</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>1:12</td>
<td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=br>15:83</td><td class=br>-68</td>
<td class=bc>1 - 0 - 15</td>
<td class=br><strong>2</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Em Vi��akovs</td><td class=kL>0:10</td>
<td class=kL>0:9</td>
<td class=kL>3:15</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>3:8</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=br>14:97</td><td class=br>-83</td>
<td class=bc>0 - 1 - 15</td>
<td class=br><strong>1</strong></td><td class=d>17.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Fagerberg Gustaf</td><td class=bc>-</td><td class=bl>Vi��akovs Em�ls</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Jarvinen Anssi</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>St�kailo Dmitri</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Vi��akovs Em�ls</td><td class=bc>-</td><td class=blW>Vikmanis �ve</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>St�kailo Dmitri</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Jarvinen Anssi</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>�irse Ilze</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>P�tersons Marks</td><td class=bc>8 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Vi��akovs Em�ls</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Fagerberg Gustaf</td><td class=bc>-</td><td class=bl>St�kailo Dmitri</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jarvinen Anssi</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>�irse Ilze</td><td class=bc>-</td><td class=bl>P�tersons Marks</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>St�kailo Dmitri</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vi��akovs Em�ls</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Fagerberg Gustaf</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>P�tersons Marks</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jarvinen Anssi</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>St�kailo Dmitri</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vi��akovs Em�ls</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Fagerberg Gustaf</td><td class=bc>-</td><td class=bl>P�tersons Marks</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Jarvinen Anssi</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>St�kailo Dmitri</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>P�tersons Marks</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vi��akovs Em�ls</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>St�kailo Dmitri</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ulis Tomas</td><td class=bc>-</td><td class=bl>P�tersons Marks</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Vi��akovs Em�ls</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Fagerberg Gustaf</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Jarvinen Anssi</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>P�tersons Marks</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>St�kailo Dmitri</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vi��akovs Em�ls</td><td class=bc>-</td><td class=blW>Jarvinen Anssi</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Petuch Hermann</td><td class=bc>-</td><td class=bl>P�tersons Marks</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>St�kailo Dmitri</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>Jarvinen Anssi</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Vi��akovs Em�ls</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>P�tersons Marks</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>St�kailo Dmitri</td><td class=bc>-</td><td class=blW>Jarvinen Anssi</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Fagerberg Gustaf</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>P�tersons Marks</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Jarvinen Anssi</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>St�kailo Dmitri</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Fagerberg Gustaf</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Vi��akovs Em�ls</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>P�tersons Marks</td><td class=bc>-</td><td class=blW>Jarvinen Anssi</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>St�kailo Dmitri</td><td class=bc>-</td><td class=bl>Vi��akovs Em�ls</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Vikmanis �ve</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Jarvinen Anssi</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>P�tersons Marks</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Petuch Hermann</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Vi��akovs Em�ls</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>St�kailo Dmitri</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Jarvinen Anssi</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>P�tersons Marks</td><td class=bc>-</td><td class=bl>Vi��akovs Em�ls</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Jarvinen Anssi</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Vi��akovs Em�ls</td><td class=bc>15 : 3</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>P�tersons Marks</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>1 : 12</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Ulis Tomas</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>St�kailo Dmitri</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Jarvinen Anssi</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>�irse Ilze</td><td class=bc>-</td><td class=bl>Vi��akovs Em�ls</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>P�tersons Marks</td><td class=bc>-</td><td class=blW>St�kailo Dmitri</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Vi��akovs Em�ls</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Jarvinen Anssi</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>St�kailo Dmitri</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>P�tersons Marks</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>0 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group B Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ed Ka�eps</td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kW>9:3</td>
<td class=kW>12:1</td>
<td class=br>69:24</td><td class=br>+45</td>
<td class=bc>11 - 3 - 2</td>
<td class=br><strong>25</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Gu Hermansson</td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>5:0</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=kW>10:1</td>
<td class=br>64:34</td><td class=br>+30</td>
<td class=bc>12 - 1 - 3</td>
<td class=br><strong>25</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>He Prokuratovs</td><td class=kW>2:1</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kW>5:2</td>
<td class=kW>6:4</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>5:7</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kW>13:1</td>
<td class=br>72:38</td><td class=br>+34</td>
<td class=bc>12 - 1 - 3</td>
<td class=br><strong>25</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Bi Karlsson</td><td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=br>51:31</td><td class=br>+20</td>
<td class=bc>11 - 3 - 2</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>J� Re�is</td><td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=kW>8:0</td>
<td class=br>62:29</td><td class=br>+33</td>
<td class=bc>12 - 1 - 3</td>
<td class=br><strong>25</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Va Smagars</td><td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kL>4:6</td>
<td class=kL>3:4</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>10:0</td>
<td class=kW>7:2</td>
<td class=kW>8:0</td>
<td class=br>78:38</td><td class=br>+40</td>
<td class=bc>12 - 0 - 4</td>
<td class=br><strong>24</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ma Zenisek</td><td class=kT>0:0</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>7:3</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=br>53:29</td><td class=br>+24</td>
<td class=bc>10 - 1 - 5</td>
<td class=br><strong>21</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Sa Kalni��</td><td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kL>5:6</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>11:0</td>
<td class=kW>7:0</td>
<td class=kW>4:2</td>
<td class=br>54:33</td><td class=br>+21</td>
<td class=bc>8 - 2 - 6</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Au Pleikys</td><td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>7:3</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=br>46:36</td><td class=br>+10</td>
<td class=bc>6 - 4 - 6</td>
<td class=br><strong>16</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>L� Bezdel�ga</td><td class=kL>1:7</td>
<td class=kL>3:4</td>
<td class=kW>7:5</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kW>6:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>8:3</td>
<td class=kW>5:1</td>
<td class=br>50:58</td><td class=br>-8</td>
<td class=bc>7 - 1 - 8</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ri Kalni��</td><td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=br>39:34</td><td class=br>+5</td>
<td class=bc>7 - 0 - 9</td>
<td class=br><strong>14</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ka Pirumshoieva</td><td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=br>23:39</td><td class=br>-16</td>
<td class=bc>6 - 1 - 9</td>
<td class=br><strong>13</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>J� Zem�ickis</td><td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=br>30:42</td><td class=br>-12</td>
<td class=bc>4 - 3 - 9</td>
<td class=br><strong>11</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Al Pimenovs</td><td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kW>12:0</td>
<td class=br>35:53</td><td class=br>-18</td>
<td class=bc>4 - 0 - 12</td>
<td class=br><strong>8</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Da Belkovs</td><td class=kL>0:8</td>
<td class=kL>2:7</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>0:10</td>
<td class=kL>3:7</td>
<td class=kL>0:11</td>
<td class=kL>3:7</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=br>33:84</td><td class=br>-51</td>
<td class=bc>2 - 0 - 14</td>
<td class=br><strong>4</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Re Saul�tis</td><td class=kL>3:9</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>0:7</td>
<td class=kL>0:7</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>3:8</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=br>23:81</td><td class=br>-58</td>
<td class=bc>1 - 1 - 14</td>
<td class=br><strong>3</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Kr Rudz�tis</td><td class=kL>1:12</td>
<td class=kL>1:10</td>
<td class=kL>1:13</td>
<td class=kL>1:5</td>
<td class=kL>0:8</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>0:12</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=br>14:113</td><td class=br>-99</td>
<td class=bc>0 - 0 - 16</td>
<td class=br><strong>0</strong></td><td class=d>17.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Karlsson Bie</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pimenovs Alekss</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Karlsson Bie</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Pirumshoieva Karyna</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Pimenovs Alekss</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Zem�ickis J�nis</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Zenisek Martin</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Pimenovs Alekss</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=blW>Pirumshoieva Karyna</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Pimenovs Alekss</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Pirumshoieva Karyna</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Pimenovs Alekss</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=blW>Karlsson Bie</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Pirumshoieva Karyna</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Pimenovs Alekss</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Karlsson Bie</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zenisek Martin</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Pimenovs Alekss</td><td class=bc>0 : 12</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Karlsson Bie</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Pimenovs Alekss</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Karlsson Bie</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>1 : 12</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=blW>Pimenovs Alekss</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Zem�ickis J�nis</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Pimenovs Alekss</td><td class=bc>-</td><td class=blW>Karlsson Bie</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Karlsson Bie</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pimenovs Alekss</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>5 : 7</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Karlsson Bie</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pimenovs Alekss</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Karlsson Bie</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pimenovs Alekss</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Karlsson Bie</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pimenovs Alekss</td><td class=bc>-</td><td class=blW>Zem�ickis J�nis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>13 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Karlsson Bie</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pimenovs Alekss</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Zem�ickis J�nis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>9 : 3</tr></td>
<tr><td class=brW>Karlsson Bie</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pimenovs Alekss</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>0 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group C Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>An Umanskyy</td><td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kT>5:5</td>
<td class=kT>3:3</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>8:0</td>
<td class=kW>7:1</td>
<td class=kW>10:1</td>
<td class=kW>9:0</td>
<td class=br>89:26</td><td class=br>+63</td>
<td class=bc>13 - 3 - 0</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Em Liepi��</td><td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>6:5</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=kW>5:3</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>15:0</td>
<td class=kW>11:0</td>
<td class=br>86:31</td><td class=br>+55</td>
<td class=bc>13 - 1 - 2</td>
<td class=br><strong>27</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ol Korabel</td><td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kW>6:1</td>
<td class=kL>2:4</td>
<td class=kW>7:3</td>
<td class=kW>10:1</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kW>9:1</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>12:0</td>
<td class=kW>7:0</td>
<td class=br>89:29</td><td class=br>+60</td>
<td class=bc>11 - 2 - 3</td>
<td class=br><strong>24</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Al �ernovojs</td><td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=br>52:28</td><td class=br>+24</td>
<td class=bc>11 - 2 - 3</td>
<td class=br><strong>24</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Sa Krasts</td><td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>11:0</td>
<td class=kW>7:0</td>
<td class=br>51:26</td><td class=br>+25</td>
<td class=bc>9 - 2 - 5</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>My Shalomayev</td><td class=kT>5:5</td>
<td class=kL>5:6</td>
<td class=kL>1:6</td>
<td class=kW>3:0</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>10:0</td>
<td class=br>62:41</td><td class=br>+21</td>
<td class=bc>9 - 2 - 5</td>
<td class=br><strong>20</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ar Zasurcevs</td><td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kW>10:0</td>
<td class=br>53:32</td><td class=br>+21</td>
<td class=bc>8 - 3 - 5</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ne �krlep</td><td class=kL>0:7</td>
<td class=kL>2:3</td>
<td class=kL>3:7</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kL>4:5</td>
<td class=kW>7:3</td>
<td class=kW>9:1</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>10:1</td>
<td class=br>63:46</td><td class=br>+17</td>
<td class=bc>8 - 2 - 6</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Mi �krlep</td><td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>1:10</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>0:1</td>
<td class=kW>8:2</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kL>0:1</td>
<td class=kW>7:0</td>
<td class=br>43:44</td><td class=br>-1</td>
<td class=bc>8 - 1 - 7</td>
<td class=br><strong>17</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Gl Storozhenko</td><td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>8:3</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=kW>4:0</td>
<td class=br>44:36</td><td class=br>+8</td>
<td class=bc>8 - 1 - 7</td>
<td class=br><strong>17</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ra Martu��ns</td><td class=kL>2:6</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kW>5:4</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=br>40:52</td><td class=br>-12</td>
<td class=bc>6 - 4 - 6</td>
<td class=br><strong>16</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Il Pavlovskis</td><td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kL>3:7</td>
<td class=kL>2:8</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>8:4</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=kW>12:0</td>
<td class=br>59:51</td><td class=br>+8</td>
<td class=bc>6 - 1 - 9</td>
<td class=br><strong>13</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>D� Vesele</td><td class=kL>2:7</td>
<td class=kL>3:6</td>
<td class=kL>1:9</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:9</td>
<td class=kL>2:3</td>
<td class=kL>3:8</td>
<td class=kT>2:2</td>
<td class=kL>4:8</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=br>43:68</td><td class=br>-25</td>
<td class=bc>4 - 2 - 10</td>
<td class=br><strong>10</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ag Pav�rs</td><td class=kL>0:8</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=br>24:44</td><td class=br>-20</td>
<td class=bc>5 - 0 - 11</td>
<td class=br><strong>10</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ro Aseri��</td><td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>1:7</td>
<td class=kL>0:6</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=br>17:60</td><td class=br>-43</td>
<td class=bc>2 - 0 - 14</td>
<td class=br><strong>4</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Em Ka�s</td><td class=kL>1:10</td>
<td class=kL>0:15</td>
<td class=kL>0:12</td>
<td class=kL>0:6</td>
<td class=kL>0:11</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kW>1:0</td>
<td class=kL>4:5</td>
<td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=br>18:99</td><td class=br>-81</td>
<td class=bc>2 - 0 - 14</td>
<td class=br><strong>4</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Dm Kolbass</td><td class=kL>0:9</td>
<td class=kL>0:11</td>
<td class=kL>0:7</td>
<td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>1:10</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>0:12</td>
<td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=br>3:123</td><td class=br>-120</td>
<td class=bc>0 - 0 - 16</td>
<td class=br><strong>0</strong></td><td class=d>17.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Kolbass Dmitrijs</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Umanskyy Anton</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>�krlep Nejc</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>�krlep Miha</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Kolbass Dmitrijs</td><td class=bc>-</td><td class=blW>�krlep Nejc</td><td class=bc>1 : 10</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>�krlep Miha</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>�krlep Nejc</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>�krlep Miha</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Kolbass Dmitrijs</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>�krlep Nejc</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>�krlep Miha</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Kolbass Dmitrijs</td><td class=bc>-</td><td class=blW>Pavlovskis Ilgvars</td><td class=bc>0 : 12</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>�krlep Nejc</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>�krlep Miha</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Pavlovskis Ilgvars</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kolbass Dmitrijs</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>�krlep Nejc</td><td class=bc>-</td><td class=bl>�krlep Miha</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>0 : 15</tr></td>
<tr><td class=br>Kolbass Dmitrijs</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>�krlep Miha</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>�krlep Nejc</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>0 : 12</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>�krlep Miha</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>�krlep Nejc</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Korabel Oleksii</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>Kolbass Dmitrijs</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Pavlovskis Ilgvars</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>�krlep Miha</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>�krlep Nejc</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Kolbass Dmitrijs</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>�krlep Miha</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>�krlep Nejc</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Kolbass Dmitrijs</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>�krlep Miha</td><td class=bc>-</td><td class=bl>Kolbass Dmitrijs</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>�krlep Nejc</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Kolbass Dmitrijs</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>�krlep Miha</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>�krlep Nejc</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Kolbass Dmitrijs</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>�krlep Miha</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>�krlep Nejc</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>9 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Korabel Oleksii</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Kolbass Dmitrijs</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>�krlep Miha</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Kolbass Dmitrijs</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Umanskyy Anton</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>�krlep Nejc</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Kolbass Dmitrijs</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=blW>�krlep Nejc</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>�krlep Miha</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Aseri�� Roberts</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kolbass Dmitrijs</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>�krlep Nejc</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>�krlep Miha</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>2 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group D Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ma Jakseboga</td><td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kW>6:5</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kT>5:5</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kW>7:0</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=br>52:20</td><td class=br>+32</td>
<td class=bc>11 - 4 - 0</td>
<td class=br><strong>26</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ro Rieksti��</td><td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kW>7:1</td>
<td class=kW>5:3</td>
<td class=kW>9:3</td>
<td class=kW>5:1</td>
<td class=br>60:32</td><td class=br>+28</td>
<td class=bc>11 - 2 - 2</td>
<td class=br><strong>24</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Bj Axelsen</td><td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>9:4</td>
<td class=br>62:28</td><td class=br>+34</td>
<td class=bc>11 - 2 - 2</td>
<td class=br><strong>24</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Si Pleikys</td><td class=kL>0:1</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>11:0</td>
<td class=br>49:28</td><td class=br>+21</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ig Saveljev</td><td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=kW>6:0</td>
<td class=br>49:18</td><td class=br>+31</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Go Lonnqvist</td><td class=kL>5:6</td>
<td class=kW>6:2</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>4:0</td>
<td class=kW>7:3</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>4:6</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kW>8:0</td>
<td class=br>62:37</td><td class=br>+25</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Gi Lasmanis</td><td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kW>1:0</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kT>5:5</td>
<td class=br>48:38</td><td class=br>+10</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Al Skudr�tis</td><td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=br>42:31</td><td class=br>+11</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ja Koski</td><td class=kT>5:5</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>3:7</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=br>43:38</td><td class=br>+5</td>
<td class=bc>5 - 4 - 6</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Hy Nechutny</td><td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kW>3:0</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=br>29:35</td><td class=br>-6</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ni Lyksholm</td><td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=br>37:45</td><td class=br>-8</td>
<td class=bc>3 - 6 - 6</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Re Stac�vi�s</td><td class=kL>0:1</td>
<td class=kL>3:6</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kW>6:4</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=br>38:47</td><td class=br>-9</td>
<td class=bc>6 - 0 - 9</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Al Hermansson</td><td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kW>6:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=br>21:56</td><td class=br>-35</td>
<td class=bc>3 - 2 - 10</td>
<td class=br><strong>8</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>El Reinfelds</td><td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>6:5</td>
<td class=kW>8:1</td>
<td class=br>31:57</td><td class=br>-26</td>
<td class=bc>2 - 1 - 12</td>
<td class=br><strong>5</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ig Zamiatin</td><td class=kL>0:4</td>
<td class=kL>3:9</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>0:7</td>
<td class=kL>2:7</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>5:6</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=br>27:72</td><td class=br>-45</td>
<td class=bc>1 - 2 - 12</td>
<td class=br><strong>4</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>M� Timbers</td><td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>4:9</td>
<td class=kL>0:11</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kT>5:5</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>3:6</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=br>21:89</td><td class=br>-68</td>
<td class=bc>0 - 1 - 14</td>
<td class=br><strong>1</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Koski Jaakko</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Lonnqvist Goran</td><td class=bc>-</td><td class=blW>Saveljev Igor</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Nechutny Hynek</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>9 : 4</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>Stac�vi�s Reinis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Koski Jaakko</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Lonnqvist Goran</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=bl>Pleikys Simonas</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Zamiatin Igor</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>Saveljev Igor</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Koski Jaakko</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Pleikys Simonas</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Lonnqvist Goran</td><td class=bc>-</td><td class=blW>Nechutny Hynek</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Stac�vi�s Reinis</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Hermansson Alfons</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Pleikys Simonas</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Koski Jaakko</td><td class=bc>-</td><td class=bl>Nechutny Hynek</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Saveljev Igor</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Pleikys Simonas</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>Nechutny Hynek</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Koski Jaakko</td><td class=bc>-</td><td class=blW>Lonnqvist Goran</td><td class=bc>3 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Saveljev Igor</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=blW>Pleikys Simonas</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Nechutny Hynek</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>Lonnqvist Goran</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Pleikys Simonas</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Nechutny Hynek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Lonnqvist Goran</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=bl>Koski Jaakko</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Pleikys Simonas</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Nechutny Hynek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Lyksholm Nico</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Lonnqvist Goran</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Koski Jaakko</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Pleikys Simonas</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Nechutny Hynek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Lonnqvist Goran</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Koski Jaakko</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Pleikys Simonas</td><td class=bc>-</td><td class=bl>Nechutny Hynek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Lonnqvist Goran</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Koski Jaakko</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Hermansson Alfons</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=blW>Axelsen Bjarne</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Nechutny Hynek</td><td class=bc>-</td><td class=blW>Lyksholm Nico</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pleikys Simonas</td><td class=bc>-</td><td class=blW>Lonnqvist Goran</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Koski Jaakko</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Axelsen Bjarne</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=bl>Lonnqvist Goran</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Nechutny Hynek</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Pleikys Simonas</td><td class=bc>-</td><td class=bl>Koski Jaakko</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Axelsen Bjarne</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Lonnqvist Goran</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Koski Jaakko</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Nechutny Hynek</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pleikys Simonas</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Axelsen Bjarne</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Koski Jaakko</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Lonnqvist Goran</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Hermansson Alfons</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Nechutny Hynek</td><td class=bc>-</td><td class=blW>Axelsen Bjarne</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pleikys Simonas</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Koski Jaakko</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Lonnqvist Goran</td><td class=bc>-</td><td class=blW>Axelsen Bjarne</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Nechutny Hynek</td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pleikys Simonas</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>11 : 0</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Stac�vi�s Reinis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Koski Jaakko</td><td class=bc>-</td><td class=blW>Axelsen Bjarne</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Lonnqvist Goran</td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Lyksholm Nico</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Nechutny Hynek</td><td class=bc>-</td><td class=blW>Stac�vi�s Reinis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pleikys Simonas</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Saveljev Igor</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>Axelsen Bjarne</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Koski Jaakko</td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Lonnqvist Goran</td><td class=bc>-</td><td class=blW>Stac�vi�s Reinis</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Nechutny Hynek</td><td class=bc>-</td><td class=blW>Saveljev Igor</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Pleikys Simonas</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>4 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group E Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Hu L�nnqvist</td><td class=kx>*</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=kW>9:3</td>
<td class=kW>5:4</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=br>67:24</td><td class=br>+43</td>
<td class=bc>12 - 2 - 1</td>
<td class=br><strong>26</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Sa Skarainis</td><td class=kW>6:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=br>60:23</td><td class=br>+37</td>
<td class=bc>12 - 1 - 2</td>
<td class=br><strong>25</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>An Liepi��</td><td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>4:0</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>9:0</td>
<td class=kW>6:1</td>
<td class=br>63:24</td><td class=br>+39</td>
<td class=bc>11 - 2 - 2</td>
<td class=br><strong>24</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Mi Tous</td><td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=br>50:34</td><td class=br>+16</td>
<td class=bc>8 - 4 - 3</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Be Rjavec</td><td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>0:7</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>6:0</td>
<td class=br>36:33</td><td class=br>+3</td>
<td class=bc>10 - 0 - 5</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Pa Plesak</td><td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=br>54:40</td><td class=br>+14</td>
<td class=bc>7 - 5 - 3</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ar Matantsev</td><td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kW>6:3</td>
<td class=kW>5:3</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=br>60:29</td><td class=br>+31</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>An Kimberg</td><td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>8:1</td>
<td class=br>44:31</td><td class=br>+13</td>
<td class=bc>6 - 6 - 3</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>To Bucek</td><td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=br>39:36</td><td class=br>+3</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ni Sviklis</td><td class=kL>3:9</td>
<td class=kL>2:4</td>
<td class=kL>2:7</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=br>42:54</td><td class=br>-12</td>
<td class=bc>4 - 2 - 9</td>
<td class=br><strong>10</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Da Baumanis</td><td class=kL>4:5</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=br>31:46</td><td class=br>-15</td>
<td class=bc>4 - 2 - 9</td>
<td class=br><strong>10</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ka �iha�ova</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>0:6</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=br>29:52</td><td class=br>-23</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>�i Vazoli��</td><td class=kL>1:7</td>
<td class=kL>0:7</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=br>28:49</td><td class=br>-21</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ro Purmalis</td><td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=br>16:53</td><td class=br>-37</td>
<td class=bc>2 - 2 - 11</td>
<td class=br><strong>6</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ma Kalni��</td><td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>0:9</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=br>14:58</td><td class=br>-44</td>
<td class=bc>1 - 2 - 12</td>
<td class=br><strong>4</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>M� �irsis</td><td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=br>20:67</td><td class=br>-47</td>
<td class=bc>0 - 3 - 12</td>
<td class=br><strong>3</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Bucek Tomas</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=blW>Tous Michal</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Liepi�� Andris</td><td class=bc>-</td><td class=blW>Rjavec Bernard</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Tous Michal</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Bucek Tomas</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Rjavec Bernard</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Tous Michal</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Bucek Tomas</td><td class=bc>-</td><td class=blW>Rjavec Bernard</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=blW>Purmalis Roberts</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Liepi�� Andris</td><td class=bc>-</td><td class=bl>L�nnqvist Hugo</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bucek Tomas</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=bl>L�nnqvist Hugo</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Tous Michal</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Bucek Tomas</td><td class=bc>-</td><td class=blW>L�nnqvist Hugo</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Purmalis Roberts</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>L�nnqvist Hugo</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Bucek Tomas</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=blW>L�nnqvist Hugo</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Bucek Tomas</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Rjavec Bernard</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>L�nnqvist Hugo</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Matantsev Artem</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>L�nnqvist Hugo</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Rjavec Bernard</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Bucek Tomas</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=blW>L�nnqvist Hugo</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Rjavec Bernard</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=bl>Bucek Tomas</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Bucek Tomas</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Bucek Tomas</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Rjavec Bernard</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=blW>Bucek Tomas</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Tous Michal</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=blW>Bucek Tomas</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Tous Michal</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=blW>Bucek Tomas</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Tous Michal</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=blW>Bucek Tomas</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=blW>Tous Michal</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Rjavec Bernard</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Bucek Tomas</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=blW>Tous Michal</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>L�nnqvist Hugo</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>5 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group F Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Re Vazoli��</td><td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>7:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=br>65:30</td><td class=br>+35</td>
<td class=bc>13 - 1 - 1</td>
<td class=br><strong>27</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ma Madera</td><td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=br>65:30</td><td class=br>+35</td>
<td class=bc>10 - 2 - 3</td>
<td class=br><strong>22</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>An Bo�i�</td><td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kW>6:1</td>
<td class=kT>0:0</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>3:6</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=br>55:29</td><td class=br>+26</td>
<td class=bc>10 - 2 - 3</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Marg �bele</td><td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=br>49:28</td><td class=br>+21</td>
<td class=bc>10 - 1 - 4</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ro Fa�ken�teins</td><td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=br>35:20</td><td class=br>+15</td>
<td class=bc>10 - 1 - 4</td>
<td class=br><strong>21</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>El R�cen�ja</td><td class=kL>4:7</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>5:4</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>8:1</td>
<td class=br>52:48</td><td class=br>+4</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Pa Strods</td><td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kT>0:0</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=br>38:25</td><td class=br>+13</td>
<td class=bc>8 - 3 - 4</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ha Ivantsova</td><td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>7:2</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=br>47:31</td><td class=br>+16</td>
<td class=bc>7 - 3 - 5</td>
<td class=br><strong>17</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ka Vi�ums</td><td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=br>34:45</td><td class=br>-11</td>
<td class=bc>7 - 2 - 6</td>
<td class=br><strong>16</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Vi Henttonen</td><td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=br>39:28</td><td class=br>+11</td>
<td class=bc>8 - 0 - 7</td>
<td class=br><strong>16</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ai Romals</td><td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kL>0:2</td>
<td class=kW>6:1</td>
<td class=br>33:44</td><td class=br>-11</td>
<td class=bc>5 - 0 - 10</td>
<td class=br><strong>10</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ei G�ze</td><td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=br>26:47</td><td class=br>-21</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Kr Kurzemnieks</td><td class=kL>0:2</td>
<td class=kL>0:7</td>
<td class=kW>6:3</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>4:5</td>
<td class=kL>1:7</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=br>28:46</td><td class=br>-18</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Za �krlep</td><td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kL>2:7</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=br>25:56</td><td class=br>-31</td>
<td class=bc>2 - 2 - 11</td>
<td class=br><strong>6</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Er Kalni��</td><td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kL>0:6</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=br>17:50</td><td class=br>-33</td>
<td class=bc>1 - 2 - 12</td>
<td class=br><strong>4</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Va Mirojevskis</td><td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:8</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=br>13:64</td><td class=br>-51</td>
<td class=bc>1 - 0 - 14</td>
<td class=br><strong>2</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>�krlep Zala</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Strods Patriks</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>Mirojevskis Vadims</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>�krlep Zala</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Strods Patriks</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Mirojevskis Vadims</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>�krlep Zala</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Strods Patriks</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Mirojevskis Vadims</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>�krlep Zala</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Strods Patriks</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Mirojevskis Vadims</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>�krlep Zala</td><td class=bc>-</td><td class=blW>Strods Patriks</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Mirojevskis Vadims</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Ivantsova Hanna</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Strods Patriks</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>�krlep Zala</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Mirojevskis Vadims</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Strods Patriks</td><td class=bc>-</td><td class=bl>Mirojevskis Vadims</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>�krlep Zala</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Mirojevskis Vadims</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Strods Patriks</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>�krlep Zala</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Mirojevskis Vadims</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Strods Patriks</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>�krlep Zala</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Madera Martin</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Mirojevskis Vadims</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Strods Patriks</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>�krlep Zala</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mirojevskis Vadims</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Strods Patriks</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>�krlep Zala</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Ivantsova Hanna</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Madera Martin</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mirojevskis Vadims</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Strods Patriks</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�krlep Zala</td><td class=bc>-</td><td class=blW>Vi�ums Kaspars</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mirojevskis Vadims</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Vi�ums Kaspars</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Strods Patriks</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Mirojevskis Vadims</td><td class=bc>-</td><td class=blW>Vi�ums Kaspars</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>�krlep Zala</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Vi�ums Kaspars</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Mirojevskis Vadims</td><td class=bc>-</td><td class=blW>�krlep Zala</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Strods Patriks</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>�krlep Zala</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Madera Martin</td><td class=bc>-</td><td class=bl>Strods Patriks</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mirojevskis Vadims</td><td class=bc>-</td><td class=blW>Romals Aigars</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Vi�ums Kaspars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>�krlep Zala</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Strods Patriks</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Romals Aigars</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Madera Martin</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>4 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group G Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Em Larsson</td><td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>2:6</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>4:7</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>10:0</td>
<td class=kW>5:4</td>
<td class=kW>5:1</td>
<td class=kT>0:0</td>
<td class=kW>4:3</td>
<td class=kW>7:0</td>
<td class=br>65:32</td><td class=br>+33</td>
<td class=bc>12 - 1 - 2</td>
<td class=br><strong>25</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>El Sili��</td><td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kL>0:1</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kW>7:2</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=br>64:29</td><td class=br>+35</td>
<td class=bc>11 - 2 - 2</td>
<td class=br><strong>24</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Al Sili��</td><td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>8:4</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>7:4</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=br>58:33</td><td class=br>+25</td>
<td class=bc>9 - 4 - 2</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ra Kuha�skis</td><td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kW>8:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>8:0</td>
<td class=kW>2:0</td>
<td class=kL>0:5</td>
<td class=kW>3:0</td>
<td class=br>48:32</td><td class=br>+16</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ja Zalokar Obadi�</td><td class=kL>2:5</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>6:4</td>
<td class=kW>7:0</td>
<td class=br>56:29</td><td class=br>+27</td>
<td class=bc>8 - 4 - 3</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Mi Saul�tis</td><td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>7:3</td>
<td class=kW>8:0</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=br>58:32</td><td class=br>+26</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Jo �str�m</td><td class=kW>7:4</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=br>53:35</td><td class=br>+18</td>
<td class=bc>7 - 4 - 4</td>
<td class=br><strong>18</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>My Verbytskyy</td><td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kW>5:4</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=br>42:44</td><td class=br>-2</td>
<td class=bc>8 - 1 - 6</td>
<td class=br><strong>17</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Kr Zarinieks</td><td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kL>4:8</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>7:4</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>7:3</td>
<td class=kT>1:1</td>
<td class=kW>6:0</td>
<td class=br>51:52</td><td class=br>-1</td>
<td class=bc>7 - 1 - 7</td>
<td class=br><strong>15</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Iv �irsis</td><td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>3:7</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kL>4:7</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>9:1</td>
<td class=br>42:44</td><td class=br>-2</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ma Krauze</td><td class=kL>0:10</td>
<td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>0:8</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=br>24:57</td><td class=br>-33</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Kr Zem�ickis</td><td class=kL>4:5</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kL>4:5</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=br>36:40</td><td class=br>-4</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Do Zupan�i�</td><td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>4:7</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=br>32:53</td><td class=br>-21</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Jo Pleikys</td><td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>3:7</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=br>18:44</td><td class=br>-26</td>
<td class=bc>2 - 3 - 10</td>
<td class=br><strong>7</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ja Hansson</td><td class=kL>3:4</td>
<td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kW>5:0</td>
<td class=kL>4:6</td>
<td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=br>28:53</td><td class=br>-25</td>
<td class=bc>2 - 1 - 12</td>
<td class=br><strong>5</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>An �krlep</td><td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>1:9</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=br>9:75</td><td class=br>-66</td>
<td class=bc>1 - 0 - 14</td>
<td class=br><strong>2</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>�str�m Joakim</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Hansson Jan-Olof</td><td class=bc>-</td><td class=blW>Zupan�i� Domen</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Zarinieks Kristaps</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Zalokar Obadi� Jakob</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>�krlep Ana ml.</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Zupan�i� Domen</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�str�m Joakim</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Hansson Jan-Olof</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=bl>Zalokar Obadi� Jakob</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Verbytskyy Mykola</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>�krlep Ana ml.</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Zupan�i� Domen</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�str�m Joakim</td><td class=bc>-</td><td class=bl>Zalokar Obadi� Jakob</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Hansson Jan-Olof</td><td class=bc>-</td><td class=blW>Verbytskyy Mykola</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>�krlep Ana ml.</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Zarinieks Kristaps</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Zupan�i� Domen</td><td class=bc>-</td><td class=blW>Zalokar Obadi� Jakob</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�str�m Joakim</td><td class=bc>-</td><td class=bl>�krlep Ana ml.</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Hansson Jan-Olof</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>Zalokar Obadi� Jakob</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Verbytskyy Mykola</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Zupan�i� Domen</td><td class=bc>-</td><td class=bl>�krlep Ana ml.</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�str�m Joakim</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Hansson Jan-Olof</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>0 : 10</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>�krlep Ana ml.</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Zupan�i� Domen</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�str�m Joakim</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Hansson Jan-Olof</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>�krlep Ana ml.</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Zupan�i� Domen</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�str�m Joakim</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Hansson Jan-Olof</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>�krlep Ana ml.</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Zupan�i� Domen</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�str�m Joakim</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>�krlep Ana ml.</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zupan�i� Domen</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Hansson Jan-Olof</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>�krlep Ana ml.</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Hansson Jan-Olof</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Zupan�i� Domen</td><td class=bc>-</td><td class=blW>�str�m Joakim</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>�krlep Ana ml.</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=bl>Hansson Jan-Olof</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>�str�m Joakim</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>�krlep Ana ml.</td><td class=bc>-</td><td class=blW>Hansson Jan-Olof</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>�str�m Joakim</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>Zupan�i� Domen</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Hansson Jan-Olof</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>�str�m Joakim</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>�krlep Ana ml.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Zupan�i� Domen</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Zalokar Obadi� Jakob</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Hansson Jan-Olof</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>�str�m Joakim</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Zupan�i� Domen</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>�krlep Ana ml.</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Zarinieks Kristaps</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Hansson Jan-Olof</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>�str�m Joakim</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Zupan�i� Domen</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>�krlep Ana ml.</td><td class=bc>-</td><td class=blW>Zalokar Obadi� Jakob</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Hansson Jan-Olof</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>�str�m Joakim</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Zupan�i� Domen</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Zalokar Obadi� Jakob</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Hansson Jan-Olof</td><td class=bc>-</td><td class=blW>�str�m Joakim</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Zupan�i� Domen</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Zalokar Obadi� Jakob</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>�krlep Ana ml.</td><td class=bc>2 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group H Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ed Naglis</td><td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>6:3</td>
<td class=kW>6:4</td>
<td class=kW>6:4</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>6:2</td>
<td class=br>69:34</td><td class=br>+35</td>
<td class=bc>12 - 2 - 1</td>
<td class=br><strong>26</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ti Rimski</td><td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>2:7</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>10:3</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=br>57:26</td><td class=br>+31</td>
<td class=bc>12 - 1 - 2</td>
<td class=br><strong>25</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Se Mihejevs</td><td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kW>6:0</td>
<td class=kW>8:2</td>
<td class=br>48:25</td><td class=br>+23</td>
<td class=bc>8 - 5 - 2</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Jo Thyzell</td><td class=kL>1:4</td>
<td class=kW>7:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>9:0</td>
<td class=br>64:34</td><td class=br>+30</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>R� Kamzols</td><td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>4:5</td>
<td class=kW>6:5</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>10:2</td>
<td class=kT>2:2</td>
<td class=br>59:32</td><td class=br>+27</td>
<td class=bc>8 - 4 - 3</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Tr M�nsson</td><td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=br>42:29</td><td class=br>+13</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>In Garan�s</td><td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>9:1</td>
<td class=kW>10:2</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=br>58:41</td><td class=br>+17</td>
<td class=bc>8 - 1 - 6</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ma Satkus</td><td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>5:6</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=kW>8:1</td>
<td class=kW>6:2</td>
<td class=kW>8:1</td>
<td class=br>63:47</td><td class=br>+16</td>
<td class=bc>7 - 2 - 6</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Si Thomas</td><td class=kL>4:6</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=br>37:33</td><td class=br>+4</td>
<td class=bc>7 - 2 - 6</td>
<td class=br><strong>16</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ma Kyllerg�rd</td><td class=kL>4:6</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kL>1:7</td>
<td class=kW>4:3</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=br>37:39</td><td class=br>-2</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Fr Platons</td><td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=br>27:38</td><td class=br>-11</td>
<td class=bc>6 - 1 - 8</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ar Salmi��</td><td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=br>33:50</td><td class=br>-17</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Mo �krlep</td><td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>1:9</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=br>28:55</td><td class=br>-27</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Vo Kvasnikov</td><td class=kL>2:5</td>
<td class=kL>3:10</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>2:10</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=br>26:71</td><td class=br>-45</td>
<td class=bc>2 - 1 - 12</td>
<td class=br><strong>5</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ra St�lmanis</td><td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>2:10</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>18:68</td><td class=br>-50</td>
<td class=bc>2 - 0 - 13</td>
<td class=br><strong>4</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>As Kocere</td><td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>2:8</td>
<td class=kL>0:9</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>1:8</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>21:65</td><td class=br>-44</td>
<td class=bc>1 - 2 - 12</td>
<td class=br><strong>4</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Thyzell Joachim</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=blW>�krlep Mojca</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kyllerg�rd Magnus</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=bl>Satkus Mazvydas</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Salmi�� Arnis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Rimski Timur</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Thyzell Joachim</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Garan�s Intars</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>�krlep Mojca</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=blW>Satkus Mazvydas</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Kyllerg�rd Magnus</td><td class=bc>-</td><td class=blW>Salmi�� Arnis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Thyzell Joachim</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>�krlep Mojca</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Garan�s Intars</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Satkus Mazvydas</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kyllerg�rd Magnus</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Rimski Timur</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>�krlep Mojca</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Thyzell Joachim</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Satkus Mazvydas</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Garan�s Intars</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=blW>Rimski Timur</td><td class=bc>3 : 10</tr></td>
<tr><td class=br>Kyllerg�rd Magnus</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>�krlep Mojca</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>Satkus Mazvydas</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Thyzell Joachim</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Rimski Timur</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Satkus Mazvydas</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>�krlep Mojca</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Thyzell Joachim</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Rimski Timur</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Kyllerg�rd Magnus</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Satkus Mazvydas</td><td class=bc>-</td><td class=blW>Salmi�� Arnis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>�krlep Mojca</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>Rimski Timur</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Thyzell Joachim</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Garan�s Intars</td><td class=bc>-</td><td class=bl>Kyllerg�rd Magnus</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Satkus Mazvydas</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Rimski Timur</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>�krlep Mojca</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Thyzell Joachim</td><td class=bc>-</td><td class=bl>Kyllerg�rd Magnus</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Salmi�� Arnis</td><td class=bc>-</td><td class=blW>Rimski Timur</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Satkus Mazvydas</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>�krlep Mojca</td><td class=bc>-</td><td class=bl>Kyllerg�rd Magnus</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Thyzell Joachim</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Rimski Timur</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Salmi�� Arnis</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Satkus Mazvydas</td><td class=bc>-</td><td class=blW>Kyllerg�rd Magnus</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Kvasnikov Volodymyr</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>�krlep Mojca</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Thyzell Joachim</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Rimski Timur</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Kyllerg�rd Magnus</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Satkus Mazvydas</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>�krlep Mojca</td><td class=bc>-</td><td class=blW>Garan�s Intars</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Rimski Timur</td><td class=bc>-</td><td class=bl>Kyllerg�rd Magnus</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Salmi�� Arnis</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Satkus Mazvydas</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�krlep Mojca</td><td class=bc>-</td><td class=blW>Thyzell Joachim</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Kyllerg�rd Magnus</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Rimski Timur</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Satkus Mazvydas</td><td class=bc>-</td><td class=blW>Thyzell Joachim</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Kyllerg�rd Magnus</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Rimski Timur</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Thyzell Joachim</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Salmi�� Arnis</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Satkus Mazvydas</td><td class=bc>-</td><td class=bl>�krlep Mojca</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kyllerg�rd Magnus</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Garan�s Intars</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Rimski Timur</td><td class=bc>-</td><td class=blW>Thyzell Joachim</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>�krlep Mojca</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=blW>Garan�s Intars</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>Kyllerg�rd Magnus</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Thyzell Joachim</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Rimski Timur</td><td class=bc>-</td><td class=bl>�krlep Mojca</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Satkus Mazvydas</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Garan�s Intars</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=blW>Thyzell Joachim</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kyllerg�rd Magnus</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>�krlep Mojca</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Rimski Timur</td><td class=bc>-</td><td class=bl>Satkus Mazvydas</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>6 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group 2.Division</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>73</td>
<td class=ic>74</td>
<td class=ic>75</td>
<td class=ic>76</td>
<td class=ic>77</td>
<td class=ic>78</td>
<td class=ic>79</td>
<td class=ic>80</td>
<td class=ic>81</td>
<td class=ic>82</td>
<td class=ic>83</td>
<td class=ic>84</td>
<td class=ic>85</td>
<td class=ic>86</td>
<td class=ic>87</td>
<td class=ic>88</td>
<td class=ic>89</td>
<td class=ic>90</td>
<td class=ic>91</td>
<td class=ic>92</td>
<td class=ic>93</td>
<td class=ic>94</td>
<td class=ic>95</td>
<td class=ic>96</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>73.</td><td class=kt>To Bucek</td><td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>8:2</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>7:4</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>7:1</td>
<td class=kW>6:3</td>
<td class=kW>10:0</td>
<td class=br>108:37</td><td class=br>+71</td>
<td class=bc>19 - 2 - 2</td>
<td class=br><strong>40</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>74.</td><td class=kt>Da Baumanis</td><td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>6:5</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kL>3:6</td>
<td class=kW>5:4</td>
<td class=kL>2:7</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kL>2:7</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>10:0</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>10:0</td>
<td class=br>93:60</td><td class=br>+33</td>
<td class=bc>17 - 2 - 4</td>
<td class=br><strong>36</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>75.</td><td class=kt>Ja Koski</td><td class=kL>2:8</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>7:3</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kL>2:6</td>
<td class=kW>3:0</td>
<td class=kW>9:4</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>10:0</td>
<td class=br>101:52</td><td class=br>+49</td>
<td class=bc>17 - 2 - 4</td>
<td class=br><strong>36</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>76.</td><td class=kt>Gl Storozhenko</td><td class=kT>4:4</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>6:3</td>
<td class=kW>1:0</td>
<td class=kW>6:0</td>
<td class=kW>7:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>10:0</td>
<td class=br>80:43</td><td class=br>+37</td>
<td class=bc>17 - 2 - 4</td>
<td class=br><strong>36</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>77.</td><td class=kt>Si Thomas</td><td class=kL>1:5</td>
<td class=kL>5:6</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>2:7</td>
<td class=kW>1:0</td>
<td class=kL>1:5</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>10:0</td>
<td class=br>78:48</td><td class=br>+30</td>
<td class=bc>15 - 4 - 4</td>
<td class=br><strong>34</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>78.</td><td class=kt>Vi Henttonen</td><td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>8:1</td>
<td class=kT>1:1</td>
<td class=kW>8:1</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kL>3:4</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>10:0</td>
<td class=br>87:37</td><td class=br>+50</td>
<td class=bc>15 - 4 - 4</td>
<td class=br><strong>34</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>79.</td><td class=kt>Ka Vi�ums</td><td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kW>5:0</td>
<td class=kW>8:1</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kT>0:0</td>
<td class=kL>5:6</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>10:0</td>
<td class=br>84:44</td><td class=br>+40</td>
<td class=bc>13 - 4 - 6</td>
<td class=br><strong>30</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>80.</td><td class=kt>Au Pleikys</td><td class=kL>2:6</td>
<td class=kW>6:3</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>6:3</td>
<td class=kW>4:0</td>
<td class=kT>4:4</td>
<td class=kW>10:0</td>
<td class=br>86:56</td><td class=br>+30</td>
<td class=bc>12 - 6 - 5</td>
<td class=br><strong>30</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>81.</td><td class=kt>He Petuch</td><td class=kL>0:4</td>
<td class=kL>4:5</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kW>7:2</td>
<td class=kL>1:8</td>
<td class=kW>6:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>7:3</td>
<td class=kW>5:1</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kW>10:0</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>10:0</td>
<td class=br>93:62</td><td class=br>+31</td>
<td class=bc>14 - 1 - 8</td>
<td class=br><strong>29</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>82.</td><td class=kt>Mi �krlep</td><td class=kL>1:4</td>
<td class=kW>7:2</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>1:3</td>
<td class=kW>7:3</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>10:0</td>
<td class=br>70:50</td><td class=br>+20</td>
<td class=bc>11 - 3 - 9</td>
<td class=br><strong>25</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>83.</td><td class=kt>Ma Kyllerg�rd</td><td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kL>1:8</td>
<td class=kL>1:8</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kT>5:5</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>10:0</td>
<td class=br>69:62</td><td class=br>+7</td>
<td class=bc>10 - 3 - 10</td>
<td class=br><strong>23</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>84.</td><td class=kt>Ra Martu��ns</td><td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>10:0</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=kW>5:4</td>
<td class=kT>4:4</td>
<td class=kW>10:0</td>
<td class=br>75:71</td><td class=br>+4</td>
<td class=bc>9 - 4 - 10</td>
<td class=br><strong>22</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>85.</td><td class=kt>Iv �irsis</td><td class=kL>2:7</td>
<td class=kW>7:2</td>
<td class=kL>3:5</td>
<td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>3:7</td>
<td class=kL>3:7</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kW>10:0</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>8:1</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>10:0</td>
<td class=br>84:72</td><td class=br>+12</td>
<td class=bc>8 - 4 - 11</td>
<td class=br><strong>20</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>86.</td><td class=kt>Hy Nechutny</td><td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kT>5:5</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>10:0</td>
<td class=br>52:59</td><td class=br>-7</td>
<td class=bc>7 - 5 - 11</td>
<td class=br><strong>19</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>87.</td><td class=kt>Ri Kalni��</td><td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>0:10</td>
<td class=kW>10:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>10:0</td>
<td class=br>55:65</td><td class=br>-10</td>
<td class=bc>8 - 3 - 12</td>
<td class=br><strong>19</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>88.</td><td class=kt>L� Bezdel�ga</td><td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>1:6</td>
<td class=kW>5:3</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kW>10:0</td>
<td class=br>54:84</td><td class=br>-30</td>
<td class=bc>7 - 4 - 12</td>
<td class=br><strong>18</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>89.</td><td class=kt>Ni Sviklis</td><td class=kL>4:7</td>
<td class=kL>0:10</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kL>0:10</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:1</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>10:0</td>
<td class=br>59:103</td><td class=br>-44</td>
<td class=bc>8 - 1 - 14</td>
<td class=br><strong>17</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>90.</td><td class=kt>Fr Platons</td><td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>2:7</td>
<td class=kW>4:2</td>
<td class=kT>5:5</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>10:0</td>
<td class=br>59:70</td><td class=br>-11</td>
<td class=bc>7 - 3 - 13</td>
<td class=br><strong>17</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>91.</td><td class=kt>To Jakseboga</td><td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>10:0</td>
<td class=br>55:55</td><td class=br>0</td>
<td class=bc>6 - 4 - 13</td>
<td class=br><strong>16</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>92.</td><td class=kt>Ma Krauze</td><td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kT>0:0</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>10:0</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>10:0</td>
<td class=br>50:61</td><td class=br>-11</td>
<td class=bc>6 - 3 - 14</td>
<td class=br><strong>15</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>93.</td><td class=kt>Kr Zarinieks</td><td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>4:9</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>6:5</td>
<td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>4:5</td>
<td class=kL>1:8</td>
<td class=kT>5:5</td>
<td class=kL>3:10</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>10:0</td>
<td class=br>70:95</td><td class=br>-25</td>
<td class=bc>5 - 4 - 14</td>
<td class=br><strong>14</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>94.</td><td class=kt>Ai Romals</td><td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>10:0</td>
<td class=br>49:64</td><td class=br>-15</td>
<td class=bc>5 - 3 - 15</td>
<td class=br><strong>13</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>95.</td><td class=kt>Il �irse</td><td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>10:0</td>
<td class=br>57:88</td><td class=br>-31</td>
<td class=bc>3 - 3 - 17</td>
<td class=br><strong>9</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>96.</td><td class=kt>Ni Lyksholm</td><td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kx>*</td>
<td class=br>0:230</td><td class=br>-230</td>
<td class=bc>0 - 0 - 23</td>
<td class=br><strong>0</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>�krlep Miha</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Koski Jaakko</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Bucek Tomas</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Kyllerg�rd Magnus</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Nechutny Hynek</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>�krlep Miha</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Koski Jaakko</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Bucek Tomas</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>Kyllerg�rd Magnus</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>�krlep Miha</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Koski Jaakko</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Bucek Tomas</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Kyllerg�rd Magnus</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Nechutny Hynek</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>�krlep Miha</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Koski Jaakko</td><td class=bc>-</td><td class=bl>Kyllerg�rd Magnus</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Bucek Tomas</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>Sviklis Nikl�vs P�teris</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Nechutny Hynek</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Kyllerg�rd Magnus</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>�krlep Miha</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Koski Jaakko</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Bucek Tomas</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Nechutny Hynek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kyllerg�rd Magnus</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>�krlep Miha</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Koski Jaakko</td><td class=bc>-</td><td class=bl>Nechutny Hynek</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Bucek Tomas</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Kyllerg�rd Magnus</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Sviklis Nikl�vs P�teris</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Nechutny Hynek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>�krlep Miha</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Koski Jaakko</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Bucek Tomas</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Kyllerg�rd Magnus</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Sviklis Nikl�vs P�teris</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Nechutny Hynek</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>�krlep Miha</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Koski Jaakko</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Bucek Tomas</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Kyllerg�rd Magnus</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Sviklis Nikl�vs P�teris</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Nechutny Hynek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�krlep Miha</td><td class=bc>-</td><td class=blW>Zarinieks Kristaps</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Koski Jaakko</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Kyllerg�rd Magnus</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Sviklis Nikl�vs P�teris</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Nechutny Hynek</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>�krlep Miha</td><td class=bc>-</td><td class=blW>Bucek Tomas</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Kyllerg�rd Magnus</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Sviklis Nikl�vs P�teris</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Nechutny Hynek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Bucek Tomas</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Koski Jaakko</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kyllerg�rd Magnus</td><td class=bc>-</td><td class=blW>Sviklis Nikl�vs P�teris</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Petuch Hermann</td><td class=bc>-</td><td class=bl>Nechutny Hynek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Bucek Tomas</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Koski Jaakko</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>�krlep Miha</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Nechutny Hynek</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Kyllerg�rd Magnus</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Zarinieks Kristaps</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Bucek Tomas</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Koski Jaakko</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>�krlep Miha</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Nechutny Hynek</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kyllerg�rd Magnus</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Petuch Hermann</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>10 : 3</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Vi�ums Kaspars</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Bucek Tomas</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Koski Jaakko</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=bl>�krlep Miha</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Nechutny Hynek</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kyllerg�rd Magnus</td><td class=bc>-</td><td class=blW>Zarinieks Kristaps</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Petuch Hermann</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Bucek Tomas</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Koski Jaakko</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>�krlep Miha</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Nechutny Hynek</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Vi�ums Kaspars</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kyllerg�rd Magnus</td><td class=bc>-</td><td class=blW>Bucek Tomas</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Koski Jaakko</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>�krlep Miha</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Nechutny Hynek</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Vi�ums Kaspars</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Bucek Tomas</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Koski Jaakko</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Kyllerg�rd Magnus</td><td class=bc>-</td><td class=blW>�krlep Miha</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Nechutny Hynek</td><td class=bc>-</td><td class=blW>Bucek Tomas</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Koski Jaakko</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=bl>�krlep Miha</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kyllerg�rd Magnus</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Romals Aigars</td><td class=bc>0 : 10</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Vi�ums Kaspars</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Bucek Tomas</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Koski Jaakko</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Nechutny Hynek</td><td class=bc>-</td><td class=bl>�krlep Miha</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kyllerg�rd Magnus</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Petuch Hermann</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Romals Aigars</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>Bucek Tomas</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Koski Jaakko</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>�krlep Miha</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Nechutny Hynek</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kyllerg�rd Magnus</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>10 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Bucek Tomas</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>Koski Jaakko</td><td class=bc>4 : 9</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>�krlep Miha</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Nechutny Hynek</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Kyllerg�rd Magnus</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Petuch Hermann</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=brW>Bucek Tomas</td><td class=bc>-</td><td class=bl>Koski Jaakko</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>�krlep Miha</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Nechutny Hynek</td><td class=bc>-</td><td class=blW>Romals Aigars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kyllerg�rd Magnus</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>Koski Jaakko</td><td class=bc>-</td><td class=bl>�krlep Miha</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Bucek Tomas</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Nechutny Hynek</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>3 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>�krlep Miha</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Koski Jaakko</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Bucek Tomas</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Nechutny Hynek</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Kyllerg�rd Magnus</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>�krlep Miha</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Koski Jaakko</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Bucek Tomas</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Nechutny Hynek</td><td class=bc>-</td><td class=blW>Kyllerg�rd Magnus</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>0 : 10</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 3.Division</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>97</td>
<td class=ic>98</td>
<td class=ic>99</td>
<td class=ic>100</td>
<td class=ic>101</td>
<td class=ic>102</td>
<td class=ic>103</td>
<td class=ic>104</td>
<td class=ic>105</td>
<td class=ic>106</td>
<td class=ic>107</td>
<td class=ic>108</td>
<td class=ic>109</td>
<td class=ic>110</td>
<td class=ic>111</td>
<td class=ic>112</td>
<td class=ic>113</td>
<td class=ic>114</td>
<td class=ic>115</td>
<td class=ic>116</td>
<td class=ic>117</td>
<td class=ic>118</td>
<td class=ic>119</td>
<td class=ic>120</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>97.</td><td class=kt>Il Pavlovskis</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>10:0</td>
<td class=br>77:32</td><td class=br>+45</td>
<td class=bc>19 - 1 - 3</td>
<td class=br><strong>39</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>98.</td><td class=kt>Kr Zem�ickis</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>6:0</td>
<td class=kL>1:4</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>8:3</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>10:0</td>
<td class=br>88:29</td><td class=br>+59</td>
<td class=bc>18 - 1 - 4</td>
<td class=br><strong>37</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>99.</td><td class=kt>Ka �iha�ova</td><td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>10:0</td>
<td class=br>74:39</td><td class=br>+35</td>
<td class=bc>16 - 3 - 4</td>
<td class=br><strong>35</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>100.</td><td class=kt>�i Vazoli��</td><td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kL>1:8</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>10:0</td>
<td class=br>69:52</td><td class=br>+17</td>
<td class=bc>14 - 4 - 5</td>
<td class=br><strong>32</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>101.</td><td class=kt>Ka Pirumshoieva</td><td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>7:3</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kW>10:0</td>
<td class=br>69:38</td><td class=br>+31</td>
<td class=bc>15 - 2 - 6</td>
<td class=br><strong>32</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>102.</td><td class=kt>Ei G�ze</td><td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kW>10:0</td>
<td class=br>72:45</td><td class=br>+27</td>
<td class=bc>13 - 4 - 6</td>
<td class=br><strong>30</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>103.</td><td class=kt>Jo Pleikys</td><td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>10:0</td>
<td class=br>59:32</td><td class=br>+27</td>
<td class=bc>13 - 3 - 7</td>
<td class=br><strong>29</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>104.</td><td class=kt>Al Pimenovs</td><td class=kL>0:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>10:0</td>
<td class=br>62:42</td><td class=br>+20</td>
<td class=bc>12 - 3 - 8</td>
<td class=br><strong>27</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>105.</td><td class=kt>Dm St�kailo</td><td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kT>6:6</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=kW>10:0</td>
<td class=br>76:49</td><td class=br>+27</td>
<td class=bc>12 - 2 - 9</td>
<td class=br><strong>26</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>106.</td><td class=kt>Ar Salmi��</td><td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kT>0:0</td>
<td class=kW>2:0</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>10:0</td>
<td class=br>53:40</td><td class=br>+13</td>
<td class=bc>9 - 8 - 6</td>
<td class=br><strong>26</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>107.</td><td class=kt>Gi Remeika</td><td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>10:0</td>
<td class=br>58:51</td><td class=br>+7</td>
<td class=bc>12 - 1 - 10</td>
<td class=br><strong>25</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>108.</td><td class=kt>D� Vesele</td><td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kW>8:1</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>10:0</td>
<td class=br>66:62</td><td class=br>+4</td>
<td class=bc>10 - 3 - 10</td>
<td class=br><strong>23</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>109.</td><td class=kt>Za �krlep</td><td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>10:0</td>
<td class=br>64:59</td><td class=br>+5</td>
<td class=bc>10 - 1 - 12</td>
<td class=br><strong>21</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>110.</td><td class=kt>J� Zem�ickis</td><td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kL>0:5</td>
<td class=kT>0:0</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>10:0</td>
<td class=br>43:44</td><td class=br>-1</td>
<td class=bc>8 - 5 - 10</td>
<td class=br><strong>21</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>111.</td><td class=kt>Kr Kurzemnieks</td><td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kW>6:3</td>
<td class=kT>0:0</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kW>5:0</td>
<td class=kW>10:0</td>
<td class=br>64:60</td><td class=br>+4</td>
<td class=bc>8 - 4 - 11</td>
<td class=br><strong>20</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>112.</td><td class=kt>Re Stac�vi�s</td><td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>0:6</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>10:3</td>
<td class=kW>10:0</td>
<td class=br>61:63</td><td class=br>-2</td>
<td class=bc>8 - 4 - 11</td>
<td class=br><strong>20</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>113.</td><td class=kt>Al Hermansson</td><td class=kL>0:3</td>
<td class=kL>3:8</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>10:0</td>
<td class=br>57:67</td><td class=br>-10</td>
<td class=bc>7 - 4 - 12</td>
<td class=br><strong>18</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>114.</td><td class=kt>Vo Kvasnikov</td><td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kW>10:0</td>
<td class=br>66:68</td><td class=br>-2</td>
<td class=bc>8 - 1 - 14</td>
<td class=br><strong>17</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>115.</td><td class=kt>El Reinfelds</td><td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kW>5:1</td>
<td class=kL>3:6</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kW>10:0</td>
<td class=br>65:70</td><td class=br>-5</td>
<td class=bc>7 - 3 - 13</td>
<td class=br><strong>17</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>116.</td><td class=kt>Ro Purmalis</td><td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kT>6:6</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>7:1</td>
<td class=kT>2:2</td>
<td class=kW>10:0</td>
<td class=br>56:63</td><td class=br>-7</td>
<td class=bc>6 - 4 - 13</td>
<td class=br><strong>16</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>117.</td><td class=kt>Ag Pav�rs</td><td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>3:7</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>10:0</td>
<td class=br>52:59</td><td class=br>-7</td>
<td class=bc>5 - 6 - 12</td>
<td class=br><strong>16</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>118.</td><td class=kt>Mo �krlep</td><td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>10:0</td>
<td class=br>47:71</td><td class=br>-24</td>
<td class=bc>6 - 1 - 16</td>
<td class=br><strong>13</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>119.</td><td class=kt>�v Vikmanis</td><td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>0:7</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>3:10</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>10:0</td>
<td class=br>37:70</td><td class=br>-33</td>
<td class=bc>4 - 4 - 15</td>
<td class=br><strong>12</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>120.</td><td class=kt>Do Zupan�i�</td><td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kx>*</td>
<td class=br>0:230</td><td class=br>-230</td>
<td class=bc>0 - 0 - 23</td>
<td class=br><strong>0</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>St�kailo Dmitri</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>�krlep Zala</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>Pimenovs Alekss</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Zem�ickis J�nis</td><td class=bc>-</td><td class=bl>�krlep Mojca</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Zupan�i� Domen</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>St�kailo Dmitri</td><td class=bc>-</td><td class=blW>Pleikys Jonas</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>�krlep Zala</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>1 : 3</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Pimenovs Alekss</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>�krlep Mojca</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Zupan�i� Domen</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=blW>Pleikys Jonas</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>�krlep Zala</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>St�kailo Dmitri</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>6 : 6</tr></td>
<tr><td class=brW>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Pimenovs Alekss</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>�krlep Mojca</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Zupan�i� Domen</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Zem�ickis J�nis</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>�krlep Zala</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>St�kailo Dmitri</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=blW>Pimenovs Alekss</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>�krlep Mojca</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Zupan�i� Domen</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>�krlep Zala</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pimenovs Alekss</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>St�kailo Dmitri</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=blW>�krlep Mojca</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Zupan�i� Domen</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>�krlep Zala</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Pimenovs Alekss</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=blW>Vikmanis �ve</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>�krlep Mojca</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>St�kailo Dmitri</td><td class=bc>-</td><td class=bl>Zupan�i� Domen</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Purmalis Roberts</td><td class=bc>-</td><td class=bl>Pimenovs Alekss</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>�krlep Zala</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>�krlep Mojca</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=bl>Zupan�i� Domen</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>St�kailo Dmitri</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Zem�ickis J�nis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Pimenovs Alekss</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Vikmanis �ve</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Purmalis Roberts</td><td class=bc>-</td><td class=bl>�krlep Mojca</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>�krlep Zala</td><td class=bc>-</td><td class=bl>Zupan�i� Domen</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>St�kailo Dmitri</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Pimenovs Alekss</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>�krlep Mojca</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Zupan�i� Domen</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>�krlep Zala</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Hermansson Alfons</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>St�kailo Dmitri</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>�krlep Mojca</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pimenovs Alekss</td><td class=bc>-</td><td class=bl>Zupan�i� Domen</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Purmalis Roberts</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>�krlep Zala</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>St�kailo Dmitri</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>�krlep Mojca</td><td class=bc>-</td><td class=bl>Zupan�i� Domen</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Pimenovs Alekss</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Hermansson Alfons</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Zem�ickis J�nis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>�krlep Zala</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>St�kailo Dmitri</td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Zupan�i� Domen</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>�krlep Mojca</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pimenovs Alekss</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Salmi�� Arnis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>�krlep Zala</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>St�kailo Dmitri</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Zupan�i� Domen</td><td class=bc>-</td><td class=blW>Hermansson Alfons</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>�krlep Mojca</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Zem�ickis J�nis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pimenovs Alekss</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>�krlep Zala</td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=blW>Pavlovskis Ilgvars</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Zupan�i� Domen</td><td class=bc>-</td><td class=blW>Zem�ickis J�nis</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>�krlep Mojca</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Salmi�� Arnis</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Pimenovs Alekss</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Purmalis Roberts</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>�krlep Zala</td><td class=bc>-</td><td class=blW>Pavlovskis Ilgvars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Pirumshoieva Karyna</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kvasnikov Volodymyr</td><td class=bc>-</td><td class=blW>St�kailo Dmitri</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Hermansson Alfons</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Zupan�i� Domen</td><td class=bc>-</td><td class=blW>Salmi�� Arnis</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>�krlep Mojca</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pimenovs Alekss</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Pavlovskis Ilgvars</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Pirumshoieva Karyna</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�krlep Zala</td><td class=bc>-</td><td class=blW>St�kailo Dmitri</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zupan�i� Domen</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>�krlep Mojca</td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Stac�vi�s Reinis</td><td class=bc>3 : 10</tr></td>
<tr><td class=br>Pimenovs Alekss</td><td class=bc>-</td><td class=blW>Pavlovskis Ilgvars</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Pirumshoieva Karyna</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>St�kailo Dmitri</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�krlep Zala</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Zem�ickis J�nis</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>Salmi�� Arnis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zupan�i� Domen</td><td class=bc>-</td><td class=blW>Stac�vi�s Reinis</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>�krlep Mojca</td><td class=bc>-</td><td class=blW>Pavlovskis Ilgvars</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Pirumshoieva Karyna</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Pimenovs Alekss</td><td class=bc>-</td><td class=bl>St�kailo Dmitri</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Kvasnikov Volodymyr</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Pleikys Jonas</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Salmi�� Arnis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Hermansson Alfons</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Pavlovskis Ilgvars</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Zupan�i� Domen</td><td class=bc>-</td><td class=blW>Pirumshoieva Karyna</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>�krlep Mojca</td><td class=bc>-</td><td class=blW>St�kailo Dmitri</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pimenovs Alekss</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Pleikys Jonas</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>�krlep Zala</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Salmi�� Arnis</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>Pavlovskis Ilgvars</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>St�kailo Dmitri</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Zupan�i� Domen</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�krlep Mojca</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pimenovs Alekss</td><td class=bc>-</td><td class=blW>�krlep Zala</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Salmi�� Arnis</td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Pavlovskis Ilgvars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>Pirumshoieva Karyna</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>St�kailo Dmitri</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Kvasnikov Volodymyr</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zupan�i� Domen</td><td class=bc>-</td><td class=blW>Pleikys Jonas</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>�krlep Mojca</td><td class=bc>-</td><td class=bl>�krlep Zala</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pimenovs Alekss</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Stac�vi�s Reinis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Pirumshoieva Karyna</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>St�kailo Dmitri</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Hermansson Alfons</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Pleikys Jonas</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>�krlep Zala</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Zupan�i� Domen</td><td class=bc>-</td><td class=blW>Purmalis Roberts</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>�krlep Mojca</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Pavlovskis Ilgvars</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Pirumshoieva Karyna</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>St�kailo Dmitri</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>Pleikys Jonas</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>�krlep Zala</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Zupan�i� Domen</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>�krlep Mojca</td><td class=bc>-</td><td class=blW>Pimenovs Alekss</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Pavlovskis Ilgvars</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>St�kailo Dmitri</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Pleikys Jonas</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>�krlep Zala</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Pimenovs Alekss</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zupan�i� Domen</td><td class=bc>-</td><td class=blW>Vikmanis �ve</td><td class=bc>0 : 10</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=blW>Pirumshoieva Karyna</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>St�kailo Dmitri</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Kvasnikov Volodymyr</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>�krlep Zala</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Purmalis Roberts</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>Pimenovs Alekss</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>�krlep Mojca</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=blW>St�kailo Dmitri</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Kvasnikov Volodymyr</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>�krlep Zala</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Salmi�� Arnis</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Zem�ickis J�nis</td><td class=bc>-</td><td class=bl>Pimenovs Alekss</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Hermansson Alfons</td><td class=bc>-</td><td class=bl>�krlep Mojca</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Zupan�i� Domen</td><td class=bc>10 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 4.Division</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>121</td>
<td class=ic>122</td>
<td class=ic>123</td>
<td class=ic>124</td>
<td class=ic>125</td>
<td class=ic>126</td>
<td class=ic>127</td>
<td class=ic>128</td>
<td class=ic>129</td>
<td class=ic>130</td>
<td class=ic>131</td>
<td class=ic>132</td>
<td class=ic>133</td>
<td class=ic>134</td>
<td class=ic>135</td>
<td class=ic>136</td>
<td class=ic>137</td>
<td class=ic>138</td>
<td class=ic>139</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>121.</td><td class=kt>Ig Zamiatin</td><td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kL>1:7</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>8:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>7:1</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>10:0</td>
<td class=kW>10:0</td>
<td class=br>71:26</td><td class=br>+45</td>
<td class=bc>13 - 3 - 2</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>122.</td><td class=kt>Ja Hansson</td><td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>10:0</td>
<td class=kW>10:0</td>
<td class=br>65:21</td><td class=br>+44</td>
<td class=bc>14 - 1 - 3</td>
<td class=br><strong>29</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>123.</td><td class=kt>As Kocere</td><td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kL>0:1</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>10:0</td>
<td class=kW>10:0</td>
<td class=br>64:20</td><td class=br>+44</td>
<td class=bc>13 - 2 - 3</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>124.</td><td class=kt>Er Kalni��</td><td class=kW>7:1</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kL>1:4</td>
<td class=kW>10:0</td>
<td class=kW>10:0</td>
<td class=br>67:30</td><td class=br>+37</td>
<td class=bc>10 - 4 - 4</td>
<td class=br><strong>24</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>125.</td><td class=kt>Re Saul�tis</td><td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kL>0:1</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>7:3</td>
<td class=kW>4:1</td>
<td class=kW>10:0</td>
<td class=kW>10:0</td>
<td class=br>58:29</td><td class=br>+29</td>
<td class=bc>11 - 2 - 5</td>
<td class=br><strong>24</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>126.</td><td class=kt>Ro Aseri��</td><td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kT>0:0</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>10:0</td>
<td class=kW>10:0</td>
<td class=br>60:28</td><td class=br>+32</td>
<td class=bc>10 - 2 - 6</td>
<td class=br><strong>22</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>127.</td><td class=kt>Ra St�lmanis</td><td class=kL>1:8</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kL>0:3</td>
<td class=kW>2:0</td>
<td class=kW>10:0</td>
<td class=kW>10:0</td>
<td class=br>51:35</td><td class=br>+16</td>
<td class=bc>10 - 1 - 7</td>
<td class=br><strong>21</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>128.</td><td class=kt>M� �irsis</td><td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>10:0</td>
<td class=kW>10:0</td>
<td class=br>55:29</td><td class=br>+26</td>
<td class=bc>8 - 5 - 5</td>
<td class=br><strong>21</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>129.</td><td class=kt>Da Belkovs</td><td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>10:0</td>
<td class=kW>10:0</td>
<td class=br>64:41</td><td class=br>+23</td>
<td class=bc>8 - 5 - 5</td>
<td class=br><strong>21</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>130.</td><td class=kt>Ma Kalni��</td><td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kW>10:0</td>
<td class=kW>10:0</td>
<td class=br>48:21</td><td class=br>+27</td>
<td class=bc>8 - 5 - 5</td>
<td class=br><strong>21</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>131.</td><td class=kt>Em Ka�s</td><td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>10:0</td>
<td class=kW>10:0</td>
<td class=br>57:40</td><td class=br>+17</td>
<td class=bc>8 - 4 - 6</td>
<td class=br><strong>20</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>132.</td><td class=kt>Ma P�tersons</td><td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=kW>10:0</td>
<td class=kW>10:0</td>
<td class=br>49:36</td><td class=br>+13</td>
<td class=bc>7 - 2 - 9</td>
<td class=br><strong>16</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>133.</td><td class=kt>An �krlep</td><td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>10:0</td>
<td class=kW>10:0</td>
<td class=br>48:38</td><td class=br>+10</td>
<td class=bc>6 - 4 - 8</td>
<td class=br><strong>16</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>134.</td><td class=kt>M� Timbers</td><td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>0:1</td>
<td class=kW>10:0</td>
<td class=kW>10:0</td>
<td class=br>42:44</td><td class=br>-2</td>
<td class=bc>6 - 2 - 10</td>
<td class=br><strong>14</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>135.</td><td class=kt>To Ulis</td><td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>4:0</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>10:0</td>
<td class=kW>10:0</td>
<td class=br>48:41</td><td class=br>+7</td>
<td class=bc>5 - 4 - 9</td>
<td class=br><strong>14</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>136.</td><td class=kt>Kr Rudz�tis</td><td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>2:7</td>
<td class=kL>3:7</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>10:0</td>
<td class=kW>10:0</td>
<td class=br>49:63</td><td class=br>-14</td>
<td class=bc>4 - 3 - 11</td>
<td class=br><strong>11</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>137.</td><td class=kt>Em Vi��akovs</td><td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>10:0</td>
<td class=kW>10:0</td>
<td class=br>31:45</td><td class=br>-14</td>
<td class=bc>4 - 1 - 13</td>
<td class=br><strong>9</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>138.</td><td class=kt>Va Mirojevskis</td><td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=br>0:170</td><td class=br>-170</td>
<td class=bc>0 - 0 - 17</td>
<td class=br><strong>0</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>139.</td><td class=kt>Dm Kolbass</td><td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=br>0:170</td><td class=br>-170</td>
<td class=bc>0 - 0 - 17</td>
<td class=br><strong>0</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ulis Tomas</td><td class=bc>-</td><td class=bl>Kolbass Dmitrijs</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>Vi��akovs Em�ls</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Zamiatin Igor</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=blW>�krlep Ana ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Mirojevskis Vadims</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Hansson Jan-Olof</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Timbers M�rti��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>P�tersons Marks</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Kolbass Dmitrijs</td><td class=bc>-</td><td class=blW>Rudz�tis Kristaps</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=bl>Vi��akovs Em�ls</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>�krlep Ana ml.</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Zamiatin Igor</td><td class=bc>-</td><td class=bl>Mirojevskis Vadims</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Hansson Jan-Olof</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Vi��akovs Em�ls</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Kolbass Dmitrijs</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>�krlep Ana ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Mirojevskis Vadims</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Hansson Jan-Olof</td><td class=bc>-</td><td class=bl>P�tersons Marks</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Vi��akovs Em�ls</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>�krlep Ana ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kolbass Dmitrijs</td><td class=bc>-</td><td class=bl>Mirojevskis Vadims</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>P�tersons Marks</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>�krlep Ana ml.</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Vi��akovs Em�ls</td><td class=bc>-</td><td class=bl>Mirojevskis Vadims</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kolbass Dmitrijs</td><td class=bc>-</td><td class=blW>Timbers M�rti��</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>P�tersons Marks</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Zamiatin Igor</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=blW>Hansson Jan-Olof</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>�krlep Ana ml.</td><td class=bc>-</td><td class=bl>Mirojevskis Vadims</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vi��akovs Em�ls</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kolbass Dmitrijs</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ulis Tomas</td><td class=bc>-</td><td class=bl>P�tersons Marks</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Hansson Jan-Olof</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Mirojevskis Vadims</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>�krlep Ana ml.</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vi��akovs Em�ls</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>P�tersons Marks</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Kolbass Dmitrijs</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Hansson Jan-Olof</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mirojevskis Vadims</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>�krlep Ana ml.</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>P�tersons Marks</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vi��akovs Em�ls</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Hansson Jan-Olof</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kolbass Dmitrijs</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mirojevskis Vadims</td><td class=bc>-</td><td class=blW>P�tersons Marks</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>�krlep Ana ml.</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Hansson Jan-Olof</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Vi��akovs Em�ls</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kolbass Dmitrijs</td><td class=bc>-</td><td class=blW>Zamiatin Igor</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Aseri�� Roberts</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Timbers M�rti��</td><td class=bc>-</td><td class=bl>P�tersons Marks</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mirojevskis Vadims</td><td class=bc>-</td><td class=blW>Hansson Jan-Olof</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>�krlep Ana ml.</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vi��akovs Em�ls</td><td class=bc>-</td><td class=blW>Zamiatin Igor</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Aseri�� Roberts</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kolbass Dmitrijs</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>0 : 10</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>P�tersons Marks</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Hansson Jan-Olof</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mirojevskis Vadims</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>�krlep Ana ml.</td><td class=bc>-</td><td class=blW>Zamiatin Igor</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vi��akovs Em�ls</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>P�tersons Marks</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Hansson Jan-Olof</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=blW>Zamiatin Igor</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mirojevskis Vadims</td><td class=bc>-</td><td class=blW>Aseri�� Roberts</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>�krlep Ana ml.</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Ulis Tomas</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Vi��akovs Em�ls</td><td class=bc>-</td><td class=bl>Kolbass Dmitrijs</td><td class=bc>10 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Hansson Jan-Olof</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>P�tersons Marks</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Zamiatin Igor</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Aseri�� Roberts</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mirojevskis Vadims</td><td class=bc>-</td><td class=blW>Ulis Tomas</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>�krlep Ana ml.</td><td class=bc>-</td><td class=bl>Kolbass Dmitrijs</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Hansson Jan-Olof</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>P�tersons Marks</td><td class=bc>-</td><td class=blW>Zamiatin Igor</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Kolbass Dmitrijs</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Mirojevskis Vadims</td><td class=bc>-</td><td class=blW>Rudz�tis Kristaps</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>�krlep Ana ml.</td><td class=bc>-</td><td class=bl>Vi��akovs Em�ls</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hansson Jan-Olof</td><td class=bc>-</td><td class=blW>Zamiatin Igor</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>P�tersons Marks</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Ulis Tomas</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Kolbass Dmitrijs</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Vi��akovs Em�ls</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Mirojevskis Vadims</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>0 : 10</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=blW>Zamiatin Igor</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Aseri�� Roberts</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Hansson Jan-Olof</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>P�tersons Marks</td><td class=bc>-</td><td class=bl>Kolbass Dmitrijs</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Vi��akovs Em�ls</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>�krlep Ana ml.</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Zamiatin Igor</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Hansson Jan-Olof</td><td class=bc>-</td><td class=bl>Kolbass Dmitrijs</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Rudz�tis Kristaps</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>P�tersons Marks</td><td class=bc>-</td><td class=bl>Vi��akovs Em�ls</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>�krlep Ana ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Mirojevskis Vadims</td><td class=bc>10 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Kolbass Dmitrijs</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Hansson Jan-Olof</td><td class=bc>-</td><td class=bl>Vi��akovs Em�ls</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>P�tersons Marks</td><td class=bc>-</td><td class=bl>�krlep Ana ml.</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Mirojevskis Vadims</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>Kolbass Dmitrijs</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Zamiatin Igor</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Vi��akovs Em�ls</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Hansson Jan-Olof</td><td class=bc>-</td><td class=bl>�krlep Ana ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Mirojevskis Vadims</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>P�tersons Marks</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>3 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
