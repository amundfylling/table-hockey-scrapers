<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>ECh 2024 Challenge</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="ECh_2024_Challenge_list.php">ECh 2024 Challenge</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group A2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=44&x=-53&p=Kr%20Naglis">Kr Naglis</a></td><td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=br>39:22</td><td class=br>+17</td>
<td class=bc>8 - 2 - 1</td>
<td class=br><strong>18</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=70&x=-53&p=An%20Kuz%C5%86ecovs">An Kuz�ecovs</a></td><td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kT>5:5</td>
<td class=kW>5:4</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=br>37:24</td><td class=br>+13</td>
<td class=bc>8 - 2 - 1</td>
<td class=br><strong>18</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=123&x=-53&p=Lu%20Jurka">Lu Jurka</a></td><td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=br>36:21</td><td class=br>+15</td>
<td class=bc>7 - 2 - 2</td>
<td class=br><strong>16</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=163&x=-53&p=Zy%20Remeika">Zy Remeika</a></td><td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>9:1</td>
<td class=kW>3:0</td>
<td class=br>38:21</td><td class=br>+17</td>
<td class=bc>6 - 2 - 3</td>
<td class=br><strong>14</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=186&x=-53&p=R%C5%AB%20Kamzols">R� Kamzols</a></td><td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=br>31:26</td><td class=br>+5</td>
<td class=bc>6 - 1 - 4</td>
<td class=br><strong>13</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=97&x=-53&p=Gi%20Lasmanis">Gi Lasmanis</a></td><td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=br>29:25</td><td class=br>+4</td>
<td class=bc>5 - 3 - 3</td>
<td class=br><strong>13</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=69&x=-53&p=Ro%20Fa%C4%BCken%C5%A1teins">Ro Fa�ken�teins</a></td><td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=br>31:31</td><td class=br>0</td>
<td class=bc>4 - 3 - 4</td>
<td class=br><strong>11</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=31&x=-53&p=Ni%20L%C4%81cis">Ni L�cis</a></td><td class=kL>2:3</td>
<td class=kT>5:5</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=br>28:36</td><td class=br>-8</td>
<td class=bc>4 - 1 - 6</td>
<td class=br><strong>9</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=201&x=-53&p=El%20R%C4%81cen%C4%81ja">El R�cen�ja</a></td><td class=kL>0:5</td>
<td class=kL>4:5</td>
<td class=kL>4:5</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=br>32:37</td><td class=br>-5</td>
<td class=bc>4 - 0 - 7</td>
<td class=br><strong>8</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=427&x=-53&p=Ja%20Forsberg">Ja Forsberg</a></td><td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=br>27:42</td><td class=br>-15</td>
<td class=bc>2 - 3 - 6</td>
<td class=br><strong>7</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=79&x=-53&p=Mi%20Saul%C4%ABtis">Mi Saul�tis</a></td><td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>1:9</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kW>5:2</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=br>23:46</td><td class=br>-23</td>
<td class=bc>1 - 1 - 9</td>
<td class=br><strong>3</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=374&x=-53&p=Dm%20Kudrytsky">Dm Kudrytsky</a></td><td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=br>16:36</td><td class=br>-20</td>
<td class=bc>1 - 0 - 10</td>
<td class=br><strong>2</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Kudrytsky Dmytro</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=blW>L�cis Niks</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Kudrytsky Dmytro</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>L�cis Niks</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kudrytsky Dmytro</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>L�cis Niks</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Kudrytsky Dmytro</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>L�cis Niks</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Kudrytsky Dmytro</td><td class=bc>-</td><td class=blW>L�cis Niks</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>L�cis Niks</td><td class=bc>-</td><td class=blW>Forsberg James-John</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kudrytsky Dmytro</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>L�cis Niks</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kudrytsky Dmytro</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>L�cis Niks</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kudrytsky Dmytro</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Jurka Lukass</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>L�cis Niks</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kudrytsky Dmytro</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Jurka Lukass</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>L�cis Niks</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kudrytsky Dmytro</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>L�cis Niks</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Kudrytsky Dmytro</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Jurka Lukass</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Kudrytsky Dmytro</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>L�cis Niks</td><td class=bc>5 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
