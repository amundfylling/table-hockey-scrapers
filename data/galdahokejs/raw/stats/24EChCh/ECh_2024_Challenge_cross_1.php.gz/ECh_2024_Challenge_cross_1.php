<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>ECh 2024 Challenge</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="ECh_2024_Challenge_list.php">ECh 2024 Challenge</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=39&x=-53&p=Kr%20Rieksti%C5%86%C5%A1">Kr Rieksti��</a></td><td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=br>32:8</td><td class=br>+24</td>
<td class=bc>7 - 1 - 0</td>
<td class=br><strong>15</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=235&x=-53&p=An%20Fjermestad">An Fjermestad</a></td><td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=br>32:17</td><td class=br>+15</td>
<td class=bc>6 - 0 - 2</td>
<td class=br><strong>12</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=133&x=-53&p=Au%20Pleikys">Au Pleikys</a></td><td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>1:6</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=br>27:20</td><td class=br>+7</td>
<td class=bc>5 - 1 - 2</td>
<td class=br><strong>11</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=11&x=-53&p=Ed%20Putni%C5%86%C5%A1">Ed Putni��</a></td><td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kW>6:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kT>2:2</td>
<td class=br>32:18</td><td class=br>+14</td>
<td class=bc>4 - 2 - 2</td>
<td class=br><strong>10</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=45&x=-53&p=Al%20Skudr%C4%ABtis">Al Skudr�tis</a></td><td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=br>18:18</td><td class=br>0</td>
<td class=bc>4 - 2 - 2</td>
<td class=br><strong>10</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=77&x=-53&p=Ei%20G%C5%ABze">Ei G�ze</a></td><td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=br>14:24</td><td class=br>-10</td>
<td class=bc>2 - 2 - 4</td>
<td class=br><strong>6</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>C</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=71&x=-53&p=Da%20Baumanis">Da Baumanis</a></td><td class=kL>0:6</td>
<td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=br>13:25</td><td class=br>-12</td>
<td class=bc>2 - 0 - 6</td>
<td class=br><strong>4</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>C</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=159&x=-53&p=Re%20Saul%C4%ABtis">Re Saul�tis</a></td><td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>7:31</td><td class=br>-24</td>
<td class=bc>1 - 0 - 7</td>
<td class=br><strong>2</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>D</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=220&x=-53&p=Jo%20Pleikys">Jo Pleikys</a></td><td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>4:18</td><td class=br>-14</td>
<td class=bc>0 - 2 - 6</td>
<td class=br><strong>2</strong></td><td class=d>9.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Putni�� Edgars</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Putni�� Edgars</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Putni�� Edgars</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Fjermestad Andreas</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Fjermestad Andreas</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=blW>Fjermestad Andreas</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Fjermestad Andreas</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>1 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
