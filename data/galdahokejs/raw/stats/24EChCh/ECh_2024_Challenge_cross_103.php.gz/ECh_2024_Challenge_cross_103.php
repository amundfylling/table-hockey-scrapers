<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>ECh 2024 Challenge</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="ECh_2024_Challenge_list.php">ECh 2024 Challenge</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=122&x=-53&p=Vi%20Henttonen">Vi Henttonen</a></td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>9:1</td>
<td class=kW>7:0</td>
<td class=br>44:16</td><td class=br>+28</td>
<td class=bc>10 - 1 - 0</td>
<td class=br><strong>21</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=45&x=-53&p=Al%20Skudr%C4%ABtis">Al Skudr�tis</a></td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>10:3</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>5:4</td>
<td class=kW>5:1</td>
<td class=kW>7:5</td>
<td class=kW>3:1</td>
<td class=br>50:29</td><td class=br>+21</td>
<td class=bc>9 - 0 - 2</td>
<td class=br><strong>18</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=77&x=-53&p=Ei%20G%C5%ABze">Ei G�ze</a></td><td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=br>30:22</td><td class=br>+8</td>
<td class=bc>8 - 0 - 3</td>
<td class=br><strong>16</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=124&x=-53&p=Ne%20Skrlep">Ne Skrlep</a></td><td class=kL>2:4</td>
<td class=kL>3:10</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kL>4:7</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=br>41:33</td><td class=br>+8</td>
<td class=bc>7 - 1 - 3</td>
<td class=br><strong>15</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=47&x=-53&p=To%20Jakseboga">To Jakseboga</a></td><td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>3:6</td>
<td class=kL>0:2</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=br>27:26</td><td class=br>+1</td>
<td class=bc>5 - 2 - 4</td>
<td class=br><strong>12</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=367&x=-53&p=Ol%20Pylypenko">Ol Pylypenko</a></td><td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=br>32:33</td><td class=br>-1</td>
<td class=bc>5 - 1 - 5</td>
<td class=br><strong>11</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=72&x=-53&p=Fr%20Platons">Fr Platons</a></td><td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=br>25:25</td><td class=br>0</td>
<td class=bc>4 - 1 - 6</td>
<td class=br><strong>9</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=18&x=-53&p=Kr%20Zarinieks">Kr Zarinieks</a></td><td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>7:4</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=br>31:40</td><td class=br>-9</td>
<td class=bc>3 - 1 - 7</td>
<td class=br><strong>7</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=90&x=-53&p=Em%20Reinfelds">Em Reinfelds</a></td><td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kW>6:3</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>4:6</td>
<td class=kT>2:2</td>
<td class=br>30:38</td><td class=br>-8</td>
<td class=bc>3 - 1 - 7</td>
<td class=br><strong>7</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=144&x=-53&p=Il%20Pavlovskis">Il Pavlovskis</a></td><td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kL>4:5</td>
<td class=kL>0:1</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=br>22:31</td><td class=br>-9</td>
<td class=bc>2 - 2 - 7</td>
<td class=br><strong>6</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=426&x=-53&p=Wi%20Wallin">Wi Wallin</a></td><td class=kL>1:9</td>
<td class=kL>5:7</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>6:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=br>27:42</td><td class=br>-15</td>
<td class=bc>2 - 2 - 7</td>
<td class=br><strong>6</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=253&x=-53&p=Ra%20St%C4%81lmanis">Ra St�lmanis</a></td><td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=br>15:39</td><td class=br>-24</td>
<td class=bc>1 - 2 - 8</td>
<td class=br><strong>4</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Skrlep Nejc</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Reinfelds Em�ls Matiass</td><td class=bc>-</td><td class=blW>Pylypenko Oleksandr</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=blW>Pylypenko Oleksandr</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>10 : 3</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=blW>Reinfelds Em�ls Matiass</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Reinfelds Em�ls Matiass</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=blW>Skrlep Nejc</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Pylypenko Oleksandr</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Reinfelds Em�ls Matiass</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Skrlep Nejc</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Reinfelds Em�ls Matiass</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Skrlep Nejc</td><td class=bc>-</td><td class=bl>Reinfelds Em�ls Matiass</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Reinfelds Em�ls Matiass</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Skrlep Nejc</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Reinfelds Em�ls Matiass</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Skrlep Nejc</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>5 : 7</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Reinfelds Em�ls Matiass</td><td class=bc>-</td><td class=blW>Zarinieks Kristaps</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Skrlep Nejc</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Reinfelds Em�ls Matiass</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Skrlep Nejc</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Reinfelds Em�ls Matiass</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Reinfelds Em�ls Matiass</td><td class=bc>-</td><td class=blW>Wallin Wilton</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Skrlep Nejc</td><td class=bc>1 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
