<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>ECh 2024 Challenge</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="ECh_2024_Challenge_list.php">ECh 2024 Challenge</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group A1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=39&x=-53&p=Kr%20Rieksti%C5%86%C5%A1">Kr Rieksti��</a></td><td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=br>44:24</td><td class=br>+20</td>
<td class=bc>8 - 3 - 0</td>
<td class=br><strong>19</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=34&x=-53&p=J%C4%93%20Re%C4%B7is">J� Re�is</a></td><td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>8:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=br>35:22</td><td class=br>+13</td>
<td class=bc>6 - 3 - 2</td>
<td class=br><strong>15</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=30&x=-53&p=Ma%20Jakseboga">Ma Jakseboga</a></td><td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=br>40:30</td><td class=br>+10</td>
<td class=bc>6 - 3 - 2</td>
<td class=br><strong>15</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=235&x=-53&p=An%20Fjermestad">An Fjermestad</a></td><td class=kL>1:5</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>4:6</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=br>37:28</td><td class=br>+9</td>
<td class=bc>7 - 0 - 4</td>
<td class=br><strong>14</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=36&x=-53&p=Ro%20Verbi%C4%8Ds">Ro Verbi�s</a></td><td class=kT>4:4</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>8:1</td>
<td class=kW>7:0</td>
<td class=br>43:27</td><td class=br>+16</td>
<td class=bc>6 - 2 - 3</td>
<td class=br><strong>14</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=11&x=-53&p=Ed%20Putni%C5%86%C5%A1">Ed Putni��</a></td><td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>6:4</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kW>5:1</td>
<td class=br>36:37</td><td class=br>-1</td>
<td class=bc>5 - 1 - 5</td>
<td class=br><strong>11</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=25&x=-53&p=J%C4%81%20Bitmanis">J� Bitmanis</a></td><td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=br>25:32</td><td class=br>-7</td>
<td class=bc>4 - 2 - 5</td>
<td class=br><strong>10</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=121&x=-53&p=Gu%20Hermansson">Gu Hermansson</a></td><td class=kL>3:6</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=br>30:35</td><td class=br>-5</td>
<td class=bc>3 - 3 - 5</td>
<td class=br><strong>9</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=202&x=-53&p=Vl%20Voronov">Vl Voronov</a></td><td class=kL>1:2</td>
<td class=kL>2:8</td>
<td class=kL>3:4</td>
<td class=kL>0:6</td>
<td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kW>1:0</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=br>25:39</td><td class=br>-14</td>
<td class=bc>4 - 0 - 7</td>
<td class=br><strong>8</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=133&x=-53&p=Au%20Pleikys">Au Pleikys</a></td><td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=br>29:33</td><td class=br>-4</td>
<td class=bc>3 - 2 - 6</td>
<td class=br><strong>8</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=114&x=-53&p=An%20Bo%C5%BEi%C4%8D">An Bo�i�</a></td><td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>1:8</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>27:36</td><td class=br>-9</td>
<td class=bc>3 - 1 - 7</td>
<td class=br><strong>7</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=162&x=-53&p=Gi%20Remeika">Gi Remeika</a></td><td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>17:45</td><td class=br>-28</td>
<td class=bc>1 - 0 - 10</td>
<td class=br><strong>2</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=blW>Putni�� Edgars</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Putni�� Edgars</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Fjermestad Andreas</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Fjermestad Andreas</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Fjermestad Andreas</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Fjermestad Andreas</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>Bitmanis J�nis Mi�elis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Fjermestad Andreas</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Fjermestad Andreas</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Rieksti�� Kristaps</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
