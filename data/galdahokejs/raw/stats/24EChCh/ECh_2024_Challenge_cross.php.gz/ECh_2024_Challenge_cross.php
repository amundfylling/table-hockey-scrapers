<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>ECh 2024 Challenge</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="ECh_2024_Challenge_list.php">ECh 2024 Challenge, 13. j�nijs 2024</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=39&x=-53&p=Kr%20Rieksti%C5%86%C5%A1">Kr Rieksti��</a></td><td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=br>32:8</td><td class=br>+24</td>
<td class=bc>7 - 1 - 0</td>
<td class=br><strong>15</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=235&x=-53&p=An%20Fjermestad">An Fjermestad</a></td><td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=br>32:17</td><td class=br>+15</td>
<td class=bc>6 - 0 - 2</td>
<td class=br><strong>12</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=133&x=-53&p=Au%20Pleikys">Au Pleikys</a></td><td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>1:6</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=br>27:20</td><td class=br>+7</td>
<td class=bc>5 - 1 - 2</td>
<td class=br><strong>11</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=11&x=-53&p=Ed%20Putni%C5%86%C5%A1">Ed Putni��</a></td><td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kW>6:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kT>2:2</td>
<td class=br>32:18</td><td class=br>+14</td>
<td class=bc>4 - 2 - 2</td>
<td class=br><strong>10</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=45&x=-53&p=Al%20Skudr%C4%ABtis">Al Skudr�tis</a></td><td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=br>18:18</td><td class=br>0</td>
<td class=bc>4 - 2 - 2</td>
<td class=br><strong>10</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=77&x=-53&p=Ei%20G%C5%ABze">Ei G�ze</a></td><td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=br>14:24</td><td class=br>-10</td>
<td class=bc>2 - 2 - 4</td>
<td class=br><strong>6</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>C</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=71&x=-53&p=Da%20Baumanis">Da Baumanis</a></td><td class=kL>0:6</td>
<td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=br>13:25</td><td class=br>-12</td>
<td class=bc>2 - 0 - 6</td>
<td class=br><strong>4</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>C</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=159&x=-53&p=Re%20Saul%C4%ABtis">Re Saul�tis</a></td><td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>7:31</td><td class=br>-24</td>
<td class=bc>1 - 0 - 7</td>
<td class=br><strong>2</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>D</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=220&x=-53&p=Jo%20Pleikys">Jo Pleikys</a></td><td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>4:18</td><td class=br>-14</td>
<td class=bc>0 - 2 - 6</td>
<td class=br><strong>2</strong></td><td class=d>9.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Putni�� Edgars</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Putni�� Edgars</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Putni�� Edgars</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Fjermestad Andreas</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Fjermestad Andreas</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=blW>Fjermestad Andreas</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Fjermestad Andreas</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>1 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=186&x=-53&p=R%C5%AB%20Kamzols">R� Kamzols</a></td><td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>9:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=br>39:15</td><td class=br>+24</td>
<td class=bc>6 - 2 - 0</td>
<td class=br><strong>14</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=69&x=-53&p=Ro%20Fa%C4%BCken%C5%A1teins">Ro Fa�ken�teins</a></td><td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=br>20:10</td><td class=br>+10</td>
<td class=bc>6 - 1 - 1</td>
<td class=br><strong>13</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=70&x=-53&p=An%20Kuz%C5%86ecovs">An Kuz�ecovs</a></td><td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=kW>8:2</td>
<td class=kW>7:2</td>
<td class=br>38:21</td><td class=br>+17</td>
<td class=bc>5 - 1 - 2</td>
<td class=br><strong>11</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=374&x=-53&p=Dm%20Kudrytsky">Dm Kudrytsky</a></td><td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=br>18:20</td><td class=br>-2</td>
<td class=bc>4 - 1 - 3</td>
<td class=br><strong>9</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=122&x=-53&p=Vi%20Henttonen">Vi Henttonen</a></td><td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=br>19:20</td><td class=br>-1</td>
<td class=bc>4 - 0 - 4</td>
<td class=br><strong>8</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=367&x=-53&p=Ol%20Pylypenko">Ol Pylypenko</a></td><td class=kL>2:9</td>
<td class=kL>1:3</td>
<td class=kL>1:7</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=br>17:30</td><td class=br>-13</td>
<td class=bc>3 - 0 - 5</td>
<td class=br><strong>6</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>C</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=424&x=-53&p=La%20Ulfvensj%C3%B6">La Ulfvensj�</a></td><td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kT>0:0</td>
<td class=br>17:24</td><td class=br>-7</td>
<td class=bc>1 - 3 - 4</td>
<td class=br><strong>5</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>C</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=197&x=-53&p=%C5%AAv%20Vikmanis">�v Vikmanis</a></td><td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>2:8</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>12:27</td><td class=br>-15</td>
<td class=bc>1 - 1 - 6</td>
<td class=br><strong>3</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>D</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=429&x=-53&p=Ro%20Forsberg">Ro Forsberg</a></td><td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kW>1:0</td>
<td class=kT>0:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>7:20</td><td class=br>-13</td>
<td class=bc>1 - 1 - 6</td>
<td class=br><strong>3</strong></td><td class=d>9.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Forsberg Robert</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Ulfvensj� Lars</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Forsberg Robert</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Kudrytsky Dmytro</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ulfvensj� Lars</td><td class=bc>-</td><td class=blW>Pylypenko Oleksandr</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Kudrytsky Dmytro</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Forsberg Robert</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ulfvensj� Lars</td><td class=bc>-</td><td class=bl>Kudrytsky Dmytro</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Kudrytsky Dmytro</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Ulfvensj� Lars</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Forsberg Robert</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Kudrytsky Dmytro</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>Forsberg Robert</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ulfvensj� Lars</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Kudrytsky Dmytro</td><td class=bc>-</td><td class=bl>Forsberg Robert</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Forsberg Robert</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kudrytsky Dmytro</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Forsberg Robert</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kudrytsky Dmytro</td><td class=bc>-</td><td class=blW>Pylypenko Oleksandr</td><td class=bc>3 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=121&x=-53&p=Gu%20Hermansson">Gu Hermansson</a></td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>8:4</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=br>32:16</td><td class=br>+16</td>
<td class=bc>5 - 2 - 1</td>
<td class=br><strong>12</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=25&x=-53&p=J%C4%81%20Bitmanis">J� Bitmanis</a></td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=br>21:13</td><td class=br>+8</td>
<td class=bc>5 - 2 - 1</td>
<td class=br><strong>12</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=30&x=-53&p=Ma%20Jakseboga">Ma Jakseboga</a></td><td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>32:16</td><td class=br>+16</td>
<td class=bc>5 - 1 - 2</td>
<td class=br><strong>11</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=162&x=-53&p=Gi%20Remeika">Gi Remeika</a></td><td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>7:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=br>24:20</td><td class=br>+4</td>
<td class=bc>3 - 3 - 2</td>
<td class=br><strong>9</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=18&x=-53&p=Kr%20Zarinieks">Kr Zarinieks</a></td><td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>2:7</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=br>26:27</td><td class=br>-1</td>
<td class=bc>2 - 5 - 1</td>
<td class=br><strong>9</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=124&x=-53&p=Ne%20Skrlep">Ne Skrlep</a></td><td class=kL>4:8</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=br>24:29</td><td class=br>-5</td>
<td class=bc>3 - 1 - 4</td>
<td class=br><strong>7</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>C</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=75&x=-53&p=L%C4%81%20Bezdel%C4%ABga">L� Bezdel�ga</a></td><td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=br>15:24</td><td class=br>-9</td>
<td class=bc>1 - 3 - 4</td>
<td class=br><strong>5</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>C</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=418&x=-53&p=Al%20Hermansson">Al Hermansson</a></td><td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>16:25</td><td class=br>-9</td>
<td class=bc>2 - 0 - 6</td>
<td class=br><strong>4</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>D</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=93&x=-53&p=Kr%20G%C5%ABtmanis">Kr G�tmanis</a></td><td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>10:30</td><td class=br>-20</td>
<td class=bc>1 - 1 - 6</td>
<td class=br><strong>3</strong></td><td class=d>9.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>G�tmanis Kristers</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>G�tmanis Kristers</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Skrlep Nejc</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Skrlep Nejc</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>4 : 8</tr></td>
<tr><td class=brW>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>G�tmanis Kristers</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Skrlep Nejc</td><td class=bc>-</td><td class=bl>G�tmanis Kristers</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>G�tmanis Kristers</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Skrlep Nejc</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Hermansson Alfons</td><td class=bc>-</td><td class=bl>G�tmanis Kristers</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>G�tmanis Kristers</td><td class=bc>-</td><td class=blW>Bitmanis J�nis Mi�elis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>G�tmanis Kristers</td><td class=bc>-</td><td class=blW>Zarinieks Kristaps</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Hermansson Alfons</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>3 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 4</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=163&x=-53&p=Zy%20Remeika">Zy Remeika</a></td><td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>8:1</td>
<td class=kW>6:1</td>
<td class=kW>12:0</td>
<td class=br>41:8</td><td class=br>+33</td>
<td class=bc>9 - 0 - 0</td>
<td class=br><strong>18</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=123&x=-53&p=Lu%20Jurka">Lu Jurka</a></td><td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=br>31:8</td><td class=br>+23</td>
<td class=bc>7 - 1 - 1</td>
<td class=br><strong>15</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=427&x=-53&p=Ja%20Forsberg">Ja Forsberg</a></td><td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>6:5</td>
<td class=kW>7:0</td>
<td class=kW>3:2</td>
<td class=kW>8:0</td>
<td class=kW>5:2</td>
<td class=br>37:16</td><td class=br>+21</td>
<td class=bc>6 - 1 - 2</td>
<td class=br><strong>13</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=79&x=-53&p=Mi%20Saul%C4%ABtis">Mi Saul�tis</a></td><td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>8:1</td>
<td class=br>34:20</td><td class=br>+14</td>
<td class=bc>5 - 2 - 2</td>
<td class=br><strong>12</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=144&x=-53&p=Il%20Pavlovskis">Il Pavlovskis</a></td><td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>20:19</td><td class=br>+1</td>
<td class=bc>4 - 1 - 4</td>
<td class=br><strong>9</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=426&x=-53&p=Wi%20Wallin">Wi Wallin</a></td><td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>5:6</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>9:0</td>
<td class=br>36:25</td><td class=br>+11</td>
<td class=bc>4 - 0 - 5</td>
<td class=br><strong>8</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>C</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=198&x=-53&p=Ar%20Verbi%C4%8Ds">Ar Verbi�s</a></td><td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=br>13:28</td><td class=br>-15</td>
<td class=bc>3 - 1 - 5</td>
<td class=br><strong>7</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>C</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=433&x=-53&p=Su%20P%C3%B6ssl">Su P�ssl</a></td><td class=kL>1:8</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=br>20:31</td><td class=br>-11</td>
<td class=bc>3 - 0 - 6</td>
<td class=br><strong>6</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>D</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=189&x=-53&p=El%20Reinfelds">El Reinfelds</a></td><td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=br>8:37</td><td class=br>-29</td>
<td class=bc>1 - 0 - 8</td>
<td class=br><strong>2</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>D</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=347&x=-53&p=Mi%20Birzgalis">Mi Birzgalis</a></td><td class=kL>0:12</td>
<td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>0:9</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=br>5:53</td><td class=br>-48</td>
<td class=bc>0 - 0 - 9</td>
<td class=br><strong>0</strong></td><td class=d>10.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Birzgalis Miks</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Jurka Lukass</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>1 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Birzgalis Miks</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Birzgalis Miks</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>0 : 12</tr></td>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Jurka Lukass</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Birzgalis Miks</td><td class=bc>-</td><td class=blW>P�ssl Susanna</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Birzgalis Miks</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>P�ssl Susanna</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Jurka Lukass</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Forsberg James-John</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>Birzgalis Miks</td><td class=bc>9 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=blW>Pavlovskis Ilgvars</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Birzgalis Miks</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=blW>Forsberg James-John</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Birzgalis Miks</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Jurka Lukass</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Birzgalis Miks</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Wallin Wilton</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Birzgalis Miks</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>P�ssl Susanna</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>1 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 5</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=114&x=-53&p=An%20Bo%C5%BEi%C4%8D">An Bo�i�</a></td><td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>35:10</td><td class=br>+25</td>
<td class=bc>8 - 0 - 1</td>
<td class=br><strong>16</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=36&x=-53&p=Ro%20Verbi%C4%8Ds">Ro Verbi�s</a></td><td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>7:0</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=br>38:14</td><td class=br>+24</td>
<td class=bc>6 - 1 - 2</td>
<td class=br><strong>13</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=34&x=-53&p=J%C4%93%20Re%C4%B7is">J� Re�is</a></td><td class=kW>3:1</td>
<td class=kL>0:7</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>4:6</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=br>28:19</td><td class=br>+9</td>
<td class=bc>6 - 0 - 3</td>
<td class=br><strong>12</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=202&x=-53&p=Vl%20Voronov">Vl Voronov</a></td><td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=br>26:27</td><td class=br>-1</td>
<td class=bc>5 - 0 - 4</td>
<td class=br><strong>10</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=253&x=-53&p=Ra%20St%C4%81lmanis">Ra St�lmanis</a></td><td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>6:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=br>21:23</td><td class=br>-2</td>
<td class=bc>5 - 0 - 4</td>
<td class=br><strong>10</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=72&x=-53&p=Fr%20Platons">Fr Platons</a></td><td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=br>19:22</td><td class=br>-3</td>
<td class=bc>4 - 1 - 4</td>
<td class=br><strong>9</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>C</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=137&x=-53&p=J%C4%81%20Z%C4%81l%C4%ABte">J� Z�l�te</a></td><td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=br>23:23</td><td class=br>0</td>
<td class=bc>4 - 0 - 5</td>
<td class=br><strong>8</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>C</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=199&x=-53&p=Ro%20Purmalis">Ro Purmalis</a></td><td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>3:7</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=br>20:31</td><td class=br>-11</td>
<td class=bc>3 - 0 - 6</td>
<td class=br><strong>6</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>D</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=84&x=-53&p=%C4%A2i%20Vazoli%C5%86%C5%A1">�i Vazoli��</a></td><td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=br>13:22</td><td class=br>-9</td>
<td class=bc>2 - 2 - 5</td>
<td class=br><strong>6</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>D</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=352&x=-53&p=Da%20B%C4%93rzi%C5%86%C5%A1">Da B�rzi��</a></td><td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=br>4:36</td><td class=br>-32</td>
<td class=bc>0 - 0 - 9</td>
<td class=br><strong>0</strong></td><td class=d>10.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>B�rzi�� Dagnis Marsels</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Z�l�te J�nis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Z�l�te J�nis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>B�rzi�� Dagnis Marsels</td><td class=bc>-</td><td class=blW>Voronov Vladimir</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Purmalis Roberts</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Z�l�te J�nis</td><td class=bc>-</td><td class=blW>Voronov Vladimir</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>B�rzi�� Dagnis Marsels</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Z�l�te J�nis</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>B�rzi�� Dagnis Marsels</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>B�rzi�� Dagnis Marsels</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Purmalis Roberts</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>B�rzi�� Dagnis Marsels</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>B�rzi�� Dagnis Marsels</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>B�rzi�� Dagnis Marsels</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Z�l�te J�nis</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Purmalis Roberts</td><td class=bc>-</td><td class=bl>B�rzi�� Dagnis Marsels</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Z�l�te J�nis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Voronov Vladimir</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>B�rzi�� Dagnis Marsels</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Z�l�te J�nis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>3 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 6</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=97&x=-53&p=Gi%20Lasmanis">Gi Lasmanis</a></td><td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>8:3</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=br>41:13</td><td class=br>+28</td>
<td class=bc>9 - 0 - 0</td>
<td class=br><strong>18</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=44&x=-53&p=Kr%20Naglis">Kr Naglis</a></td><td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kT>6:6</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>8:1</td>
<td class=kW>9:1</td>
<td class=kW>11:2</td>
<td class=kW>10:0</td>
<td class=br>55:20</td><td class=br>+35</td>
<td class=bc>5 - 3 - 1</td>
<td class=br><strong>13</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=31&x=-53&p=Ni%20L%C4%81cis">Ni L�cis</a></td><td class=kL>3:8</td>
<td class=kT>6:6</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>8:1</td>
<td class=kW>8:1</td>
<td class=kW>7:1</td>
<td class=br>48:28</td><td class=br>+20</td>
<td class=bc>6 - 1 - 2</td>
<td class=br><strong>13</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=201&x=-53&p=El%20R%C4%81cen%C4%81ja">El R�cen�ja</a></td><td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kW>7:0</td>
<td class=kW>10:0</td>
<td class=kW>12:0</td>
<td class=br>45:18</td><td class=br>+27</td>
<td class=bc>5 - 1 - 3</td>
<td class=br><strong>11</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=90&x=-53&p=Em%20Reinfelds">Em Reinfelds</a></td><td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=br>25:17</td><td class=br>+8</td>
<td class=bc>5 - 1 - 3</td>
<td class=br><strong>11</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=47&x=-53&p=To%20Jakseboga">To Jakseboga</a></td><td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>5:4</td>
<td class=br>22:31</td><td class=br>-9</td>
<td class=bc>4 - 0 - 5</td>
<td class=br><strong>8</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>C</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=10001&x=-53&p=Marg%20%C4%80bele">Marg �bele</a></td><td class=kL>3:4</td>
<td class=kL>1:8</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>9:2</td>
<td class=br>28:26</td><td class=br>+2</td>
<td class=bc>4 - 0 - 5</td>
<td class=br><strong>8</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>C</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=152&x=-53&p=To%20Ulis">To Ulis</a></td><td class=kL>2:5</td>
<td class=kL>1:9</td>
<td class=kL>1:8</td>
<td class=kL>0:7</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=br>14:39</td><td class=br>-25</td>
<td class=bc>3 - 0 - 6</td>
<td class=br><strong>6</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>D</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=345&x=-53&p=Ra%20Meija">Ra Meija</a></td><td class=kL>1:5</td>
<td class=kL>2:11</td>
<td class=kL>1:8</td>
<td class=kL>0:10</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=br>8:49</td><td class=br>-41</td>
<td class=bc>0 - 1 - 8</td>
<td class=br><strong>1</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>D</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=428&x=-53&p=An%20Israelsson">An Israelsson</a></td><td class=kL>0:4</td>
<td class=kL>0:10</td>
<td class=kL>1:7</td>
<td class=kL>0:12</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kL>2:9</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=br>11:56</td><td class=br>-45</td>
<td class=bc>0 - 1 - 8</td>
<td class=br><strong>1</strong></td><td class=d>10.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Israelsson Anna-Maria</td><td class=bc>-</td><td class=blW>Ulis Tomas</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Reinfelds Em�ls Matiass</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>L�cis Niks</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Reinfelds Em�ls Matiass</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Israelsson Anna-Maria</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>L�cis Niks</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Reinfelds Em�ls Matiass</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Israelsson Anna-Maria</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Reinfelds Em�ls Matiass</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Israelsson Anna-Maria</td><td class=bc>-</td><td class=blW>L�cis Niks</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Reinfelds Em�ls Matiass</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>L�cis Niks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>11 : 2</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Reinfelds Em�ls Matiass</td><td class=bc>-</td><td class=blW>L�cis Niks</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Israelsson Anna-Maria</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>L�cis Niks</td><td class=bc>6 : 6</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Reinfelds Em�ls Matiass</td><td class=bc>-</td><td class=bl>Israelsson Anna-Maria</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>L�cis Niks</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Israelsson Anna-Maria</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Reinfelds Em�ls Matiass</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>L�cis Niks</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Israelsson Anna-Maria</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Ulis Tomas</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Israelsson Anna-Maria</td><td class=bc>12 : 0</tr></td>
<tr><td class=brW>L�cis Niks</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Ulis Tomas</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Reinfelds Em�ls Matiass</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Israelsson Anna-Maria</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>L�cis Niks</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Reinfelds Em�ls Matiass</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>0 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group A1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=39&x=-53&p=Kr%20Rieksti%C5%86%C5%A1">Kr Rieksti��</a></td><td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=br>44:24</td><td class=br>+20</td>
<td class=bc>8 - 3 - 0</td>
<td class=br><strong>19</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=34&x=-53&p=J%C4%93%20Re%C4%B7is">J� Re�is</a></td><td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>8:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=br>35:22</td><td class=br>+13</td>
<td class=bc>6 - 3 - 2</td>
<td class=br><strong>15</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=30&x=-53&p=Ma%20Jakseboga">Ma Jakseboga</a></td><td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=br>40:30</td><td class=br>+10</td>
<td class=bc>6 - 3 - 2</td>
<td class=br><strong>15</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=235&x=-53&p=An%20Fjermestad">An Fjermestad</a></td><td class=kL>1:5</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>4:6</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=br>37:28</td><td class=br>+9</td>
<td class=bc>7 - 0 - 4</td>
<td class=br><strong>14</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=36&x=-53&p=Ro%20Verbi%C4%8Ds">Ro Verbi�s</a></td><td class=kT>4:4</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>8:1</td>
<td class=kW>7:0</td>
<td class=br>43:27</td><td class=br>+16</td>
<td class=bc>6 - 2 - 3</td>
<td class=br><strong>14</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=11&x=-53&p=Ed%20Putni%C5%86%C5%A1">Ed Putni��</a></td><td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>6:4</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kW>5:1</td>
<td class=br>36:37</td><td class=br>-1</td>
<td class=bc>5 - 1 - 5</td>
<td class=br><strong>11</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=25&x=-53&p=J%C4%81%20Bitmanis">J� Bitmanis</a></td><td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=br>25:32</td><td class=br>-7</td>
<td class=bc>4 - 2 - 5</td>
<td class=br><strong>10</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=121&x=-53&p=Gu%20Hermansson">Gu Hermansson</a></td><td class=kL>3:6</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=br>30:35</td><td class=br>-5</td>
<td class=bc>3 - 3 - 5</td>
<td class=br><strong>9</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=202&x=-53&p=Vl%20Voronov">Vl Voronov</a></td><td class=kL>1:2</td>
<td class=kL>2:8</td>
<td class=kL>3:4</td>
<td class=kL>0:6</td>
<td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kW>1:0</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=br>25:39</td><td class=br>-14</td>
<td class=bc>4 - 0 - 7</td>
<td class=br><strong>8</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=133&x=-53&p=Au%20Pleikys">Au Pleikys</a></td><td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=br>29:33</td><td class=br>-4</td>
<td class=bc>3 - 2 - 6</td>
<td class=br><strong>8</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=114&x=-53&p=An%20Bo%C5%BEi%C4%8D">An Bo�i�</a></td><td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>1:8</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>27:36</td><td class=br>-9</td>
<td class=bc>3 - 1 - 7</td>
<td class=br><strong>7</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=162&x=-53&p=Gi%20Remeika">Gi Remeika</a></td><td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>17:45</td><td class=br>-28</td>
<td class=bc>1 - 0 - 10</td>
<td class=br><strong>2</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=blW>Putni�� Edgars</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Putni�� Edgars</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Fjermestad Andreas</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Fjermestad Andreas</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Fjermestad Andreas</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Fjermestad Andreas</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>Bitmanis J�nis Mi�elis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Fjermestad Andreas</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Fjermestad Andreas</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Rieksti�� Kristaps</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group A2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=44&x=-53&p=Kr%20Naglis">Kr Naglis</a></td><td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=br>39:22</td><td class=br>+17</td>
<td class=bc>8 - 2 - 1</td>
<td class=br><strong>18</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=70&x=-53&p=An%20Kuz%C5%86ecovs">An Kuz�ecovs</a></td><td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kT>5:5</td>
<td class=kW>5:4</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=br>37:24</td><td class=br>+13</td>
<td class=bc>8 - 2 - 1</td>
<td class=br><strong>18</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=123&x=-53&p=Lu%20Jurka">Lu Jurka</a></td><td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=br>36:21</td><td class=br>+15</td>
<td class=bc>7 - 2 - 2</td>
<td class=br><strong>16</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=163&x=-53&p=Zy%20Remeika">Zy Remeika</a></td><td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>9:1</td>
<td class=kW>3:0</td>
<td class=br>38:21</td><td class=br>+17</td>
<td class=bc>6 - 2 - 3</td>
<td class=br><strong>14</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=186&x=-53&p=R%C5%AB%20Kamzols">R� Kamzols</a></td><td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=br>31:26</td><td class=br>+5</td>
<td class=bc>6 - 1 - 4</td>
<td class=br><strong>13</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=97&x=-53&p=Gi%20Lasmanis">Gi Lasmanis</a></td><td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=br>29:25</td><td class=br>+4</td>
<td class=bc>5 - 3 - 3</td>
<td class=br><strong>13</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=69&x=-53&p=Ro%20Fa%C4%BCken%C5%A1teins">Ro Fa�ken�teins</a></td><td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=br>31:31</td><td class=br>0</td>
<td class=bc>4 - 3 - 4</td>
<td class=br><strong>11</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=31&x=-53&p=Ni%20L%C4%81cis">Ni L�cis</a></td><td class=kL>2:3</td>
<td class=kT>5:5</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=br>28:36</td><td class=br>-8</td>
<td class=bc>4 - 1 - 6</td>
<td class=br><strong>9</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=201&x=-53&p=El%20R%C4%81cen%C4%81ja">El R�cen�ja</a></td><td class=kL>0:5</td>
<td class=kL>4:5</td>
<td class=kL>4:5</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=br>32:37</td><td class=br>-5</td>
<td class=bc>4 - 0 - 7</td>
<td class=br><strong>8</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=427&x=-53&p=Ja%20Forsberg">Ja Forsberg</a></td><td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=br>27:42</td><td class=br>-15</td>
<td class=bc>2 - 3 - 6</td>
<td class=br><strong>7</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=79&x=-53&p=Mi%20Saul%C4%ABtis">Mi Saul�tis</a></td><td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>1:9</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kW>5:2</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=br>23:46</td><td class=br>-23</td>
<td class=bc>1 - 1 - 9</td>
<td class=br><strong>3</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=374&x=-53&p=Dm%20Kudrytsky">Dm Kudrytsky</a></td><td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=br>16:36</td><td class=br>-20</td>
<td class=bc>1 - 0 - 10</td>
<td class=br><strong>2</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Kudrytsky Dmytro</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=blW>L�cis Niks</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Kudrytsky Dmytro</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>L�cis Niks</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kudrytsky Dmytro</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>L�cis Niks</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Kudrytsky Dmytro</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>L�cis Niks</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Kudrytsky Dmytro</td><td class=bc>-</td><td class=blW>L�cis Niks</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>L�cis Niks</td><td class=bc>-</td><td class=blW>Forsberg James-John</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kudrytsky Dmytro</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>L�cis Niks</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kudrytsky Dmytro</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>L�cis Niks</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kudrytsky Dmytro</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Jurka Lukass</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>L�cis Niks</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kudrytsky Dmytro</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Jurka Lukass</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>L�cis Niks</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kudrytsky Dmytro</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>L�cis Niks</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Kudrytsky Dmytro</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Jurka Lukass</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Kudrytsky Dmytro</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>L�cis Niks</td><td class=bc>5 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=122&x=-53&p=Vi%20Henttonen">Vi Henttonen</a></td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>9:1</td>
<td class=kW>7:0</td>
<td class=br>44:16</td><td class=br>+28</td>
<td class=bc>10 - 1 - 0</td>
<td class=br><strong>21</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=45&x=-53&p=Al%20Skudr%C4%ABtis">Al Skudr�tis</a></td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>10:3</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>5:4</td>
<td class=kW>5:1</td>
<td class=kW>7:5</td>
<td class=kW>3:1</td>
<td class=br>50:29</td><td class=br>+21</td>
<td class=bc>9 - 0 - 2</td>
<td class=br><strong>18</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=77&x=-53&p=Ei%20G%C5%ABze">Ei G�ze</a></td><td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=br>30:22</td><td class=br>+8</td>
<td class=bc>8 - 0 - 3</td>
<td class=br><strong>16</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=124&x=-53&p=Ne%20Skrlep">Ne Skrlep</a></td><td class=kL>2:4</td>
<td class=kL>3:10</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kL>4:7</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=br>41:33</td><td class=br>+8</td>
<td class=bc>7 - 1 - 3</td>
<td class=br><strong>15</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=47&x=-53&p=To%20Jakseboga">To Jakseboga</a></td><td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>3:6</td>
<td class=kL>0:2</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=br>27:26</td><td class=br>+1</td>
<td class=bc>5 - 2 - 4</td>
<td class=br><strong>12</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=367&x=-53&p=Ol%20Pylypenko">Ol Pylypenko</a></td><td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=br>32:33</td><td class=br>-1</td>
<td class=bc>5 - 1 - 5</td>
<td class=br><strong>11</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=72&x=-53&p=Fr%20Platons">Fr Platons</a></td><td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=br>25:25</td><td class=br>0</td>
<td class=bc>4 - 1 - 6</td>
<td class=br><strong>9</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=18&x=-53&p=Kr%20Zarinieks">Kr Zarinieks</a></td><td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>7:4</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=br>31:40</td><td class=br>-9</td>
<td class=bc>3 - 1 - 7</td>
<td class=br><strong>7</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=90&x=-53&p=Em%20Reinfelds">Em Reinfelds</a></td><td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kW>6:3</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>4:6</td>
<td class=kT>2:2</td>
<td class=br>30:38</td><td class=br>-8</td>
<td class=bc>3 - 1 - 7</td>
<td class=br><strong>7</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=144&x=-53&p=Il%20Pavlovskis">Il Pavlovskis</a></td><td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kL>4:5</td>
<td class=kL>0:1</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=br>22:31</td><td class=br>-9</td>
<td class=bc>2 - 2 - 7</td>
<td class=br><strong>6</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=426&x=-53&p=Wi%20Wallin">Wi Wallin</a></td><td class=kL>1:9</td>
<td class=kL>5:7</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>6:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=br>27:42</td><td class=br>-15</td>
<td class=bc>2 - 2 - 7</td>
<td class=br><strong>6</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=253&x=-53&p=Ra%20St%C4%81lmanis">Ra St�lmanis</a></td><td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=br>15:39</td><td class=br>-24</td>
<td class=bc>1 - 2 - 8</td>
<td class=br><strong>4</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Skrlep Nejc</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Reinfelds Em�ls Matiass</td><td class=bc>-</td><td class=blW>Pylypenko Oleksandr</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=blW>Pylypenko Oleksandr</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>10 : 3</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=blW>Reinfelds Em�ls Matiass</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Reinfelds Em�ls Matiass</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=blW>Skrlep Nejc</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Pylypenko Oleksandr</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Reinfelds Em�ls Matiass</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Skrlep Nejc</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Reinfelds Em�ls Matiass</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Skrlep Nejc</td><td class=bc>-</td><td class=bl>Reinfelds Em�ls Matiass</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Reinfelds Em�ls Matiass</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Skrlep Nejc</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Reinfelds Em�ls Matiass</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Skrlep Nejc</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>5 : 7</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Reinfelds Em�ls Matiass</td><td class=bc>-</td><td class=blW>Zarinieks Kristaps</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Skrlep Nejc</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Reinfelds Em�ls Matiass</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Skrlep Nejc</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Reinfelds Em�ls Matiass</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Reinfelds Em�ls Matiass</td><td class=bc>-</td><td class=blW>Wallin Wilton</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Skrlep Nejc</td><td class=bc>1 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=424&x=-53&p=La%20Ulfvensj%C3%B6">La Ulfvensj�</a></td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=br>33:14</td><td class=br>+19</td>
<td class=bc>8 - 2 - 1</td>
<td class=br><strong>18</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=137&x=-53&p=J%C4%81%20Z%C4%81l%C4%ABte">J� Z�l�te</a></td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=br>39:22</td><td class=br>+17</td>
<td class=bc>7 - 2 - 2</td>
<td class=br><strong>16</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=10001&x=-53&p=Marg%20%C4%80bele">Marg �bele</a></td><td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=br>32:13</td><td class=br>+19</td>
<td class=bc>7 - 1 - 3</td>
<td class=br><strong>15</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=75&x=-53&p=L%C4%81%20Bezdel%C4%ABga">L� Bezdel�ga</a></td><td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=br>28:18</td><td class=br>+10</td>
<td class=bc>7 - 1 - 3</td>
<td class=br><strong>15</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=198&x=-53&p=Ar%20Verbi%C4%8Ds">Ar Verbi�s</a></td><td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>6:4</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=br>30:22</td><td class=br>+8</td>
<td class=bc>6 - 2 - 3</td>
<td class=br><strong>14</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=71&x=-53&p=Da%20Baumanis">Da Baumanis</a></td><td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=br>21:23</td><td class=br>-2</td>
<td class=bc>6 - 1 - 4</td>
<td class=br><strong>13</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=197&x=-53&p=%C5%AAv%20Vikmanis">�v Vikmanis</a></td><td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=br>31:25</td><td class=br>+6</td>
<td class=bc>4 - 3 - 4</td>
<td class=br><strong>11</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=433&x=-53&p=Su%20P%C3%B6ssl">Su P�ssl</a></td><td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kL>0:8</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=br>29:34</td><td class=br>-5</td>
<td class=bc>4 - 2 - 5</td>
<td class=br><strong>10</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=199&x=-53&p=Ro%20Purmalis">Ro Purmalis</a></td><td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>4:6</td>
<td class=kL>1:2</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=br>21:38</td><td class=br>-17</td>
<td class=bc>4 - 0 - 7</td>
<td class=br><strong>8</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=418&x=-53&p=Al%20Hermansson">Al Hermansson</a></td><td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=br>27:27</td><td class=br>0</td>
<td class=bc>2 - 3 - 6</td>
<td class=br><strong>7</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=152&x=-53&p=To%20Ulis">To Ulis</a></td><td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=br>16:41</td><td class=br>-25</td>
<td class=bc>2 - 0 - 9</td>
<td class=br><strong>4</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=159&x=-53&p=Re%20Saul%C4%ABtis">Re Saul�tis</a></td><td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=br>16:46</td><td class=br>-30</td>
<td class=bc>0 - 1 - 10</td>
<td class=br><strong>1</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ulfvensj� Lars</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>P�ssl Susanna</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ulfvensj� Lars</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Purmalis Roberts</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ulfvensj� Lars</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Purmalis Roberts</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Hermansson Alfons</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ulfvensj� Lars</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Z�l�te J�nis</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>P�ssl Susanna</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Purmalis Roberts</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ulis Tomas</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Z�l�te J�nis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ulfvensj� Lars</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>Vikmanis �ve</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>P�ssl Susanna</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Z�l�te J�nis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=blW>Z�l�te J�nis</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Ulis Tomas</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Z�l�te J�nis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Ulfvensj� Lars</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Z�l�te J�nis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Ulfvensj� Lars</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>P�ssl Susanna</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Hermansson Alfons</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Purmalis Roberts</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ulfvensj� Lars</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>3 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group D</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=429&x=-53&p=Ro%20Forsberg">Ro Forsberg</a></td><td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>10:0</td>
<td class=kW>5:0</td>
<td class=br>33:7</td><td class=br>+26</td>
<td class=bc>7 - 0 - 1</td>
<td class=br><strong>14</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=220&x=-53&p=Jo%20Pleikys">Jo Pleikys</a></td><td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=br>24:8</td><td class=br>+16</td>
<td class=bc>5 - 2 - 1</td>
<td class=br><strong>12</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=84&x=-53&p=%C4%A2i%20Vazoli%C5%86%C5%A1">�i Vazoli��</a></td><td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>6:0</td>
<td class=br>24:12</td><td class=br>+12</td>
<td class=bc>4 - 4 - 0</td>
<td class=br><strong>12</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=189&x=-53&p=El%20Reinfelds">El Reinfelds</a></td><td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=br>30:21</td><td class=br>+9</td>
<td class=bc>5 - 1 - 2</td>
<td class=br><strong>11</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=352&x=-53&p=Da%20B%C4%93rzi%C5%86%C5%A1">Da B�rzi��</a></td><td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>0:6</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=br>14:18</td><td class=br>-4</td>
<td class=bc>3 - 1 - 4</td>
<td class=br><strong>7</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=428&x=-53&p=An%20Israelsson">An Israelsson</a></td><td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=br>18:22</td><td class=br>-4</td>
<td class=bc>3 - 0 - 5</td>
<td class=br><strong>6</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=93&x=-53&p=Kr%20G%C5%ABtmanis">Kr G�tmanis</a></td><td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>6:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=br>19:19</td><td class=br>0</td>
<td class=bc>2 - 2 - 4</td>
<td class=br><strong>6</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=345&x=-53&p=Ra%20Meija">Ra Meija</a></td><td class=kL>0:10</td>
<td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kL>2:7</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=br>11:33</td><td class=br>-22</td>
<td class=bc>0 - 3 - 5</td>
<td class=br><strong>3</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=347&x=-53&p=Mi%20Birzgalis">Mi Birzgalis</a></td><td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=br>6:39</td><td class=br>-33</td>
<td class=bc>0 - 1 - 7</td>
<td class=br><strong>1</strong></td><td class=d>9.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Israelsson Anna-Maria</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Forsberg Robert</td><td class=bc>-</td><td class=bl>B�rzi�� Dagnis Marsels</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>G�tmanis Kristers</td><td class=bc>-</td><td class=bl>Birzgalis Miks</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Israelsson Anna-Maria</td><td class=bc>-</td><td class=blW>B�rzi�� Dagnis Marsels</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Birzgalis Miks</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Forsberg Robert</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>G�tmanis Kristers</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>B�rzi�� Dagnis Marsels</td><td class=bc>-</td><td class=bl>Birzgalis Miks</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Israelsson Anna-Maria</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Forsberg Robert</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Birzgalis Miks</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>B�rzi�� Dagnis Marsels</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Israelsson Anna-Maria</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>G�tmanis Kristers</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Birzgalis Miks</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>1 : 4</tr></td>
<tr><td class=br>B�rzi�� Dagnis Marsels</td><td class=bc>-</td><td class=blW>G�tmanis Kristers</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Israelsson Anna-Maria</td><td class=bc>-</td><td class=blW>Forsberg Robert</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=bl>G�tmanis Kristers</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Birzgalis Miks</td><td class=bc>-</td><td class=blW>Forsberg Robert</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>B�rzi�� Dagnis Marsels</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>G�tmanis Kristers</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Forsberg Robert</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Pleikys Jonas</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Birzgalis Miks</td><td class=bc>-</td><td class=blW>Israelsson Anna-Maria</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>G�tmanis Kristers</td><td class=bc>-</td><td class=blW>Forsberg Robert</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Pleikys Jonas</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Israelsson Anna-Maria</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>B�rzi�� Dagnis Marsels</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Forsberg Robert</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>G�tmanis Kristers</td><td class=bc>-</td><td class=blW>Israelsson Anna-Maria</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>B�rzi�� Dagnis Marsels</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Birzgalis Miks</td><td class=bc>6 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
