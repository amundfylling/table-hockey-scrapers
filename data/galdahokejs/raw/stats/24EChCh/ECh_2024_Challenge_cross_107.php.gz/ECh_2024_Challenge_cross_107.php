<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>ECh 2024 Challenge</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="ECh_2024_Challenge_list.php">ECh 2024 Challenge</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group D</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=429&x=-53&p=Ro%20Forsberg">Ro Forsberg</a></td><td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>10:0</td>
<td class=kW>5:0</td>
<td class=br>33:7</td><td class=br>+26</td>
<td class=bc>7 - 0 - 1</td>
<td class=br><strong>14</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=220&x=-53&p=Jo%20Pleikys">Jo Pleikys</a></td><td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=br>24:8</td><td class=br>+16</td>
<td class=bc>5 - 2 - 1</td>
<td class=br><strong>12</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=84&x=-53&p=%C4%A2i%20Vazoli%C5%86%C5%A1">�i Vazoli��</a></td><td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>6:0</td>
<td class=br>24:12</td><td class=br>+12</td>
<td class=bc>4 - 4 - 0</td>
<td class=br><strong>12</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=189&x=-53&p=El%20Reinfelds">El Reinfelds</a></td><td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=br>30:21</td><td class=br>+9</td>
<td class=bc>5 - 1 - 2</td>
<td class=br><strong>11</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=352&x=-53&p=Da%20B%C4%93rzi%C5%86%C5%A1">Da B�rzi��</a></td><td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>0:6</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=br>14:18</td><td class=br>-4</td>
<td class=bc>3 - 1 - 4</td>
<td class=br><strong>7</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=428&x=-53&p=An%20Israelsson">An Israelsson</a></td><td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=br>18:22</td><td class=br>-4</td>
<td class=bc>3 - 0 - 5</td>
<td class=br><strong>6</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=93&x=-53&p=Kr%20G%C5%ABtmanis">Kr G�tmanis</a></td><td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>6:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=br>19:19</td><td class=br>0</td>
<td class=bc>2 - 2 - 4</td>
<td class=br><strong>6</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=345&x=-53&p=Ra%20Meija">Ra Meija</a></td><td class=kL>0:10</td>
<td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kL>2:7</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=br>11:33</td><td class=br>-22</td>
<td class=bc>0 - 3 - 5</td>
<td class=br><strong>3</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=347&x=-53&p=Mi%20Birzgalis">Mi Birzgalis</a></td><td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=br>6:39</td><td class=br>-33</td>
<td class=bc>0 - 1 - 7</td>
<td class=br><strong>1</strong></td><td class=d>9.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Israelsson Anna-Maria</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Forsberg Robert</td><td class=bc>-</td><td class=bl>B�rzi�� Dagnis Marsels</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>G�tmanis Kristers</td><td class=bc>-</td><td class=bl>Birzgalis Miks</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Israelsson Anna-Maria</td><td class=bc>-</td><td class=blW>B�rzi�� Dagnis Marsels</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Birzgalis Miks</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Forsberg Robert</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>G�tmanis Kristers</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>B�rzi�� Dagnis Marsels</td><td class=bc>-</td><td class=bl>Birzgalis Miks</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Israelsson Anna-Maria</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Forsberg Robert</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Birzgalis Miks</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>B�rzi�� Dagnis Marsels</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Israelsson Anna-Maria</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>G�tmanis Kristers</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Birzgalis Miks</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>1 : 4</tr></td>
<tr><td class=br>B�rzi�� Dagnis Marsels</td><td class=bc>-</td><td class=blW>G�tmanis Kristers</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Israelsson Anna-Maria</td><td class=bc>-</td><td class=blW>Forsberg Robert</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=bl>G�tmanis Kristers</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Birzgalis Miks</td><td class=bc>-</td><td class=blW>Forsberg Robert</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>B�rzi�� Dagnis Marsels</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>G�tmanis Kristers</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Forsberg Robert</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Pleikys Jonas</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Birzgalis Miks</td><td class=bc>-</td><td class=blW>Israelsson Anna-Maria</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>G�tmanis Kristers</td><td class=bc>-</td><td class=blW>Forsberg Robert</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Pleikys Jonas</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Israelsson Anna-Maria</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>B�rzi�� Dagnis Marsels</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Forsberg Robert</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>G�tmanis Kristers</td><td class=bc>-</td><td class=blW>Israelsson Anna-Maria</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>B�rzi�� Dagnis Marsels</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Birzgalis Miks</td><td class=bc>6 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
