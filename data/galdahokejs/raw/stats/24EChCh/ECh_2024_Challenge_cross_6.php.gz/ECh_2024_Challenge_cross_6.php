<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>ECh 2024 Challenge</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="ECh_2024_Challenge_list.php">ECh 2024 Challenge</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 6</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=97&x=-53&p=Gi%20Lasmanis">Gi Lasmanis</a></td><td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>8:3</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=br>41:13</td><td class=br>+28</td>
<td class=bc>9 - 0 - 0</td>
<td class=br><strong>18</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=44&x=-53&p=Kr%20Naglis">Kr Naglis</a></td><td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kT>6:6</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>8:1</td>
<td class=kW>9:1</td>
<td class=kW>11:2</td>
<td class=kW>10:0</td>
<td class=br>55:20</td><td class=br>+35</td>
<td class=bc>5 - 3 - 1</td>
<td class=br><strong>13</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=31&x=-53&p=Ni%20L%C4%81cis">Ni L�cis</a></td><td class=kL>3:8</td>
<td class=kT>6:6</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>8:1</td>
<td class=kW>8:1</td>
<td class=kW>7:1</td>
<td class=br>48:28</td><td class=br>+20</td>
<td class=bc>6 - 1 - 2</td>
<td class=br><strong>13</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=201&x=-53&p=El%20R%C4%81cen%C4%81ja">El R�cen�ja</a></td><td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kW>7:0</td>
<td class=kW>10:0</td>
<td class=kW>12:0</td>
<td class=br>45:18</td><td class=br>+27</td>
<td class=bc>5 - 1 - 3</td>
<td class=br><strong>11</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=90&x=-53&p=Em%20Reinfelds">Em Reinfelds</a></td><td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=br>25:17</td><td class=br>+8</td>
<td class=bc>5 - 1 - 3</td>
<td class=br><strong>11</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=47&x=-53&p=To%20Jakseboga">To Jakseboga</a></td><td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>5:4</td>
<td class=br>22:31</td><td class=br>-9</td>
<td class=bc>4 - 0 - 5</td>
<td class=br><strong>8</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>C</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=10001&x=-53&p=Marg%20%C4%80bele">Marg �bele</a></td><td class=kL>3:4</td>
<td class=kL>1:8</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>9:2</td>
<td class=br>28:26</td><td class=br>+2</td>
<td class=bc>4 - 0 - 5</td>
<td class=br><strong>8</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>C</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=152&x=-53&p=To%20Ulis">To Ulis</a></td><td class=kL>2:5</td>
<td class=kL>1:9</td>
<td class=kL>1:8</td>
<td class=kL>0:7</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=br>14:39</td><td class=br>-25</td>
<td class=bc>3 - 0 - 6</td>
<td class=br><strong>6</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>D</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=345&x=-53&p=Ra%20Meija">Ra Meija</a></td><td class=kL>1:5</td>
<td class=kL>2:11</td>
<td class=kL>1:8</td>
<td class=kL>0:10</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=br>8:49</td><td class=br>-41</td>
<td class=bc>0 - 1 - 8</td>
<td class=br><strong>1</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>D</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=428&x=-53&p=An%20Israelsson">An Israelsson</a></td><td class=kL>0:4</td>
<td class=kL>0:10</td>
<td class=kL>1:7</td>
<td class=kL>0:12</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kL>2:9</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=br>11:56</td><td class=br>-45</td>
<td class=bc>0 - 1 - 8</td>
<td class=br><strong>1</strong></td><td class=d>10.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Israelsson Anna-Maria</td><td class=bc>-</td><td class=blW>Ulis Tomas</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Reinfelds Em�ls Matiass</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>L�cis Niks</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Reinfelds Em�ls Matiass</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Israelsson Anna-Maria</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>L�cis Niks</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Reinfelds Em�ls Matiass</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Israelsson Anna-Maria</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Reinfelds Em�ls Matiass</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Israelsson Anna-Maria</td><td class=bc>-</td><td class=blW>L�cis Niks</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Reinfelds Em�ls Matiass</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>L�cis Niks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Meija Ralfs</td><td class=bc>11 : 2</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Reinfelds Em�ls Matiass</td><td class=bc>-</td><td class=blW>L�cis Niks</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Israelsson Anna-Maria</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>L�cis Niks</td><td class=bc>6 : 6</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Reinfelds Em�ls Matiass</td><td class=bc>-</td><td class=bl>Israelsson Anna-Maria</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>L�cis Niks</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Israelsson Anna-Maria</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Reinfelds Em�ls Matiass</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>L�cis Niks</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Israelsson Anna-Maria</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Ulis Tomas</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Israelsson Anna-Maria</td><td class=bc>12 : 0</tr></td>
<tr><td class=brW>L�cis Niks</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Ulis Tomas</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Reinfelds Em�ls Matiass</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Israelsson Anna-Maria</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>L�cis Niks</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Reinfelds Em�ls Matiass</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Meija Ralfs</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>0 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
