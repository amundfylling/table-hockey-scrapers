<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>ECh 2024 Challenge</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="ECh_2024_Challenge_list.php">ECh 2024 Challenge</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=121&x=-53&p=Gu%20Hermansson">Gu Hermansson</a></td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>8:4</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=br>32:16</td><td class=br>+16</td>
<td class=bc>5 - 2 - 1</td>
<td class=br><strong>12</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=25&x=-53&p=J%C4%81%20Bitmanis">J� Bitmanis</a></td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=br>21:13</td><td class=br>+8</td>
<td class=bc>5 - 2 - 1</td>
<td class=br><strong>12</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=30&x=-53&p=Ma%20Jakseboga">Ma Jakseboga</a></td><td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>32:16</td><td class=br>+16</td>
<td class=bc>5 - 1 - 2</td>
<td class=br><strong>11</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=162&x=-53&p=Gi%20Remeika">Gi Remeika</a></td><td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>7:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=br>24:20</td><td class=br>+4</td>
<td class=bc>3 - 3 - 2</td>
<td class=br><strong>9</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=18&x=-53&p=Kr%20Zarinieks">Kr Zarinieks</a></td><td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>2:7</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=br>26:27</td><td class=br>-1</td>
<td class=bc>2 - 5 - 1</td>
<td class=br><strong>9</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=124&x=-53&p=Ne%20Skrlep">Ne Skrlep</a></td><td class=kL>4:8</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=br>24:29</td><td class=br>-5</td>
<td class=bc>3 - 1 - 4</td>
<td class=br><strong>7</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>C</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=75&x=-53&p=L%C4%81%20Bezdel%C4%ABga">L� Bezdel�ga</a></td><td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=br>15:24</td><td class=br>-9</td>
<td class=bc>1 - 3 - 4</td>
<td class=br><strong>5</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>C</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=418&x=-53&p=Al%20Hermansson">Al Hermansson</a></td><td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>16:25</td><td class=br>-9</td>
<td class=bc>2 - 0 - 6</td>
<td class=br><strong>4</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>D</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=93&x=-53&p=Kr%20G%C5%ABtmanis">Kr G�tmanis</a></td><td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>10:30</td><td class=br>-20</td>
<td class=bc>1 - 1 - 6</td>
<td class=br><strong>3</strong></td><td class=d>9.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>G�tmanis Kristers</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>G�tmanis Kristers</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Skrlep Nejc</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Skrlep Nejc</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>4 : 8</tr></td>
<tr><td class=brW>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>G�tmanis Kristers</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Skrlep Nejc</td><td class=bc>-</td><td class=bl>G�tmanis Kristers</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>G�tmanis Kristers</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Skrlep Nejc</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Hermansson Alfons</td><td class=bc>-</td><td class=bl>G�tmanis Kristers</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>G�tmanis Kristers</td><td class=bc>-</td><td class=blW>Bitmanis J�nis Mi�elis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>G�tmanis Kristers</td><td class=bc>-</td><td class=blW>Zarinieks Kristaps</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Hermansson Alfons</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>3 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
