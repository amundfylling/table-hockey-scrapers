<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>ECh 2024 Challenge</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="ECh_2024_Challenge_list.php">ECh 2024 Challenge</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=186&x=-53&p=R%C5%AB%20Kamzols">R� Kamzols</a></td><td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>9:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=br>39:15</td><td class=br>+24</td>
<td class=bc>6 - 2 - 0</td>
<td class=br><strong>14</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=69&x=-53&p=Ro%20Fa%C4%BCken%C5%A1teins">Ro Fa�ken�teins</a></td><td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=br>20:10</td><td class=br>+10</td>
<td class=bc>6 - 1 - 1</td>
<td class=br><strong>13</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=70&x=-53&p=An%20Kuz%C5%86ecovs">An Kuz�ecovs</a></td><td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=kW>8:2</td>
<td class=kW>7:2</td>
<td class=br>38:21</td><td class=br>+17</td>
<td class=bc>5 - 1 - 2</td>
<td class=br><strong>11</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=374&x=-53&p=Dm%20Kudrytsky">Dm Kudrytsky</a></td><td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=br>18:20</td><td class=br>-2</td>
<td class=bc>4 - 1 - 3</td>
<td class=br><strong>9</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=122&x=-53&p=Vi%20Henttonen">Vi Henttonen</a></td><td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=br>19:20</td><td class=br>-1</td>
<td class=bc>4 - 0 - 4</td>
<td class=br><strong>8</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=367&x=-53&p=Ol%20Pylypenko">Ol Pylypenko</a></td><td class=kL>2:9</td>
<td class=kL>1:3</td>
<td class=kL>1:7</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=br>17:30</td><td class=br>-13</td>
<td class=bc>3 - 0 - 5</td>
<td class=br><strong>6</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>C</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=424&x=-53&p=La%20Ulfvensj%C3%B6">La Ulfvensj�</a></td><td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kT>0:0</td>
<td class=br>17:24</td><td class=br>-7</td>
<td class=bc>1 - 3 - 4</td>
<td class=br><strong>5</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>C</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=197&x=-53&p=%C5%AAv%20Vikmanis">�v Vikmanis</a></td><td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>2:8</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>12:27</td><td class=br>-15</td>
<td class=bc>1 - 1 - 6</td>
<td class=br><strong>3</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>D</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=429&x=-53&p=Ro%20Forsberg">Ro Forsberg</a></td><td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kW>1:0</td>
<td class=kT>0:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>7:20</td><td class=br>-13</td>
<td class=bc>1 - 1 - 6</td>
<td class=br><strong>3</strong></td><td class=d>9.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Forsberg Robert</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Ulfvensj� Lars</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Forsberg Robert</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Kudrytsky Dmytro</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ulfvensj� Lars</td><td class=bc>-</td><td class=blW>Pylypenko Oleksandr</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Kudrytsky Dmytro</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Forsberg Robert</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ulfvensj� Lars</td><td class=bc>-</td><td class=bl>Kudrytsky Dmytro</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Kudrytsky Dmytro</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Ulfvensj� Lars</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Forsberg Robert</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Kudrytsky Dmytro</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>Forsberg Robert</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ulfvensj� Lars</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Kudrytsky Dmytro</td><td class=bc>-</td><td class=bl>Forsberg Robert</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Forsberg Robert</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kudrytsky Dmytro</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Forsberg Robert</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kudrytsky Dmytro</td><td class=bc>-</td><td class=blW>Pylypenko Oleksandr</td><td class=bc>3 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
