<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>ECh 2024 Challenge</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="ECh_2024_Challenge_list.php">ECh 2024 Challenge</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 5</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=114&x=-53&p=An%20Bo%C5%BEi%C4%8D">An Bo�i�</a></td><td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>35:10</td><td class=br>+25</td>
<td class=bc>8 - 0 - 1</td>
<td class=br><strong>16</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=36&x=-53&p=Ro%20Verbi%C4%8Ds">Ro Verbi�s</a></td><td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>7:0</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=br>38:14</td><td class=br>+24</td>
<td class=bc>6 - 1 - 2</td>
<td class=br><strong>13</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=34&x=-53&p=J%C4%93%20Re%C4%B7is">J� Re�is</a></td><td class=kW>3:1</td>
<td class=kL>0:7</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>4:6</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=br>28:19</td><td class=br>+9</td>
<td class=bc>6 - 0 - 3</td>
<td class=br><strong>12</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=202&x=-53&p=Vl%20Voronov">Vl Voronov</a></td><td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=br>26:27</td><td class=br>-1</td>
<td class=bc>5 - 0 - 4</td>
<td class=br><strong>10</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=253&x=-53&p=Ra%20St%C4%81lmanis">Ra St�lmanis</a></td><td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>6:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=br>21:23</td><td class=br>-2</td>
<td class=bc>5 - 0 - 4</td>
<td class=br><strong>10</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=72&x=-53&p=Fr%20Platons">Fr Platons</a></td><td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=br>19:22</td><td class=br>-3</td>
<td class=bc>4 - 1 - 4</td>
<td class=br><strong>9</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>C</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=137&x=-53&p=J%C4%81%20Z%C4%81l%C4%ABte">J� Z�l�te</a></td><td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=br>23:23</td><td class=br>0</td>
<td class=bc>4 - 0 - 5</td>
<td class=br><strong>8</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>C</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=199&x=-53&p=Ro%20Purmalis">Ro Purmalis</a></td><td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>3:7</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=br>20:31</td><td class=br>-11</td>
<td class=bc>3 - 0 - 6</td>
<td class=br><strong>6</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>D</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=84&x=-53&p=%C4%A2i%20Vazoli%C5%86%C5%A1">�i Vazoli��</a></td><td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=br>13:22</td><td class=br>-9</td>
<td class=bc>2 - 2 - 5</td>
<td class=br><strong>6</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>D</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=352&x=-53&p=Da%20B%C4%93rzi%C5%86%C5%A1">Da B�rzi��</a></td><td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=br>4:36</td><td class=br>-32</td>
<td class=bc>0 - 0 - 9</td>
<td class=br><strong>0</strong></td><td class=d>10.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>B�rzi�� Dagnis Marsels</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Z�l�te J�nis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Z�l�te J�nis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>B�rzi�� Dagnis Marsels</td><td class=bc>-</td><td class=blW>Voronov Vladimir</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Purmalis Roberts</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Z�l�te J�nis</td><td class=bc>-</td><td class=blW>Voronov Vladimir</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>B�rzi�� Dagnis Marsels</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Z�l�te J�nis</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>B�rzi�� Dagnis Marsels</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>B�rzi�� Dagnis Marsels</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Purmalis Roberts</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>B�rzi�� Dagnis Marsels</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>B�rzi�� Dagnis Marsels</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>B�rzi�� Dagnis Marsels</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Z�l�te J�nis</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Purmalis Roberts</td><td class=bc>-</td><td class=bl>B�rzi�� Dagnis Marsels</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Z�l�te J�nis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Voronov Vladimir</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>B�rzi�� Dagnis Marsels</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Z�l�te J�nis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>3 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
