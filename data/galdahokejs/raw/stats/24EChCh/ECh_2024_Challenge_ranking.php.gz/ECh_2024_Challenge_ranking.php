<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>ECh 2024 Challenge</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="ECh_2024_Challenge_list.php">Final Ranking</a></span></h2></div></div></div></div><h3 align="right">ECh 2024 Challenge&nbsp;&nbsp;</h3>
<p><div align="center">
<p class=v><br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0 class="rnk">
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">M</th>
<th align="center">+</th>
<th align="center">=</th>
<th align="center">-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">P</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al><a href="stats.php?idpl=44&x=-53&p=Naglis%20Kristaps">Naglis Kristaps</a></td>
<td class=al>LAT</td>
<td class=ar>28</td>
<td class=ar>19</td>
<td class=ar>5</td>
<td class=ar>4</td>
<td class=ar>120</td>
<td class=al>&nbsp;:&nbsp;63</td>
<td class=ar>43</td>
</tr><tr><td class=br>2.</td>
<td class=bl><a href="stats.php?idpl=39&x=-53&p=Rieksti%C5%86%C5%A1%20Kristaps">Rieksti�� Kristaps</a></td>
<td class=bl>LAT</td>
<td class=br>28</td>
<td class=br>20</td>
<td class=br>4</td>
<td class=br>4</td>
<td class=br>110</td>
<td class=bl>&nbsp;:&nbsp;51</td>
<td class=br>44</td>
</tr><tr><td class=ar>3.</td>
<td class=al><a href="stats.php?idpl=34&x=-53&p=Re%C4%B7is%20J%C4%93kabs">Re�is J�kabs</a></td>
<td class=al>LAT</td>
<td class=ar>28</td>
<td class=ar>15</td>
<td class=ar>3</td>
<td class=ar>10</td>
<td class=ar>82</td>
<td class=al>&nbsp;:&nbsp;69</td>
<td class=ar>33</td>
</tr><tr><td class=br>4.</td>
<td class=bl><a href="stats.php?idpl=70&x=-53&p=Kuz%C5%86ecovs%20Andrejs">Kuz�ecovs Andrejs</a></td>
<td class=bl>LAT</td>
<td class=br>28</td>
<td class=br>16</td>
<td class=br>3</td>
<td class=br>9</td>
<td class=br>96</td>
<td class=bl>&nbsp;:&nbsp;77</td>
<td class=br>35</td>
</tr><tr><td class=ar>5.</td>
<td class=al><a href="stats.php?idpl=123&x=-53&p=Jurka%20Lukass">Jurka Lukass</a></td>
<td class=al>LAT</td>
<td class=ar>20</td>
<td class=ar>14</td>
<td class=ar>3</td>
<td class=ar>3</td>
<td class=ar>67</td>
<td class=al>&nbsp;:&nbsp;29</td>
<td class=ar>31</td>
</tr><tr><td class=br>6.</td>
<td class=bl><a href="stats.php?idpl=30&x=-53&p=Jakseboga%20Mat%C4%ABss">Jakseboga Mat�ss</a></td>
<td class=bl>LAT</td>
<td class=br>19</td>
<td class=br>11</td>
<td class=br>4</td>
<td class=br>4</td>
<td class=br>72</td>
<td class=bl>&nbsp;:&nbsp;46</td>
<td class=br>26</td>
</tr><tr><td class=ar>7.</td>
<td class=al><a href="stats.php?idpl=163&x=-53&p=Remeika%20Zygimantas">Remeika Zygimantas</a></td>
<td class=al>LTU</td>
<td class=ar>20</td>
<td class=ar>15</td>
<td class=ar>2</td>
<td class=ar>3</td>
<td class=ar>79</td>
<td class=al>&nbsp;:&nbsp;29</td>
<td class=ar>32</td>
</tr><tr><td class=br>8.</td>
<td class=bl><a href="stats.php?idpl=235&x=-53&p=Fjermestad%20Andreas">Fjermestad Andreas</a></td>
<td class=bl>NOR</td>
<td class=br>19</td>
<td class=br>13</td>
<td class=br>0</td>
<td class=br>6</td>
<td class=br>69</td>
<td class=bl>&nbsp;:&nbsp;45</td>
<td class=br>26</td>
</tr><tr><td class=ar>9.</td>
<td class=al><a href="stats.php?idpl=36&x=-53&p=Verbi%C4%8Ds%20Roberts">Verbi�s Roberts</a></td>
<td class=al>LAT</td>
<td class=ar>20</td>
<td class=ar>12</td>
<td class=ar>3</td>
<td class=ar>5</td>
<td class=ar>81</td>
<td class=al>&nbsp;:&nbsp;41</td>
<td class=ar>27</td>
</tr><tr><td class=br>10.</td>
<td class=bl><a href="stats.php?idpl=186&x=-53&p=Kamzols%20R%C5%ABdolfs">Kamzols R�dolfs</a></td>
<td class=bl>LAT</td>
<td class=br>19</td>
<td class=br>12</td>
<td class=br>3</td>
<td class=br>4</td>
<td class=br>70</td>
<td class=bl>&nbsp;:&nbsp;41</td>
<td class=br>27</td>
</tr><tr><td class=ar>11.</td>
<td class=al><a href="stats.php?idpl=97&x=-53&p=Lasmanis%20Gints">Lasmanis Gints</a></td>
<td class=al>LAT</td>
<td class=ar>20</td>
<td class=ar>14</td>
<td class=ar>3</td>
<td class=ar>3</td>
<td class=ar>70</td>
<td class=al>&nbsp;:&nbsp;38</td>
<td class=ar>31</td>
</tr><tr><td class=br>12.</td>
<td class=bl><a href="stats.php?idpl=11&x=-53&p=Putni%C5%86%C5%A1%20Edgars">Putni�� Edgars</a></td>
<td class=bl>LAT</td>
<td class=br>19</td>
<td class=br>9</td>
<td class=br>3</td>
<td class=br>7</td>
<td class=br>68</td>
<td class=bl>&nbsp;:&nbsp;55</td>
<td class=br>21</td>
</tr><tr><td class=ar>13.</td>
<td class=al><a href="stats.php?idpl=69&x=-53&p=Fa%C4%BCken%C5%A1teins%20Rom%C4%81ns">Fa�ken�teins Rom�ns</a></td>
<td class=al>LAT</td>
<td class=ar>19</td>
<td class=ar>10</td>
<td class=ar>4</td>
<td class=ar>5</td>
<td class=ar>51</td>
<td class=al>&nbsp;:&nbsp;41</td>
<td class=ar>24</td>
</tr><tr><td class=br>14.</td>
<td class=bl><a href="stats.php?idpl=25&x=-53&p=Bitmanis%20J%C4%81nis%20Mi%C4%B7elis">Bitmanis J�nis Mi�elis</a></td>
<td class=bl>LAT</td>
<td class=br>19</td>
<td class=br>9</td>
<td class=br>4</td>
<td class=br>6</td>
<td class=br>46</td>
<td class=bl>&nbsp;:&nbsp;45</td>
<td class=br>22</td>
</tr><tr><td class=ar>15.</td>
<td class=al><a href="stats.php?idpl=121&x=-53&p=Hermansson%20Gustaf">Hermansson Gustaf</a></td>
<td class=al>SWE</td>
<td class=ar>19</td>
<td class=ar>8</td>
<td class=ar>5</td>
<td class=ar>6</td>
<td class=ar>62</td>
<td class=al>&nbsp;:&nbsp;51</td>
<td class=ar>21</td>
</tr><tr><td class=br>16.</td>
<td class=bl><a href="stats.php?idpl=31&x=-53&p=L%C4%81cis%20Niks">L�cis Niks</a></td>
<td class=bl>LAT</td>
<td class=br>20</td>
<td class=br>10</td>
<td class=br>2</td>
<td class=br>8</td>
<td class=br>76</td>
<td class=bl>&nbsp;:&nbsp;64</td>
<td class=br>22</td>
</tr><tr><td class=ar>17.</td>
<td class=al><a href="stats.php?idpl=201&x=-53&p=R%C4%81cen%C4%81ja%20El%C4%93na">R�cen�ja El�na</a></td>
<td class=al>LAT</td>
<td class=ar>20</td>
<td class=ar>9</td>
<td class=ar>1</td>
<td class=ar>10</td>
<td class=ar>77</td>
<td class=al>&nbsp;:&nbsp;55</td>
<td class=ar>19</td>
</tr><tr><td class=br>18.</td>
<td class=bl><a href="stats.php?idpl=202&x=-53&p=Voronov%20Vladimir">Voronov Vladimir</a></td>
<td class=bl>LTU</td>
<td class=br>20</td>
<td class=br>9</td>
<td class=br>0</td>
<td class=br>11</td>
<td class=br>51</td>
<td class=bl>&nbsp;:&nbsp;66</td>
<td class=br>18</td>
</tr><tr><td class=ar>19.</td>
<td class=al><a href="stats.php?idpl=133&x=-53&p=Pleikys%20Audrius">Pleikys Audrius</a></td>
<td class=al>LTU</td>
<td class=ar>19</td>
<td class=ar>8</td>
<td class=ar>3</td>
<td class=ar>8</td>
<td class=ar>56</td>
<td class=al>&nbsp;:&nbsp;53</td>
<td class=ar>19</td>
</tr><tr><td class=br>20.</td>
<td class=bl><a href="stats.php?idpl=427&x=-53&p=Forsberg%20James-John">Forsberg James-John</a></td>
<td class=bl>SWE</td>
<td class=br>20</td>
<td class=br>8</td>
<td class=br>4</td>
<td class=br>8</td>
<td class=br>64</td>
<td class=bl>&nbsp;:&nbsp;58</td>
<td class=br>20</td>
</tr><tr><td class=ar>21.</td>
<td class=al><a href="stats.php?idpl=114&x=-53&p=Bo%C5%BEi%C4%8D%20An%C5%BEe">Bo�i� An�e</a></td>
<td class=al>SLO</td>
<td class=ar>20</td>
<td class=ar>11</td>
<td class=ar>1</td>
<td class=ar>8</td>
<td class=ar>62</td>
<td class=al>&nbsp;:&nbsp;46</td>
<td class=ar>23</td>
</tr><tr><td class=br>22.</td>
<td class=bl><a href="stats.php?idpl=79&x=-53&p=Saul%C4%ABtis%20Mikus">Saul�tis Mikus</a></td>
<td class=bl>LAT</td>
<td class=br>20</td>
<td class=br>6</td>
<td class=br>3</td>
<td class=br>11</td>
<td class=br>57</td>
<td class=bl>&nbsp;:&nbsp;66</td>
<td class=br>15</td>
</tr><tr><td class=ar>23.</td>
<td class=al><a href="stats.php?idpl=374&x=-53&p=Kudrytsky%20Dmytro">Kudrytsky Dmytro</a></td>
<td class=al>UKR</td>
<td class=ar>19</td>
<td class=ar>5</td>
<td class=ar>1</td>
<td class=ar>13</td>
<td class=ar>34</td>
<td class=al>&nbsp;:&nbsp;56</td>
<td class=ar>11</td>
</tr><tr><td class=br>24.</td>
<td class=bl><a href="stats.php?idpl=162&x=-53&p=Remeika%20Gintautas">Remeika Gintautas</a></td>
<td class=bl>LTU</td>
<td class=br>19</td>
<td class=br>4</td>
<td class=br>3</td>
<td class=br>12</td>
<td class=br>41</td>
<td class=bl>&nbsp;:&nbsp;65</td>
<td class=br>11</td>
</tr><tr><td class=ar>25.</td>
<td class=al><a href="stats.php?idpl=122&x=-53&p=Henttonen%20Ville">Henttonen Ville</a></td>
<td class=al>FIN</td>
<td class=ar>19</td>
<td class=ar>14</td>
<td class=ar>1</td>
<td class=ar>4</td>
<td class=ar>63</td>
<td class=al>&nbsp;:&nbsp;36</td>
<td class=ar>29</td>
</tr><tr><td class=br>26.</td>
<td class=bl><a href="stats.php?idpl=45&x=-53&p=Skudr%C4%ABtis%20Alekss">Skudr�tis Alekss</a></td>
<td class=bl>LAT</td>
<td class=br>19</td>
<td class=br>13</td>
<td class=br>2</td>
<td class=br>4</td>
<td class=br>68</td>
<td class=bl>&nbsp;:&nbsp;47</td>
<td class=br>28</td>
</tr><tr><td class=ar>27.</td>
<td class=al><a href="stats.php?idpl=77&x=-53&p=G%C5%ABze%20Ein%C4%81rs">G�ze Ein�rs</a></td>
<td class=al>LAT</td>
<td class=ar>19</td>
<td class=ar>10</td>
<td class=ar>2</td>
<td class=ar>7</td>
<td class=ar>44</td>
<td class=al>&nbsp;:&nbsp;46</td>
<td class=ar>22</td>
</tr><tr><td class=br>28.</td>
<td class=bl><a href="stats.php?idpl=124&x=-53&p=Skrlep%20Nejc">Skrlep Nejc</a></td>
<td class=bl>SLO</td>
<td class=br>19</td>
<td class=br>10</td>
<td class=br>2</td>
<td class=br>7</td>
<td class=br>65</td>
<td class=bl>&nbsp;:&nbsp;62</td>
<td class=br>22</td>
</tr><tr><td class=ar>29.</td>
<td class=al><a href="stats.php?idpl=47&x=-53&p=Jakseboga%20Toms">Jakseboga Toms</a></td>
<td class=al>LAT</td>
<td class=ar>20</td>
<td class=ar>9</td>
<td class=ar>2</td>
<td class=ar>9</td>
<td class=ar>49</td>
<td class=al>&nbsp;:&nbsp;57</td>
<td class=ar>20</td>
</tr><tr><td class=br>30.</td>
<td class=bl><a href="stats.php?idpl=367&x=-53&p=Pylypenko%20Oleksandr">Pylypenko Oleksandr</a></td>
<td class=bl>UKR</td>
<td class=br>19</td>
<td class=br>8</td>
<td class=br>1</td>
<td class=br>10</td>
<td class=br>49</td>
<td class=bl>&nbsp;:&nbsp;63</td>
<td class=br>17</td>
</tr><tr><td class=ar>31.</td>
<td class=al><a href="stats.php?idpl=72&x=-53&p=Platons%20Fredijs">Platons Fredijs</a></td>
<td class=al>LAT</td>
<td class=ar>20</td>
<td class=ar>8</td>
<td class=ar>2</td>
<td class=ar>10</td>
<td class=ar>44</td>
<td class=al>&nbsp;:&nbsp;47</td>
<td class=ar>18</td>
</tr><tr><td class=br>32.</td>
<td class=bl><a href="stats.php?idpl=18&x=-53&p=Zarinieks%20Kristaps">Zarinieks Kristaps</a></td>
<td class=bl>LAT</td>
<td class=br>19</td>
<td class=br>5</td>
<td class=br>6</td>
<td class=br>8</td>
<td class=br>57</td>
<td class=bl>&nbsp;:&nbsp;67</td>
<td class=br>16</td>
</tr><tr><td class=ar>33.</td>
<td class=al><a href="stats.php?idpl=90&x=-53&p=Reinfelds%20Em%C4%ABls%20Matiass">Reinfelds Em�ls Matiass</a></td>
<td class=al>LAT</td>
<td class=ar>20</td>
<td class=ar>8</td>
<td class=ar>2</td>
<td class=ar>10</td>
<td class=ar>55</td>
<td class=al>&nbsp;:&nbsp;55</td>
<td class=ar>18</td>
</tr><tr><td class=br>34.</td>
<td class=bl><a href="stats.php?idpl=144&x=-53&p=Pavlovskis%20Ilgvars">Pavlovskis Ilgvars</a></td>
<td class=bl>LAT</td>
<td class=br>20</td>
<td class=br>6</td>
<td class=br>3</td>
<td class=br>11</td>
<td class=br>42</td>
<td class=bl>&nbsp;:&nbsp;50</td>
<td class=br>15</td>
</tr><tr><td class=ar>35.</td>
<td class=al><a href="stats.php?idpl=426&x=-53&p=Wallin%20Wilton">Wallin Wilton</a></td>
<td class=al>SWE</td>
<td class=ar>20</td>
<td class=ar>6</td>
<td class=ar>2</td>
<td class=ar>12</td>
<td class=ar>63</td>
<td class=al>&nbsp;:&nbsp;67</td>
<td class=ar>14</td>
</tr><tr><td class=br>36.</td>
<td class=bl><a href="stats.php?idpl=253&x=-53&p=St%C4%81lmanis%20Raimonds">St�lmanis Raimonds</a></td>
<td class=bl>LAT</td>
<td class=br>20</td>
<td class=br>6</td>
<td class=br>2</td>
<td class=br>12</td>
<td class=br>36</td>
<td class=bl>&nbsp;:&nbsp;62</td>
<td class=br>14</td>
</tr><tr><td class=ar>37.</td>
<td class=al><a href="stats.php?idpl=424&x=-53&p=Ulfvensj%C3%B6%20Lars">Ulfvensj� Lars</a></td>
<td class=al>SWE</td>
<td class=ar>19</td>
<td class=ar>9</td>
<td class=ar>5</td>
<td class=ar>5</td>
<td class=ar>50</td>
<td class=al>&nbsp;:&nbsp;38</td>
<td class=ar>23</td>
</tr><tr><td class=br>38.</td>
<td class=bl><a href="stats.php?idpl=137&x=-53&p=Z%C4%81l%C4%ABte%20J%C4%81nis">Z�l�te J�nis</a></td>
<td class=bl>LAT</td>
<td class=br>20</td>
<td class=br>11</td>
<td class=br>2</td>
<td class=br>7</td>
<td class=br>62</td>
<td class=bl>&nbsp;:&nbsp;45</td>
<td class=br>24</td>
</tr><tr><td class=ar>39.</td>
<td class=al><a href="stats.php?idpl=10001&x=-53&p=%C4%80bele%20Margarita">�bele Margarita</a></td>
<td class=al>LAT</td>
<td class=ar>20</td>
<td class=ar>11</td>
<td class=ar>1</td>
<td class=ar>8</td>
<td class=ar>60</td>
<td class=al>&nbsp;:&nbsp;39</td>
<td class=ar>23</td>
</tr><tr><td class=br>40.</td>
<td class=bl><a href="stats.php?idpl=75&x=-53&p=Bezdel%C4%ABga%20L%C4%81sma">Bezdel�ga L�sma</a></td>
<td class=bl>LAT</td>
<td class=br>19</td>
<td class=br>8</td>
<td class=br>4</td>
<td class=br>7</td>
<td class=br>43</td>
<td class=bl>&nbsp;:&nbsp;42</td>
<td class=br>20</td>
</tr><tr><td class=ar>41.</td>
<td class=al><a href="stats.php?idpl=198&x=-53&p=Verbi%C4%8Ds%20Art%C5%ABrs">Verbi�s Art�rs</a></td>
<td class=al>LAT</td>
<td class=ar>20</td>
<td class=ar>9</td>
<td class=ar>3</td>
<td class=ar>8</td>
<td class=ar>43</td>
<td class=al>&nbsp;:&nbsp;50</td>
<td class=ar>21</td>
</tr><tr><td class=br>42.</td>
<td class=bl><a href="stats.php?idpl=71&x=-53&p=Baumanis%20Danilo">Baumanis Danilo</a></td>
<td class=bl>LAT</td>
<td class=br>19</td>
<td class=br>8</td>
<td class=br>1</td>
<td class=br>10</td>
<td class=br>34</td>
<td class=bl>&nbsp;:&nbsp;48</td>
<td class=br>17</td>
</tr><tr><td class=ar>43.</td>
<td class=al><a href="stats.php?idpl=197&x=-53&p=Vikmanis%20%C5%AAve">Vikmanis �ve</a></td>
<td class=al>LAT</td>
<td class=ar>19</td>
<td class=ar>5</td>
<td class=ar>4</td>
<td class=ar>10</td>
<td class=ar>43</td>
<td class=al>&nbsp;:&nbsp;52</td>
<td class=ar>14</td>
</tr><tr><td class=br>44.</td>
<td class=bl><a href="stats.php?idpl=433&x=-53&p=P%C3%B6ssl%20Susanna">P�ssl Susanna</a></td>
<td class=bl>SWE</td>
<td class=br>20</td>
<td class=br>7</td>
<td class=br>2</td>
<td class=br>11</td>
<td class=br>49</td>
<td class=bl>&nbsp;:&nbsp;65</td>
<td class=br>16</td>
</tr><tr><td class=ar>45.</td>
<td class=al><a href="stats.php?idpl=199&x=-53&p=Purmalis%20Roberts">Purmalis Roberts</a></td>
<td class=al>LAT</td>
<td class=ar>20</td>
<td class=ar>7</td>
<td class=ar>0</td>
<td class=ar>13</td>
<td class=ar>41</td>
<td class=al>&nbsp;:&nbsp;69</td>
<td class=ar>14</td>
</tr><tr><td class=br>46.</td>
<td class=bl><a href="stats.php?idpl=418&x=-53&p=Hermansson%20Alfons">Hermansson Alfons</a></td>
<td class=bl>SWE</td>
<td class=br>19</td>
<td class=br>4</td>
<td class=br>3</td>
<td class=br>12</td>
<td class=br>43</td>
<td class=bl>&nbsp;:&nbsp;52</td>
<td class=br>11</td>
</tr><tr><td class=ar>47.</td>
<td class=al><a href="stats.php?idpl=152&x=-53&p=Ulis%20Tomas">Ulis Tomas</a></td>
<td class=al>LTU</td>
<td class=ar>20</td>
<td class=ar>5</td>
<td class=ar>0</td>
<td class=ar>15</td>
<td class=ar>30</td>
<td class=al>&nbsp;:&nbsp;80</td>
<td class=ar>10</td>
</tr><tr><td class=br>48.</td>
<td class=bl><a href="stats.php?idpl=159&x=-53&p=Saul%C4%ABtis%20Ren%C4%81rs">Saul�tis Ren�rs</a></td>
<td class=bl>LAT</td>
<td class=br>19</td>
<td class=br>1</td>
<td class=br>1</td>
<td class=br>17</td>
<td class=br>23</td>
<td class=bl>&nbsp;:&nbsp;77</td>
<td class=br>3</td>
</tr><tr><td class=ar>49.</td>
<td class=al><a href="stats.php?idpl=429&x=-53&p=Forsberg%20Robert">Forsberg Robert</a></td>
<td class=al>SWE</td>
<td class=ar>16</td>
<td class=ar>8</td>
<td class=ar>1</td>
<td class=ar>7</td>
<td class=ar>40</td>
<td class=al>&nbsp;:&nbsp;27</td>
<td class=ar>17</td>
</tr><tr><td class=br>50.</td>
<td class=bl><a href="stats.php?idpl=220&x=-53&p=Pleikys%20Jonas">Pleikys Jonas</a></td>
<td class=bl>LTU</td>
<td class=br>16</td>
<td class=br>5</td>
<td class=br>4</td>
<td class=br>7</td>
<td class=br>28</td>
<td class=bl>&nbsp;:&nbsp;26</td>
<td class=br>14</td>
</tr><tr><td class=ar>51.</td>
<td class=al><a href="stats.php?idpl=84&x=-53&p=Vazoli%C5%86%C5%A1%20%C4%A2irts">Vazoli�� �irts</a></td>
<td class=al>LAT</td>
<td class=ar>17</td>
<td class=ar>6</td>
<td class=ar>6</td>
<td class=ar>5</td>
<td class=ar>37</td>
<td class=al>&nbsp;:&nbsp;34</td>
<td class=ar>18</td>
</tr><tr><td class=br>52.</td>
<td class=bl><a href="stats.php?idpl=189&x=-53&p=Reinfelds%20Elvis%20Gustavs%20">Reinfelds Elvis Gustavs </a></td>
<td class=bl>LAT</td>
<td class=br>17</td>
<td class=br>6</td>
<td class=br>1</td>
<td class=br>10</td>
<td class=br>38</td>
<td class=bl>&nbsp;:&nbsp;58</td>
<td class=br>13</td>
</tr><tr><td class=ar>53.</td>
<td class=al><a href="stats.php?idpl=352&x=-53&p=B%C4%93rzi%C5%86%C5%A1%20Dagnis%20Marsels">B�rzi�� Dagnis Marsels</a></td>
<td class=al>LAT</td>
<td class=ar>17</td>
<td class=ar>3</td>
<td class=ar>1</td>
<td class=ar>13</td>
<td class=ar>18</td>
<td class=al>&nbsp;:&nbsp;54</td>
<td class=ar>7</td>
</tr><tr><td class=br>54.</td>
<td class=bl><a href="stats.php?idpl=428&x=-53&p=Israelsson%20Anna-Maria">Israelsson Anna-Maria</a></td>
<td class=bl>SWE</td>
<td class=br>17</td>
<td class=br>3</td>
<td class=br>1</td>
<td class=br>13</td>
<td class=br>29</td>
<td class=bl>&nbsp;:&nbsp;78</td>
<td class=br>7</td>
</tr><tr><td class=ar>55.</td>
<td class=al><a href="stats.php?idpl=93&x=-53&p=G%C5%ABtmanis%20Kristers">G�tmanis Kristers</a></td>
<td class=al>LAT</td>
<td class=ar>16</td>
<td class=ar>3</td>
<td class=ar>3</td>
<td class=ar>10</td>
<td class=ar>29</td>
<td class=al>&nbsp;:&nbsp;49</td>
<td class=ar>9</td>
</tr><tr><td class=br>56.</td>
<td class=bl><a href="stats.php?idpl=345&x=-53&p=Meija%20Ralfs">Meija Ralfs</a></td>
<td class=bl>LAT</td>
<td class=br>17</td>
<td class=br>0</td>
<td class=br>4</td>
<td class=br>13</td>
<td class=br>19</td>
<td class=bl>&nbsp;:&nbsp;82</td>
<td class=br>4</td>
</tr><tr><td class=ar>57.</td>
<td class=al><a href="stats.php?idpl=347&x=-53&p=Birzgalis%20Miks">Birzgalis Miks</a></td>
<td class=al>LAT</td>
<td class=ar>17</td>
<td class=ar>0</td>
<td class=ar>1</td>
<td class=ar>16</td>
<td class=ar>11</td>
<td class=al>&nbsp;:&nbsp;92</td>
<td class=ar>1</td>
</tr></table></td></tr></table></div></p>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
