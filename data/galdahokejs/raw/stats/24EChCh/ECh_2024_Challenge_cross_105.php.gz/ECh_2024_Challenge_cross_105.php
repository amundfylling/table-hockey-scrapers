<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>ECh 2024 Challenge</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="ECh_2024_Challenge_list.php">ECh 2024 Challenge</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=424&x=-53&p=La%20Ulfvensj%C3%B6">La Ulfvensj�</a></td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=br>33:14</td><td class=br>+19</td>
<td class=bc>8 - 2 - 1</td>
<td class=br><strong>18</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=137&x=-53&p=J%C4%81%20Z%C4%81l%C4%ABte">J� Z�l�te</a></td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=br>39:22</td><td class=br>+17</td>
<td class=bc>7 - 2 - 2</td>
<td class=br><strong>16</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=10001&x=-53&p=Marg%20%C4%80bele">Marg �bele</a></td><td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=br>32:13</td><td class=br>+19</td>
<td class=bc>7 - 1 - 3</td>
<td class=br><strong>15</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=75&x=-53&p=L%C4%81%20Bezdel%C4%ABga">L� Bezdel�ga</a></td><td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=br>28:18</td><td class=br>+10</td>
<td class=bc>7 - 1 - 3</td>
<td class=br><strong>15</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=198&x=-53&p=Ar%20Verbi%C4%8Ds">Ar Verbi�s</a></td><td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>6:4</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=br>30:22</td><td class=br>+8</td>
<td class=bc>6 - 2 - 3</td>
<td class=br><strong>14</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=71&x=-53&p=Da%20Baumanis">Da Baumanis</a></td><td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=br>21:23</td><td class=br>-2</td>
<td class=bc>6 - 1 - 4</td>
<td class=br><strong>13</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=197&x=-53&p=%C5%AAv%20Vikmanis">�v Vikmanis</a></td><td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=br>31:25</td><td class=br>+6</td>
<td class=bc>4 - 3 - 4</td>
<td class=br><strong>11</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=433&x=-53&p=Su%20P%C3%B6ssl">Su P�ssl</a></td><td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kL>0:8</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=br>29:34</td><td class=br>-5</td>
<td class=bc>4 - 2 - 5</td>
<td class=br><strong>10</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=199&x=-53&p=Ro%20Purmalis">Ro Purmalis</a></td><td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>4:6</td>
<td class=kL>1:2</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=br>21:38</td><td class=br>-17</td>
<td class=bc>4 - 0 - 7</td>
<td class=br><strong>8</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=418&x=-53&p=Al%20Hermansson">Al Hermansson</a></td><td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=br>27:27</td><td class=br>0</td>
<td class=bc>2 - 3 - 6</td>
<td class=br><strong>7</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=152&x=-53&p=To%20Ulis">To Ulis</a></td><td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=br>16:41</td><td class=br>-25</td>
<td class=bc>2 - 0 - 9</td>
<td class=br><strong>4</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=159&x=-53&p=Re%20Saul%C4%ABtis">Re Saul�tis</a></td><td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=br>16:46</td><td class=br>-30</td>
<td class=bc>0 - 1 - 10</td>
<td class=br><strong>1</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ulfvensj� Lars</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>P�ssl Susanna</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ulfvensj� Lars</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Purmalis Roberts</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ulfvensj� Lars</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Purmalis Roberts</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Hermansson Alfons</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ulfvensj� Lars</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Z�l�te J�nis</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>P�ssl Susanna</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Purmalis Roberts</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ulis Tomas</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Z�l�te J�nis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ulfvensj� Lars</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>Vikmanis �ve</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>P�ssl Susanna</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Z�l�te J�nis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=blW>Z�l�te J�nis</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Ulis Tomas</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Z�l�te J�nis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=blW>Ulfvensj� Lars</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Z�l�te J�nis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Purmalis Roberts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Ulfvensj� Lars</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>P�ssl Susanna</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Hermansson Alfons</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>Ulfvensj� Lars</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Purmalis Roberts</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ulfvensj� Lars</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>Purmalis Roberts</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>3 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
