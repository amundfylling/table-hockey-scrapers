<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>ECh 2024 Challenge</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="ECh_2024_Challenge_list.php">ECh 2024 Challenge</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 4</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=163&x=-53&p=Zy%20Remeika">Zy Remeika</a></td><td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>8:1</td>
<td class=kW>6:1</td>
<td class=kW>12:0</td>
<td class=br>41:8</td><td class=br>+33</td>
<td class=bc>9 - 0 - 0</td>
<td class=br><strong>18</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=123&x=-53&p=Lu%20Jurka">Lu Jurka</a></td><td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=br>31:8</td><td class=br>+23</td>
<td class=bc>7 - 1 - 1</td>
<td class=br><strong>15</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=427&x=-53&p=Ja%20Forsberg">Ja Forsberg</a></td><td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>6:5</td>
<td class=kW>7:0</td>
<td class=kW>3:2</td>
<td class=kW>8:0</td>
<td class=kW>5:2</td>
<td class=br>37:16</td><td class=br>+21</td>
<td class=bc>6 - 1 - 2</td>
<td class=br><strong>13</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=79&x=-53&p=Mi%20Saul%C4%ABtis">Mi Saul�tis</a></td><td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>8:1</td>
<td class=br>34:20</td><td class=br>+14</td>
<td class=bc>5 - 2 - 2</td>
<td class=br><strong>12</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=144&x=-53&p=Il%20Pavlovskis">Il Pavlovskis</a></td><td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>20:19</td><td class=br>+1</td>
<td class=bc>4 - 1 - 4</td>
<td class=br><strong>9</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=426&x=-53&p=Wi%20Wallin">Wi Wallin</a></td><td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>5:6</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>9:0</td>
<td class=br>36:25</td><td class=br>+11</td>
<td class=bc>4 - 0 - 5</td>
<td class=br><strong>8</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>C</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=198&x=-53&p=Ar%20Verbi%C4%8Ds">Ar Verbi�s</a></td><td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=br>13:28</td><td class=br>-15</td>
<td class=bc>3 - 1 - 5</td>
<td class=br><strong>7</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>C</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=433&x=-53&p=Su%20P%C3%B6ssl">Su P�ssl</a></td><td class=kL>1:8</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=br>20:31</td><td class=br>-11</td>
<td class=bc>3 - 0 - 6</td>
<td class=br><strong>6</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>D</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=189&x=-53&p=El%20Reinfelds">El Reinfelds</a></td><td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=br>8:37</td><td class=br>-29</td>
<td class=bc>1 - 0 - 8</td>
<td class=br><strong>2</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>D</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=347&x=-53&p=Mi%20Birzgalis">Mi Birzgalis</a></td><td class=kL>0:12</td>
<td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>0:9</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=br>5:53</td><td class=br>-48</td>
<td class=bc>0 - 0 - 9</td>
<td class=br><strong>0</strong></td><td class=d>10.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Birzgalis Miks</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Jurka Lukass</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>1 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Birzgalis Miks</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Birzgalis Miks</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>0 : 12</tr></td>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Jurka Lukass</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Birzgalis Miks</td><td class=bc>-</td><td class=blW>P�ssl Susanna</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Birzgalis Miks</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>P�ssl Susanna</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>P�ssl Susanna</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Pavlovskis Ilgvars</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Jurka Lukass</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Forsberg James-John</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>Birzgalis Miks</td><td class=bc>9 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=blW>Pavlovskis Ilgvars</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Birzgalis Miks</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=blW>Forsberg James-John</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Birzgalis Miks</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Jurka Lukass</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Birzgalis Miks</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>P�ssl Susanna</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Wallin Wilton</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Birzgalis Miks</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pavlovskis Ilgvars</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>P�ssl Susanna</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>1 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
