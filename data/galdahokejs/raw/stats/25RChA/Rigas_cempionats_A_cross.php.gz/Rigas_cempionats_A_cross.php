<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Rigas cempionats A</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../25RChA/Rigas_cempionats_A_index.php">Rigas cempionats A, 15. November 2025</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group A grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>B</td><td class=d>1.</td><td class=kt>Ra Kalni��</td><td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>6:5</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kW>7:3</td>
<td class=kW>13:0</td>
<td class=kW>7:0</td>
<td class=kW>11:3</td>
<td class=kW>12:3</td>
<td class=kW>9:1</td>
<td class=kW>9:4</td>
<td class=br>100:32</td><td class=br>+68</td>
<td class=bc>14 - 0 - 0</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>B</td><td class=d>2.</td><td class=kt>Kr Naglis</td><td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kW>5:3</td>
<td class=kW>6:4</td>
<td class=kW>4:1</td>
<td class=br>53:33</td><td class=br>+20</td>
<td class=bc>11 - 0 - 3</td>
<td class=br><strong>22</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>B</td><td class=d>3.</td><td class=kt>Al Sili��</td><td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>3:6</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=kW>7:2</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=br>53:32</td><td class=br>+21</td>
<td class=bc>10 - 1 - 3</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>B</td><td class=d>4.</td><td class=kt>Ro Fa�ken�teins</td><td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=br>38:21</td><td class=br>+17</td>
<td class=bc>8 - 3 - 3</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt>Al �ernovojs</td><td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kW>6:3</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>9:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=br>46:37</td><td class=br>+9</td>
<td class=bc>8 - 1 - 5</td>
<td class=br><strong>17</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt>Marg �bele</td><td class=kL>5:6</td>
<td class=kW>6:3</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=br>43:31</td><td class=br>+12</td>
<td class=bc>8 - 0 - 6</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>C</td><td class=d>7.</td><td class=kt>D� Apfelbaums</td><td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kW>6:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>6:0</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=br>49:26</td><td class=br>+23</td>
<td class=bc>7 - 2 - 5</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>C</td><td class=d>8.</td><td class=kt>Kr Kurzemnieks</td><td class=kL>3:6</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>6:5</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=br>44:52</td><td class=br>-8</td>
<td class=bc>5 - 4 - 5</td>
<td class=br><strong>14</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>C</td><td class=d>9.</td><td class=kt>El R�cen�ja</td><td class=kL>3:7</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kW>2:0</td>
<td class=kT>4:4</td>
<td class=kL>5:6</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=br>52:42</td><td class=br>+10</td>
<td class=bc>6 - 2 - 6</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>C</td><td class=d>10.</td><td class=kt>Kr Zarinieks</td><td class=kL>0:13</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=br>32:57</td><td class=br>-25</td>
<td class=bc>5 - 3 - 6</td>
<td class=br><strong>13</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>Ra Martu��ns</td><td class=kL>0:7</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kL>1:3</td>
<td class=kW>1:0</td>
<td class=br>31:43</td><td class=br>-12</td>
<td class=bc>3 - 3 - 8</td>
<td class=br><strong>9</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>D</td><td class=d>12.</td><td class=kt>Ag Pav�rs</td><td class=kL>3:11</td>
<td class=kL>0:7</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=br>23:56</td><td class=br>-33</td>
<td class=bc>3 - 2 - 9</td>
<td class=br><strong>8</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>D</td><td class=d>13.</td><td class=kt>Ge Jansons</td><td class=kL>3:12</td>
<td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>3:9</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=br>30:72</td><td class=br>-42</td>
<td class=bc>2 - 1 - 11</td>
<td class=br><strong>5</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>D</td><td class=d>14.</td><td class=kt>El Reinfelds</td><td class=kL>1:9</td>
<td class=kL>4:6</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kL>1:6</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=br>27:60</td><td class=br>-33</td>
<td class=bc>2 - 0 - 12</td>
<td class=br><strong>4</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ro Aseri��</td><td class=kL>4:9</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=br>18:45</td><td class=br>-27</td>
<td class=bc>0 - 4 - 10</td>
<td class=br><strong>4</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>11 : 3</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Kr Kurzemnieks</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>Ge Jansons</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Kr Kurzemnieks</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Kr Kurzemnieks</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ge Jansons</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>El Reinfelds</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>12 : 3</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>9 : 4</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>13 : 0</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>4 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group B grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>B</td><td class=d>1.</td><td class=kt>Ro Rieksti��</td><td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>8:1</td>
<td class=kL>2:3</td>
<td class=br>62:23</td><td class=br>+39</td>
<td class=bc>12 - 1 - 1</td>
<td class=br><strong>25</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>B</td><td class=d>2.</td><td class=kt>He Prokuratovs</td><td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kW>7:1</td>
<td class=kW>7:2</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=br>53:28</td><td class=br>+25</td>
<td class=bc>9 - 2 - 3</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>B</td><td class=d>3.</td><td class=kt>Sa Kalni��</td><td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>9:0</td>
<td class=kW>3:1</td>
<td class=br>47:30</td><td class=br>+17</td>
<td class=bc>9 - 2 - 3</td>
<td class=br><strong>20</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>B</td><td class=d>4.</td><td class=kt>Kr Zem�ickis</td><td class=kL>4:5</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kL>3:5</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=br>51:25</td><td class=br>+26</td>
<td class=bc>8 - 3 - 3</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt>Ar Zasurcevs</td><td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>12:2</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>7:5</td>
<td class=br>54:34</td><td class=br>+20</td>
<td class=bc>7 - 5 - 2</td>
<td class=br><strong>19</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt>Ed Naglis</td><td class=kL>2:4</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>6:5</td>
<td class=kL>3:5</td>
<td class=kW>7:2</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>8:3</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>6:1</td>
<td class=br>62:38</td><td class=br>+24</td>
<td class=bc>9 - 1 - 4</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>C</td><td class=d>7.</td><td class=kt>Iv �irsis</td><td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kL>5:6</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=br>48:39</td><td class=br>+9</td>
<td class=bc>8 - 1 - 5</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>C</td><td class=d>8.</td><td class=kt>Gu Ern�teins</td><td class=kL>0:6</td>
<td class=kL>2:7</td>
<td class=kL>3:5</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=br>38:51</td><td class=br>-13</td>
<td class=bc>6 - 1 - 7</td>
<td class=br><strong>13</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>C</td><td class=d>9.</td><td class=kt>Ro Kerns</td><td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kW>5:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=br>33:43</td><td class=br>-10</td>
<td class=bc>6 - 0 - 8</td>
<td class=br><strong>12</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>C</td><td class=d>10.</td><td class=kt>To Jakseboga</td><td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kW>8:1</td>
<td class=kW>3:1</td>
<td class=br>38:37</td><td class=br>+1</td>
<td class=bc>6 - 0 - 8</td>
<td class=br><strong>12</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>Ai Romals</td><td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kL>1:4</td>
<td class=kW>9:2</td>
<td class=kW>6:2</td>
<td class=br>38:40</td><td class=br>-2</td>
<td class=bc>4 - 3 - 7</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>D</td><td class=d>12.</td><td class=kt>Er Kalni��</td><td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>2:12</td>
<td class=kL>3:8</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=br>24:58</td><td class=br>-34</td>
<td class=bc>4 - 1 - 9</td>
<td class=br><strong>9</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>D</td><td class=d>13.</td><td class=kt>M� �irsis</td><td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>4:5</td>
<td class=kW>5:3</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=br>39:47</td><td class=br>-8</td>
<td class=bc>4 - 0 - 10</td>
<td class=br><strong>8</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>D</td><td class=d>14.</td><td class=kt>M� Timbers</td><td class=kL>1:8</td>
<td class=kL>2:6</td>
<td class=kL>0:9</td>
<td class=kL>0:6</td>
<td class=kL>3:5</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>1:8</td>
<td class=kL>2:9</td>
<td class=kL>1:2</td>
<td class=kL>2:7</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=br>24:78</td><td class=br>-54</td>
<td class=bc>1 - 1 - 12</td>
<td class=br><strong>3</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>As Kocere</td><td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>5:7</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=br>22:62</td><td class=br>-40</td>
<td class=bc>1 - 1 - 12</td>
<td class=br><strong>3</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Gu Ern�teins</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>M� Timbers</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>As Kocere</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>12 : 2</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Gu Ern�teins</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Gu Ern�teins</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>5 : 7</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>1 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group C grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>B</td><td class=d>1.</td><td class=kt>El Sili��</td><td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>6:4</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=br>61:23</td><td class=br>+38</td>
<td class=bc>10 - 3 - 1</td>
<td class=br><strong>23</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>B</td><td class=d>2.</td><td class=kt>Ra Kuha�skis</td><td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=kW>7:4</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>7:0</td>
<td class=kW>4:3</td>
<td class=br>61:35</td><td class=br>+26</td>
<td class=bc>10 - 3 - 1</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>B</td><td class=d>3.</td><td class=kt>Kr Lagzdi�a</td><td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=br>53:26</td><td class=br>+27</td>
<td class=bc>9 - 4 - 1</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>B</td><td class=d>4.</td><td class=kt>Se Mihejevs</td><td class=kW>1:0</td>
<td class=kL>4:5</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kW>6:0</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=br>37:23</td><td class=br>+14</td>
<td class=bc>9 - 2 - 3</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt>Sa Krasts</td><td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=br>46:24</td><td class=br>+22</td>
<td class=bc>7 - 3 - 4</td>
<td class=br><strong>17</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt>Ri Kalni��</td><td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=br>36:30</td><td class=br>+6</td>
<td class=bc>7 - 3 - 4</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>C</td><td class=d>7.</td><td class=kt>Mi Saul�tis</td><td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kL>2:4</td>
<td class=kW>7:0</td>
<td class=kW>7:0</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=br>51:32</td><td class=br>+19</td>
<td class=bc>6 - 4 - 4</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>C</td><td class=d>8.</td><td class=kt>Fi Buhtujevs</td><td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>3:1</td>
<td class=kW>7:3</td>
<td class=kW>10:1</td>
<td class=br>50:35</td><td class=br>+15</td>
<td class=bc>7 - 2 - 5</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>C</td><td class=d>9.</td><td class=kt>Ra Neija</td><td class=kL>4:6</td>
<td class=kL>4:7</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kW>7:3</td>
<td class=br>49:45</td><td class=br>+4</td>
<td class=bc>5 - 4 - 5</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>C</td><td class=d>10.</td><td class=kt>Da Belkovs</td><td class=kL>1:7</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=br>27:45</td><td class=br>-18</td>
<td class=bc>4 - 2 - 8</td>
<td class=br><strong>10</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>Ka Vi�ums</td><td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>0:3</td>
<td class=br>24:43</td><td class=br>-19</td>
<td class=bc>3 - 3 - 8</td>
<td class=br><strong>9</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>D</td><td class=d>12.</td><td class=kt>Ma Kalni��</td><td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>0:7</td>
<td class=kL>0:8</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=br>14:47</td><td class=br>-33</td>
<td class=bc>3 - 1 - 10</td>
<td class=br><strong>7</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>D</td><td class=d>13.</td><td class=kt>D� Vesele</td><td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>6:6</td>
<td class=kW>4:3</td>
<td class=br>26:55</td><td class=br>-29</td>
<td class=bc>2 - 3 - 9</td>
<td class=br><strong>7</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>D</td><td class=d>14.</td><td class=kt>Al Liepi��</td><td class=kL>2:6</td>
<td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>0:8</td>
<td class=kL>0:1</td>
<td class=kL>2:6</td>
<td class=kL>3:7</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kT>6:6</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=br>28:66</td><td class=br>-38</td>
<td class=bc>2 - 1 - 11</td>
<td class=br><strong>5</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ma Krauze</td><td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>1:10</td>
<td class=kL>3:7</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=br>22:56</td><td class=br>-34</td>
<td class=bc>2 - 0 - 12</td>
<td class=br><strong>4</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ka Vi�ums</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ri Kalni��</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>6 : 6</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>Ri Kalni��</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Ri Kalni��</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ra Neija</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Ma Kalni��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=blW>Ri Kalni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Da Belkovs</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Ri Kalni��</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ra Neija</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Ma Kalni��</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>4 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ri Kalni��</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Da Belkovs</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ri Kalni��</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>3 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group D grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>B</td><td class=d>1.</td><td class=kt>Va Smagars</td><td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>8:0</td>
<td class=kW>3:2</td>
<td class=kW>7:3</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=br>58:22</td><td class=br>+36</td>
<td class=bc>11 - 1 - 1</td>
<td class=br><strong>23</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>B</td><td class=d>2.</td><td class=kt>Sa Skarainis</td><td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=br>47:29</td><td class=br>+18</td>
<td class=bc>8 - 4 - 1</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>B</td><td class=d>3.</td><td class=kt>Al Skudr�tis</td><td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kT>5:5</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kW>10:2</td>
<td class=br>54:34</td><td class=br>+20</td>
<td class=bc>8 - 1 - 4</td>
<td class=br><strong>17</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>B</td><td class=d>4.</td><td class=kt>J� Bitmanis</td><td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=br>38:31</td><td class=br>+7</td>
<td class=bc>8 - 1 - 4</td>
<td class=br><strong>17</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt>Ni Sviklis</td><td class=kL>0:8</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kW>8:1</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>9:4</td>
<td class=kW>5:3</td>
<td class=br>48:44</td><td class=br>+4</td>
<td class=bc>6 - 3 - 4</td>
<td class=br><strong>15</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt>J� Re�is</td><td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>6:3</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=kW>7:0</td>
<td class=br>52:35</td><td class=br>+17</td>
<td class=bc>7 - 1 - 5</td>
<td class=br><strong>15</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>C</td><td class=d>7.</td><td class=kt>An Kuz�ecovs</td><td class=kL>3:7</td>
<td class=kT>2:2</td>
<td class=kT>5:5</td>
<td class=kL>3:6</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>4:5</td>
<td class=kW>9:3</td>
<td class=kW>4:3</td>
<td class=kW>6:3</td>
<td class=kW>3:0</td>
<td class=kW>9:0</td>
<td class=br>59:44</td><td class=br>+15</td>
<td class=bc>6 - 3 - 4</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>C</td><td class=d>8.</td><td class=kt>Ei G�ze</td><td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=br>29:21</td><td class=br>+8</td>
<td class=bc>6 - 2 - 5</td>
<td class=br><strong>14</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>C</td><td class=d>9.</td><td class=kt>Da Baumanis</td><td class=kL>0:6</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kL>3:6</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kT>5:5</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=br>41:42</td><td class=br>-1</td>
<td class=bc>6 - 2 - 5</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>C</td><td class=d>10.</td><td class=kt>Re Stac�vi�s</td><td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>1:8</td>
<td class=kL>2:6</td>
<td class=kL>3:9</td>
<td class=kW>1:0</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=br>29:46</td><td class=br>-17</td>
<td class=bc>4 - 2 - 7</td>
<td class=br><strong>10</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>J� Zem�ickis</td><td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=br>16:31</td><td class=br>-15</td>
<td class=bc>3 - 2 - 8</td>
<td class=br><strong>8</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>D</td><td class=d>12.</td><td class=kt>Il �irse</td><td class=kL>2:6</td>
<td class=kL>4:5</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kT>5:5</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=br>34:51</td><td class=br>-17</td>
<td class=bc>3 - 1 - 9</td>
<td class=br><strong>7</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>D</td><td class=d>13.</td><td class=kt>Gu Buls</td><td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>4:9</td>
<td class=kL>2:7</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=br>23:52</td><td class=br>-29</td>
<td class=bc>2 - 0 - 11</td>
<td class=br><strong>4</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>D</td><td class=d>14.</td><td class=kt>Re Saul�tis</td><td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>2:10</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>0:7</td>
<td class=kL>0:9</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=br>16:62</td><td class=br>-46</td>
<td class=bc>1 - 1 - 11</td>
<td class=br><strong>3</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>4 : 9</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>9 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>8 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>2 : 10</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group 1.l�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Ra Kalni��</td><td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kW>11:2</td>
<td class=kW>7:0</td>
<td class=kW>4:2 K</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=kW>5:2 K</td>
<td class=kW>9:0</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>9:2</td>
<td class=kW>5:3 K</td>
<td class=kW>8:5</td>
<td class=kW>3:0</td>
<td class=kW>7:2</td>
<td class=kW>10:0</td>
<td class=kW>2:1 K</td>
<td class=kW>8:1</td>
<td class=kW>8:1</td>
<td class=kW>6:5 K</td>
<td class=br>140:39</td><td class=br>+101</td>
<td class=bc>23 - 0 - 0</td>
<td class=br><strong>46</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Va Smagars</td><td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>1:4 K</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>8:0 K</td>
<td class=kW>3:2 K</td>
<td class=kL>4:6</td>
<td class=kT>2:2</td>
<td class=kW>4:2 K</td>
<td class=kL>2:4</td>
<td class=kW>5:4</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2 K</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>7:2</td>
<td class=br>80:56</td><td class=br>+24</td>
<td class=bc>14 - 3 - 6</td>
<td class=br><strong>31</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Ra Kuha�skis</td><td class=kL>2:11</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kW>2:1</td>
<td class=kT>3:3 K</td>
<td class=kT>1:1</td>
<td class=kW>5:4 K</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kT>3:3 K</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>8:3</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>5:4 K</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>4:3 K</td>
<td class=kW>4:2</td>
<td class=br>73:71</td><td class=br>+2</td>
<td class=bc>13 - 5 - 5</td>
<td class=br><strong>31</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Sa Skarainis</td><td class=kL>0:7</td>
<td class=kW>4:1 K</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>0:6</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>4:1 K</td>
<td class=kT>4:4 K</td>
<td class=kT>1:1</td>
<td class=kL>3:6</td>
<td class=kL>1:3 K</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kL>3:5</td>
<td class=kW>6:3</td>
<td class=kW>5:4 K</td>
<td class=kW>4:3</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=br>75:58</td><td class=br>+17</td>
<td class=bc>13 - 4 - 6</td>
<td class=br><strong>30</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Al Sili��</td><td class=kL>2:4 K</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>3:6 K</td>
<td class=kL>0:6</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kL>2:4</td>
<td class=kL>1:2 K</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>3:1 K</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kW>4:2 K</td>
<td class=br>75:60</td><td class=br>+15</td>
<td class=bc>14 - 2 - 7</td>
<td class=br><strong>30</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ro Rieksti��</td><td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kL>3:7</td>
<td class=kL>3:4</td>
<td class=kW>4:2 K</td>
<td class=kT>2:2</td>
<td class=kW>4:2 K</td>
<td class=kT>3:3</td>
<td class=kW>5:4 K</td>
<td class=kW>3:1 K</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kT>2:2 K</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=br>71:53</td><td class=br>+18</td>
<td class=bc>13 - 3 - 7</td>
<td class=br><strong>29</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>El Sili��</td><td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kT>3:3 K</td>
<td class=kW>6:0</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>0:1 K</td>
<td class=kW>3:0</td>
<td class=kL>1:4</td>
<td class=kT>4:4 K</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2 K</td>
<td class=kT>1:1</td>
<td class=kW>8:1</td>
<td class=kW>5:1 K</td>
<td class=kW>3:1</td>
<td class=br>58:47</td><td class=br>+11</td>
<td class=bc>10 - 7 - 6</td>
<td class=br><strong>27</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Al �ernovojs</td><td class=kL>2:5 K</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>6:3 K</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>2:7</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kL>3:4 K</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>1:0 K</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1 K</td>
<td class=br>60:49</td><td class=br>+11</td>
<td class=bc>11 - 4 - 8</td>
<td class=br><strong>26</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Se Mihejevs</td><td class=kL>0:9</td>
<td class=kL>2:3</td>
<td class=kL>4:5 K</td>
<td class=kT>1:1</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kW>1:0 K</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>0:4</td>
<td class=kW>5:3 K</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kW>2:1 K</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kW>4:1 K</td>
<td class=kW>2:1</td>
<td class=br>54:59</td><td class=br>-5</td>
<td class=bc>10 - 5 - 8</td>
<td class=br><strong>25</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ni Sviklis</td><td class=kL>3:4</td>
<td class=kL>0:8 K</td>
<td class=kL>4:5</td>
<td class=kL>1:4 K</td>
<td class=kL>0:6</td>
<td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>5:1 K</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kT>5:5 K</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2 K</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=br>66:73</td><td class=br>-7</td>
<td class=bc>11 - 3 - 9</td>
<td class=br><strong>25</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>J� Re�is</td><td class=kL>1:5</td>
<td class=kL>2:3 K</td>
<td class=kL>2:4</td>
<td class=kT>4:4 K</td>
<td class=kL>1:3</td>
<td class=kW>7:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kL>1:5 K</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kL>2:4 K</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kL>3:4 K</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=br>71:63</td><td class=br>+8</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Kr Lagzdi�a</td><td class=kL>3:4</td>
<td class=kW>6:4</td>
<td class=kT>3:3 K</td>
<td class=kT>1:1</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kT>4:4 K</td>
<td class=kL>1:3</td>
<td class=kL>3:5 K</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kL>3:5</td>
<td class=kT>3:3 K</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1 K</td>
<td class=kW>4:3</td>
<td class=br>72:64</td><td class=br>+8</td>
<td class=bc>9 - 5 - 9</td>
<td class=br><strong>23</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ed Naglis</td><td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4 K</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kW>6:2</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>6:2 K</td>
<td class=kL>1:3</td>
<td class=kL>1:5 K</td>
<td class=kL>1:2 K</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kW>4:0</td>
<td class=kT>3:3 K</td>
<td class=kW>9:1</td>
<td class=kW>5:3</td>
<td class=br>80:68</td><td class=br>+12</td>
<td class=bc>9 - 4 - 10</td>
<td class=br><strong>22</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>J� Bitmanis</td><td class=kL>0:5</td>
<td class=kL>2:4 K</td>
<td class=kL>2:3</td>
<td class=kW>3:1 K</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>5:5 K</td>
<td class=kW>4:2 K</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kL>3:7</td>
<td class=kW>6:1</td>
<td class=kL>2:4 K</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=br>62:67</td><td class=br>-5</td>
<td class=bc>8 - 6 - 9</td>
<td class=br><strong>22</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>He Prokuratovs</td><td class=kL>2:9</td>
<td class=kW>4:2</td>
<td class=kL>3:8</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>2:4 K</td>
<td class=kL>0:1</td>
<td class=kL>0:7</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>2:6 K</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>3:3 K</td>
<td class=kW>6:2 K</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kT>1:1 K</td>
<td class=kW>4:2</td>
<td class=kL>5:6</td>
<td class=br>62:74</td><td class=br>-12</td>
<td class=bc>8 - 6 - 9</td>
<td class=br><strong>22</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Kr Naglis</td><td class=kL>3:5 K</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kW>2:1 K</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kW>4:3 K</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kW>7:4</td>
<td class=kL>2:3</td>
<td class=kL>1:3 K</td>
<td class=kL>2:5</td>
<td class=kW>8:2</td>
<td class=kL>3:6 K</td>
<td class=br>70:74</td><td class=br>-4</td>
<td class=bc>7 - 6 - 10</td>
<td class=br><strong>20</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Kr Zem�ickis</td><td class=kL>5:8</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kL>4:5 K</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kW>5:1 K</td>
<td class=kW>7:3</td>
<td class=kT>3:3 K</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kL>1:3 K</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kT>2:2 K</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=br>60:69</td><td class=br>-9</td>
<td class=bc>6 - 8 - 9</td>
<td class=br><strong>20</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Sa Kalni��</td><td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kL>1:3 K</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>0:5</td>
<td class=kW>2:1 K</td>
<td class=kL>1:6</td>
<td class=kL>2:6 K</td>
<td class=kT>2:2</td>
<td class=kW>3:1 K</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kT>3:3 K</td>
<td class=kL>1:7</td>
<td class=kW>4:1</td>
<td class=br>45:64</td><td class=br>-19</td>
<td class=bc>8 - 3 - 12</td>
<td class=br><strong>19</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Al Skudr�tis</td><td class=kL>2:7</td>
<td class=kL>2:3 K</td>
<td class=kT>2:2</td>
<td class=kL>4:5 K</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kL>2:3 K</td>
<td class=kW>4:3 K</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2 K</td>
<td class=kT>4:4</td>
<td class=kL>4:7</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=br>67:77</td><td class=br>-10</td>
<td class=bc>7 - 5 - 11</td>
<td class=br><strong>19</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Sa Krasts</td><td class=kL>0:10</td>
<td class=kL>1:6</td>
<td class=kL>4:5 K</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>2:3 K</td>
<td class=kL>1:3</td>
<td class=kL>1:2 K</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kT>3:3 K</td>
<td class=kW>5:2</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=br>48:68</td><td class=br>-20</td>
<td class=bc>6 - 3 - 14</td>
<td class=br><strong>15</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>21.</td><td class=kt>Ro Fa�ken�teins</td><td class=kL>1:2 K</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>0:8</td>
<td class=kL>1:3 K</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>0:1 K</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1 K</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>2:1 K</td>
<td class=br>34:53</td><td class=br>-19</td>
<td class=bc>5 - 5 - 13</td>
<td class=br><strong>15</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>22.</td><td class=kt>Ar Zasurcevs</td><td class=kL>1:8</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2 K</td>
<td class=kL>1:8</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kT>3:3 K</td>
<td class=kL>0:6</td>
<td class=kT>1:1 K</td>
<td class=kW>5:2</td>
<td class=kT>2:2 K</td>
<td class=kT>3:3 K</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kT>6:6</td>
<td class=kW>5:4</td>
<td class=br>50:93</td><td class=br>-43</td>
<td class=bc>2 - 8 - 13</td>
<td class=br><strong>12</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>23.</td><td class=kt>Ri Kalni��</td><td class=kL>1:8</td>
<td class=kL>0:3</td>
<td class=kL>3:4 K</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kL>1:6</td>
<td class=kL>1:5 K</td>
<td class=kT>3:3</td>
<td class=kL>1:4 K</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kL>1:3 K</td>
<td class=kL>1:9</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>2:8</td>
<td class=kL>2:4</td>
<td class=kW>7:1</td>
<td class=kW>4:2</td>
<td class=kT>1:1 K</td>
<td class=kL>2:5</td>
<td class=kT>6:6</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=br>51:100</td><td class=br>-49</td>
<td class=bc>3 - 4 - 16</td>
<td class=br><strong>10</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>24.</td><td class=kt>Marg �bele</td><td class=kL>5:6 K</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>2:4 K</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:2 K</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kW>6:5</td>
<td class=kW>6:3 K</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>1:2 K</td>
<td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=br>58:83</td><td class=br>-25</td>
<td class=bc>3 - 3 - 17</td>
<td class=br><strong>9</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>8 : 5</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ri Kalni��</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ri Kalni��</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>11 : 2</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>9 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>4 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>6 : 6</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ri Kalni��</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>2 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 2.l�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>D� Apfelbaums</td><td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=br>61:24</td><td class=br>+37</td>
<td class=bc>15 - 3 - 1</td>
<td class=br><strong>33</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>An Kuz�ecovs</td><td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>5:4</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kT>5:5</td>
<td class=kW>6:3</td>
<td class=kW>8:1</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>12:2</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kW>11:0</td>
<td class=kW>6:5</td>
<td class=br>96:50</td><td class=br>+46</td>
<td class=bc>13 - 2 - 4</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Fi Buhtujevs</td><td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=br>62:45</td><td class=br>+17</td>
<td class=bc>12 - 3 - 4</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Mi Saul�tis</td><td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>6:4</td>
<td class=kL>4:6</td>
<td class=kL>4:5</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>8:3</td>
<td class=br>68:47</td><td class=br>+21</td>
<td class=bc>10 - 5 - 4</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>El R�cen�ja</td><td class=kL>0:2</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kW>7:4</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kT>5:5</td>
<td class=br>68:48</td><td class=br>+20</td>
<td class=bc>10 - 4 - 5</td>
<td class=br><strong>24</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ra Martu��ns</td><td class=kT>1:1</td>
<td class=kL>3:5</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=br>63:48</td><td class=br>+15</td>
<td class=bc>10 - 4 - 5</td>
<td class=br><strong>24</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Ra Neija</td><td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>8:3</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>8:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kT>5:5</td>
<td class=br>72:50</td><td class=br>+22</td>
<td class=bc>11 - 2 - 6</td>
<td class=br><strong>24</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Gu Ern�teins</td><td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kT>4:4</td>
<td class=kL>3:8</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=br>61:58</td><td class=br>+3</td>
<td class=bc>9 - 5 - 5</td>
<td class=br><strong>23</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Da Baumanis</td><td class=kL>3:4</td>
<td class=kT>5:5</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kL>0:5</td>
<td class=kT>4:4</td>
<td class=kW>2:0</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>7:4</td>
<td class=br>65:65</td><td class=br>0</td>
<td class=bc>8 - 5 - 6</td>
<td class=br><strong>21</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Re Stac�vi�s</td><td class=kL>0:2</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kL>4:6</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=br>56:45</td><td class=br>+11</td>
<td class=bc>8 - 4 - 7</td>
<td class=br><strong>20</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Kr Kurzemnieks</td><td class=kT>2:2</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kW>6:4</td>
<td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kL>6:7</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=br>67:63</td><td class=br>+4</td>
<td class=bc>8 - 4 - 7</td>
<td class=br><strong>20</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ei G�ze</td><td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=br>41:55</td><td class=br>-14</td>
<td class=bc>6 - 5 - 8</td>
<td class=br><strong>17</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ai Romals</td><td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kW>7:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=br>49:54</td><td class=br>-5</td>
<td class=bc>7 - 2 - 10</td>
<td class=br><strong>16</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>To Jakseboga</td><td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kL>1:6</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=br>38:56</td><td class=br>-18</td>
<td class=bc>6 - 4 - 9</td>
<td class=br><strong>16</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Kr Zarinieks</td><td class=kL>1:3</td>
<td class=kL>2:12</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>4:7</td>
<td class=kL>2:4</td>
<td class=kL>2:8</td>
<td class=kL>3:5</td>
<td class=kW>5:4</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kT>6:6</td>
<td class=br>59:85</td><td class=br>-26</td>
<td class=bc>5 - 3 - 11</td>
<td class=br><strong>13</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Ro Kerns</td><td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=br>48:53</td><td class=br>-5</td>
<td class=bc>4 - 4 - 11</td>
<td class=br><strong>12</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>17.</td><td class=kt>Ka Vi�ums</td><td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>1:7</td>
<td class=br>40:70</td><td class=br>-30</td>
<td class=bc>5 - 1 - 13</td>
<td class=br><strong>11</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>18.</td><td class=kt>J� Zem�ickis</td><td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=br>28:53</td><td class=br>-25</td>
<td class=bc>5 - 0 - 14</td>
<td class=br><strong>10</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>19.</td><td class=kt>Da Belkovs</td><td class=kL>0:7</td>
<td class=kL>0:11</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=br>30:75</td><td class=br>-45</td>
<td class=bc>2 - 4 - 13</td>
<td class=br><strong>8</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>20.</td><td class=kt>Iv �irsis</td><td class=kL>1:5</td>
<td class=kL>5:6</td>
<td class=kL>2:4</td>
<td class=kL>3:8</td>
<td class=kT>5:5</td>
<td class=kL>0:5</td>
<td class=kT>5:5</td>
<td class=kL>1:3</td>
<td class=kL>4:7</td>
<td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kT>6:6</td>
<td class=kL>2:4</td>
<td class=kW>7:1</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=br>57:85</td><td class=br>-28</td>
<td class=bc>2 - 4 - 13</td>
<td class=br><strong>8</strong></td><td class=d>20.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Ra Martu��ns</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Gu Ern�teins</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>Ra Martu��ns</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Da Belkovs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Gu Ern�teins</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>Kr Kurzemnieks</td><td class=bc>4 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>5 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Gu Ern�teins</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Kr Kurzemnieks</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>7 : 6</tr></td>
<tr><td class=brW>Ka Vi�ums</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ra Neija</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>Gu Ern�teins</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Gu Ern�teins</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Neija</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>2 : 12</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Kr Kurzemnieks</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>6 : 6</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>Gu Ern�teins</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Kr Kurzemnieks</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=blW>Kr Kurzemnieks</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ra Neija</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Ra Martu��ns</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=blW>Ra Martu��ns</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Gu Ern�teins</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ra Neija</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ra Neija</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>8 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 3.l�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>M� �irsis</td><td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kW>7:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=br>66:33</td><td class=br>+33</td>
<td class=bc>13 - 3 - 3</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Ag Pav�rs</td><td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kW>5:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kW>8:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=br>62:42</td><td class=br>+20</td>
<td class=bc>13 - 1 - 5</td>
<td class=br><strong>27</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Al Liepi��</td><td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>4:6</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=br>54:49</td><td class=br>+5</td>
<td class=bc>9 - 5 - 5</td>
<td class=br><strong>23</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Gu Buls</td><td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=br>61:40</td><td class=br>+21</td>
<td class=bc>11 - 1 - 7</td>
<td class=br><strong>23</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ge Jansons</td><td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>8:3</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>7:5</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>7:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=br>67:44</td><td class=br>+23</td>
<td class=bc>10 - 3 - 6</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Re Saul�tis</td><td class=kL>0:4</td>
<td class=kW>3:1</td>
<td class=kW>6:4</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=br>46:45</td><td class=br>+1</td>
<td class=bc>10 - 2 - 7</td>
<td class=br><strong>22</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>D� Vesele</td><td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>3:8</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=br>59:50</td><td class=br>+9</td>
<td class=bc>8 - 5 - 6</td>
<td class=br><strong>21</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ma Kalni��</td><td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kL>0:2</td>
<td class=kW>1:0</td>
<td class=kT>0:0</td>
<td class=kW>3:1</td>
<td class=br>26:27</td><td class=br>-1</td>
<td class=bc>7 - 7 - 5</td>
<td class=br><strong>21</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ma Krauze</td><td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>7:2</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kL>0:5</td>
<td class=br>41:35</td><td class=br>+6</td>
<td class=bc>9 - 3 - 7</td>
<td class=br><strong>21</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>An Kova��uks</td><td class=kW>4:2</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>6:5</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=br>58:58</td><td class=br>0</td>
<td class=bc>9 - 2 - 8</td>
<td class=br><strong>20</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Il �irse</td><td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kL>3:4</td>
<td class=kW>6:1</td>
<td class=kL>4:5</td>
<td class=br>58:45</td><td class=br>+13</td>
<td class=bc>8 - 4 - 7</td>
<td class=br><strong>20</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Er Kalni��</td><td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kL>2:7</td>
<td class=kL>0:2</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=br>38:53</td><td class=br>-15</td>
<td class=bc>9 - 1 - 9</td>
<td class=br><strong>19</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ro Aseri��</td><td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>8:0</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=br>37:34</td><td class=br>+3</td>
<td class=bc>6 - 6 - 7</td>
<td class=br><strong>18</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Br Gor�anovs</td><td class=kL>0:3</td>
<td class=kL>3:8</td>
<td class=kL>3:4</td>
<td class=kL>2:7</td>
<td class=kL>5:7</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=kL>1:2</td>
<td class=kW>6:4</td>
<td class=br>57:60</td><td class=br>-3</td>
<td class=bc>8 - 1 - 10</td>
<td class=br><strong>17</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Ha V�veris</td><td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=br>50:50</td><td class=br>0</td>
<td class=bc>6 - 4 - 9</td>
<td class=br><strong>16</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>El Reinfelds</td><td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kL>0:5</td>
<td class=kW>7:1</td>
<td class=kW>5:4</td>
<td class=kW>5:3</td>
<td class=br>44:63</td><td class=br>-19</td>
<td class=bc>7 - 2 - 10</td>
<td class=br><strong>16</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ed Garan�s</td><td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kW>2:1</td>
<td class=kL>0:8</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kL>1:4</td>
<td class=br>34:64</td><td class=br>-30</td>
<td class=bc>7 - 0 - 12</td>
<td class=br><strong>14</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>As Kocere</td><td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>5:6</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>0:8</td>
<td class=kL>4:5</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=br>39:65</td><td class=br>-26</td>
<td class=bc>5 - 2 - 12</td>
<td class=br><strong>12</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>�r Egl�tis</td><td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kL>0:1</td>
<td class=kT>4:4</td>
<td class=kL>1:6</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kL>4:5</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>28:47</td><td class=br>-19</td>
<td class=bc>4 - 3 - 12</td>
<td class=br><strong>11</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>M� Timbers</td><td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>4:6</td>
<td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>42:63</td><td class=br>-21</td>
<td class=bc>3 - 1 - 15</td>
<td class=br><strong>7</strong></td><td class=d>20.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>�r Egl�tis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>Ed Garan�s</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ge Jansons</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>As Kocere</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=blW>Ed Garan�s</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>As Kocere</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ge Jansons</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>M� Timbers</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>An Kova��uks</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ed Garan�s</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>�r Egl�tis</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ge Jansons</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>8 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=blW>M� Timbers</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>An Kova��uks</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ed Garan�s</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>4 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>M� Timbers</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Ge Jansons</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Ge Jansons</td><td class=bc>5 : 7</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Ma Kalni��</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ed Garan�s</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Ge Jansons</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>Er Kalni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Ge Jansons</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Ma Kalni��</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>El Reinfelds</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>�r Egl�tis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>Ed Garan�s</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Ma Kalni��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Er Kalni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Er Kalni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Ge Jansons</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>�r Egl�tis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ge Jansons</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ed Garan�s</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ge Jansons</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>El Reinfelds</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>As Kocere</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>1 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
