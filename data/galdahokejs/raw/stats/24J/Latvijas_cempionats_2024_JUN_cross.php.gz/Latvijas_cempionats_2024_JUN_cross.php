<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Latvijas cempionats 2024 JUN</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../24J/Latvijas_cempionats_2024_JUN_index.php">Latvijas cempionats 2024 JUN, 13. April 2024</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group JUN A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Re Vazoli��</td><td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kT>5:5</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>8:1</td>
<td class=kW>6:1</td>
<td class=kW>8:0</td>
<td class=kW>6:1</td>
<td class=kW>10:0</td>
<td class=kW>6:0</td>
<td class=br>68:13</td><td class=br>+55</td>
<td class=bc>11 - 1 - 0</td>
<td class=br><strong>23</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ro L�vmanis</td><td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>11:0</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=br>57:11</td><td class=br>+46</td>
<td class=bc>10 - 0 - 2</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Al Pimenovs</td><td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>8:3</td>
<td class=kW>4:0</td>
<td class=br>42:23</td><td class=br>+19</td>
<td class=bc>8 - 1 - 3</td>
<td class=br><strong>17</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>He Prokuratovs</td><td class=kT>5:5</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=kW>8:0</td>
<td class=br>53:22</td><td class=br>+31</td>
<td class=bc>8 - 1 - 3</td>
<td class=br><strong>17</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Kr Markus</td><td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=br>35:19</td><td class=br>+16</td>
<td class=bc>8 - 1 - 3</td>
<td class=br><strong>17</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ei G�ze</td><td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=br>29:19</td><td class=br>+10</td>
<td class=bc>7 - 2 - 3</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Ro Kerns</td><td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>10:1</td>
<td class=kW>6:2</td>
<td class=br>41:28</td><td class=br>+13</td>
<td class=bc>7 - 1 - 4</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Ed Ern�teins</td><td class=kL>1:8</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=br>34:38</td><td class=br>-4</td>
<td class=bc>5 - 1 - 6</td>
<td class=br><strong>11</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ma Belousovs</td><td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>9:0</td>
<td class=br>25:36</td><td class=br>-11</td>
<td class=bc>3 - 1 - 8</td>
<td class=br><strong>7</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>M� �irsis</td><td class=kL>0:8</td>
<td class=kL>0:11</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kT>0:0</td>
<td class=br>19:45</td><td class=br>-26</td>
<td class=bc>2 - 2 - 8</td>
<td class=br><strong>6</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>�d Erenpreiss</td><td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=br>10:50</td><td class=br>-40</td>
<td class=bc>2 - 0 - 10</td>
<td class=br><strong>4</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Da Mergins</td><td class=kL>0:10</td>
<td class=kL>0:4</td>
<td class=kL>3:8</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>0:2</td>
<td class=kL>1:10</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=br>9:65</td><td class=br>-56</td>
<td class=bc>1 - 0 - 11</td>
<td class=br><strong>2</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ra Meija</td><td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>0:8</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kL>0:6</td>
<td class=kL>0:9</td>
<td class=kT>0:0</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=br>2:55</td><td class=br>-53</td>
<td class=bc>0 - 1 - 11</td>
<td class=br><strong>1</strong></td><td class=d>13.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ma Belousovs</td><td class=bc>-</td><td class=bl>�d Erenpreiss</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Ed Ern�teins</td><td class=bc>-</td><td class=blW>Al Pimenovs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Da Mergins</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Kr Markus</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>�d Erenpreiss</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Belousovs</td><td class=bc>-</td><td class=blW>Al Pimenovs</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ed Ern�teins</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=bl>Kr Markus</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=blW>Ro L�vmanis</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>�d Erenpreiss</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ma Belousovs</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Kr Markus</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ed Ern�teins</td><td class=bc>-</td><td class=blW>Ro L�vmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>�d Erenpreiss</td><td class=bc>-</td><td class=blW>Kr Markus</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Belousovs</td><td class=bc>-</td><td class=blW>Ro L�vmanis</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Ed Ern�teins</td><td class=bc>-</td><td class=bl>Da Mergins</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Al Pimenovs</td><td class=bc>-</td><td class=bl>Kr Markus</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Ro L�vmanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>�d Erenpreiss</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ma Belousovs</td><td class=bc>-</td><td class=bl>Da Mergins</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Kr Markus</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Ro L�vmanis</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Al Pimenovs</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Da Mergins</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>�d Erenpreiss</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma Belousovs</td><td class=bc>-</td><td class=blW>Ed Ern�teins</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=blW>Ro L�vmanis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Da Mergins</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ed Ern�teins</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>�d Erenpreiss</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ro L�vmanis</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Kr Markus</td><td class=bc>-</td><td class=bl>Da Mergins</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Ed Ern�teins</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ma Belousovs</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Da Mergins</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ro L�vmanis</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kr Markus</td><td class=bc>-</td><td class=bl>Ed Ern�teins</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Ma Belousovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Al Pimenovs</td><td class=bc>-</td><td class=bl>�d Erenpreiss</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Ed Ern�teins</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ro L�vmanis</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kr Markus</td><td class=bc>-</td><td class=bl>Ma Belousovs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>�d Erenpreiss</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=bl>Ed Ern�teins</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=bl>Ma Belousovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ro L�vmanis</td><td class=bc>-</td><td class=bl>�d Erenpreiss</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Kr Markus</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Al Pimenovs</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ed Ern�teins</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>Ma Belousovs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=blW>�d Erenpreiss</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ro L�vmanis</td><td class=bc>-</td><td class=blW>Al Pimenovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Markus</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ma Belousovs</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ed Ern�teins</td><td class=bc>-</td><td class=bl>�d Erenpreiss</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=blW>Al Pimenovs</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ro L�vmanis</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>6 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group JUN B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ed Naglis</td><td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>3:0</td>
<td class=kW>8:2</td>
<td class=kW>7:1</td>
<td class=kW>11:2</td>
<td class=kW>11:2</td>
<td class=kW>9:0</td>
<td class=kW>5:0</td>
<td class=br>77:18</td><td class=br>+59</td>
<td class=bc>11 - 0 - 1</td>
<td class=br><strong>22</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ni Sviklis</td><td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>5:5</td>
<td class=kL>4:6</td>
<td class=kW>6:1</td>
<td class=kL>2:4</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>9:1</td>
<td class=kW>8:0</td>
<td class=kW>8:1</td>
<td class=kW>12:0</td>
<td class=br>72:27</td><td class=br>+45</td>
<td class=bc>9 - 1 - 2</td>
<td class=br><strong>19</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ro Verbi�s</td><td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kW>8:2</td>
<td class=kW>5:1</td>
<td class=kW>8:3</td>
<td class=kW>7:2</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=br>54:29</td><td class=br>+25</td>
<td class=bc>8 - 1 - 3</td>
<td class=br><strong>17</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Kr Kurzemnieks</td><td class=kL>3:6</td>
<td class=kT>5:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>7:5</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>8:3</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=br>49:31</td><td class=br>+18</td>
<td class=bc>8 - 1 - 3</td>
<td class=br><strong>17</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ni L�cis</td><td class=kL>1:3</td>
<td class=kW>6:4</td>
<td class=kL>2:3</td>
<td class=kL>5:7</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=br>52:28</td><td class=br>+24</td>
<td class=bc>7 - 2 - 3</td>
<td class=br><strong>16</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ri Kalni��</td><td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=br>34:25</td><td class=br>+9</td>
<td class=bc>7 - 1 - 4</td>
<td class=br><strong>15</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>�i Vazoli��</td><td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>4:2</td>
<td class=br>31:23</td><td class=br>+8</td>
<td class=bc>6 - 2 - 4</td>
<td class=br><strong>14</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Ra Talbergs</td><td class=kL>2:8</td>
<td class=kL>2:6</td>
<td class=kL>2:8</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=br>36:42</td><td class=br>-6</td>
<td class=bc>5 - 2 - 5</td>
<td class=br><strong>12</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Gu Kaveckis</td><td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=br>15:35</td><td class=br>-20</td>
<td class=bc>4 - 0 - 8</td>
<td class=br><strong>8</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>El Reinfelds</td><td class=kL>2:11</td>
<td class=kL>1:9</td>
<td class=kL>3:8</td>
<td class=kL>3:8</td>
<td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=kW>8:1</td>
<td class=br>31:57</td><td class=br>-26</td>
<td class=bc>3 - 1 - 8</td>
<td class=br><strong>7</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>Ra St�lmanis</td><td class=kL>2:11</td>
<td class=kL>0:8</td>
<td class=kL>2:7</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>9:0</td>
<td class=br>22:50</td><td class=br>-28</td>
<td class=bc>3 - 0 - 9</td>
<td class=br><strong>6</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ma Isakovs</td><td class=kL>0:9</td>
<td class=kL>1:8</td>
<td class=kT>4:4</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kL>4:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>16:61</td><td class=br>-45</td>
<td class=bc>1 - 1 - 10</td>
<td class=br><strong>3</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>De Heidemanis</td><td class=kL>0:5</td>
<td class=kL>0:12</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>1:8</td>
<td class=kL>0:9</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>6:69</td><td class=br>-63</td>
<td class=bc>0 - 0 - 12</td>
<td class=br><strong>0</strong></td><td class=d>13.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>�i Vazoli��</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Isakovs</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ri Kalni��</td><td class=bc>-</td><td class=bl>Ra Talbergs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Gu Kaveckis</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Ra St�lmanis</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ni L�cis</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=bl>Ra Talbergs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Isakovs</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Ri Kalni��</td><td class=bc>-</td><td class=bl>Ra St�lmanis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Gu Kaveckis</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>Ra Talbergs</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>�i Vazoli��</td><td class=bc>-</td><td class=bl>Ra St�lmanis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ma Isakovs</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Gu Kaveckis</td><td class=bc>-</td><td class=blW>Ni L�cis</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ra Talbergs</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>Ra St�lmanis</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ma Isakovs</td><td class=bc>-</td><td class=blW>Ni L�cis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Kr Kurzemnieks</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ra St�lmanis</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Ra Talbergs</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>Kr Kurzemnieks</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Isakovs</td><td class=bc>-</td><td class=blW>Gu Kaveckis</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ra St�lmanis</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ra Talbergs</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>Kr Kurzemnieks</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Gu Kaveckis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>Ri Kalni��</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 11</tr></td>
<tr><td class=br>Ra St�lmanis</td><td class=bc>-</td><td class=blW>Ni L�cis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ra Talbergs</td><td class=bc>-</td><td class=bl>Gu Kaveckis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>Ri Kalni��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Ma Isakovs</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Kr Kurzemnieks</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ra St�lmanis</td><td class=bc>-</td><td class=blW>Gu Kaveckis</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ra Talbergs</td><td class=bc>-</td><td class=bl>Ma Isakovs</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=blW>Kr Kurzemnieks</td><td class=bc>5 : 7</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Gu Kaveckis</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ri Kalni��</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ra St�lmanis</td><td class=bc>-</td><td class=bl>Ma Isakovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ra Talbergs</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>2 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Gu Kaveckis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ma Isakovs</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ra St�lmanis</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>12 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Gu Kaveckis</td><td class=bc>-</td><td class=blW>Ri Kalni��</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Ma Isakovs</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ni L�cis</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>El Reinfelds</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ra St�lmanis</td><td class=bc>-</td><td class=bl>Ra Talbergs</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ri Kalni��</td><td class=bc>-</td><td class=bl>Ma Isakovs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Gu Kaveckis</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ni L�cis</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ra Talbergs</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>1 : 9</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ma Isakovs</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Gu Kaveckis</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Ra Talbergs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ni L�cis</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ra St�lmanis</td><td class=bc>11 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group JUN C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Kr Lagzdi�a</td><td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kL>0:1</td>
<td class=kW>8:1</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>9:0</td>
<td class=kW>11:0</td>
<td class=kW>8:0</td>
<td class=kW>14:0</td>
<td class=br>72:7</td><td class=br>+65</td>
<td class=bc>9 - 1 - 1</td>
<td class=br><strong>19</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ar Zasurcevs</td><td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=kW>6:3</td>
<td class=kW>9:1</td>
<td class=kW>7:0</td>
<td class=kW>11:1</td>
<td class=br>57:17</td><td class=br>+40</td>
<td class=bc>9 - 1 - 1</td>
<td class=br><strong>19</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ra Kuha�skis</td><td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>10:0</td>
<td class=kW>8:0</td>
<td class=kW>8:0</td>
<td class=kW>8:0</td>
<td class=kW>15:1</td>
<td class=br>70:20</td><td class=br>+50</td>
<td class=bc>8 - 1 - 2</td>
<td class=br><strong>17</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ed Putni��</td><td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>12:2</td>
<td class=kW>9:0</td>
<td class=kW>7:1</td>
<td class=kW>16:0</td>
<td class=br>66:22</td><td class=br>+44</td>
<td class=bc>7 - 2 - 2</td>
<td class=br><strong>16</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>To Jakseboga</td><td class=kW>1:0</td>
<td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=br>33:25</td><td class=br>+8</td>
<td class=bc>6 - 3 - 2</td>
<td class=br><strong>15</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Iv �irsis</td><td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kW>8:1</td>
<td class=kW>6:5</td>
<td class=kW>4:1</td>
<td class=br>41:35</td><td class=br>+6</td>
<td class=bc>5 - 2 - 4</td>
<td class=br><strong>12</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Ro Iga</td><td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>7:0</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=br>28:26</td><td class=br>+2</td>
<td class=bc>4 - 2 - 5</td>
<td class=br><strong>10</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>�v Vikmanis</td><td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>0:10</td>
<td class=kL>0:2</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=br>13:38</td><td class=br>-25</td>
<td class=bc>3 - 2 - 6</td>
<td class=br><strong>8</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>J� T�ns</td><td class=kL>0:9</td>
<td class=kL>3:6</td>
<td class=kL>0:8</td>
<td class=kL>2:12</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=br>19:50</td><td class=br>-31</td>
<td class=bc>2 - 2 - 7</td>
<td class=br><strong>6</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Kr Kl�vi��</td><td class=kL>0:11</td>
<td class=kL>1:9</td>
<td class=kL>0:8</td>
<td class=kL>0:9</td>
<td class=kT>2:2</td>
<td class=kL>1:8</td>
<td class=kL>0:7</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=br>9:64</td><td class=br>-55</td>
<td class=bc>1 - 2 - 8</td>
<td class=br><strong>4</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>Al Sili��</td><td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>0:8</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>5:6</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=br>13:53</td><td class=br>-40</td>
<td class=bc>0 - 3 - 8</td>
<td class=br><strong>3</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ma Krauze</td><td class=kL>0:14</td>
<td class=kL>1:11</td>
<td class=kL>1:15</td>
<td class=kL>0:16</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kW>4:0</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=br>12:76</td><td class=br>-64</td>
<td class=bc>1 - 1 - 9</td>
<td class=br><strong>3</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>J� T�ns</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ro Iga</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>Ro Iga</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>0 : 14</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Ro Iga</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Iga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>Ro Iga</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>16 : 0</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ro Iga</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>11 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ro Iga</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>J� T�ns</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ro Iga</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>15 : 1</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>11 : 0</tr></td>
<tr><td class=br>Ro Iga</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>2 : 12</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Kr Kl�vi��</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ro Iga</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Iga</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ro Iga</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>8 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group JUN D</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Al Skudr�tis</td><td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>8:3</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kW>7:0</td>
<td class=kW>8:3</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=br>58:16</td><td class=br>+42</td>
<td class=bc>10 - 1 - 0</td>
<td class=br><strong>21</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Kr Zem�ickis</td><td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>8:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>43:24</td><td class=br>+19</td>
<td class=bc>8 - 2 - 1</td>
<td class=br><strong>18</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>J� Re�is</td><td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>10:0</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=br>48:15</td><td class=br>+33</td>
<td class=bc>9 - 0 - 2</td>
<td class=br><strong>18</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>J� Bitmanis</td><td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=br>46:13</td><td class=br>+33</td>
<td class=bc>8 - 2 - 1</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ar Salmi��</td><td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=br>36:19</td><td class=br>+17</td>
<td class=bc>7 - 0 - 4</td>
<td class=br><strong>14</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Re Saul�tis</td><td class=kL>3:8</td>
<td class=kL>2:8</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=br>27:36</td><td class=br>-9</td>
<td class=bc>5 - 0 - 6</td>
<td class=br><strong>10</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Fr Platons</td><td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=br>22:24</td><td class=br>-2</td>
<td class=bc>4 - 2 - 5</td>
<td class=br><strong>10</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Ro Purmalis</td><td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kW>5:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=br>29:38</td><td class=br>-9</td>
<td class=bc>2 - 2 - 7</td>
<td class=br><strong>6</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ag Pav�rs</td><td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kT>0:0</td>
<td class=br>16:40</td><td class=br>-24</td>
<td class=bc>2 - 2 - 7</td>
<td class=br><strong>6</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ja Vecgravis</td><td class=kL>3:8</td>
<td class=kL>2:3</td>
<td class=kL>0:10</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=br>12:46</td><td class=br>-34</td>
<td class=bc>2 - 0 - 9</td>
<td class=br><strong>4</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>Br Gor�anovs</td><td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>15:42</td><td class=br>-27</td>
<td class=bc>1 - 2 - 8</td>
<td class=br><strong>4</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Da B�rzi��</td><td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>0:7</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kT>0:0</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>4:43</td><td class=br>-39</td>
<td class=bc>1 - 1 - 9</td>
<td class=br><strong>3</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Ja Vecgravis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Da B�rzi��</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Ar Salmi��</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Ja Vecgravis</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Da B�rzi��</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Ar Salmi��</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Ja Vecgravis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Da B�rzi��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ja Vecgravis</td><td class=bc>-</td><td class=blW>Da B�rzi��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Da B�rzi��</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ja Vecgravis</td><td class=bc>-</td><td class=blW>Ar Salmi��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Ar Salmi��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da B�rzi��</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ja Vecgravis</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Da B�rzi��</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ja Vecgravis</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da B�rzi��</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ja Vecgravis</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ar Salmi��</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da B�rzi��</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ja Vecgravis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Da B�rzi��</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ar Salmi��</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>Ja Vecgravis</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Ja Vecgravis</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Ar Salmi��</td><td class=bc>-</td><td class=bl>Da B�rzi��</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Ja Vecgravis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>Da B�rzi��</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>6 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group JUN 1.l�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Re Vazoli��</td><td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0 K</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2 K</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kT>5:5 K</td>
<td class=kW>3:1</td>
<td class=kW>5:2 K</td>
<td class=kW>3:1 K</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>8:2</td>
<td class=br>93:33</td><td class=br>+60</td>
<td class=bc>20 - 2 - 1</td>
<td class=br><strong>42</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Ed Naglis</td><td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kL>3:4</td>
<td class=kT>6:6</td>
<td class=kW>3:1 K</td>
<td class=kW>11:3</td>
<td class=kW>6:4</td>
<td class=kW>5:2 K</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kL>2:3 K</td>
<td class=kW>4:0</td>
<td class=kW>8:4</td>
<td class=kW>6:3 K</td>
<td class=kW>9:3</td>
<td class=kW>7:2 K</td>
<td class=kL>3:4</td>
<td class=kW>10:1</td>
<td class=br>116:61</td><td class=br>+55</td>
<td class=bc>17 - 1 - 5</td>
<td class=br><strong>35</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Ra Kuha�skis</td><td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>8:2</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>2:5 K</td>
<td class=kW>4:0</td>
<td class=kL>3:4 K</td>
<td class=kW>1:0</td>
<td class=kW>3:2 K</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kT>4:4 K</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>4:3 K</td>
<td class=kW>4:0</td>
<td class=kL>4:5</td>
<td class=kW>8:2</td>
<td class=br>84:53</td><td class=br>+31</td>
<td class=bc>15 - 2 - 6</td>
<td class=br><strong>32</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>Al Skudr�tis</td><td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>2:8</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:3 K</td>
<td class=kW>2:1</td>
<td class=kT>2:2 K</td>
<td class=kW>9:3</td>
<td class=kT>3:3</td>
<td class=kW>7:0</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1 K</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>9:0</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kW>3:1 K</td>
<td class=kW>8:3 K</td>
<td class=br>94:54</td><td class=br>+40</td>
<td class=bc>14 - 4 - 5</td>
<td class=br><strong>32</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Ro L�vmanis</td><td class=kL>0:3 K</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>4:0 K</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1 K</td>
<td class=kW>2:1</td>
<td class=kL>2:3 K</td>
<td class=kW>4:0 K</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=br>63:43</td><td class=br>+20</td>
<td class=bc>15 - 1 - 7</td>
<td class=br><strong>31</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>J� Re�is</td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kL>3:5 K</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:3 K</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kW>2:0</td>
<td class=kL>2:4 K</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kW>3:1 K</td>
<td class=kW>6:1 K</td>
<td class=br>71:46</td><td class=br>+25</td>
<td class=bc>13 - 4 - 6</td>
<td class=br><strong>30</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Kr Lagzdi�a</td><td class=kL>1:2</td>
<td class=kL>4:5</td>
<td class=kW>5:2 K</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kT>1:1 K</td>
<td class=kL>2:3</td>
<td class=kW>4:1 K</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kL>0:1 K</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kW>7:3</td>
<td class=kL>3:4</td>
<td class=kW>8:1 K</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=br>82:37</td><td class=br>+45</td>
<td class=bc>14 - 1 - 8</td>
<td class=br><strong>29</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>J� Bitmanis</td><td class=kL>0:6</td>
<td class=kW>4:3</td>
<td class=kL>0:4</td>
<td class=kT>2:2 K</td>
<td class=kL>2:3</td>
<td class=kL>3:4 K</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kT>3:3 K</td>
<td class=kL>2:5</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1 K</td>
<td class=kW>2:1 K</td>
<td class=br>67:57</td><td class=br>+10</td>
<td class=bc>13 - 3 - 7</td>
<td class=br><strong>29</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>Ar Zasurcevs</td><td class=kL>1:4</td>
<td class=kT>6:6</td>
<td class=kW>4:3 K</td>
<td class=kL>3:9</td>
<td class=kW>4:2</td>
<td class=kL>2:6</td>
<td class=kT>1:1 K</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>3:4 K</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>6:2 K</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2 K</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=br>75:58</td><td class=br>+17</td>
<td class=bc>12 - 5 - 6</td>
<td class=br><strong>29</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Ni L�cis</td><td class=kT>2:2</td>
<td class=kL>1:3 K</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3 K</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>6:4 K</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=kL>5:7 K</td>
<td class=kT>4:4</td>
<td class=kT>4:4 K</td>
<td class=kW>2:1</td>
<td class=k>&nbsp;</td>
<td class=br>68:56</td><td class=br>+12</td>
<td class=bc>9 - 7 - 6</td>
<td class=br><strong>25</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Ed Putni��</td><td class=kL>2:5</td>
<td class=kL>3:11</td>
<td class=kL>2:3 K</td>
<td class=kL>0:7</td>
<td class=kW>3:1</td>
<td class=kL>3:6</td>
<td class=kL>1:4 K</td>
<td class=kL>3:5</td>
<td class=kW>4:3 K</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kT>4:4 K</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kT>4:4 K</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=br>75:84</td><td class=br>-9</td>
<td class=bc>10 - 5 - 8</td>
<td class=br><strong>25</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>Kr Markus</td><td class=kL>2:3 K</td>
<td class=kL>4:6</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>0:4 K</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1 K</td>
<td class=kL>2:3</td>
<td class=kL>1:5 K</td>
<td class=kT>2:2 K</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=br>56:55</td><td class=br>+1</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>Ro Verbi�s</td><td class=kL>1:6</td>
<td class=kL>2:5 K</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2 K</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>3:4 K</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2 K</td>
<td class=kL>0:3</td>
<td class=kW>3:0 K</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=br>50:61</td><td class=br>-11</td>
<td class=bc>9 - 5 - 9</td>
<td class=br><strong>23</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>To Jakseboga</td><td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kT>4:4 K</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kW>1:0 K</td>
<td class=kL>1:3</td>
<td class=kL>2:6 K</td>
<td class=kL>2:4</td>
<td class=kT>4:4 K</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kW>4:1 K</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=br>48:55</td><td class=br>-7</td>
<td class=bc>9 - 4 - 10</td>
<td class=br><strong>22</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>Kr Zem�ickis</td><td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>1:5 K</td>
<td class=kL>1:4</td>
<td class=kW>4:2 K</td>
<td class=kL>1:4</td>
<td class=kT>3:3 K</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kW>5:3 K</td>
<td class=kW>8:2 K</td>
<td class=br>58:62</td><td class=br>-4</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>He Prokuratovs</td><td class=kT>5:5 K</td>
<td class=kL>1:7</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kL>1:4 K</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4 K</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>4:2 K</td>
<td class=kL>1:2 K</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=br>61:70</td><td class=br>-9</td>
<td class=bc>8 - 4 - 11</td>
<td class=br><strong>20</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ni Sviklis</td><td class=kL>1:3</td>
<td class=kW>3:2 K</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>4:6 K</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3 K</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kT>5:5 K</td>
<td class=kW>4:3</td>
<td class=kW>6:1 K</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=br>60:71</td><td class=br>-11</td>
<td class=bc>9 - 2 - 12</td>
<td class=br><strong>20</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Al Pimenovs</td><td class=kL>2:5 K</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kW>3:2 K</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kW>5:1 K</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4 K</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:3 K</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=br>44:63</td><td class=br>-19</td>
<td class=bc>6 - 7 - 10</td>
<td class=br><strong>19</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Ei G�ze</td><td class=kL>1:3 K</td>
<td class=kL>4:8</td>
<td class=kL>1:2</td>
<td class=kL>0:9</td>
<td class=kL>0:4 K</td>
<td class=kT>1:1</td>
<td class=kL>3:7</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>0:7</td>
<td class=kL>3:4</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1 K</td>
<td class=kL>0:6</td>
<td class=kW>3:2 K</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=br>36:77</td><td class=br>-41</td>
<td class=bc>5 - 4 - 14</td>
<td class=br><strong>14</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Kr Kurzemnieks</td><td class=kL>2:3</td>
<td class=kL>3:6 K</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>7:5 K</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>2:4 K</td>
<td class=kW>5:4</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kT>5:5 K</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>2:1 K</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=br>58:84</td><td class=br>-26</td>
<td class=bc>6 - 2 - 15</td>
<td class=br><strong>14</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Iv �irsis</td><td class=kL>2:6</td>
<td class=kL>3:9</td>
<td class=kL>3:4 K</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>1:8 K</td>
<td class=kL>1:6</td>
<td class=kL>2:4 K</td>
<td class=kT>4:4</td>
<td class=kT>4:4 K</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kL>1:4 K</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kW>2:0</td>
<td class=br>48:82</td><td class=br>-34</td>
<td class=bc>5 - 3 - 15</td>
<td class=br><strong>13</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Ri Kalni��</td><td class=kL>2:6</td>
<td class=kL>2:7 K</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kT>4:4 K</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kL>0:3 K</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>1:6 K</td>
<td class=kL>0:1</td>
<td class=kW>2:0</td>
<td class=kL>1:2 K</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=br>38:76</td><td class=br>-38</td>
<td class=bc>3 - 3 - 17</td>
<td class=br><strong>9</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Ar Salmi��</td><td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>5:4</td>
<td class=kL>1:3 K</td>
<td class=kL>2:4</td>
<td class=kL>1:3 K</td>
<td class=kL>1:4</td>
<td class=kL>1:4 K</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>3:5 K</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>3:1 K</td>
<td class=br>42:76</td><td class=br>-34</td>
<td class=bc>4 - 1 - 18</td>
<td class=br><strong>9</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Re Saul�tis</td><td class=kL>2:8</td>
<td class=kL>1:10</td>
<td class=kL>2:8</td>
<td class=kL>3:8 K</td>
<td class=kL>1:6</td>
<td class=kL>1:6 K</td>
<td class=kL>2:6</td>
<td class=kL>1:2 K</td>
<td class=kL>0:4</td>
<td class=k>&nbsp;</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>2:8 K</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>1:3 K</td>
<td class=kx>*</td>
<td class=br>30:103</td><td class=br>-73</td>
<td class=bc>0 - 3 - 19</td>
<td class=br><strong>3</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ro L�vmanis</td><td class=bc>-</td><td class=blW>Ni L�cis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Al Pimenovs</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Ni L�cis</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Ar Salmi��</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ro L�vmanis</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Kr Markus</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Kr Markus</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ro L�vmanis</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Al Pimenovs</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Ni L�cis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kr Markus</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ro L�vmanis</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=blW>Ni L�cis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Ar Salmi��</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Ri Kalni��</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ro L�vmanis</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ro L�vmanis</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kr Markus</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ni L�cis</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro L�vmanis</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro L�vmanis</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ar Salmi��</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ro L�vmanis</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ri Kalni��</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Markus</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ro L�vmanis</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Markus</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ro L�vmanis</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ni L�cis</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ro L�vmanis</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Markus</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Ro L�vmanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ni L�cis</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Kr Markus</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ri Kalni��</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Ro L�vmanis</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Kr Markus</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ni L�cis</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Al Pimenovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Kr Markus</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Ro L�vmanis</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Kr Markus</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>9 : 3</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>Ro L�vmanis</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Kr Markus</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>6 : 6</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Ro L�vmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Kr Markus</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Ro L�vmanis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Al Pimenovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>11 : 3</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>4 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group JUN 2.l�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt>Ro Kerns</td><td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>9:2</td>
<td class=kW>5:0</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=br>64:17</td><td class=br>+47</td>
<td class=bc>13 - 2 - 0</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt>Fr Platons</td><td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kT>0:0</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=br>51:20</td><td class=br>+31</td>
<td class=bc>11 - 3 - 1</td>
<td class=br><strong>25</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt>Ro Iga</td><td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=br>44:23</td><td class=br>+21</td>
<td class=bc>10 - 4 - 1</td>
<td class=br><strong>24</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt>�i Vazoli��</td><td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=br>27:13</td><td class=br>+14</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ra Talbergs</td><td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>7:3</td>
<td class=kW>4:1</td>
<td class=br>40:34</td><td class=br>+6</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ed Ern�teins</td><td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kW>8:0</td>
<td class=br>42:27</td><td class=br>+15</td>
<td class=bc>8 - 1 - 6</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>El Reinfelds</td><td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>6:4</td>
<td class=kW>2:1</td>
<td class=br>43:40</td><td class=br>+3</td>
<td class=bc>8 - 1 - 6</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ro Purmalis</td><td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kL>0:2</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=br>44:34</td><td class=br>+10</td>
<td class=bc>7 - 2 - 6</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>�v Vikmanis</td><td class=kL>1:4</td>
<td class=kT>0:0</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kW>2:0</td>
<td class=br>21:23</td><td class=br>-2</td>
<td class=bc>5 - 3 - 7</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>J� T�ns</td><td class=kL>2:9</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=br>29:41</td><td class=br>-12</td>
<td class=bc>6 - 1 - 8</td>
<td class=br><strong>13</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ag Pav�rs</td><td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=br>16:34</td><td class=br>-18</td>
<td class=bc>4 - 3 - 8</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>M� �irsis</td><td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=br>25:44</td><td class=br>-19</td>
<td class=bc>3 - 4 - 8</td>
<td class=br><strong>10</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ma Belousovs</td><td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=br>20:33</td><td class=br>-13</td>
<td class=bc>3 - 3 - 9</td>
<td class=br><strong>9</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Gu Kaveckis</td><td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>0:1</td>
<td class=br>15:32</td><td class=br>-17</td>
<td class=bc>3 - 1 - 11</td>
<td class=br><strong>7</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Kr Kl�vi��</td><td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>3:7</td>
<td class=kL>0:1</td>
<td class=kL>4:6</td>
<td class=kL>1:5</td>
<td class=kW>1:0</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>20:51</td><td class=br>-31</td>
<td class=bc>3 - 1 - 11</td>
<td class=br><strong>7</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Ja Vecgravis</td><td class=kL>2:7</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>0:8</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>10:45</td><td class=br>-35</td>
<td class=bc>2 - 2 - 11</td>
<td class=br><strong>6</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�i Vazoli��</td><td class=bc>-</td><td class=bl>Ja Vecgravis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ro Iga</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ed Ern�teins</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ra Talbergs</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>Gu Kaveckis</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ja Vecgravis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Iga</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ed Ern�teins</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ra Talbergs</td><td class=bc>-</td><td class=bl>Gu Kaveckis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Ma Belousovs</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ja Vecgravis</td><td class=bc>-</td><td class=blW>Kr Kl�vi��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>�i Vazoli��</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ro Iga</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Gu Kaveckis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ed Ern�teins</td><td class=bc>-</td><td class=bl>Ma Belousovs</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ra Talbergs</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ja Vecgravis</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>Gu Kaveckis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ro Iga</td><td class=bc>-</td><td class=bl>Ma Belousovs</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ed Ern�teins</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>El Reinfelds</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Kr Kl�vi��</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ja Vecgravis</td><td class=bc>-</td><td class=blW>J� T�ns</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Gu Kaveckis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Ma Belousovs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Iga</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Ra Talbergs</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>J� T�ns</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>Gu Kaveckis</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ja Vecgravis</td><td class=bc>-</td><td class=bl>Ma Belousovs</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>Ra Talbergs</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ro Iga</td><td class=bc>-</td><td class=bl>Ed Ern�teins</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>J� T�ns</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Gu Kaveckis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>El Reinfelds</td><td class=bc>-</td><td class=bl>Ma Belousovs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ja Vecgravis</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ra Talbergs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Ed Ern�teins</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=blW>Gu Kaveckis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Ma Belousovs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>Ra Talbergs</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ja Vecgravis</td><td class=bc>-</td><td class=blW>Ed Ern�teins</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Ro Iga</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Gu Kaveckis</td><td class=bc>-</td><td class=blW>Ma Belousovs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=bl>Ra Talbergs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ed Ern�teins</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ja Vecgravis</td><td class=bc>-</td><td class=blW>Ro Iga</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ma Belousovs</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Gu Kaveckis</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>J� T�ns</td><td class=bc>-</td><td class=bl>Ra Talbergs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Ed Ern�teins</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ro Iga</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Vecgravis</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Belousovs</td><td class=bc>-</td><td class=blW>Ra Talbergs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Gu Kaveckis</td><td class=bc>-</td><td class=blW>Ed Ern�teins</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Ro Iga</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Ra Talbergs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=bl>Ed Ern�teins</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Belousovs</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Gu Kaveckis</td><td class=bc>-</td><td class=blW>Ro Iga</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>El Reinfelds</td><td class=bc>-</td><td class=bl>Ja Vecgravis</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ra Talbergs</td><td class=bc>-</td><td class=bl>Ed Ern�teins</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Ro Iga</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ma Belousovs</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Gu Kaveckis</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Ja Vecgravis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ed Ern�teins</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ra Talbergs</td><td class=bc>-</td><td class=blW>Ro Iga</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Belousovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Kaveckis</td><td class=bc>-</td><td class=blW>Ja Vecgravis</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>J� T�ns</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>Ro Iga</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ed Ern�teins</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ra Talbergs</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>Ja Vecgravis</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ma Belousovs</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Gu Kaveckis</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>J� T�ns</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ro Iga</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ed Ern�teins</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ra Talbergs</td><td class=bc>-</td><td class=bl>Ja Vecgravis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Kr Kl�vi��</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Belousovs</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Gu Kaveckis</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Iga</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Ja Vecgravis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ed Ern�teins</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ra Talbergs</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ma Belousovs</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>1 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group JUN 3.l�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt>Br Gor�anovs</td><td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=kW>10:0</td>
<td class=br>29:8</td><td class=br>+21</td>
<td class=bc>6 - 2 - 1</td>
<td class=br><strong>14</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt>�d Erenpreiss</td><td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kT>0:0</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=br>14:5</td><td class=br>+9</td>
<td class=bc>6 - 2 - 1</td>
<td class=br><strong>14</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt>Al Sili��</td><td class=kW>2:0</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=br>18:9</td><td class=br>+9</td>
<td class=bc>6 - 1 - 2</td>
<td class=br><strong>13</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt>Ra St�lmanis</td><td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=br>18:12</td><td class=br>+6</td>
<td class=bc>5 - 2 - 2</td>
<td class=br><strong>12</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ma Krauze</td><td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=br>14:8</td><td class=br>+6</td>
<td class=bc>5 - 1 - 3</td>
<td class=br><strong>11</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ma Isakovs</td><td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=br>22:12</td><td class=br>+10</td>
<td class=bc>5 - 1 - 3</td>
<td class=br><strong>11</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Da B�rzi��</td><td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=br>11:13</td><td class=br>-2</td>
<td class=bc>3 - 2 - 4</td>
<td class=br><strong>8</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ra Meija</td><td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=br>10:21</td><td class=br>-11</td>
<td class=bc>1 - 2 - 6</td>
<td class=br><strong>4</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Da Mergins</td><td class=kL>0:7</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=br>7:32</td><td class=br>-25</td>
<td class=bc>1 - 0 - 8</td>
<td class=br><strong>2</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>De Heidemanis</td><td class=kL>0:10</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=br>8:31</td><td class=br>-23</td>
<td class=bc>0 - 1 - 8</td>
<td class=br><strong>1</strong></td><td class=d>10.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>�d Erenpreiss</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ra St�lmanis</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Da B�rzi��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�d Erenpreiss</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra St�lmanis</td><td class=bc>-</td><td class=bl>Da B�rzi��</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Ma Isakovs</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Da B�rzi��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�d Erenpreiss</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ra St�lmanis</td><td class=bc>-</td><td class=blW>Ma Isakovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Da Mergins</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=bl>Da B�rzi��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ma Isakovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�d Erenpreiss</td><td class=bc>-</td><td class=bl>Da Mergins</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra St�lmanis</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Da B�rzi��</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Ma Isakovs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>Da Mergins</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�d Erenpreiss</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>Ma Isakovs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Da B�rzi��</td><td class=bc>-</td><td class=bl>Da Mergins</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ra St�lmanis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ma Isakovs</td><td class=bc>-</td><td class=bl>Da Mergins</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Da B�rzi��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Ra St�lmanis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>�d Erenpreiss</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ma Isakovs</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Ra St�lmanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da B�rzi��</td><td class=bc>-</td><td class=blW>�d Erenpreiss</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=blW>Ra St�lmanis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ma Isakovs</td><td class=bc>-</td><td class=bl>�d Erenpreiss</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Da B�rzi��</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Ra St�lmanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>�d Erenpreiss</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ma Isakovs</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ra St�lmanis</td><td class=bc>-</td><td class=blW>�d Erenpreiss</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=blW>Ra Meija</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Isakovs</td><td class=bc>-</td><td class=bl>Da B�rzi��</td><td class=bc>2 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
