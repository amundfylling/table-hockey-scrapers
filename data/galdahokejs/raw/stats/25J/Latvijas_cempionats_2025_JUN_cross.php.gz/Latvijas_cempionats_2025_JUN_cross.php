<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Latvijas cempionats 2025 JUN</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Latvijas_cempionats_2025_JUN_list.php">Latvijas cempionats 2025 JUN, 12. April 2025</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group JUN A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Re Vazoli��</td><td class=kx>*</td>
<td class=kW>12:0</td>
<td class=kW>9:2</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kW>8:0</td>
<td class=kW>9:1</td>
<td class=kW>13:1</td>
<td class=kW>11:0</td>
<td class=kW>6:1</td>
<td class=br>84:11</td><td class=br>+73</td>
<td class=bc>10 - 0 - 0</td>
<td class=br><strong>20</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Da Baumanis</td><td class=kL>0:12</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kL>3:4</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>3:2</td>
<td class=br>31:23</td><td class=br>+8</td>
<td class=bc>7 - 1 - 2</td>
<td class=br><strong>15</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ed Putni��</td><td class=kL>2:9</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>7:4</td>
<td class=kW>8:2</td>
<td class=kW>2:0</td>
<td class=kW>6:4</td>
<td class=kW>4:2</td>
<td class=br>36:28</td><td class=br>+8</td>
<td class=bc>6 - 2 - 2</td>
<td class=br><strong>14</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ro Verbi�s</td><td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>10:1</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=br>35:20</td><td class=br>+15</td>
<td class=bc>5 - 3 - 2</td>
<td class=br><strong>13</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt>Fr Platons</td><td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>8:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=br>29:16</td><td class=br>+13</td>
<td class=bc>6 - 1 - 3</td>
<td class=br><strong>13</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt>Ag Pav�rs</td><td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=br>25:22</td><td class=br>+3</td>
<td class=bc>5 - 1 - 4</td>
<td class=br><strong>11</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Al Sili��</td><td class=kL>0:8</td>
<td class=kL>0:4</td>
<td class=kL>4:7</td>
<td class=kL>1:10</td>
<td class=kL>1:8</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=br>20:48</td><td class=br>-28</td>
<td class=bc>3 - 0 - 7</td>
<td class=br><strong>6</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Ar Verbi�s</td><td class=kL>1:9</td>
<td class=kL>0:3</td>
<td class=kL>2:8</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=br>14:44</td><td class=br>-30</td>
<td class=bc>3 - 0 - 7</td>
<td class=br><strong>6</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>C</td><td class=d>9.</td><td class=kt>Kr S�manis</td><td class=kL>1:13</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>6:3</td>
<td class=br>18:37</td><td class=br>-19</td>
<td class=bc>2 - 0 - 8</td>
<td class=br><strong>4</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>C</td><td class=d>10.</td><td class=kt>Br Gor�anovs</td><td class=kL>0:11</td>
<td class=kL>0:8</td>
<td class=kL>4:6</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=br>15:48</td><td class=br>-33</td>
<td class=bc>2 - 0 - 8</td>
<td class=br><strong>4</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>Da Belkovs</td><td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kW>6:0</td>
<td class=kL>3:6</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=br>21:31</td><td class=br>-10</td>
<td class=bc>2 - 0 - 8</td>
<td class=br><strong>4</strong></td><td class=d>11.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>0 : 11</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>0 : 12</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=blW>S�manis Kri�j�nis</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=blW>Sili�� Alberts</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Putni�� Edgars</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=blW>Putni�� Edgars</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>13 : 1</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Sili�� Alberts</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>8 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Putni�� Edgars</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Putni�� Edgars</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>2 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group JUN B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>J� Re�is</td><td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kW>11:2</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>10:3</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=br>50:19</td><td class=br>+31</td>
<td class=bc>8 - 2 - 0</td>
<td class=br><strong>18</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ro Kerns</td><td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=br>33:18</td><td class=br>+15</td>
<td class=bc>7 - 2 - 1</td>
<td class=br><strong>16</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Kr Zem�ickis</td><td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=br>34:16</td><td class=br>+18</td>
<td class=bc>8 - 0 - 2</td>
<td class=br><strong>16</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Kr Kurzemnieks</td><td class=kL>2:11</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>0:9</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=br>30:28</td><td class=br>+2</td>
<td class=bc>7 - 0 - 3</td>
<td class=br><strong>14</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt>Ei G�ze</td><td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=br>18:14</td><td class=br>+4</td>
<td class=bc>6 - 1 - 3</td>
<td class=br><strong>13</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt>M� �irsis</td><td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kW>9:0</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=br>23:11</td><td class=br>+12</td>
<td class=bc>5 - 0 - 5</td>
<td class=br><strong>10</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Ma Kalni��</td><td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=br>14:20</td><td class=br>-6</td>
<td class=bc>3 - 2 - 5</td>
<td class=br><strong>8</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Ol Ozoli��-Karlsons</td><td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=br>17:27</td><td class=br>-10</td>
<td class=bc>3 - 1 - 6</td>
<td class=br><strong>7</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>C</td><td class=d>9.</td><td class=kt>Em Ka�s</td><td class=kL>3:10</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=br>13:35</td><td class=br>-22</td>
<td class=bc>2 - 1 - 7</td>
<td class=br><strong>5</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>C</td><td class=d>10.</td><td class=kt>An Kova��uks</td><td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=br>11:26</td><td class=br>-15</td>
<td class=bc>1 - 1 - 8</td>
<td class=br><strong>3</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>Ra St�lmanis</td><td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=br>5:34</td><td class=br>-29</td>
<td class=bc>0 - 0 - 10</td>
<td class=br><strong>0</strong></td><td class=d>11.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>3 : 10</tr></td>
<tr><td class=brW>Kerns Roberts</td><td class=bc>-</td><td class=bl>Ozoli��-Karlsons Olafs</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>9 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Ozoli��-Karlsons Olafs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kerns Roberts</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Ozoli��-Karlsons Olafs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Ozoli��-Karlsons Olafs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Kerns Roberts</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=blW>Kerns Roberts</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Kerns Roberts</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kerns Roberts</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kova��uks Andris</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 11</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kerns Roberts</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>Ozoli��-Karlsons Olafs</td><td class=bc>1 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group JUN C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Iv �irsis</td><td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kL>1:2</td>
<td class=kW>7:3</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=br>39:22</td><td class=br>+17</td>
<td class=bc>8 - 1 - 1</td>
<td class=br><strong>17</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Al Skudr�tis</td><td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=kW>6:1</td>
<td class=kW>11:1</td>
<td class=kW>8:0</td>
<td class=br>53:15</td><td class=br>+38</td>
<td class=bc>8 - 1 - 1</td>
<td class=br><strong>17</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>To Jakseboga</td><td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=br>25:14</td><td class=br>+11</td>
<td class=bc>6 - 4 - 0</td>
<td class=br><strong>16</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ar Zasurcevs</td><td class=kL>4:5</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>8:3</td>
<td class=kW>7:0</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=br>49:22</td><td class=br>+27</td>
<td class=bc>6 - 1 - 3</td>
<td class=br><strong>13</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt>Ma Krauze</td><td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=br>23:22</td><td class=br>+1</td>
<td class=bc>6 - 1 - 3</td>
<td class=br><strong>13</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt>Er Kalni��</td><td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>3:8</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=br>24:30</td><td class=br>-6</td>
<td class=bc>4 - 1 - 5</td>
<td class=br><strong>9</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>�i Vazoli��</td><td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>17:26</td><td class=br>-9</td>
<td class=bc>4 - 0 - 6</td>
<td class=br><strong>8</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Gu Skapsts</td><td class=kL>3:5</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>9:1</td>
<td class=br>29:31</td><td class=br>-2</td>
<td class=bc>3 - 1 - 6</td>
<td class=br><strong>7</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>C</td><td class=d>9.</td><td class=kt>El Reinfelds</td><td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=br>25:33</td><td class=br>-8</td>
<td class=bc>3 - 1 - 6</td>
<td class=br><strong>7</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>C</td><td class=d>10.</td><td class=kt>Kr Rudz�tis</td><td class=kL>1:6</td>
<td class=kL>1:11</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=br>12:40</td><td class=br>-28</td>
<td class=bc>1 - 0 - 9</td>
<td class=br><strong>2</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>Re Masulis</td><td class=kL>2:3</td>
<td class=kL>0:8</td>
<td class=kT>1:1</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>1:9</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=br>6:47</td><td class=br>-41</td>
<td class=bc>0 - 1 - 9</td>
<td class=br><strong>1</strong></td><td class=d>11.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=blW>Rudz�tis Kristaps</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Masulis Ren�rs</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Masulis Ren�rs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Masulis Ren�rs</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Masulis Ren�rs</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>8 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Masulis Ren�rs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>1 : 11</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Skapsts Gustavs</td><td class=bc>2 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group JUN D</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>He Prokuratovs</td><td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kW>8:0</td>
<td class=kW>5:2</td>
<td class=kW>12:2</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=br>50:15</td><td class=br>+35</td>
<td class=bc>8 - 1 - 1</td>
<td class=br><strong>17</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>J� Bitmanis</td><td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>10:0</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=br>41:5</td><td class=br>+36</td>
<td class=bc>8 - 1 - 1</td>
<td class=br><strong>17</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ri Kalni��</td><td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>29:18</td><td class=br>+11</td>
<td class=bc>7 - 0 - 3</td>
<td class=br><strong>14</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>�v Vikmanis</td><td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>7:1</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=br>29:21</td><td class=br>+8</td>
<td class=bc>5 - 2 - 3</td>
<td class=br><strong>12</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt>Re Stac�vi�s</td><td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>7:5</td>
<td class=kW>5:3</td>
<td class=kL>0:3</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=br>33:27</td><td class=br>+6</td>
<td class=bc>5 - 2 - 3</td>
<td class=br><strong>12</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt>Ra Martu��ns</td><td class=kW>2:0</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>5:7</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=br>31:24</td><td class=br>+7</td>
<td class=bc>6 - 0 - 4</td>
<td class=br><strong>12</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Ge Jansons</td><td class=kL>0:8</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=br>16:31</td><td class=br>-15</td>
<td class=bc>3 - 1 - 6</td>
<td class=br><strong>7</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Re Saul�tis</td><td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=br>26:28</td><td class=br>-2</td>
<td class=bc>3 - 1 - 6</td>
<td class=br><strong>7</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>C</td><td class=d>9.</td><td class=kt>Ro Garda</td><td class=kL>2:12</td>
<td class=kL>0:10</td>
<td class=kL>0:3</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=br>10:50</td><td class=br>-40</td>
<td class=bc>2 - 0 - 8</td>
<td class=br><strong>4</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>C</td><td class=d>10.</td><td class=kt>Al Liepi��</td><td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>18:36</td><td class=br>-18</td>
<td class=bc>1 - 2 - 7</td>
<td class=br><strong>4</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>�r Egl�tis</td><td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>10:38</td><td class=br>-28</td>
<td class=bc>2 - 0 - 8</td>
<td class=br><strong>4</strong></td><td class=d>11.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Stac�vi�s Reinis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>7 : 5</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>10 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>12 : 2</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=blW>Garda Roberts</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=blW>Bitmanis J�nis Mi�elis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Vikmanis �ve</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Garda Roberts</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Bitmanis J�nis Mi�elis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Vikmanis �ve</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=blW>Stac�vi�s Reinis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Bitmanis J�nis Mi�elis</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Vikmanis �ve</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Stac�vi�s Reinis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>1 : 6</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group JUN 1.liga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/8</td><td class=d>1.</td><td class=kt>J� Re�is</td><td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>12:1</td>
<td class=kW>6:5</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=br>57:33</td><td class=br>+24</td>
<td class=bc>11 - 3 - 1</td>
<td class=br><strong>25</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/8</td><td class=d>2.</td><td class=kt>Re Vazoli��</td><td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=br>65:33</td><td class=br>+32</td>
<td class=bc>11 - 2 - 2</td>
<td class=br><strong>24</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/8</td><td class=d>3.</td><td class=kt>Al Skudr�tis</td><td class=kT>4:4</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kL>0:2</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=br>50:35</td><td class=br>+15</td>
<td class=bc>10 - 1 - 4</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/8</td><td class=d>4.</td><td class=kt>He Prokuratovs</td><td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kW>7:2</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=br>53:33</td><td class=br>+20</td>
<td class=bc>8 - 4 - 3</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/8</td><td class=d>5.</td><td class=kt>Ro Kerns</td><td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=br>31:24</td><td class=br>+7</td>
<td class=bc>7 - 4 - 4</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/8</td><td class=d>6.</td><td class=kt>Ro Verbi�s</td><td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>0:1</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=br>36:31</td><td class=br>+5</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/8</td><td class=d>7.</td><td class=kt>Ar Zasurcevs</td><td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kW>2:0</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=br>32:35</td><td class=br>-3</td>
<td class=bc>6 - 3 - 6</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/8</td><td class=d>8.</td><td class=kt>Kr Zem�ickis</td><td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=br>31:38</td><td class=br>-7</td>
<td class=bc>6 - 3 - 6</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>J� Bitmanis</td><td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>6:0</td>
<td class=br>34:28</td><td class=br>+6</td>
<td class=bc>7 - 0 - 8</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ed Putni��</td><td class=kL>3:4</td>
<td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kL>2:7</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kW>4:1</td>
<td class=kW>7:6</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=br>50:44</td><td class=br>+6</td>
<td class=bc>7 - 0 - 8</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>To Jakseboga</td><td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kW>4:1</td>
<td class=br>33:45</td><td class=br>-12</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Iv �irsis</td><td class=kL>1:12</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=br>35:55</td><td class=br>-20</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Kr Kurzemnieks</td><td class=kL>5:6</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>3:6</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=br>37:49</td><td class=br>-12</td>
<td class=bc>4 - 2 - 9</td>
<td class=br><strong>10</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Da Baumanis</td><td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>6:7</td>
<td class=kW>5:1</td>
<td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=br>40:47</td><td class=br>-7</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Ri Kalni��</td><td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=br>27:44</td><td class=br>-17</td>
<td class=bc>2 - 4 - 9</td>
<td class=br><strong>8</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>�v Vikmanis</td><td class=kL>2:7</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kL>0:7</td>
<td class=kT>3:3</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=br>29:66</td><td class=br>-37</td>
<td class=bc>2 - 3 - 10</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kerns Roberts</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>12 : 1</tr></td>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Kerns Roberts</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Kerns Roberts</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Kurzemnieks Kri�j�nis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Kerns Roberts</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Putni�� Edgars</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Kurzemnieks Kri�j�nis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Kerns Roberts</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Kerns Roberts</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Verbi�s Roberts</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Putni�� Edgars</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Verbi�s Roberts</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kerns Roberts</td><td class=bc>-</td><td class=bl>Putni�� Edgars</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>Putni�� Edgars</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Putni�� Edgars</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>7 : 6</tr></td>
<tr><td class=brW>Verbi�s Roberts</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kerns Roberts</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Bitmanis J�nis Mi�elis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Putni�� Edgars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Verbi�s Roberts</td><td class=bc>-</td><td class=blW>Vikmanis �ve</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kerns Roberts</td><td class=bc>-</td><td class=blW>Bitmanis J�nis Mi�elis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kurzemnieks Kri�j�nis</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>2 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group JUN 2.liga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt>Fr Platons</td><td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kL>0:5</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=br>36:23</td><td class=br>+13</td>
<td class=bc>10 - 2 - 3</td>
<td class=br><strong>22</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt>Er Kalni��</td><td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=br>40:31</td><td class=br>+9</td>
<td class=bc>10 - 1 - 4</td>
<td class=br><strong>21</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt>Ra Martu��ns</td><td class=kW>5:0</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=kW>8:0</td>
<td class=kW>7:1</td>
<td class=br>55:20</td><td class=br>+35</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt>�i Vazoli��</td><td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=br>29:21</td><td class=br>+8</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ma Kalni��</td><td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=br>33:24</td><td class=br>+9</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>M� �irsis</td><td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=br>38:34</td><td class=br>+4</td>
<td class=bc>6 - 6 - 3</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Ar Verbi�s</td><td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:8</td>
<td class=kW>5:0</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=br>32:32</td><td class=br>0</td>
<td class=bc>8 - 1 - 6</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ma Krauze</td><td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=br>39:32</td><td class=br>+7</td>
<td class=bc>7 - 3 - 5</td>
<td class=br><strong>17</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Re Saul�tis</td><td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>8:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=br>41:34</td><td class=br>+7</td>
<td class=bc>6 - 4 - 5</td>
<td class=br><strong>16</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ag Pav�rs</td><td class=kL>0:2</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=br>25:30</td><td class=br>-5</td>
<td class=bc>7 - 1 - 7</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ge Jansons</td><td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=kW>3:2</td>
<td class=kW>8:1</td>
<td class=br>42:43</td><td class=br>-1</td>
<td class=bc>5 - 3 - 7</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ei G�ze</td><td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kT>0:0</td>
<td class=kW>4:2</td>
<td class=br>30:35</td><td class=br>-5</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Re Stac�vi�s</td><td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>6:1</td>
<td class=br>31:39</td><td class=br>-8</td>
<td class=bc>4 - 2 - 9</td>
<td class=br><strong>10</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Ol Ozoli��-Karlsons</td><td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=br>23:43</td><td class=br>-20</td>
<td class=bc>2 - 3 - 10</td>
<td class=br><strong>7</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Gu Skapsts</td><td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>0:8</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>0:0</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=br>22:41</td><td class=br>-19</td>
<td class=bc>3 - 1 - 11</td>
<td class=br><strong>7</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Al Sili��</td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=br>20:54</td><td class=br>-34</td>
<td class=bc>3 - 1 - 11</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Stac�vi�s Reinis</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Stac�vi�s Reinis</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Ozoli��-Karlsons Olafs</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>Ozoli��-Karlsons Olafs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Ozoli��-Karlsons Olafs</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Skapsts Gustavs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ozoli��-Karlsons Olafs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>Vazoli�� �irts</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Ozoli��-Karlsons Olafs</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Ozoli��-Karlsons Olafs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Ozoli��-Karlsons Olafs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>G�ze Ein�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Ozoli��-Karlsons Olafs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>G�ze Ein�rs</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Verbi�s Art�rs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Verbi�s Art�rs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Sili�� Alberts</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vazoli�� �irts</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Verbi�s Art�rs</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>G�ze Ein�rs</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=blW>Stac�vi�s Reinis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Vazoli�� �irts</td><td class=bc>3 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group JUN 3.liga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt>Br Gor�anovs</td><td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>4:5</td>
<td class=kL>3:5</td>
<td class=kW>7:4</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=br>38:23</td><td class=br>+15</td>
<td class=bc>8 - 0 - 3</td>
<td class=br><strong>16</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt>�r Egl�tis</td><td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=br>29:23</td><td class=br>+6</td>
<td class=bc>7 - 1 - 3</td>
<td class=br><strong>15</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt>Ra St�lmanis</td><td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>3:7</td>
<td class=kT>1:1</td>
<td class=br>23:24</td><td class=br>-1</td>
<td class=bc>4 - 5 - 2</td>
<td class=br><strong>13</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt>El Reinfelds</td><td class=kW>5:3</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=br>37:28</td><td class=br>+9</td>
<td class=bc>5 - 3 - 3</td>
<td class=br><strong>13</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>An Kova��uks</td><td class=kL>4:7</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>32:22</td><td class=br>+10</td>
<td class=bc>6 - 1 - 4</td>
<td class=br><strong>13</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Kr Rudz�tis</td><td class=kL>0:1</td>
<td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=br>22:16</td><td class=br>+6</td>
<td class=bc>5 - 2 - 4</td>
<td class=br><strong>12</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Da Belkovs</td><td class=kL>1:3</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kW>5:3</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>7:0</td>
<td class=br>34:25</td><td class=br>+9</td>
<td class=bc>6 - 0 - 5</td>
<td class=br><strong>12</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Al Liepi��</td><td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=br>25:22</td><td class=br>+3</td>
<td class=bc>4 - 3 - 4</td>
<td class=br><strong>11</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Em Ka�s</td><td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>1:0</td>
<td class=kW>6:0</td>
<td class=br>23:24</td><td class=br>-1</td>
<td class=bc>4 - 3 - 4</td>
<td class=br><strong>11</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ro Garda</td><td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=br>27:33</td><td class=br>-6</td>
<td class=bc>3 - 2 - 6</td>
<td class=br><strong>8</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Kr S�manis</td><td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kW>7:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=br>28:29</td><td class=br>-1</td>
<td class=bc>3 - 1 - 7</td>
<td class=br><strong>7</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Re Masulis</td><td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=br>2:51</td><td class=br>-49</td>
<td class=bc>0 - 1 - 10</td>
<td class=br><strong>1</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Masulis Ren�rs</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Masulis Ren�rs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Masulis Ren�rs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Rudz�tis Kristaps</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Kova��uks Andris</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=blW>Rudz�tis Kristaps</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Kova��uks Andris</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Garda Roberts</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=blW>Kova��uks Andris</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=blW>Garda Roberts</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>6 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Kova��uks Andris</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>S�manis Kri�j�nis</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=blW>S�manis Kri�j�nis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kova��uks Andris</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Masulis Ren�rs</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Garda Roberts</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Masulis Ren�rs</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Masulis Ren�rs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>1 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
