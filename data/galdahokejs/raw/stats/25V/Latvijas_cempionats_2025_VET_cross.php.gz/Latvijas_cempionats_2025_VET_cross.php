<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Latvijas cempionats 2025 VET</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../25V/Latvijas_cempionats_2025_VET_index.php">Latvijas cempionats 2025 VET, 12. April 2025</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group VET A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Sa Krasts</td><td class=kx>*</td>
<td class=kL>1:2 + 3:3</td>
<td class=kT>4:4 + 3:1</td>
<td class=kL>1:3 + 3:2</td>
<td class=kL>0:3 + 2:1</td>
<td class=kW>6:0 + 3:2</td>
<td class=kW>2:1 + 5:1</td>
<td class=kW>3:1 + 4:1</td>
<td class=kW>5:3 + 6:1</td>
<td class=br>51:29</td><td class=br>+22</td>
<td class=bc>11 - 2 - 3</td>
<td class=br><strong>24</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Se Mihejevs</td><td class=kW>2:1 + 3:3</td>
<td class=kx>*</td>
<td class=kW>3:0 + 2:3</td>
<td class=kW>3:2 + 3:1</td>
<td class=kT>2:2 + 1:0</td>
<td class=kL>2:3 + 1:1</td>
<td class=kT>2:2 + 6:1</td>
<td class=kW>4:0 + 0:2</td>
<td class=kW>4:0 + 3:2</td>
<td class=br>41:23</td><td class=br>+18</td>
<td class=bc>9 - 4 - 3</td>
<td class=br><strong>22</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Al �ernovojs</td><td class=kT>4:4 + 1:3</td>
<td class=kL>0:3 + 3:2</td>
<td class=kx>*</td>
<td class=kW>6:1 + 3:1</td>
<td class=kL>1:3 + 3:1</td>
<td class=kW>2:1 + 1:3</td>
<td class=kT>2:2 + 4:1</td>
<td class=kT>1:1 + 4:1</td>
<td class=kW>6:2 + 6:1</td>
<td class=br>47:30</td><td class=br>+17</td>
<td class=bc>9 - 3 - 4</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Sa Skarainis</td><td class=kW>3:1 + 2:3</td>
<td class=kL>2:3 + 1:3</td>
<td class=kL>1:6 + 1:3</td>
<td class=kx>*</td>
<td class=kW>2:1 + 3:1</td>
<td class=kW>5:2 + 3:4</td>
<td class=kW>5:0 + 5:2</td>
<td class=kW>2:0 + 4:1</td>
<td class=kW>5:1 + 5:2</td>
<td class=br>49:33</td><td class=br>+16</td>
<td class=bc>10 - 0 - 6</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Sa Kalni��</td><td class=kW>3:0 + 1:2</td>
<td class=kT>2:2 + 0:1</td>
<td class=kW>3:1 + 1:3</td>
<td class=kL>1:2 + 1:3</td>
<td class=kx>*</td>
<td class=kT>2:2 + 4:2</td>
<td class=kW>5:1 + 3:1</td>
<td class=kW>3:2 + 4:0</td>
<td class=kW>4:0 + 3:0</td>
<td class=br>40:22</td><td class=br>+18</td>
<td class=bc>9 - 2 - 5</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ro Fa�ken�teins</td><td class=kL>0:6 + 2:3</td>
<td class=kW>3:2 + 1:1</td>
<td class=kL>1:2 + 3:1</td>
<td class=kL>2:5 + 4:3</td>
<td class=kT>2:2 + 2:4</td>
<td class=kx>*</td>
<td class=kW>3:2 + 0:4</td>
<td class=kW>3:1 + 1:2</td>
<td class=kW>4:0 + 3:1</td>
<td class=br>34:39</td><td class=br>-5</td>
<td class=bc>7 - 2 - 7</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Gu Buls</td><td class=kL>1:2 + 1:5</td>
<td class=kT>2:2 + 1:6</td>
<td class=kT>2:2 + 1:4</td>
<td class=kL>0:5 + 2:5</td>
<td class=kL>1:5 + 1:3</td>
<td class=kL>2:3 + 4:0</td>
<td class=kx>*</td>
<td class=kT>3:3 + 5:0</td>
<td class=kW>2:0 + 1:1</td>
<td class=br>29:46</td><td class=br>-17</td>
<td class=bc>3 - 4 - 9</td>
<td class=br><strong>10</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>J� Zem�ickis</td><td class=kL>1:3 + 1:4</td>
<td class=kL>0:4 + 2:0</td>
<td class=kT>1:1 + 1:4</td>
<td class=kL>0:2 + 1:4</td>
<td class=kL>2:3 + 0:4</td>
<td class=kL>1:3 + 2:1</td>
<td class=kT>3:3 + 0:5</td>
<td class=kx>*</td>
<td class=kT>1:1 + 0:1</td>
<td class=br>16:43</td><td class=br>-27</td>
<td class=bc>2 - 3 - 11</td>
<td class=br><strong>7</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>J� Rekti��</td><td class=kL>3:5 + 1:6</td>
<td class=kL>0:4 + 2:3</td>
<td class=kL>2:6 + 1:6</td>
<td class=kL>1:5 + 2:5</td>
<td class=kL>0:4 + 0:3</td>
<td class=kL>0:4 + 1:3</td>
<td class=kL>0:2 + 1:1</td>
<td class=kT>1:1 + 1:0</td>
<td class=kx>*</td>
<td class=br>16:58</td><td class=br>-42</td>
<td class=bc>1 - 2 - 13</td>
<td class=br><strong>4</strong></td><td class=d>9.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Buls Gun�rs</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>2 : 2 + 1 : 4</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>3 : 1 + 1 : 2</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>1 : 2 + 1 : 3</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>5 : 3 + 6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>1 : 1 + 4 : 1</tr></td>
<tr><td class=br>Buls Gun�rs</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>0 : 5 + 2 : 5</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>4 : 0 + 3 : 1</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>2 : 2 + 0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>0 : 2 + 1 : 4</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>6 : 2 + 6 : 1</tr></td>
<tr><td class=br>Buls Gun�rs</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>2 : 2 + 1 : 6</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>0 : 6 + 2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>5 : 1 + 5 : 2</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>0 : 4 + 2 : 0</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>4 : 4 + 1 : 3</tr></td>
<tr><td class=br>Buls Gun�rs</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>1 : 5 + 1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>0 : 4 + 2 : 3</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>3 : 1 + 2 : 3</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>2 : 3 + 0 : 4</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>2 : 1 + 1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>2 : 1 + 3 : 3</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>0 : 4 + 0 : 3</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>5 : 2 + 3 : 4</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=bl>Buls Gun�rs</td><td class=bc>3 : 3 + 0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>0 : 3 + 2 : 1</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>2 : 3 + 1 : 1</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Buls Gun�rs</td><td class=bc>0 : 2 + 1 : 1</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>1 : 6 + 1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>2 : 2 + 4 : 2</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Buls Gun�rs</td><td class=bc>2 : 1 + 5 : 1</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>3 : 0 + 2 : 3</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>1 : 1 + 1 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Buls Gun�rs</td><td class=bc>3 : 2 + 0 : 4</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>3 : 1 + 1 : 3</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>3 : 1 + 4 : 1</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>3 : 2 + 3 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group VET aplis</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt>Gu Buls</td><td class=kx>*</td>
<td class=kW>2:0 + 5:2 + 2:3</td>
<td class=kT>0:0 + 5:1 + 5:0</td>
<td class=br>19:6</td><td class=br>+13</td>
<td class=bc>4 - 1 - 1</td>
<td class=br><strong>9</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt>J� Rekti��</td><td class=kL>0:2 + 2:5 + 3:2</td>
<td class=kx>*</td>
<td class=kW>2:1 + 4:0 + 5:0</td>
<td class=br>16:10</td><td class=br>+6</td>
<td class=bc>4 - 0 - 2</td>
<td class=br><strong>8</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt>J� Zem�ickis</td><td class=kT>0:0 + 1:5 + 0:5</td>
<td class=kL>1:2 + 0:4 + 0:5</td>
<td class=kx>*</td>
<td class=br>2:21</td><td class=br>-19</td>
<td class=bc>0 - 1 - 5</td>
<td class=br><strong>1</strong></td><td class=d>3.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Buls Gun�rs</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>2 : 0 + 5 : 2 + 2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Rekti�� J�nis</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>2 : 1 + 4 : 0 + 5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=bl>Buls Gun�rs</td><td class=bc>0 : 0 + 1 : 5 + 0 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
