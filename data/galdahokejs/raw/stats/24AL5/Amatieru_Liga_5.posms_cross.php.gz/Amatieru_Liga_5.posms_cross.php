<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Amatieru Liga 5.posms</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../24AL5/Amatieru_Liga_5.posms_index.php">Amatieru Liga 5.posms, 2. March 2024</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group AL A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Re Stac�vi�s</td><td class=kx>*</td>
<td class=kW>8:3</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>1:0</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=br>57:22</td><td class=br>+35</td>
<td class=bc>11 - 3 - 1</td>
<td class=br><strong>25</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Iv �irsis</td><td class=kL>3:8</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kW>8:1</td>
<td class=br>55:38</td><td class=br>+17</td>
<td class=bc>11 - 1 - 3</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>An Zi�icka</td><td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>40:23</td><td class=br>+17</td>
<td class=bc>10 - 1 - 4</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Il �irse</td><td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>8:1</td>
<td class=br>51:23</td><td class=br>+28</td>
<td class=bc>10 - 1 - 4</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ra Talbergs</td><td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=kW>5:2</td>
<td class=br>52:26</td><td class=br>+26</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>As Kocere</td><td class=kL>0:5</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=br>55:35</td><td class=br>+20</td>
<td class=bc>8 - 3 - 4</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>J� Zem�ickis</td><td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=br>37:24</td><td class=br>+13</td>
<td class=bc>8 - 3 - 4</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ar Pavlovs</td><td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kW>2:0</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kT>0:0</td>
<td class=kW>6:1</td>
<td class=br>34:28</td><td class=br>+6</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ra St�lmanis</td><td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=br>32:28</td><td class=br>+4</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ro Purmalis</td><td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kL>0:1</td>
<td class=kW>10:0</td>
<td class=br>40:34</td><td class=br>+6</td>
<td class=bc>6 - 1 - 8</td>
<td class=br><strong>13</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Al Liepi��</td><td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=br>28:36</td><td class=br>-8</td>
<td class=bc>4 - 4 - 7</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Kr G�tmanis</td><td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>28:31</td><td class=br>-3</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ed Jansons</td><td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=br>30:46</td><td class=br>-16</td>
<td class=bc>5 - 0 - 10</td>
<td class=br><strong>10</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Al Sili��</td><td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=br>18:38</td><td class=br>-20</td>
<td class=bc>3 - 2 - 10</td>
<td class=br><strong>8</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Ra Meija</td><td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kT>0:0</td>
<td class=kL>0:3</td>
<td class=kW>1:0</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>9:56</td><td class=br>-47</td>
<td class=bc>2 - 1 - 12</td>
<td class=br><strong>5</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Mi Birzgalis</td><td class=kL>0:7</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>1:8</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>0:10</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>7:85</td><td class=br>-78</td>
<td class=bc>0 - 0 - 15</td>
<td class=br><strong>0</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Mi Birzgalis</td><td class=bc>-</td><td class=blW>An Zi�icka</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ed Jansons</td><td class=bc>-</td><td class=blW>As Kocere</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Ra St�lmanis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ra Talbergs</td><td class=bc>-</td><td class=blW>Ar Pavlovs</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>An Zi�icka</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Birzgalis</td><td class=bc>-</td><td class=blW>As Kocere</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Kr G�tmanis</td><td class=bc>-</td><td class=bl>Ra St�lmanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ed Jansons</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Ra Talbergs</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>An Zi�icka</td><td class=bc>-</td><td class=bl>Ra St�lmanis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Birzgalis</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ed Jansons</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Ra Talbergs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>Ra St�lmanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>An Zi�icka</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Mi Birzgalis</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=blW>Ar Pavlovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ed Jansons</td><td class=bc>-</td><td class=blW>Ra Talbergs</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ra St�lmanis</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>An Zi�icka</td><td class=bc>-</td><td class=blW>Ar Pavlovs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Birzgalis</td><td class=bc>-</td><td class=blW>Ra Talbergs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ed Jansons</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ra St�lmanis</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Ra Talbergs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>An Zi�icka</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Birzgalis</td><td class=bc>-</td><td class=blW>Ra Meija</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ed Jansons</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra St�lmanis</td><td class=bc>-</td><td class=blW>Ra Talbergs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>An Zi�icka</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Birzgalis</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=blW>Ed Jansons</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ra Talbergs</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ra St�lmanis</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Zi�icka</td><td class=bc>-</td><td class=blW>Ed Jansons</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Birzgalis</td><td class=bc>-</td><td class=blW>Kr G�tmanis</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ar Pavlovs</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Ra Meija</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra St�lmanis</td><td class=bc>-</td><td class=bl>Ed Jansons</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Mi Birzgalis</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>An Zi�icka</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ra Talbergs</td><td class=bc>-</td><td class=bl>Ra Meija</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ed Jansons</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>Kr G�tmanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ra St�lmanis</td><td class=bc>-</td><td class=bl>Mi Birzgalis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>An Zi�icka</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ra Talbergs</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=blW>Ed Jansons</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Mi Birzgalis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>An Zi�icka</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ra St�lmanis</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Ed Jansons</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ra Talbergs</td><td class=bc>-</td><td class=blW>Kr G�tmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ar Pavlovs</td><td class=bc>-</td><td class=bl>Mi Birzgalis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>An Zi�icka</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ra St�lmanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Ed Jansons</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Kr G�tmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Mi Birzgalis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ra Talbergs</td><td class=bc>-</td><td class=bl>An Zi�icka</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ar Pavlovs</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ra St�lmanis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Mi Birzgalis</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>An Zi�icka</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ra Talbergs</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ar Pavlovs</td><td class=bc>-</td><td class=bl>Ra St�lmanis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ed Jansons</td><td class=bc>-</td><td class=bl>Mi Birzgalis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>An Zi�icka</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>As Kocere</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=bl>Ra St�lmanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ra Talbergs</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ar Pavlovs</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=blW>An Zi�icka</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ed Jansons</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Ra St�lmanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ra Meija</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ra Talbergs</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group AL B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ei G�ze</td><td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=br>53:10</td><td class=br>+43</td>
<td class=bc>15 - 0 - 0</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>L� Bezdel�ga</td><td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=br>59:14</td><td class=br>+45</td>
<td class=bc>11 - 2 - 2</td>
<td class=br><strong>24</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>�v Vikmanis</td><td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>6:5</td>
<td class=kL>3:7</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>1:0</td>
<td class=br>43:30</td><td class=br>+13</td>
<td class=bc>10 - 2 - 3</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ro Aseri��</td><td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kL>0:1</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=kW>2:0</td>
<td class=br>40:14</td><td class=br>+26</td>
<td class=bc>10 - 2 - 3</td>
<td class=br><strong>22</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Da Baumanis</td><td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>9:1</td>
<td class=kW>8:0</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=br>52:28</td><td class=br>+24</td>
<td class=bc>10 - 1 - 4</td>
<td class=br><strong>21</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>D� Vesele</td><td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>8:1</td>
<td class=kW>8:0</td>
<td class=kW>6:0</td>
<td class=br>54:23</td><td class=br>+31</td>
<td class=bc>8 - 3 - 4</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Re Saul�tis</td><td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>5:6</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>9:0</td>
<td class=kW>4:0</td>
<td class=kW>10:1</td>
<td class=kW>4:0</td>
<td class=br>51:26</td><td class=br>+25</td>
<td class=bc>7 - 3 - 5</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ar Verbi�s</td><td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kW>7:3</td>
<td class=kW>1:0</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>7:0</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=br>39:24</td><td class=br>+15</td>
<td class=bc>6 - 5 - 4</td>
<td class=br><strong>17</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>J� T�ns</td><td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=br>36:28</td><td class=br>+8</td>
<td class=bc>7 - 3 - 5</td>
<td class=br><strong>17</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ag Pav�rs</td><td class=kL>1:7</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=br>44:42</td><td class=br>+2</td>
<td class=bc>8 - 1 - 6</td>
<td class=br><strong>17</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Em Ka�s</td><td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=br>25:40</td><td class=br>-15</td>
<td class=bc>4 - 2 - 9</td>
<td class=br><strong>10</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Br Gor�anovs</td><td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>0:1</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=br>26:45</td><td class=br>-19</td>
<td class=bc>4 - 2 - 9</td>
<td class=br><strong>10</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>M� Timbers</td><td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:9</td>
<td class=kL>0:5</td>
<td class=kL>0:9</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>1:0</td>
<td class=br>17:55</td><td class=br>-38</td>
<td class=bc>3 - 0 - 12</td>
<td class=br><strong>6</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>De Heidemanis</td><td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>1:8</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kT>0:0</td>
<td class=br>6:66</td><td class=br>-60</td>
<td class=bc>1 - 2 - 12</td>
<td class=br><strong>4</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Da Mergins</td><td class=kL>0:1</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>0:2</td>
<td class=kL>0:8</td>
<td class=kL>1:10</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>1:7</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>5:72</td><td class=br>-67</td>
<td class=bc>1 - 0 - 14</td>
<td class=br><strong>2</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Kr Kl�vi��</td><td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kT>0:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>11:44</td><td class=br>-33</td>
<td class=bc>0 - 2 - 13</td>
<td class=br><strong>2</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Ar Verbi�s</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>J� T�ns</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Da Mergins</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>Ar Verbi�s</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>De Heidemanis</td><td class=bc>-</td><td class=bl>Da Mergins</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>Ar Verbi�s</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Da Mergins</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ar Verbi�s</td><td class=bc>-</td><td class=blW>J� T�ns</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Da Mergins</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>8 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>J� T�ns</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ar Verbi�s</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>Da Mergins</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>J� T�ns</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ar Verbi�s</td><td class=bc>-</td><td class=bl>Da Mergins</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>M� Timbers</td><td class=bc>-</td><td class=bl>Da Mergins</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ar Verbi�s</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>Da Mergins</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>J� T�ns</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ar Verbi�s</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ar Verbi�s</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>De Heidemanis</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ar Verbi�s</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ar Verbi�s</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Ar Verbi�s</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=bl>Ar Verbi�s</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Ar Verbi�s</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=blW>J� T�ns</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=blW>M� Timbers</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>Ar Verbi�s</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>J� T�ns</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Kr Kl�vi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Ar Verbi�s</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>De Heidemanis</td><td class=bc>-</td><td class=blW>M� Timbers</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Kr Kl�vi��</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Da Mergins</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
