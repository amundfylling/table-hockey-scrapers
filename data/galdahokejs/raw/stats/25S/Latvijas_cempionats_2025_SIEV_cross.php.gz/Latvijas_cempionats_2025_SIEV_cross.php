<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Latvijas cempionats 2025 SIEV</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../25S/Latvijas_cempionats_2025_SIEV_index.php">Latvijas cempionats 2025 SIEV, 12. April 2025</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group SIEV A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Kr Lagzdi�a</td><td class=kx>*</td>
<td class=kW>4:3 + 3:2</td>
<td class=kW>5:1 + 4:2</td>
<td class=kW>2:1 + 3:0</td>
<td class=kW>7:2 + 8:0</td>
<td class=kW>7:1 + 1:3</td>
<td class=kW>2:1 + 1:1</td>
<td class=kW>4:2 + 6:0</td>
<td class=kW>3:0 + 7:2</td>
<td class=br>67:21</td><td class=br>+46</td>
<td class=bc>14 - 1 - 1</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>El R�cen�ja</td><td class=kL>3:4 + 2:3</td>
<td class=kx>*</td>
<td class=kL>0:5 + 4:2</td>
<td class=kT>3:3 + 7:3</td>
<td class=kT>4:4 + 2:2</td>
<td class=kW>2:1 + 2:1</td>
<td class=kW>1:0 + 4:2</td>
<td class=kW>7:2 + 2:3</td>
<td class=kW>3:0 + 4:0</td>
<td class=br>50:35</td><td class=br>+15</td>
<td class=bc>9 - 3 - 4</td>
<td class=br><strong>21</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ka �iha�ova</td><td class=kL>1:5 + 2:4</td>
<td class=kW>5:0 + 2:4</td>
<td class=kx>*</td>
<td class=kT>5:5 + 3:5</td>
<td class=kW>4:1 + 5:1</td>
<td class=kT>1:1 + 4:4</td>
<td class=kW>5:1 + 1:4</td>
<td class=kW>4:2 + 5:4</td>
<td class=kW>4:2 + 6:0</td>
<td class=br>57:43</td><td class=br>+14</td>
<td class=bc>8 - 3 - 5</td>
<td class=br><strong>19</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Il �irse</td><td class=kL>1:2 + 0:3</td>
<td class=kT>3:3 + 3:7</td>
<td class=kT>5:5 + 5:3</td>
<td class=kx>*</td>
<td class=kW>6:2 + 2:4</td>
<td class=kL>3:4 + 4:0</td>
<td class=kW>4:3 + 6:3</td>
<td class=kW>7:2 + 2:2</td>
<td class=kW>7:3 + 7:1</td>
<td class=br>65:47</td><td class=br>+18</td>
<td class=bc>8 - 3 - 5</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt>D� Vesele</td><td class=kL>2:7 + 0:8</td>
<td class=kT>4:4 + 2:2</td>
<td class=kL>1:4 + 1:5</td>
<td class=kL>2:6 + 4:2</td>
<td class=kx>*</td>
<td class=kT>2:2 + 2:0</td>
<td class=kW>6:2 + 3:1</td>
<td class=kW>4:2 + 2:0</td>
<td class=kW>3:2 + 6:1</td>
<td class=br>44:48</td><td class=br>-4</td>
<td class=bc>8 - 3 - 5</td>
<td class=br><strong>19</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt>Marg �bele</td><td class=kL>1:7 + 3:1</td>
<td class=kL>1:2 + 1:2</td>
<td class=kT>1:1 + 4:4</td>
<td class=kW>4:3 + 0:4</td>
<td class=kT>2:2 + 0:2</td>
<td class=kx>*</td>
<td class=kW>7:1 + 0:5</td>
<td class=kW>6:1 + 4:1</td>
<td class=kW>4:1 + 3:1</td>
<td class=br>41:38</td><td class=br>+3</td>
<td class=bc>7 - 3 - 6</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>L� Bezdel�ga</td><td class=kL>1:2 + 1:1</td>
<td class=kL>0:1 + 2:4</td>
<td class=kL>1:5 + 4:1</td>
<td class=kL>3:4 + 3:6</td>
<td class=kL>2:6 + 1:3</td>
<td class=kL>1:7 + 5:0</td>
<td class=kx>*</td>
<td class=kL>2:3 + 5:0</td>
<td class=kW>5:1 + 5:2</td>
<td class=br>41:46</td><td class=br>-5</td>
<td class=bc>5 - 1 - 10</td>
<td class=br><strong>11</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>As Kocere</td><td class=kL>2:4 + 0:6</td>
<td class=kL>2:7 + 3:2</td>
<td class=kL>2:4 + 4:5</td>
<td class=kL>2:7 + 2:2</td>
<td class=kL>2:4 + 0:2</td>
<td class=kL>1:6 + 1:4</td>
<td class=kW>3:2 + 0:5</td>
<td class=kx>*</td>
<td class=kW>4:0 + 2:2</td>
<td class=br>30:62</td><td class=br>-32</td>
<td class=bc>3 - 2 - 11</td>
<td class=br><strong>8</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>T� Gor�anova</td><td class=kL>0:3 + 2:7</td>
<td class=kL>0:3 + 0:4</td>
<td class=kL>2:4 + 0:6</td>
<td class=kL>3:7 + 1:7</td>
<td class=kL>2:3 + 1:6</td>
<td class=kL>1:4 + 1:3</td>
<td class=kL>1:5 + 2:5</td>
<td class=kL>0:4 + 2:2</td>
<td class=kx>*</td>
<td class=br>18:73</td><td class=br>-55</td>
<td class=bc>0 - 1 - 15</td>
<td class=br><strong>1</strong></td><td class=d>9.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>2 : 2 + 0 : 2</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>0 : 1 + 2 : 4</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>2 : 4 + 0 : 6</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 2 + 0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>4 : 4 + 2 : 2</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=bl>�iha�ova Katr�na</td><td class=bc>1 : 1 + 4 : 4</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 2 + 1 : 1</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>0 : 4 + 2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>0 : 5 + 4 : 2</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>2 : 7 + 0 : 8</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>6 : 1 + 4 : 1</tr></td>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>3 : 4 + 3 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 5 + 2 : 4</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>7 : 2 + 2 : 3</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>2 : 6 + 4 : 2</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>4 : 1 + 3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>4 : 2 + 6 : 0</tr></td>
<tr><td class=br>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>5 : 5 + 3 : 5</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>3 : 0 + 4 : 0</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>6 : 2 + 3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>2 : 7 + 2 : 2</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>3 : 0 + 7 : 2</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>5 : 1 + 1 : 4</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>2 : 1 + 2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>�irse Ilze</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>7 : 3 + 7 : 1</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Bezdel�ga L�sma</td><td class=bc>3 : 2 + 0 : 5</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>7 : 1 + 1 : 3</tr></td>
<tr><td class=brW>�iha�ova Katr�na</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>4 : 1 + 5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Bezdel�ga L�sma</td><td class=bc>1 : 5 + 2 : 5</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>3 : 4 + 4 : 0</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>2 : 4 + 0 : 2</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>4 : 3 + 3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Bezdel�ga L�sma</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>1 : 7 + 5 : 0</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>2 : 3 + 1 : 6</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>3 : 3 + 3 : 7</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>�iha�ova Katr�na</td><td class=bc>2 : 4 + 4 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
