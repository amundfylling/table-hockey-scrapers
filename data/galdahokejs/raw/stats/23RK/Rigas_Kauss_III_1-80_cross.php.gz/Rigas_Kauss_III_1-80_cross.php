<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Rigas Kauss III 1-80</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../23RK/Rigas_Kauss_III_1-80_index.php">Rigas Kauss III 1-80, 2. decembris 2023</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group SF A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Pa Petr</td><td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kW>6:2</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kW>6:5</td>
<td class=kW>9:0</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=br>67:34</td><td class=br>+33</td>
<td class=bc>12 - 0 - 3</td>
<td class=br><strong>24</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Un �sterman</td><td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>8:3</td>
<td class=br>55:35</td><td class=br>+20</td>
<td class=bc>10 - 3 - 2</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>D� Apfelbaums</td><td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=br>38:24</td><td class=br>+14</td>
<td class=bc>10 - 2 - 3</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Tr Mansson</td><td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=br>38:27</td><td class=br>+11</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ja Pelkonen</td><td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>6:3</td>
<td class=kL>5:6</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=br>56:40</td><td class=br>+16</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>To Baumanis</td><td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>8:0</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=br>53:34</td><td class=br>+19</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ma Zenisek</td><td class=kL>5:6</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=br>51:40</td><td class=br>+11</td>
<td class=bc>6 - 4 - 5</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Kr Lebl</td><td class=kL>0:9</td>
<td class=kW>5:2</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=br>44:47</td><td class=br>-3</td>
<td class=bc>6 - 4 - 5</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Em Liepi��</td><td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>6:5</td>
<td class=kW>3:2</td>
<td class=kL>3:6</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>10:3</td>
<td class=kW>4:0</td>
<td class=br>55:45</td><td class=br>+10</td>
<td class=bc>6 - 3 - 6</td>
<td class=br><strong>15</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>An Bo�i�</td><td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kT>4:4</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>5:8</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=br>50:46</td><td class=br>+4</td>
<td class=bc>5 - 4 - 6</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>R� Kamzols</td><td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=br>35:37</td><td class=br>-2</td>
<td class=bc>5 - 4 - 6</td>
<td class=br><strong>14</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>An Kuz�ecovs</td><td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kW>8:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=br>43:51</td><td class=br>-8</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>J� Z�l�te</td><td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>0:8</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kW>3:0</td>
<td class=kW>5:4</td>
<td class=br>30:48</td><td class=br>-18</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Da Landa</td><td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=br>32:45</td><td class=br>-13</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Da Sippo</td><td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>3:10</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=br>21:67</td><td class=br>-46</td>
<td class=bc>1 - 1 - 13</td>
<td class=br><strong>3</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Ma Kyllerg�rd</td><td class=kL>2:6</td>
<td class=kL>3:8</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=br>21:69</td><td class=br>-48</td>
<td class=bc>0 - 0 - 15</td>
<td class=br><strong>0</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>An Bo�i�</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Da Sippo</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ma Kyllerg�rd</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Da Landa</td><td class=bc>-</td><td class=bl>Un �sterman</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Da Sippo</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>An Bo�i�</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>Ja Pelkonen</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>Un �sterman</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma Kyllerg�rd</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Da Landa</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Da Sippo</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Ja Pelkonen</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>An Bo�i�</td><td class=bc>-</td><td class=blW>Un �sterman</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Kyllerg�rd</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>Da Sippo</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ja Pelkonen</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Un �sterman</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Bo�i�</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Da Landa</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Da Sippo</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Un �sterman</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>An Bo�i�</td><td class=bc>-</td><td class=bl>Da Landa</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Ma Kyllerg�rd</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Da Sippo</td><td class=bc>-</td><td class=blW>Un �sterman</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Zenisek</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Da Landa</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Ma Kyllerg�rd</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>An Bo�i�</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>5 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Un �sterman</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Da Sippo</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>3 : 10</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ma Zenisek</td><td class=bc>-</td><td class=bl>Da Landa</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ma Kyllerg�rd</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Un �sterman</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Da Sippo</td><td class=bc>-</td><td class=bl>Da Landa</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>Ma Kyllerg�rd</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ma Zenisek</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>An Bo�i�</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Un �sterman</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Da Landa</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Kyllerg�rd</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Da Sippo</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ma Zenisek</td><td class=bc>-</td><td class=bl>An Bo�i�</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Da Landa</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Un �sterman</td><td class=bc>-</td><td class=bl>Ma Kyllerg�rd</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Sippo</td><td class=bc>-</td><td class=blW>An Bo�i�</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Da Landa</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ma Kyllerg�rd</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Un �sterman</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>An Bo�i�</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Da Sippo</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Da Landa</td><td class=bc>-</td><td class=bl>Ma Kyllerg�rd</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=bl>An Bo�i�</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Un �sterman</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Da Sippo</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ma Kyllerg�rd</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Da Landa</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>An Bo�i�</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Un �sterman</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Kyllerg�rd</td><td class=bc>-</td><td class=blW>An Bo�i�</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Landa</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Un �sterman</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Da Sippo</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>An Bo�i�</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ma Kyllerg�rd</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Da Landa</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Da Sippo</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Un �sterman</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>An Bo�i�</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Kyllerg�rd</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Da Landa</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Da Sippo</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Ja Pelkonen</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>An Bo�i�</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Kyllerg�rd</td><td class=bc>-</td><td class=blW>Da Sippo</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Landa</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=bl>Un �sterman</td><td class=bc>3 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group SF B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ol Korabel</td><td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>8:1</td>
<td class=kW>6:0</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=br>75:20</td><td class=br>+55</td>
<td class=bc>14 - 0 - 1</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>At S�lis</td><td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>7:6</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=br>58:31</td><td class=br>+27</td>
<td class=bc>12 - 2 - 1</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>An Liepi��</td><td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kL>6:7</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=br>45:34</td><td class=br>+11</td>
<td class=bc>9 - 3 - 3</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Kr Lagzdi�a</td><td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>5:5</td>
<td class=kW>9:1</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>8:2</td>
<td class=br>57:37</td><td class=br>+20</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ar Zaharovs</td><td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=br>42:30</td><td class=br>+12</td>
<td class=bc>9 - 0 - 6</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Re Vazoli��</td><td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kT>5:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=br>42:36</td><td class=br>+6</td>
<td class=bc>7 - 3 - 5</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>J� Re�is</td><td class=kL>1:7</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kL>1:9</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>7:1</td>
<td class=br>43:46</td><td class=br>-3</td>
<td class=bc>7 - 1 - 7</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ma Madera</td><td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>9:2</td>
<td class=br>49:42</td><td class=br>+7</td>
<td class=bc>7 - 1 - 7</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Gu Hermansson</td><td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kW>7:6</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=br>37:48</td><td class=br>-11</td>
<td class=bc>7 - 1 - 7</td>
<td class=br><strong>15</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>An Fjermestad</td><td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=br>43:41</td><td class=br>+2</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Si Pleikys</td><td class=kL>1:8</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=br>32:48</td><td class=br>-16</td>
<td class=bc>6 - 0 - 9</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Vi Henttonen</td><td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=br>26:44</td><td class=br>-18</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>El R�cen�ja</td><td class=kW>3:2</td>
<td class=kL>6:7</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>4:9</td>
<td class=br>34:48</td><td class=br>-14</td>
<td class=bc>5 - 0 - 10</td>
<td class=br><strong>10</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Da Hrustaljova</td><td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=br>33:44</td><td class=br>-11</td>
<td class=bc>3 - 2 - 10</td>
<td class=br><strong>8</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Kr Naglis</td><td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=br>37:54</td><td class=br>-17</td>
<td class=bc>3 - 1 - 11</td>
<td class=br><strong>7</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Ar Zasurcevs</td><td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>2:8</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:7</td>
<td class=kL>2:9</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kW>9:4</td>
<td class=kL>2:7</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=br>27:77</td><td class=br>-50</td>
<td class=bc>1 - 0 - 14</td>
<td class=br><strong>2</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>At S�lis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>At S�lis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>At S�lis</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>At S�lis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>At S�lis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>9 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>7 : 6</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>At S�lis</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>At S�lis</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Da Hrustaljova</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>At S�lis</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Da Hrustaljova</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>At S�lis</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Da Hrustaljova</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>At S�lis</td><td class=bc>-</td><td class=bl>Da Hrustaljova</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Da Hrustaljova</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>At S�lis</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Da Hrustaljova</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>At S�lis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Da Hrustaljova</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>At S�lis</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Da Hrustaljova</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>At S�lis</td><td class=bc>6 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>At S�lis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Da Hrustaljova</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>At S�lis</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>2 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group SF C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>La Fridell</td><td class=kx>*</td>
<td class=kW>7:5</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=br>54:28</td><td class=br>+26</td>
<td class=bc>9 - 4 - 2</td>
<td class=br><strong>22</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Lu Jurka</td><td class=kL>5:7</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=br>44:32</td><td class=br>+12</td>
<td class=bc>10 - 2 - 3</td>
<td class=br><strong>22</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>El Sili��</td><td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>9:4</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=br>50:32</td><td class=br>+18</td>
<td class=bc>8 - 4 - 3</td>
<td class=br><strong>20</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Sa Skarainis</td><td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>40:29</td><td class=br>+11</td>
<td class=bc>6 - 6 - 3</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Sa Kalni��</td><td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kW>7:5</td>
<td class=br>39:37</td><td class=br>+2</td>
<td class=bc>6 - 6 - 3</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ed Ka�eps</td><td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=br>39:33</td><td class=br>+6</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Go Lonnqvist</td><td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kL>2:6</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=br>45:39</td><td class=br>+6</td>
<td class=bc>8 - 1 - 6</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ig Saveljev</td><td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=br>32:33</td><td class=br>-1</td>
<td class=bc>5 - 6 - 4</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Ti Mihhaljov</td><td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kW>8:2</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=br>45:40</td><td class=br>+5</td>
<td class=bc>5 - 5 - 5</td>
<td class=br><strong>15</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>Al Sili��</td><td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>6:3</td>
<td class=kW>7:4</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>42:34</td><td class=br>+8</td>
<td class=bc>5 - 5 - 5</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Kr Rieksti��</td><td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=br>42:36</td><td class=br>+6</td>
<td class=bc>5 - 5 - 5</td>
<td class=br><strong>15</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Al Skudr�tis</td><td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=br>35:40</td><td class=br>-5</td>
<td class=bc>5 - 4 - 6</td>
<td class=br><strong>14</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ni L�cis</td><td class=kL>0:4</td>
<td class=kW>3:0</td>
<td class=kL>4:9</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kL>3:6</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=br>37:49</td><td class=br>-12</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>He Prokuratovs</td><td class=kL>0:8</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kL>2:8</td>
<td class=kL>4:7</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=br>33:61</td><td class=br>-28</td>
<td class=bc>4 - 0 - 11</td>
<td class=br><strong>8</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Ve Huotelin</td><td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=br>30:43</td><td class=br>-13</td>
<td class=bc>3 - 2 - 10</td>
<td class=br><strong>8</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Ra Stern�ts</td><td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>5:7</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=br>22:63</td><td class=br>-41</td>
<td class=bc>0 - 2 - 13</td>
<td class=br><strong>2</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>La Fridell</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ti Mihhaljov</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>La Fridell</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ni L�cis</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>La Fridell</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ni L�cis</td><td class=bc>-</td><td class=bl>Ti Mihhaljov</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>La Fridell</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ti Mihhaljov</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>Go Lonnqvist</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>La Fridell</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>Ti Mihhaljov</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ti Mihhaljov</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>La Fridell</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Ti Mihhaljov</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>Go Lonnqvist</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>La Fridell</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>Ti Mihhaljov</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Go Lonnqvist</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>La Fridell</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>7 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ti Mihhaljov</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Go Lonnqvist</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>9 : 4</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Ti Mihhaljov</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>La Fridell</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ti Mihhaljov</td><td class=bc>-</td><td class=blW>Go Lonnqvist</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Ni L�cis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>La Fridell</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ti Mihhaljov</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>La Fridell</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ti Mihhaljov</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=bl>La Fridell</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ni L�cis</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ti Mihhaljov</td><td class=bc>-</td><td class=bl>La Fridell</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=blW>La Fridell</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ti Mihhaljov</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>La Fridell</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ni L�cis</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ti Mihhaljov</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>La Fridell</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>7 : 5</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ti Mihhaljov</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>5 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group SF D</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ar Matantsev</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=kW>5:4</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=br>57:32</td><td class=br>+25</td>
<td class=bc>10 - 3 - 2</td>
<td class=br><strong>23</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ed Naglis</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>7:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kT>6:6</td>
<td class=kW>6:5</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>8:2</td>
<td class=br>61:36</td><td class=br>+25</td>
<td class=bc>10 - 2 - 3</td>
<td class=br><strong>22</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Va Smagars</td><td class=kW>2:1</td>
<td class=kL>2:7</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>9:2</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=br>50:34</td><td class=br>+16</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Hu Lonnqvist</td><td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>7:3</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kW>5:4</td>
<td class=br>52:39</td><td class=br>+13</td>
<td class=bc>8 - 3 - 4</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Mi Kobrle</td><td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kT>5:5</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>5:4</td>
<td class=kW>5:1</td>
<td class=kW>7:4</td>
<td class=kW>5:1</td>
<td class=kW>6:5</td>
<td class=br>58:43</td><td class=br>+15</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Di Ziemelis</td><td class=kL>3:5</td>
<td class=kT>6:6</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>8:4</td>
<td class=br>51:47</td><td class=br>+4</td>
<td class=bc>7 - 3 - 5</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ma Jakseboga</td><td class=kL>2:4</td>
<td class=kL>5:6</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kT>5:5</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kW>7:0</td>
<td class=kW>9:3</td>
<td class=br>56:43</td><td class=br>+13</td>
<td class=bc>7 - 1 - 7</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Be Suominen</td><td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kW>5:4</td>
<td class=kW>7:3</td>
<td class=kL>2:7</td>
<td class=kW>8:0</td>
<td class=br>40:39</td><td class=br>+1</td>
<td class=bc>7 - 1 - 7</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>He Nilsson</td><td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=br>38:41</td><td class=br>-3</td>
<td class=bc>5 - 5 - 5</td>
<td class=br><strong>15</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>Pa Plesak</td><td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>7:0</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=br>36:40</td><td class=br>-4</td>
<td class=bc>5 - 4 - 6</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Am Risa Fylling</td><td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>1:7</td>
<td class=kW>5:2</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=br>33:47</td><td class=br>-14</td>
<td class=bc>4 - 4 - 7</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ha Ivantsova</td><td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kL>1:6</td>
<td class=br>37:44</td><td class=br>-7</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>In Garan�s</td><td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>3:7</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kL>5:8</td>
<td class=kW>5:0</td>
<td class=br>46:53</td><td class=br>-7</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>R� Logins</td><td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kL>2:9</td>
<td class=kW>5:3</td>
<td class=kL>4:7</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kL>3:7</td>
<td class=kT>3:3</td>
<td class=kL>0:7</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>5:2</td>
<td class=br>47:69</td><td class=br>-22</td>
<td class=bc>4 - 3 - 8</td>
<td class=br><strong>11</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Ro Verbi�s</td><td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>0:7</td>
<td class=kW>7:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kW>8:5</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=br>37:60</td><td class=br>-23</td>
<td class=bc>2 - 5 - 8</td>
<td class=br><strong>9</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Ne Skrlep</td><td class=kL>1:5</td>
<td class=kL>2:8</td>
<td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kL>5:6</td>
<td class=kL>4:8</td>
<td class=kL>3:9</td>
<td class=kL>0:8</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=br>44:76</td><td class=br>-32</td>
<td class=bc>3 - 2 - 10</td>
<td class=br><strong>8</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>R� Logins</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 9</tr></td>
<tr><td class=brW>Hu Lonnqvist</td><td class=bc>-</td><td class=bl>Ne Skrlep</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Am Risa Fylling</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>5 : 8</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ne Skrlep</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>R� Logins</td><td class=bc>-</td><td class=bl>Am Risa Fylling</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Hu Lonnqvist</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>He Nilsson</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=blW>Ne Skrlep</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Am Risa Fylling</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Pa Plesak</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>R� Logins</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Hu Lonnqvist</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ne Skrlep</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>Am Risa Fylling</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>He Nilsson</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>R� Logins</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>Ne Skrlep</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=bl>Am Risa Fylling</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>He Nilsson</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Hu Lonnqvist</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ne Skrlep</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>Am Risa Fylling</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=blW>Hu Lonnqvist</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>R� Logins</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ne Skrlep</td><td class=bc>-</td><td class=bl>Am Risa Fylling</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Hu Lonnqvist</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>R� Logins</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Am Risa Fylling</td><td class=bc>-</td><td class=blW>Pa Plesak</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ne Skrlep</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>Hu Lonnqvist</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>R� Logins</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Am Risa Fylling</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ne Skrlep</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>Hu Lonnqvist</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>R� Logins</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Am Risa Fylling</td><td class=bc>-</td><td class=bl>Hu Lonnqvist</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ne Skrlep</td><td class=bc>-</td><td class=blW>R� Logins</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=bl>Hu Lonnqvist</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>R� Logins</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Am Risa Fylling</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ne Skrlep</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Hu Lonnqvist</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>R� Logins</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Am Risa Fylling</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ne Skrlep</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Hu Lonnqvist</td><td class=bc>-</td><td class=blW>R� Logins</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>He Nilsson</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Am Risa Fylling</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ne Skrlep</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>4 : 8</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>R� Logins</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Hu Lonnqvist</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Am Risa Fylling</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ne Skrlep</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>R� Logins</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Hu Lonnqvist</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>6 : 6</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Am Risa Fylling</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>R� Logins</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Hu Lonnqvist</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>He Nilsson</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=bl>Ne Skrlep</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>R� Logins</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Hu Lonnqvist</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ne Skrlep</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=bl>Am Risa Fylling</td><td class=bc>2 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group A FINAL </br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/8</td><td class=d>1.</td><td class=kt>Ke Eriksson</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=kW>6:4</td>
<td class=kW>6:4</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>10:0</td>
<td class=br>96:47</td><td class=br>+49</td>
<td class=bc>15 - 3 - 5</td>
<td class=br><strong>33</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/8</td><td class=d>2.</td><td class=kt>Ed Ka�eps</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>6:4</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>10:0</td>
<td class=br>79:48</td><td class=br>+31</td>
<td class=bc>15 - 3 - 5</td>
<td class=br><strong>33</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/8</td><td class=d>3.</td><td class=kt>Ra Kalni��</td><td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>6:1</td>
<td class=kW>6:4</td>
<td class=kT>4:4</td>
<td class=kW>7:1</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=kW>10:0</td>
<td class=br>100:51</td><td class=br>+49</td>
<td class=bc>14 - 4 - 5</td>
<td class=br><strong>32</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/8</td><td class=d>4.</td><td class=kt>Ha �sterman</td><td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kL>5:6</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>10:0</td>
<td class=br>88:47</td><td class=br>+41</td>
<td class=bc>15 - 2 - 6</td>
<td class=br><strong>32</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Pa Petr</td><td class=kT>3:3</td>
<td class=kL>4:6</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kW>9:3</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>8:6</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=kL>1:3</td>
<td class=kW>6:4</td>
<td class=kW>5:1</td>
<td class=kW>10:0</td>
<td class=br>110:66</td><td class=br>+44</td>
<td class=bc>14 - 4 - 5</td>
<td class=br><strong>32</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>Ja Pelkonen</td><td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>10:0</td>
<td class=br>77:38</td><td class=br>+39</td>
<td class=bc>14 - 2 - 7</td>
<td class=br><strong>30</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Lu Jurka</td><td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>10:0</td>
<td class=br>68:42</td><td class=br>+26</td>
<td class=bc>12 - 5 - 6</td>
<td class=br><strong>29</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>El Sili��</td><td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>6:1</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>10:0</td>
<td class=br>86:58</td><td class=br>+28</td>
<td class=bc>12 - 4 - 7</td>
<td class=br><strong>28</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>Ro Rieksti��</td><td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kL>3:9</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kT>4:4</td>
<td class=kW>10:0</td>
<td class=br>70:59</td><td class=br>+11</td>
<td class=bc>13 - 2 - 8</td>
<td class=br><strong>28</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Un �sterman</td><td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kL>3:9</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>10:0</td>
<td class=br>81:63</td><td class=br>+18</td>
<td class=bc>12 - 3 - 8</td>
<td class=br><strong>27</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>La Fridell</td><td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>5:4</td>
<td class=kL>0:6</td>
<td class=kW>4:2</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kL>1:5</td>
<td class=kW>6:4</td>
<td class=kW>9:2</td>
<td class=kW>10:0</td>
<td class=br>74:63</td><td class=br>+11</td>
<td class=bc>11 - 4 - 8</td>
<td class=br><strong>26</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>Ti Mihhaljov</td><td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>10:0</td>
<td class=br>58:53</td><td class=br>+5</td>
<td class=bc>10 - 5 - 8</td>
<td class=br><strong>25</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Em Liepi��</td><td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kL>4:5</td>
<td class=kL>4:5</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>10:0</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>10:0</td>
<td class=br>74:63</td><td class=br>+11</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Al Sili��</td><td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kW>6:5</td>
<td class=kL>6:8</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kL>2:3</td>
<td class=kL>0:10</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kW>2:1</td>
<td class=kW>7:4</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>10:0</td>
<td class=br>73:76</td><td class=br>-3</td>
<td class=bc>8 - 6 - 9</td>
<td class=br><strong>22</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>D� Apfelbaums</td><td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>10:0</td>
<td class=br>54:55</td><td class=br>-1</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>An Bo�i�</td><td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kL>2:6</td>
<td class=kW>5:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>3:5</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>10:0</td>
<td class=br>53:59</td><td class=br>-6</td>
<td class=bc>7 - 6 - 10</td>
<td class=br><strong>20</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Sa Kalni��</td><td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kW>10:0</td>
<td class=br>51:68</td><td class=br>-17</td>
<td class=bc>8 - 4 - 11</td>
<td class=br><strong>20</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Tr Mansson</td><td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>4:6</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kT>0:0</td>
<td class=kW>10:0</td>
<td class=br>56:62</td><td class=br>-6</td>
<td class=bc>7 - 4 - 12</td>
<td class=br><strong>18</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Kr Lebl</td><td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>9:3</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kL>2:6</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kW>10:0</td>
<td class=br>72:75</td><td class=br>-3</td>
<td class=bc>8 - 2 - 13</td>
<td class=br><strong>18</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Go Lonnqvist</td><td class=kL>4:6</td>
<td class=kL>1:3</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>6:1</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>10:0</td>
<td class=br>61:79</td><td class=br>-18</td>
<td class=bc>7 - 3 - 13</td>
<td class=br><strong>17</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Sa Skarainis</td><td class=kL>4:6</td>
<td class=kW>4:2</td>
<td class=kL>1:7</td>
<td class=kL>2:7</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kL>4:7</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>10:0</td>
<td class=br>57:75</td><td class=br>-18</td>
<td class=bc>6 - 2 - 15</td>
<td class=br><strong>14</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Ig Saveljev</td><td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>4:6</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>2:6</td>
<td class=kL>4:6</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kW>10:0</td>
<td class=br>54:82</td><td class=br>-28</td>
<td class=bc>4 - 4 - 15</td>
<td class=br><strong>12</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Ma Zenisek</td><td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kL>2:9</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>0:0</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kW>10:0</td>
<td class=br>50:83</td><td class=br>-33</td>
<td class=bc>2 - 7 - 14</td>
<td class=br><strong>11</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>To Baumanis</td><td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kx>*</td>
<td class=br>0:230</td><td class=br>-230</td>
<td class=bc>0 - 0 - 23</td>
<td class=br><strong>0</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>La Fridell</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Un �sterman</td><td class=bc>-</td><td class=bl>Ha �sterman</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>An Bo�i�</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ti Mihhaljov</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ha �sterman</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>La Fridell</td><td class=bc>-</td><td class=bl>Ke Eriksson</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Un �sterman</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>An Bo�i�</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Ti Mihhaljov</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Go Lonnqvist</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>0 : 10</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Ha �sterman</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ke Eriksson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>La Fridell</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Un �sterman</td><td class=bc>-</td><td class=bl>An Bo�i�</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=blW>Ti Mihhaljov</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Go Lonnqvist</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ha �sterman</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>An Bo�i�</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>La Fridell</td><td class=bc>-</td><td class=blW>Ti Mihhaljov</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Un �sterman</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=blW>Go Lonnqvist</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>10 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ha �sterman</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>An Bo�i�</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ti Mihhaljov</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>La Fridell</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Un �sterman</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>An Bo�i�</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ha �sterman</td><td class=bc>-</td><td class=bl>Ti Mihhaljov</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>La Fridell</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Un �sterman</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>An Bo�i�</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=blW>Ti Mihhaljov</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ha �sterman</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>La Fridell</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Un �sterman</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>An Bo�i�</td><td class=bc>-</td><td class=bl>Ti Mihhaljov</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ha �sterman</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>La Fridell</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Un �sterman</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ti Mihhaljov</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Bo�i�</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ha �sterman</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ja Pelkonen</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>La Fridell</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Un �sterman</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ti Mihhaljov</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>An Bo�i�</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Ha �sterman</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>La Fridell</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Un �sterman</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>Go Lonnqvist</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ti Mihhaljov</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Bo�i�</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ke Eriksson</td><td class=bc>-</td><td class=bl>Ja Pelkonen</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ha �sterman</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>La Fridell</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ti Mihhaljov</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>An Bo�i�</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Ja Pelkonen</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ha �sterman</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Un �sterman</td><td class=bc>9 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ti Mihhaljov</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>An Bo�i�</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ke Eriksson</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ha �sterman</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Un �sterman</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>La Fridell</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Go Lonnqvist</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ti Mihhaljov</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Bo�i�</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ke Eriksson</td><td class=bc>-</td><td class=blW>Un �sterman</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ha �sterman</td><td class=bc>-</td><td class=bl>La Fridell</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ti Mihhaljov</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Bo�i�</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Un �sterman</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=blW>La Fridell</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ke Eriksson</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ha �sterman</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ja Pelkonen</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Zenisek</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ti Mihhaljov</td><td class=bc>-</td><td class=bl>Un �sterman</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>An Bo�i�</td><td class=bc>-</td><td class=bl>La Fridell</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>6 : 8</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ke Eriksson</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ja Pelkonen</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Go Lonnqvist</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Un �sterman</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>La Fridell</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ti Mihhaljov</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Bo�i�</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ha �sterman</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>Un �sterman</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>La Fridell</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ti Mihhaljov</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Bo�i�</td><td class=bc>-</td><td class=blW>Ha �sterman</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>Un �sterman</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>La Fridell</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>Ha �sterman</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ti Mihhaljov</td><td class=bc>-</td><td class=bl>Ke Eriksson</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>An Bo�i�</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Un �sterman</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>La Fridell</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ha �sterman</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ti Mihhaljov</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Un �sterman</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=blW>La Fridell</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=bl>Ha �sterman</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>An Bo�i�</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Un �sterman</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>La Fridell</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Ha �sterman</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ke Eriksson</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>An Bo�i�</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Ti Mihhaljov</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Un �sterman</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>La Fridell</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=blW>Ha �sterman</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=bl>An Bo�i�</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Ti Mihhaljov</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Un �sterman</td><td class=bc>-</td><td class=bl>La Fridell</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>Ha �sterman</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>An Bo�i�</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>Ti Mihhaljov</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=br>La Fridell</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Un �sterman</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Ha �sterman</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>An Bo�i�</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ti Mihhaljov</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>3 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group B FINAL</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/8</td><td class=d>1.</td><td class=kt>Ol Korabel</td><td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>4:7</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=kW>7:0</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=br>96:41</td><td class=br>+55</td>
<td class=bc>16 - 3 - 4</td>
<td class=br><strong>35</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/8</td><td class=d>2.</td><td class=kt>Ma Madera</td><td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>7:3</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>1:8</td>
<td class=kW>3:2</td>
<td class=kW>6:4</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=br>78:57</td><td class=br>+21</td>
<td class=bc>16 - 2 - 5</td>
<td class=br><strong>34</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/8</td><td class=d>3.</td><td class=kt>At S�lis</td><td class=kW>7:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>0:5</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=br>73:55</td><td class=br>+18</td>
<td class=bc>14 - 5 - 4</td>
<td class=br><strong>33</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/8</td><td class=d>4.</td><td class=kt>Mi Kobrle</td><td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kL>0:5</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kW>5:4</td>
<td class=kW>5:2</td>
<td class=kW>6:5</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>8:3</td>
<td class=kW>7:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=br>85:60</td><td class=br>+25</td>
<td class=bc>14 - 2 - 7</td>
<td class=br><strong>30</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Ed Caics</td><td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>8:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kL>1:4</td>
<td class=kW>10:0</td>
<td class=kW>7:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=br>85:61</td><td class=br>+24</td>
<td class=bc>12 - 4 - 7</td>
<td class=br><strong>28</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>Ar Matantsev</td><td class=kT>3:3</td>
<td class=kL>3:7</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>6:4</td>
<td class=kW>4:3</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=br>71:58</td><td class=br>+13</td>
<td class=bc>12 - 4 - 7</td>
<td class=br><strong>28</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Ev Matantsev</td><td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>7:5</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=br>79:49</td><td class=br>+30</td>
<td class=bc>12 - 4 - 7</td>
<td class=br><strong>28</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Ed Nilsson</td><td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kW>4:0</td>
<td class=kT>5:5</td>
<td class=kT>5:5</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>5:3</td>
<td class=br>81:66</td><td class=br>+15</td>
<td class=bc>10 - 6 - 7</td>
<td class=br><strong>26</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>Va Smagars</td><td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>2:8</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=br>62:64</td><td class=br>-2</td>
<td class=bc>12 - 2 - 9</td>
<td class=br><strong>26</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Kr Lagzdi�a</td><td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>10:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>8:4</td>
<td class=br>72:51</td><td class=br>+21</td>
<td class=bc>12 - 2 - 9</td>
<td class=br><strong>26</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Hu Lonnqvist</td><td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=br>56:51</td><td class=br>+5</td>
<td class=bc>11 - 3 - 9</td>
<td class=br><strong>25</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>Sa Lagzdi��</td><td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>4:6</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kL>2:10</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=br>69:73</td><td class=br>-4</td>
<td class=bc>12 - 0 - 11</td>
<td class=br><strong>24</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ed Naglis</td><td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kL>5:6</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=kW>5:4</td>
<td class=kW>6:4</td>
<td class=kW>4:1</td>
<td class=br>71:72</td><td class=br>-1</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Ma Jakseboga</td><td class=kL>2:7</td>
<td class=kW>4:1</td>
<td class=kL>3:5</td>
<td class=kL>4:5</td>
<td class=kL>2:5</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>3:5</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=br>66:64</td><td class=br>+2</td>
<td class=bc>10 - 4 - 9</td>
<td class=br><strong>24</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>J� Re�is</td><td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>4:5</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>4:6</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=br>55:62</td><td class=br>-7</td>
<td class=bc>11 - 1 - 11</td>
<td class=br><strong>23</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Re Vazoli��</td><td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>5:6</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kW>6:2</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>6:5</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=br>64:70</td><td class=br>-6</td>
<td class=bc>10 - 2 - 11</td>
<td class=br><strong>22</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Be Suominen</td><td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kT>5:5</td>
<td class=kL>3:4</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=br>57:63</td><td class=br>-6</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Ar Zaharovs</td><td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>0:7</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kT>5:5</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=br>50:58</td><td class=br>-8</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Di Ziemelis</td><td class=kL>2:5</td>
<td class=kW>8:1</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kL>0:10</td>
<td class=kW>5:2</td>
<td class=kL>5:7</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=br>71:71</td><td class=br>0</td>
<td class=bc>9 - 2 - 12</td>
<td class=br><strong>20</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>An Liepi��</td><td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kW>5:0</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=br>44:60</td><td class=br>-16</td>
<td class=bc>6 - 4 - 13</td>
<td class=br><strong>16</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>An Fjermestad</td><td class=kL>0:6</td>
<td class=kL>4:6</td>
<td class=kL>1:3</td>
<td class=kL>3:8</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>2:7</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kW>5:4</td>
<td class=kL>3:4</td>
<td class=kW>5:4</td>
<td class=kW>6:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=br>54:91</td><td class=br>-37</td>
<td class=bc>5 - 3 - 15</td>
<td class=br><strong>13</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Gu Hermansson</td><td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=br>49:90</td><td class=br>-41</td>
<td class=bc>3 - 6 - 14</td>
<td class=br><strong>12</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>He Nilsson</td><td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>4:6</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>7:2</td>
<td class=br>46:89</td><td class=br>-43</td>
<td class=bc>4 - 1 - 18</td>
<td class=br><strong>9</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Pa Plesak</td><td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kL>4:8</td>
<td class=kT>1:1</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>2:7</td>
<td class=kx>*</td>
<td class=br>40:98</td><td class=br>-58</td>
<td class=bc>0 - 4 - 19</td>
<td class=br><strong>4</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ed Nilsson</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>At S�lis</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Hu Lonnqvist</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ed Nilsson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>At S�lis</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Hu Lonnqvist</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ed Nilsson</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>At S�lis</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Hu Lonnqvist</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ed Nilsson</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>He Nilsson</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>At S�lis</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Hu Lonnqvist</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ed Nilsson</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>At S�lis</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Hu Lonnqvist</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ed Nilsson</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>At S�lis</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ed Nilsson</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>At S�lis</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Hu Lonnqvist</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>He Nilsson</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ed Nilsson</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>At S�lis</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Hu Lonnqvist</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ed Nilsson</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Hu Lonnqvist</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>At S�lis</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ed Nilsson</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Hu Lonnqvist</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>At S�lis</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Hu Lonnqvist</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ed Nilsson</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Hu Lonnqvist</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ed Nilsson</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=blW>At S�lis</td><td class=bc>4 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Hu Lonnqvist</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>4 : 8</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ed Nilsson</td><td class=bc>-</td><td class=blW>At S�lis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Hu Lonnqvist</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>At S�lis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ed Nilsson</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Hu Lonnqvist</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>He Nilsson</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>At S�lis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Hu Lonnqvist</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>At S�lis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ed Nilsson</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Hu Lonnqvist</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>At S�lis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Hu Lonnqvist</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>At S�lis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Hu Lonnqvist</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>At S�lis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=bl>Ed Nilsson</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Hu Lonnqvist</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>At S�lis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ed Nilsson</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>He Nilsson</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Hu Lonnqvist</td><td class=bc>-</td><td class=bl>At S�lis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ed Nilsson</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>At S�lis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hu Lonnqvist</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ed Nilsson</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>5 : 7</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>At S�lis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Hu Lonnqvist</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>At S�lis</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>10 : 2</tr></td>
<tr><td class=brW>Hu Lonnqvist</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>At S�lis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Hu Lonnqvist</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>1 : 6</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
