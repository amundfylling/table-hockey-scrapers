<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Rigas Kauss I Qualification</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../23RK/Rigas_Kauss_I_Qualification_index.php">Rigas Kauss I Qualification, 2. decembris 2023</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<p class=v>Group Q A grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>An Liepi��</td><td class=kx>*</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>8:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>10:0</td>
<td class=kW>9:0</td>
<td class=kW>10:1</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=br>85:6</td><td class=br>+79</td>
<td class=bc>14 - 0 - 0</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>J� Zem�ickis</td><td class=kL>0:7</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=kW>6:0</td>
<td class=br>43:14</td><td class=br>+29</td>
<td class=bc>12 - 1 - 1</td>
<td class=br><strong>25</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>�i Vazoli��</td><td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=kW>9:1</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=kW>4:0</td>
<td class=br>45:13</td><td class=br>+32</td>
<td class=bc>10 - 0 - 4</td>
<td class=br><strong>20</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Kr G�tmanis</td><td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>0:1</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>8:0</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>7:0</td>
<td class=br>44:21</td><td class=br>+23</td>
<td class=bc>8 - 2 - 4</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ma Me�viets</td><td class=kL>1:8</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>10:1</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>8:0</td>
<td class=br>44:27</td><td class=br>+17</td>
<td class=bc>9 - 0 - 5</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>An Zi�icka</td><td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kT>0:0</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=br>36:20</td><td class=br>+16</td>
<td class=bc>7 - 3 - 4</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Ei G�ze</td><td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>9:0</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=br>35:20</td><td class=br>+15</td>
<td class=bc>7 - 3 - 4</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Pa Janouskovec</td><td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kW>3:0</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>6:3</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=br>35:24</td><td class=br>+11</td>
<td class=bc>7 - 2 - 5</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ar Pavlovs</td><td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>8:2</td>
<td class=kW>5:0</td>
<td class=br>31:29</td><td class=br>+2</td>
<td class=bc>6 - 1 - 7</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>My Razkevich</td><td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>3:6</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=k>&nbsp;</td>
<td class=kW>14:0</td>
<td class=kW>8:1</td>
<td class=kW>8:0</td>
<td class=br>46:24</td><td class=br>+22</td>
<td class=bc>4 - 3 - 6</td>
<td class=br><strong>11</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Au Liepi��</td><td class=kL>0:10</td>
<td class=kL>0:1</td>
<td class=kL>0:6</td>
<td class=kT>4:4</td>
<td class=kL>1:10</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=br>20:51</td><td class=br>-31</td>
<td class=bc>3 - 3 - 8</td>
<td class=br><strong>9</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Se Podtinnijs</td><td class=kL>0:9</td>
<td class=kL>1:3</td>
<td class=kL>1:9</td>
<td class=kL>0:8</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>0:9</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=k>&nbsp;</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=br>17:67</td><td class=br>-50</td>
<td class=bc>2 - 2 - 9</td>
<td class=br><strong>6</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Em Ka�s</td><td class=kL>1:10</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kT>0:0</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>0:14</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=br>13:57</td><td class=br>-44</td>
<td class=bc>1 - 3 - 10</td>
<td class=br><strong>5</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Al Liepi��</td><td class=kL>0:7</td>
<td class=kL>0:7</td>
<td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kW>2:1</td>
<td class=kL>2:8</td>
<td class=kL>1:8</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=br>16:71</td><td class=br>-55</td>
<td class=bc>2 - 0 - 12</td>
<td class=br><strong>4</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Al Kaikova</td><td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=br>4:70</td><td class=br>-66</td>
<td class=bc>0 - 1 - 13</td>
<td class=br><strong>1</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=blW>An Zi�icka</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Pa Janouskovec</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Al Kaikova</td><td class=bc>-</td><td class=blW>My Razkevich</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=bl>Se Podtinnijs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Ma Me�viets</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>An Zi�icka</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kr G�tmanis</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pa Janouskovec</td><td class=bc>-</td><td class=bl>Se Podtinnijs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Al Kaikova</td><td class=bc>-</td><td class=blW>Ar Pavlovs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Ma Me�viets</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Au Liepi��</td><td class=bc>10 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Zi�icka</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr G�tmanis</td><td class=bc>-</td><td class=bl>Se Podtinnijs</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pa Janouskovec</td><td class=bc>-</td><td class=blW>Ma Me�viets</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Al Kaikova</td><td class=bc>-</td><td class=blW>Au Liepi��</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>�i Vazoli��</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Se Podtinnijs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>An Zi�icka</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kr G�tmanis</td><td class=bc>-</td><td class=bl>Ma Me�viets</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>Au Liepi��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pa Janouskovec</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Kaikova</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=bl>Se Podtinnijs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�i Vazoli��</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Ma Me�viets</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>An Zi�icka</td><td class=bc>-</td><td class=bl>Au Liepi��</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr G�tmanis</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Pa Janouskovec</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Se Podtinnijs</td><td class=bc>-</td><td class=blW>Ar Pavlovs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>Ma Me�viets</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>�i Vazoli��</td><td class=bc>-</td><td class=bl>Au Liepi��</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>An Zi�icka</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kr G�tmanis</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>Al Kaikova</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=blW>Ma Me�viets</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Se Podtinnijs</td><td class=bc>-</td><td class=bl>Au Liepi��</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>My Razkevich</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>An Zi�icka</td><td class=bc>-</td><td class=bl>Al Kaikova</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=blW>Pa Janouskovec</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ma Me�viets</td><td class=bc>-</td><td class=bl>Au Liepi��</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Ar Pavlovs</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Se Podtinnijs</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>My Razkevich</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>14 : 0</tr></td>
<tr><td class=brW>�i Vazoli��</td><td class=bc>-</td><td class=bl>Al Kaikova</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Pa Janouskovec</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Zi�icka</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Au Liepi��</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Me�viets</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Ar Pavlovs</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Se Podtinnijs</td><td class=bc>-</td><td class=bl>Al Kaikova</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>Pa Janouskovec</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Au Liepi��</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ma Me�viets</td><td class=bc>-</td><td class=bl>Al Kaikova</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=blW>Pa Janouskovec</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Se Podtinnijs</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>�i Vazoli��</td><td class=bc>-</td><td class=bl>An Zi�icka</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Al Kaikova</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Au Liepi��</td><td class=bc>-</td><td class=bl>Pa Janouskovec</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Me�viets</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=blW>Kr G�tmanis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Se Podtinnijs</td><td class=bc>-</td><td class=blW>An Zi�icka</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=bl>Al Kaikova</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Pa Janouskovec</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Au Liepi��</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Me�viets</td><td class=bc>-</td><td class=blW>An Zi�icka</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Se Podtinnijs</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>1 : 9</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Al Kaikova</td><td class=bc>-</td><td class=blW>Pa Janouskovec</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>An Zi�icka</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Au Liepi��</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ma Me�viets</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ar Pavlovs</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Pa Janouskovec</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Al Kaikova</td><td class=bc>-</td><td class=blW>Kr G�tmanis</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=bl>An Zi�icka</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Au Liepi��</td><td class=bc>-</td><td class=blW>My Razkevich</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ma Me�viets</td><td class=bc>-</td><td class=bl>Se Podtinnijs</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Kr G�tmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pa Janouskovec</td><td class=bc>-</td><td class=bl>An Zi�icka</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Al Kaikova</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Se Podtinnijs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Au Liepi��</td><td class=bc>-</td><td class=blW>Ar Pavlovs</td><td class=bc>1 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group Q B grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Fi Buhtujevs</td><td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>7:6</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kW>10:0</td>
<td class=kW>8:1</td>
<td class=kW>3:2</td>
<td class=br>80:24</td><td class=br>+56</td>
<td class=bc>14 - 0 - 0</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ro Purmalis</td><td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kW>9:1</td>
<td class=kW>5:2</td>
<td class=kW>11:0</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=br>51:21</td><td class=br>+30</td>
<td class=bc>11 - 1 - 2</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>D� Vesele</td><td class=kL>3:6</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>3:5</td>
<td class=kW>3:0</td>
<td class=kW>7:2</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>7:0</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=br>56:20</td><td class=br>+36</td>
<td class=bc>11 - 0 - 3</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Il �irse</td><td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>6:5</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>8:1</td>
<td class=br>52:29</td><td class=br>+23</td>
<td class=bc>11 - 0 - 3</td>
<td class=br><strong>22</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ar Verbi�s</td><td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=br>49:23</td><td class=br>+26</td>
<td class=bc>9 - 1 - 4</td>
<td class=br><strong>19</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ha V�veris</td><td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>5:6</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=kW>7:2</td>
<td class=kW>8:0</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=br>61:33</td><td class=br>+28</td>
<td class=bc>8 - 0 - 6</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Ur Me�ek</td><td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>6:4</td>
<td class=kL>3:6</td>
<td class=kW>5:3</td>
<td class=k>&nbsp;</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=br>42:46</td><td class=br>-4</td>
<td class=bc>7 - 1 - 5</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>El Reinfelds</td><td class=kL>6:7</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>6:4</td>
<td class=kL>1:2</td>
<td class=kW>7:0</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=br>45:36</td><td class=br>+9</td>
<td class=bc>5 - 3 - 6</td>
<td class=br><strong>13</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Os Upenieks</td><td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>4:6</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=br>30:40</td><td class=br>-10</td>
<td class=bc>5 - 1 - 8</td>
<td class=br><strong>11</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Al Prohorovs</td><td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kW>6:3</td>
<td class=kT>4:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=kW>5:4</td>
<td class=kW>7:0</td>
<td class=kW>4:1</td>
<td class=k>&nbsp;</td>
<td class=br>34:40</td><td class=br>-6</td>
<td class=bc>5 - 1 - 6</td>
<td class=br><strong>11</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ar Helin</td><td class=kL>2:6</td>
<td class=kL>1:9</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>1:7</td>
<td class=kL>3:5</td>
<td class=kL>4:6</td>
<td class=kT>3:3</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>9:0</td>
<td class=kW>4:3</td>
<td class=k>&nbsp;</td>
<td class=br>34:52</td><td class=br>-18</td>
<td class=bc>3 - 1 - 8</td>
<td class=br><strong>7</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>J� T�ns</td><td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=k>&nbsp;</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=br>28:46</td><td class=br>-18</td>
<td class=bc>3 - 0 - 10</td>
<td class=br><strong>6</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ar Gusevs</td><td class=kL>0:10</td>
<td class=kL>0:11</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>2:4</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kL>0:9</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=br>8:82</td><td class=br>-74</td>
<td class=bc>2 - 0 - 12</td>
<td class=br><strong>4</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Re Apa�ko</td><td class=kL>1:8</td>
<td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=br>16:48</td><td class=br>-32</td>
<td class=bc>1 - 1 - 12</td>
<td class=br><strong>3</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Ra R�ders</td><td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>1:8</td>
<td class=kL>2:6</td>
<td class=kL>0:7</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kL>1:7</td>
<td class=kL>0:2</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=br>11:57</td><td class=br>-46</td>
<td class=bc>1 - 0 - 11</td>
<td class=br><strong>2</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Re Apa�ko</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ar Gusevs</td><td class=bc>-</td><td class=blW>Ar Verbi�s</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ar Helin</td><td class=bc>-</td><td class=bl>Os Upenieks</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ur Me�ek</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Al Prohorovs</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Re Apa�ko</td><td class=bc>-</td><td class=blW>Ar Verbi�s</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Os Upenieks</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ar Gusevs</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ar Helin</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ur Me�ek</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Ar Verbi�s</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>Os Upenieks</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Re Apa�ko</td><td class=bc>-</td><td class=blW>J� T�ns</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ar Gusevs</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ar Helin</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Al Prohorovs</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ar Verbi�s</td><td class=bc>-</td><td class=bl>Os Upenieks</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Re Apa�ko</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ar Gusevs</td><td class=bc>-</td><td class=blW>Al Prohorovs</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ar Helin</td><td class=bc>-</td><td class=blW>Ur Me�ek</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Os Upenieks</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ar Verbi�s</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Re Apa�ko</td><td class=bc>-</td><td class=blW>Al Prohorovs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Ur Me�ek</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ar Gusevs</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>J� T�ns</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Os Upenieks</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ar Verbi�s</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Al Prohorovs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>Ur Me�ek</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Re Apa�ko</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Ar Helin</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Os Upenieks</td><td class=bc>-</td><td class=bl>Al Prohorovs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ar Verbi�s</td><td class=bc>-</td><td class=bl>Ur Me�ek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>Ar Helin</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Re Apa�ko</td><td class=bc>-</td><td class=bl>Ar Gusevs</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=bl>Al Prohorovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=bl>Ur Me�ek</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Os Upenieks</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ar Verbi�s</td><td class=bc>-</td><td class=bl>Ar Helin</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Ar Gusevs</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Al Prohorovs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ur Me�ek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=blW>Ar Helin</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Os Upenieks</td><td class=bc>-</td><td class=bl>Ar Gusevs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ar Verbi�s</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Re Apa�ko</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Al Prohorovs</td><td class=bc>-</td><td class=bl>Ur Me�ek</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>El Reinfelds</td><td class=bc>-</td><td class=bl>Ar Helin</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>Ar Gusevs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Os Upenieks</td><td class=bc>-</td><td class=bl>Re Apa�ko</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ar Verbi�s</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ur Me�ek</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Prohorovs</td><td class=bc>-</td><td class=bl>Ar Helin</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>Ar Gusevs</td><td class=bc>11 : 0</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>6 : 7</tr></td>
<tr><td class=brW>Ra R�ders</td><td class=bc>-</td><td class=bl>Re Apa�ko</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Os Upenieks</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Ar Helin</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ur Me�ek</td><td class=bc>-</td><td class=bl>Ar Gusevs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Prohorovs</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>Re Apa�ko</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>El Reinfelds</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>J� T�ns</td><td class=bc>-</td><td class=blW>Ar Verbi�s</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ar Helin</td><td class=bc>-</td><td class=bl>Ar Gusevs</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ur Me�ek</td><td class=bc>-</td><td class=bl>Re Apa�ko</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Prohorovs</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ar Verbi�s</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>Os Upenieks</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ar Gusevs</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ar Helin</td><td class=bc>-</td><td class=bl>Re Apa�ko</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Ur Me�ek</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Al Prohorovs</td><td class=bc>-</td><td class=blW>Ar Verbi�s</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>Os Upenieks</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>J� T�ns</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Re Apa�ko</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Ar Gusevs</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ar Helin</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Ar Verbi�s</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ur Me�ek</td><td class=bc>-</td><td class=bl>Os Upenieks</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Al Prohorovs</td><td class=bc>-</td><td class=bl>J� T�ns</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>6 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group Q C grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ro Aseri��</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=br>47:10</td><td class=br>+37</td>
<td class=bc>12 - 1 - 0</td>
<td class=br><strong>25</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>L� Bezdel�ga</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>8:1</td>
<td class=kW>8:2</td>
<td class=kW>4:2</td>
<td class=kW>10:0</td>
<td class=kW>8:0</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=br>65:13</td><td class=br>+52</td>
<td class=bc>11 - 1 - 1</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Dm Stykailo</td><td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>8:0</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>52:9</td><td class=br>+43</td>
<td class=bc>10 - 1 - 2</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Zi �mits</td><td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=br>32:14</td><td class=br>+18</td>
<td class=bc>9 - 1 - 3</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Re Saul�tis</td><td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>7:0</td>
<td class=br>42:22</td><td class=br>+20</td>
<td class=bc>8 - 1 - 4</td>
<td class=br><strong>17</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>�v Vikmanis</td><td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=br>26:19</td><td class=br>+7</td>
<td class=bc>7 - 2 - 4</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Jo Pleikys</td><td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=br>28:14</td><td class=br>+14</td>
<td class=bc>7 - 1 - 5</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Kr Gremze</td><td class=kL>2:6</td>
<td class=kL>1:8</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>30:42</td><td class=br>-12</td>
<td class=bc>6 - 0 - 7</td>
<td class=br><strong>12</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ha Upmalis</td><td class=kL>0:5</td>
<td class=kL>2:8</td>
<td class=kL>0:8</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kT>0:0</td>
<td class=kL>2:4</td>
<td class=br>30:39</td><td class=br>-9</td>
<td class=bc>4 - 3 - 6</td>
<td class=br><strong>11</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>To Kazakevicius</td><td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kT>0:0</td>
<td class=kW>1:0</td>
<td class=kW>1:0</td>
<td class=br>7:31</td><td class=br>-24</td>
<td class=bc>3 - 1 - 9</td>
<td class=br><strong>7</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>He S�lis</td><td class=kL>2:5</td>
<td class=kL>0:10</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:1</td>
<td class=kL>1:7</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=br>11:51</td><td class=br>-40</td>
<td class=bc>3 - 0 - 10</td>
<td class=br><strong>6</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Da Gucols</td><td class=kL>0:3</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kT>0:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=br>11:42</td><td class=br>-31</td>
<td class=bc>2 - 1 - 10</td>
<td class=br><strong>5</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ge Jansons</td><td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kT>0:0</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=br>5:42</td><td class=br>-37</td>
<td class=bc>1 - 1 - 11</td>
<td class=br><strong>3</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Ro Garda</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=br>8:46</td><td class=br>-38</td>
<td class=bc>1 - 0 - 12</td>
<td class=br><strong>2</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Ha Upmalis</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=blW>Zi �mits</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr Gremze</td><td class=bc>-</td><td class=blW>Dm Stykailo</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Da Gucols</td><td class=bc>-</td><td class=blW>He S�lis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Kazakevicius</td><td class=bc>-</td><td class=blW>Jo Pleikys</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>Ha Upmalis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Zi �mits</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Dm Stykailo</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=blW>He S�lis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Gremze</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Da Gucols</td><td class=bc>-</td><td class=blW>Jo Pleikys</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>To Kazakevicius</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ha Upmalis</td><td class=bc>-</td><td class=blW>Zi �mits</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Dm Stykailo</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>He S�lis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=blW>Jo Pleikys</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kr Gremze</td><td class=bc>-</td><td class=bl>To Kazakevicius</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Da Gucols</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Zi �mits</td><td class=bc>-</td><td class=bl>Dm Stykailo</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Ha Upmalis</td><td class=bc>-</td><td class=bl>He S�lis</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>To Kazakevicius</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=blW>Ge Jansons</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kr Gremze</td><td class=bc>-</td><td class=bl>Da Gucols</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Dm Stykailo</td><td class=bc>-</td><td class=bl>He S�lis</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Zi �mits</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ha Upmalis</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>To Kazakevicius</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Da Gucols</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=blW>Kr Gremze</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>He S�lis</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Dm Stykailo</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Zi �mits</td><td class=bc>-</td><td class=bl>To Kazakevicius</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ha Upmalis</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>Da Gucols</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Kr Gremze</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>He S�lis</td><td class=bc>-</td><td class=blW>To Kazakevicius</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Dm Stykailo</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Zi �mits</td><td class=bc>-</td><td class=bl>Da Gucols</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ha Upmalis</td><td class=bc>-</td><td class=blW>Kr Gremze</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Jo Pleikys</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>Da Gucols</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>He S�lis</td><td class=bc>-</td><td class=blW>Kr Gremze</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Dm Stykailo</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Zi �mits</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ha Upmalis</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>To Kazakevicius</td><td class=bc>-</td><td class=bl>Da Gucols</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Jo Pleikys</td><td class=bc>-</td><td class=bl>Kr Gremze</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>He S�lis</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Dm Stykailo</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Zi �mits</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ha Upmalis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Kr Gremze</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>To Kazakevicius</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>He S�lis</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Dm Stykailo</td><td class=bc>-</td><td class=bl>Ha Upmalis</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Zi �mits</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Da Gucols</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>To Kazakevicius</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>Ha Upmalis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>He S�lis</td><td class=bc>-</td><td class=blW>Zi �mits</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Dm Stykailo</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Kr Gremze</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Da Gucols</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>To Kazakevicius</td><td class=bc>-</td><td class=blW>Ha Upmalis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Jo Pleikys</td><td class=bc>-</td><td class=bl>Zi �mits</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>Dm Stykailo</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>He S�lis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr Gremze</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Gucols</td><td class=bc>-</td><td class=blW>Ha Upmalis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Zi �mits</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>To Kazakevicius</td><td class=bc>-</td><td class=blW>Dm Stykailo</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Jo Pleikys</td><td class=bc>-</td><td class=bl>He S�lis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ro Garda</td><td class=bc>-</td><td class=bl>Ha Upmalis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Gremze</td><td class=bc>-</td><td class=blW>Zi �mits</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Gucols</td><td class=bc>-</td><td class=blW>Dm Stykailo</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>He S�lis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Kazakevicius</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
