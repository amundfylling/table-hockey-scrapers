<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Rigas Kauss II Groups</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../23RK/Rigas_Kauss_II_Groups_index.php">Rigas Kauss II Groups, 2. decembris 2023</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ol Korabel</td><td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kT>4:4</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>8:4</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=kW>10:0</td>
<td class=br>71:28</td><td class=br>+43</td>
<td class=bc>10 - 2 - 2</td>
<td class=br><strong>22</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>To Baumanis</td><td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>10:0</td>
<td class=br>56:21</td><td class=br>+35</td>
<td class=bc>9 - 3 - 2</td>
<td class=br><strong>21</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>An Liepi��</td><td class=kW>6:3</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>6:3</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>10:0</td>
<td class=br>57:30</td><td class=br>+27</td>
<td class=bc>9 - 3 - 2</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>In Garan�s</td><td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=kW>8:1</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>7:0</td>
<td class=kW>4:3</td>
<td class=kW>10:0</td>
<td class=br>61:30</td><td class=br>+31</td>
<td class=bc>9 - 3 - 2</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ar Zasurcevs</td><td class=kL>0:6</td>
<td class=kW>5:0</td>
<td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>6:4</td>
<td class=kW>5:2</td>
<td class=kW>10:0</td>
<td class=br>56:38</td><td class=br>+18</td>
<td class=bc>10 - 0 - 4</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Tr Mansson</td><td class=kL>2:6</td>
<td class=kL>1:7</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>10:0</td>
<td class=br>45:30</td><td class=br>+15</td>
<td class=bc>8 - 2 - 4</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Sa Skarainis</td><td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>1:8</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>10:0</td>
<td class=br>40:38</td><td class=br>+2</td>
<td class=bc>6 - 4 - 4</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>An Bo�i�</td><td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>0:2</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=kW>3:0</td>
<td class=kW>10:0</td>
<td class=br>52:24</td><td class=br>+28</td>
<td class=bc>7 - 2 - 5</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>�r Zaics</td><td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>10:0</td>
<td class=br>36:28</td><td class=br>+8</td>
<td class=bc>5 - 5 - 4</td>
<td class=br><strong>15</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ra Kuha�skis</td><td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kW>4:0</td>
<td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>10:0</td>
<td class=br>47:39</td><td class=br>+8</td>
<td class=bc>6 - 1 - 7</td>
<td class=br><strong>13</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>L� Bezdel�ga</td><td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kW>10:0</td>
<td class=br>38:55</td><td class=br>-17</td>
<td class=bc>3 - 2 - 9</td>
<td class=br><strong>8</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Bi Karlsson</td><td class=kL>4:8</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>10:0</td>
<td class=br>35:46</td><td class=br>-11</td>
<td class=bc>3 - 2 - 9</td>
<td class=br><strong>8</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ja Hansson</td><td class=kL>0:7</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>4:6</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>0:7</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>10:0</td>
<td class=br>27:56</td><td class=br>-29</td>
<td class=bc>2 - 2 - 10</td>
<td class=br><strong>6</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>D</td><td class=d>14.</td><td class=kt>Dm Stykailo</td><td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>10:0</td>
<td class=br>29:47</td><td class=br>-18</td>
<td class=bc>2 - 1 - 11</td>
<td class=br><strong>5</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ar Tseluiko</td><td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kx>*</td>
<td class=br>0:140</td><td class=br>-140</td>
<td class=bc>0 - 0 - 14</td>
<td class=br><strong>0</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>�r Zaics</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>An Bo�i�</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>Dm Stykailo</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Bi Karlsson</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>�r Zaics</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Dm Stykailo</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>An Bo�i�</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Bi Karlsson</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>�r Zaics</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Dm Stykailo</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>An Bo�i�</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Dm Stykailo</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>�r Zaics</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>An Bo�i�</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>Bi Karlsson</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Dm Stykailo</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>�r Zaics</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Bi Karlsson</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>An Bo�i�</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Dm Stykailo</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>�r Zaics</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Bi Karlsson</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Dm Stykailo</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Bi Karlsson</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>�r Zaics</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=bl>An Bo�i�</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Bi Karlsson</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Dm Stykailo</td><td class=bc>-</td><td class=blW>Ja Hansson</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>�r Zaics</td><td class=bc>-</td><td class=bl>An Bo�i�</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Bi Karlsson</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Dm Stykailo</td><td class=bc>-</td><td class=blW>An Bo�i�</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>�r Zaics</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Bi Karlsson</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>An Bo�i�</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Dm Stykailo</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>0 : 10</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Bi Karlsson</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>An Bo�i�</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Dm Stykailo</td><td class=bc>-</td><td class=bl>�r Zaics</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Bi Karlsson</td><td class=bc>-</td><td class=blW>An Bo�i�</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=bl>�r Zaics</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>10 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>An Bo�i�</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Bi Karlsson</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>�r Zaics</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Dm Stykailo</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>An Bo�i�</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Bi Karlsson</td><td class=bc>-</td><td class=bl>�r Zaics</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Dm Stykailo</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>An Bo�i�</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>�r Zaics</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ja Hansson</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Bi Karlsson</td><td class=bc>-</td><td class=bl>Dm Stykailo</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>3 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ja Pelkonen</td><td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>8:3</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kL>0:5</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=br>60:29</td><td class=br>+31</td>
<td class=bc>11 - 1 - 2</td>
<td class=br><strong>23</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Pa Petr</td><td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kW>6:1</td>
<td class=kW>7:3</td>
<td class=kW>7:2</td>
<td class=kW>7:1</td>
<td class=kW>8:1</td>
<td class=kW>8:2</td>
<td class=kW>8:1</td>
<td class=kW>7:2</td>
<td class=kW>5:3</td>
<td class=br>81:30</td><td class=br>+51</td>
<td class=bc>11 - 1 - 2</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Kr Naglis</td><td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>6:3</td>
<td class=kW>7:2</td>
<td class=kW>6:3</td>
<td class=k>&nbsp;</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=br>51:27</td><td class=br>+24</td>
<td class=bc>9 - 3 - 1</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Lu Jurka</td><td class=kW>5:2</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=br>40:21</td><td class=br>+19</td>
<td class=bc>9 - 2 - 3</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>An Fjermestad</td><td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kW>8:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=br>51:30</td><td class=br>+21</td>
<td class=bc>8 - 3 - 3</td>
<td class=br><strong>19</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Da Hrustaljova</td><td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kL>3:6</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>3:0</td>
<td class=br>43:29</td><td class=br>+14</td>
<td class=bc>8 - 2 - 4</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Da Sippo</td><td class=kL>3:8</td>
<td class=kL>1:6</td>
<td class=kL>2:7</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kL>0:4</td>
<td class=kW>3:1</td>
<td class=kW>7:4</td>
<td class=kW>6:2</td>
<td class=br>41:49</td><td class=br>-8</td>
<td class=bc>7 - 1 - 6</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ma Kyllerg�rd</td><td class=kL>2:5</td>
<td class=kL>3:7</td>
<td class=kL>3:6</td>
<td class=kW>3:2</td>
<td class=kL>1:8</td>
<td class=kW>1:0</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=br>30:50</td><td class=br>-20</td>
<td class=bc>6 - 0 - 8</td>
<td class=br><strong>12</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Mi Saul�tis</td><td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=k>&nbsp;</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=br>36:30</td><td class=br>+6</td>
<td class=bc>5 - 2 - 6</td>
<td class=br><strong>12</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ka Pirumshoeva</td><td class=kW>5:0</td>
<td class=kL>1:7</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=br>31:35</td><td class=br>-4</td>
<td class=bc>4 - 4 - 6</td>
<td class=br><strong>12</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ro Iga</td><td class=kL>2:5</td>
<td class=kL>1:8</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>3:6</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=br>26:45</td><td class=br>-19</td>
<td class=bc>5 - 1 - 8</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Mi Margolis</td><td class=kL>2:3</td>
<td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=br>32:43</td><td class=br>-11</td>
<td class=bc>4 - 2 - 8</td>
<td class=br><strong>10</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Hy Nechutny</td><td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=br>25:48</td><td class=br>-23</td>
<td class=bc>3 - 1 - 10</td>
<td class=br><strong>7</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>D</td><td class=d>14.</td><td class=kt>Il �irse</td><td class=kL>0:7</td>
<td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>2:7</td>
<td class=kL>4:7</td>
<td class=kL>3:4</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=br>19:61</td><td class=br>-42</td>
<td class=bc>1 - 1 - 12</td>
<td class=br><strong>3</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>�i Vazoli��</td><td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=br>19:58</td><td class=br>-39</td>
<td class=bc>1 - 0 - 13</td>
<td class=br><strong>2</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Da Hrustaljova</td><td class=bc>-</td><td class=bl>Da Sippo</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ro Iga</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ma Kyllerg�rd</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Mi Margolis</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>Da Sippo</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Da Hrustaljova</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ro Iga</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Ja Pelkonen</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Hy Nechutny</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Kyllerg�rd</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Da Sippo</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>Ka Pirumshoeva</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ro Iga</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Sippo</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ro Iga</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=blW>Ma Kyllerg�rd</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Da Sippo</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>Ma Kyllerg�rd</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ro Iga</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Hy Nechutny</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Da Sippo</td><td class=bc>-</td><td class=blW>Mi Margolis</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>�i Vazoli��</td><td class=bc>-</td><td class=bl>Ma Kyllerg�rd</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ka Pirumshoeva</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>Ma Kyllerg�rd</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Da Sippo</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Ro Iga</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Hy Nechutny</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Kyllerg�rd</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Ka Pirumshoeva</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Sippo</td><td class=bc>-</td><td class=bl>Ro Iga</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>Da Hrustaljova</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Hy Nechutny</td><td class=bc>-</td><td class=blW>Ma Kyllerg�rd</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=bl>Ro Iga</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Da Hrustaljova</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Sippo</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Mi Margolis</td><td class=bc>-</td><td class=bl>Ma Kyllerg�rd</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Hy Nechutny</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Ro Iga</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Da Hrustaljova</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ma Kyllerg�rd</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ro Iga</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Hy Nechutny</td><td class=bc>-</td><td class=blW>Da Hrustaljova</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Da Sippo</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma Kyllerg�rd</td><td class=bc>-</td><td class=blW>Ro Iga</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Da Hrustaljova</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Hy Nechutny</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Da Sippo</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Ro Iga</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Da Hrustaljova</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ma Kyllerg�rd</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Mi Margolis</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Da Sippo</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Hy Nechutny</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=blW>Ka Pirumshoeva</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ro Iga</td><td class=bc>-</td><td class=blW>Da Hrustaljova</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Kyllerg�rd</td><td class=bc>-</td><td class=blW>Da Sippo</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Hy Nechutny</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ro Iga</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=bl>Da Sippo</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ma Kyllerg�rd</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Ja Pelkonen</td><td class=bc>2 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>At S�lis</td><td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>6:4</td>
<td class=kL>0:4</td>
<td class=kW>6:4</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>10:2</td>
<td class=kW>6:2</td>
<td class=kW>9:1</td>
<td class=kW>7:2</td>
<td class=br>78:26</td><td class=br>+52</td>
<td class=bc>12 - 1 - 1</td>
<td class=br><strong>25</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ti Mihhaljov</td><td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=br>48:22</td><td class=br>+26</td>
<td class=bc>12 - 1 - 1</td>
<td class=br><strong>25</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>An Kuz�ecovs</td><td class=kL>4:6</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>7:5</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>10:0</td>
<td class=br>61:36</td><td class=br>+25</td>
<td class=bc>9 - 1 - 4</td>
<td class=br><strong>19</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Kr Lagzdi�a</td><td class=kW>4:0</td>
<td class=kL>0:1</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=br>34:22</td><td class=br>+12</td>
<td class=bc>9 - 0 - 5</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>He Nilsson</td><td class=kL>4:6</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=br>45:33</td><td class=br>+12</td>
<td class=bc>8 - 1 - 5</td>
<td class=br><strong>17</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>J� Z�l�te</td><td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>5:7</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kW>7:3</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=br>47:43</td><td class=br>+4</td>
<td class=bc>8 - 0 - 6</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Si Pleikys</td><td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>8:0</td>
<td class=br>45:38</td><td class=br>+7</td>
<td class=bc>7 - 2 - 5</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ma Jakseboga</td><td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>7:3</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=br>47:28</td><td class=br>+19</td>
<td class=bc>7 - 1 - 6</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Fi Buhtujevs</td><td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kL>4:5</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>8:2</td>
<td class=br>42:33</td><td class=br>+9</td>
<td class=bc>6 - 3 - 5</td>
<td class=br><strong>15</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Po Kvasnikova</td><td class=kL>1:7</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=br>28:33</td><td class=br>-5</td>
<td class=bc>6 - 1 - 7</td>
<td class=br><strong>13</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Fr Platons</td><td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=br>19:31</td><td class=br>-12</td>
<td class=bc>5 - 0 - 9</td>
<td class=br><strong>10</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ni Sviklis</td><td class=kL>2:10</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>3:7</td>
<td class=kL>2:4</td>
<td class=kL>3:7</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=br>33:59</td><td class=br>-26</td>
<td class=bc>3 - 1 - 10</td>
<td class=br><strong>7</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Al Pimenovs</td><td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=br>20:48</td><td class=br>-28</td>
<td class=bc>2 - 3 - 9</td>
<td class=br><strong>7</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>D</td><td class=d>14.</td><td class=kt>J� Zem�ickis</td><td class=kL>1:9</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=br>19:61</td><td class=br>-42</td>
<td class=bc>0 - 4 - 10</td>
<td class=br><strong>4</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ju Steisunas</td><td class=kL>2:7</td>
<td class=kL>3:6</td>
<td class=kL>0:10</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>2:8</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=br>20:73</td><td class=br>-53</td>
<td class=bc>1 - 1 - 12</td>
<td class=br><strong>3</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Ju Steisunas</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>At S�lis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ti Mihhaljov</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>He Nilsson</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ju Steisunas</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>At S�lis</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ti Mihhaljov</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Ju Steisunas</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>At S�lis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Al Pimenovs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>He Nilsson</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ju Steisunas</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>At S�lis</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Ti Mihhaljov</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ju Steisunas</td><td class=bc>-</td><td class=blW>At S�lis</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Ti Mihhaljov</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>At S�lis</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ju Steisunas</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>He Nilsson</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Ti Mihhaljov</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>At S�lis</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ju Steisunas</td><td class=bc>-</td><td class=blW>He Nilsson</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ti Mihhaljov</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>He Nilsson</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>At S�lis</td><td class=bc>-</td><td class=bl>Ti Mihhaljov</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ju Steisunas</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>5 : 7</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Al Pimenovs</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Ti Mihhaljov</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>At S�lis</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ju Steisunas</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>Ti Mihhaljov</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>At S�lis</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ju Steisunas</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ti Mihhaljov</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>He Nilsson</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>At S�lis</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Ju Steisunas</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ti Mihhaljov</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>At S�lis</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>10 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Po Kvasnikova</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ti Mihhaljov</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>He Nilsson</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Ju Steisunas</td><td class=bc>8 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ti Mihhaljov</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>He Nilsson</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=blW>Ju Steisunas</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>At S�lis</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Po Kvasnikova</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ti Mihhaljov</td><td class=bc>-</td><td class=bl>Ju Steisunas</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>At S�lis</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>0 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group D</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ed Ka�eps</td><td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>8:2</td>
<td class=kW>5:0</td>
<td class=br>58:19</td><td class=br>+39</td>
<td class=bc>10 - 4 - 0</td>
<td class=br><strong>24</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Va Smagars</td><td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>7:0</td>
<td class=kW>6:2</td>
<td class=kW>11:0</td>
<td class=br>70:29</td><td class=br>+41</td>
<td class=bc>9 - 3 - 2</td>
<td class=br><strong>21</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Al Sili��</td><td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kW>7:0</td>
<td class=kL>5:6</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>7:4</td>
<td class=kW>5:2</td>
<td class=kW>6:4</td>
<td class=kW>9:2</td>
<td class=kW>5:2</td>
<td class=br>65:33</td><td class=br>+32</td>
<td class=bc>9 - 3 - 2</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ar Matantsev</td><td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kW>9:1</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kW>8:1</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=kW>6:1</td>
<td class=br>72:28</td><td class=br>+44</td>
<td class=bc>10 - 0 - 4</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ig Saveljev</td><td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=k>&nbsp;</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>8:3</td>
<td class=kW>5:3</td>
<td class=br>50:29</td><td class=br>+21</td>
<td class=bc>9 - 1 - 3</td>
<td class=br><strong>19</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ma Zenisek</td><td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kL>0:7</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>6:1</td>
<td class=kW>9:0</td>
<td class=br>52:34</td><td class=br>+18</td>
<td class=bc>8 - 3 - 3</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ni L�cis</td><td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kW>6:5</td>
<td class=kL>1:9</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kW>5:0</td>
<td class=kW>9:2</td>
<td class=kW>4:3</td>
<td class=br>46:46</td><td class=br>0</td>
<td class=bc>6 - 3 - 5</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ra Stern�ts</td><td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kW>5:4</td>
<td class=kL>2:7</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=br>39:44</td><td class=br>-5</td>
<td class=bc>7 - 1 - 6</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Li �sterman</td><td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=br>29:39</td><td class=br>-10</td>
<td class=bc>6 - 2 - 6</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>My Verbytskyy</td><td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kL>0:5</td>
<td class=kW>5:4</td>
<td class=k>&nbsp;</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=br>27:32</td><td class=br>-5</td>
<td class=bc>5 - 3 - 5</td>
<td class=br><strong>13</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Au Pleikys</td><td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>4:7</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kW>3:0</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>5:4</td>
<td class=kW>7:1</td>
<td class=br>38:42</td><td class=br>-4</td>
<td class=bc>5 - 1 - 8</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Il Pavlovskis</td><td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>1:8</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>1:0</td>
<td class=br>20:48</td><td class=br>-28</td>
<td class=bc>2 - 1 - 11</td>
<td class=br><strong>5</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ro Purmalis</td><td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kL>4:6</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kL>1:3</td>
<td class=br>22:57</td><td class=br>-35</td>
<td class=bc>2 - 1 - 11</td>
<td class=br><strong>5</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>D</td><td class=d>14.</td><td class=kt>Iv �irsis</td><td class=kL>2:8</td>
<td class=kL>2:6</td>
<td class=kL>2:9</td>
<td class=kL>0:8</td>
<td class=kL>3:8</td>
<td class=kL>1:6</td>
<td class=kL>2:9</td>
<td class=kL>3:6</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>27:82</td><td class=br>-55</td>
<td class=bc>2 - 0 - 12</td>
<td class=br><strong>4</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>To Ulis</td><td class=kL>0:5</td>
<td class=kL>0:11</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kL>0:9</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>1:7</td>
<td class=kL>0:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>16:69</td><td class=br>-53</td>
<td class=bc>1 - 0 - 13</td>
<td class=br><strong>2</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ni L�cis</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Li �sterman</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ma Zenisek</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Ra Stern�ts</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Li �sterman</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Zenisek</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Li �sterman</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=blW>Ra Stern�ts</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ni L�cis</td><td class=bc>-</td><td class=bl>Li �sterman</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ra Stern�ts</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>To Ulis</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Zenisek</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Li �sterman</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ra Stern�ts</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=blW>Il Pavlovskis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=bl>Li �sterman</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>Li �sterman</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ni L�cis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ma Zenisek</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Li �sterman</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Li �sterman</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ni L�cis</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>0 : 9</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=blW>Li �sterman</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Ni L�cis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ra Stern�ts</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Li �sterman</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>11 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ni L�cis</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Li �sterman</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ni L�cis</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Li �sterman</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Ra Stern�ts</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ni L�cis</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Li �sterman</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=blW>Ra Stern�ts</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>4 : 6</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group E</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ed Naglis</td><td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>5:6</td>
<td class=kW>6:4</td>
<td class=kW>4:1</td>
<td class=kT>5:5</td>
<td class=kW>7:0</td>
<td class=kW>7:2</td>
<td class=kW>7:0</td>
<td class=kW>6:0</td>
<td class=kW>9:1</td>
<td class=br>75:29</td><td class=br>+46</td>
<td class=bc>12 - 1 - 1</td>
<td class=br><strong>25</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>El Sili��</td><td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kW>8:1</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kW>10:3</td>
<td class=br>66:24</td><td class=br>+42</td>
<td class=bc>11 - 1 - 2</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>J� Re�is</td><td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>5:3</td>
<td class=kW>8:1</td>
<td class=br>51:27</td><td class=br>+24</td>
<td class=bc>9 - 2 - 3</td>
<td class=br><strong>20</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Vi Henttonen</td><td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=br>42:22</td><td class=br>+20</td>
<td class=bc>9 - 2 - 3</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Am Risa Fylling</td><td class=kL>1:2</td>
<td class=kL>1:8</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kW>8:1</td>
<td class=kW>10:2</td>
<td class=br>51:38</td><td class=br>+13</td>
<td class=bc>6 - 5 - 3</td>
<td class=br><strong>17</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Hu Lonnqvist</td><td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=br>53:27</td><td class=br>+26</td>
<td class=bc>8 - 1 - 5</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ha Ivantsova</td><td class=kW>6:5</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=kW>6:3</td>
<td class=kW>9:0</td>
<td class=br>52:34</td><td class=br>+18</td>
<td class=bc>7 - 3 - 4</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>El R�cen�ja</td><td class=kL>4:6</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kL>4:6</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>6:0</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=br>50:36</td><td class=br>+14</td>
<td class=bc>7 - 3 - 4</td>
<td class=br><strong>17</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Gl Storozhenko</td><td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>9:0</td>
<td class=kW>8:0</td>
<td class=br>39:36</td><td class=br>+3</td>
<td class=bc>6 - 0 - 8</td>
<td class=br><strong>12</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ed Putni��</td><td class=kT>5:5</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>6:4</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>7:1</td>
<td class=kW>8:3</td>
<td class=kW>6:4</td>
<td class=kW>9:1</td>
<td class=br>57:51</td><td class=br>+6</td>
<td class=bc>5 - 2 - 7</td>
<td class=br><strong>12</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Mark �bele</td><td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>2:0</td>
<td class=br>25:42</td><td class=br>-17</td>
<td class=bc>5 - 1 - 8</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ri Kalni��</td><td class=kL>2:7</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kW>4:0</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=br>21:39</td><td class=br>-18</td>
<td class=bc>4 - 1 - 9</td>
<td class=br><strong>9</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Zi �mits</td><td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kL>1:7</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kW>2:1</td>
<td class=kL>3:8</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=br>19:70</td><td class=br>-51</td>
<td class=bc>2 - 2 - 10</td>
<td class=br><strong>6</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>D</td><td class=d>14.</td><td class=kt>Vo Kvasnikov</td><td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>1:8</td>
<td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kL>0:2</td>
<td class=kL>0:9</td>
<td class=kL>4:6</td>
<td class=kL>2:7</td>
<td class=kL>0:3</td>
<td class=kW>6:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>26:72</td><td class=br>-46</td>
<td class=bc>2 - 0 - 12</td>
<td class=br><strong>4</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ja Janouskovec</td><td class=kL>1:9</td>
<td class=kL>3:10</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>2:10</td>
<td class=kL>1:7</td>
<td class=kL>0:9</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>1:9</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>12:92</td><td class=br>-80</td>
<td class=bc>0 - 0 - 14</td>
<td class=br><strong>0</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Mark �bele</td><td class=bc>-</td><td class=bl>Zi �mits</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ja Janouskovec</td><td class=bc>-</td><td class=blW>Am Risa Fylling</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Hu Lonnqvist</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Zi �mits</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=bl>Am Risa Fylling</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ja Janouskovec</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Zi �mits</td><td class=bc>-</td><td class=bl>Am Risa Fylling</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Janouskovec</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Hu Lonnqvist</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Am Risa Fylling</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Zi �mits</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Mark �bele</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=blW>Hu Lonnqvist</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ja Janouskovec</td><td class=bc>-</td><td class=blW>Vo Kvasnikov</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Am Risa Fylling</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Zi �mits</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=blW>Hu Lonnqvist</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Am Risa Fylling</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Hu Lonnqvist</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zi �mits</td><td class=bc>-</td><td class=blW>Vo Kvasnikov</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=blW>Ri Kalni��</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Ja Janouskovec</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Am Risa Fylling</td><td class=bc>-</td><td class=bl>Hu Lonnqvist</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Zi �mits</td><td class=bc>-</td><td class=bl>Ja Janouskovec</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>Hu Lonnqvist</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Am Risa Fylling</td><td class=bc>-</td><td class=blW>Ri Kalni��</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Ja Janouskovec</td><td class=bc>10 : 3</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zi �mits</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Hu Lonnqvist</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Ja Janouskovec</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Am Risa Fylling</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>Mark �bele</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Hu Lonnqvist</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Ja Janouskovec</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Am Risa Fylling</td><td class=bc>-</td><td class=bl>Mark �bele</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Zi �mits</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Ri Kalni��</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Hu Lonnqvist</td><td class=bc>-</td><td class=bl>Ja Janouskovec</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=bl>Mark �bele</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Zi �mits</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Am Risa Fylling</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ri Kalni��</td><td class=bc>-</td><td class=bl>Ja Janouskovec</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Hu Lonnqvist</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Mark �bele</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Zi �mits</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ja Janouskovec</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Mark �bele</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Hu Lonnqvist</td><td class=bc>-</td><td class=bl>Zi �mits</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Am Risa Fylling</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Janouskovec</td><td class=bc>-</td><td class=blW>Mark �bele</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=bl>Zi �mits</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Hu Lonnqvist</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Am Risa Fylling</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Mark �bele</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Zi �mits</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ja Janouskovec</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Am Risa Fylling</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Hu Lonnqvist</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>6 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group F</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Mi Kobrle</td><td class=kx>*</td>
<td class=kW>9:2</td>
<td class=kL>3:4</td>
<td class=kW>6:1</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>8:5</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>8:2</td>
<td class=kW>7:3</td>
<td class=br>79:34</td><td class=br>+45</td>
<td class=bc>12 - 0 - 2</td>
<td class=br><strong>24</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Da Landa</td><td class=kL>2:9</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>1:0</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=br>53:30</td><td class=br>+23</td>
<td class=bc>11 - 1 - 2</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>La Fridell</td><td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>4:6</td>
<td class=kW>5:3</td>
<td class=kW>8:2</td>
<td class=kL>2:3</td>
<td class=kW>7:4</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=br>65:33</td><td class=br>+32</td>
<td class=bc>11 - 0 - 3</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Re Vazoli��</td><td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kW>6:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kW>7:3</td>
<td class=kW>8:2</td>
<td class=br>56:40</td><td class=br>+16</td>
<td class=bc>9 - 1 - 4</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Pa Plesak</td><td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kW>6:4</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>51:31</td><td class=br>+20</td>
<td class=bc>9 - 1 - 4</td>
<td class=br><strong>19</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>R� Logins</td><td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>2:8</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>6:4</td>
<td class=kW>2:1</td>
<td class=br>40:47</td><td class=br>-7</td>
<td class=bc>8 - 2 - 4</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Be Suominen</td><td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kL>0:3</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=br>42:29</td><td class=br>+13</td>
<td class=bc>8 - 2 - 4</td>
<td class=br><strong>18</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Go Lonnqvist</td><td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kL>4:7</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=br>38:39</td><td class=br>-1</td>
<td class=bc>5 - 3 - 6</td>
<td class=br><strong>13</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ar Salmi��</td><td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kL>4:6</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kL>1:4</td>
<td class=br>35:41</td><td class=br>-6</td>
<td class=bc>4 - 3 - 7</td>
<td class=br><strong>11</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Sa Krasts</td><td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=br>34:34</td><td class=br>0</td>
<td class=bc>4 - 2 - 8</td>
<td class=br><strong>10</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ma Satkus</td><td class=kL>5:8</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kL>1:7</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>7:0</td>
<td class=br>38:49</td><td class=br>-11</td>
<td class=bc>3 - 3 - 8</td>
<td class=br><strong>9</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Da Baumanis</td><td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=br>28:46</td><td class=br>-18</td>
<td class=bc>2 - 3 - 9</td>
<td class=br><strong>7</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Gi Remeika</td><td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=br>23:41</td><td class=br>-18</td>
<td class=bc>3 - 1 - 10</td>
<td class=br><strong>7</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>D</td><td class=d>14.</td><td class=kt>Do Zupancic</td><td class=kL>2:8</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>3:7</td>
<td class=kL>1:3</td>
<td class=kL>4:6</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=br>24:61</td><td class=br>-37</td>
<td class=bc>2 - 2 - 10</td>
<td class=br><strong>6</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ro Aseri��</td><td class=kL>3:7</td>
<td class=kL>1:8</td>
<td class=kL>0:6</td>
<td class=kL>2:8</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kW>4:1</td>
<td class=kL>1:6</td>
<td class=kL>0:7</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=br>19:70</td><td class=br>-51</td>
<td class=bc>1 - 2 - 11</td>
<td class=br><strong>4</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Do Zupancic</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>La Fridell</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>8 : 5</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Landa</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>R� Logins</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Do Zupancic</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>La Fridell</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Pa Plesak</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Da Landa</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Do Zupancic</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>La Fridell</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>R� Logins</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>Ar Salmi��</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Do Zupancic</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>Pa Plesak</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>La Fridell</td><td class=bc>-</td><td class=bl>R� Logins</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Da Landa</td><td class=bc>9 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>Gi Remeika</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Do Zupancic</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>R� Logins</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Da Landa</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>La Fridell</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ar Salmi��</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Pa Plesak</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>Go Lonnqvist</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>R� Logins</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Do Zupancic</td><td class=bc>-</td><td class=blW>Da Landa</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Pa Plesak</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Go Lonnqvist</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>R� Logins</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=bl>Da Landa</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Do Zupancic</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>La Fridell</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>R� Logins</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ar Salmi��</td><td class=bc>-</td><td class=bl>Da Landa</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>La Fridell</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Do Zupancic</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>R� Logins</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Da Landa</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Gi Remeika</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>La Fridell</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>8 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>R� Logins</td><td class=bc>-</td><td class=blW>Da Landa</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>La Fridell</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Do Zupancic</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Da Landa</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>R� Logins</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>La Fridell</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Gi Remeika</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ar Salmi��</td><td class=bc>-</td><td class=bl>Do Zupancic</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Da Landa</td><td class=bc>-</td><td class=bl>La Fridell</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>R� Logins</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>Do Zupancic</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>La Fridell</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Da Landa</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>R� Logins</td><td class=bc>-</td><td class=bl>Do Zupancic</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>La Fridell</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Do Zupancic</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Da Landa</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>R� Logins</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>6 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>La Fridell</td><td class=bc>-</td><td class=bl>Do Zupancic</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Da Landa</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>R� Logins</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>4 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group G</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Un �sterman</td><td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>8:2</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=br>69:25</td><td class=br>+44</td>
<td class=bc>12 - 2 - 0</td>
<td class=br><strong>26</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Kr Rieksti��</td><td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=br>48:24</td><td class=br>+24</td>
<td class=bc>10 - 3 - 1</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>D� Apfelbaums</td><td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=br>54:31</td><td class=br>+23</td>
<td class=bc>8 - 4 - 2</td>
<td class=br><strong>20</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Al Skudr�tis</td><td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kW>6:5</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>8:1</td>
<td class=br>53:31</td><td class=br>+22</td>
<td class=bc>8 - 3 - 3</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ve Huotelin</td><td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>6:4</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>7:3</td>
<td class=br>53:37</td><td class=br>+16</td>
<td class=bc>9 - 1 - 4</td>
<td class=br><strong>19</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Sa Kalni��</td><td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kL>0:6</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=br>35:32</td><td class=br>+3</td>
<td class=bc>8 - 1 - 5</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ne Skrlep</td><td class=kL>0:6</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>6:4</td>
<td class=kW>7:2</td>
<td class=br>54:43</td><td class=br>+11</td>
<td class=bc>8 - 0 - 6</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ro Verbi�s</td><td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kL>5:6</td>
<td class=kL>2:6</td>
<td class=kW>6:0</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=kW>7:5</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=br>54:45</td><td class=br>+9</td>
<td class=bc>7 - 1 - 6</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>My Shalomayev</td><td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>11:1</td>
<td class=br>51:40</td><td class=br>+11</td>
<td class=bc>5 - 3 - 6</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Kr Zarinieks</td><td class=kL>2:8</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=br>31:58</td><td class=br>-27</td>
<td class=bc>4 - 2 - 8</td>
<td class=br><strong>10</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Kr Zem�ickis</td><td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kT>1:1</td>
<td class=kL>4:6</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>10:0</td>
<td class=kT>2:2</td>
<td class=br>33:50</td><td class=br>-17</td>
<td class=bc>2 - 5 - 7</td>
<td class=br><strong>9</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Em Reinfelds</td><td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>5:7</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=br>35:49</td><td class=br>-14</td>
<td class=bc>4 - 1 - 9</td>
<td class=br><strong>9</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ra Martu��ns</td><td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>8:2</td>
<td class=br>35:55</td><td class=br>-20</td>
<td class=bc>2 - 2 - 10</td>
<td class=br><strong>6</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>D</td><td class=d>14.</td><td class=kt>To Jakseboga</td><td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>4:6</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>0:10</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=br>28:59</td><td class=br>-31</td>
<td class=bc>1 - 3 - 10</td>
<td class=br><strong>5</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>D� Vesele</td><td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>1:8</td>
<td class=kL>3:7</td>
<td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kL>1:11</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=br>23:77</td><td class=br>-54</td>
<td class=bc>0 - 3 - 11</td>
<td class=br><strong>3</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Un �sterman</td><td class=bc>-</td><td class=bl>Ne Skrlep</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Em Reinfelds</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ne Skrlep</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Un �sterman</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ne Skrlep</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=blW>Em Reinfelds</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Ne Skrlep</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Em Reinfelds</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Un �sterman</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Ne Skrlep</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Em Reinfelds</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>Un �sterman</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Ne Skrlep</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Em Reinfelds</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Un �sterman</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ne Skrlep</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Em Reinfelds</td><td class=bc>7 : 5</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Un �sterman</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ne Skrlep</td><td class=bc>-</td><td class=blW>Em Reinfelds</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Un �sterman</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>4 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Em Reinfelds</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Un �sterman</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ne Skrlep</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=blW>Un �sterman</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ne Skrlep</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Un �sterman</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ne Skrlep</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Un �sterman</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ne Skrlep</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Un �sterman</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>11 : 1</tr></td>
<tr><td class=br>Ne Skrlep</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Un �sterman</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Un �sterman</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Ne Skrlep</td><td class=bc>5 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group H</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Em Liepi��</td><td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>5:4</td>
<td class=kW>5:4</td>
<td class=kW>5:1</td>
<td class=kW>10:1</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=br>69:27</td><td class=br>+42</td>
<td class=bc>11 - 2 - 1</td>
<td class=br><strong>24</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ma Madera</td><td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>5:5</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>7:5</td>
<td class=kW>6:2</td>
<td class=br>59:30</td><td class=br>+29</td>
<td class=bc>11 - 1 - 2</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Di Ziemelis</td><td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=kW>7:1</td>
<td class=kW>7:1</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=br>61:35</td><td class=br>+26</td>
<td class=bc>9 - 2 - 3</td>
<td class=br><strong>20</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Kr Lebl</td><td class=kL>3:4</td>
<td class=kT>5:5</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>8:1</td>
<td class=kW>2:1</td>
<td class=kT>0:0</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>50:28</td><td class=br>+22</td>
<td class=bc>9 - 2 - 3</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Gu Hermansson</td><td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>7:0</td>
<td class=kW>6:1</td>
<td class=br>43:22</td><td class=br>+21</td>
<td class=bc>9 - 2 - 3</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>R� Kamzols</td><td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=br>47:32</td><td class=br>+15</td>
<td class=bc>8 - 1 - 5</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ar Zaharovs</td><td class=kL>0:7</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>7:1</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>9:5</td>
<td class=br>50:39</td><td class=br>+11</td>
<td class=bc>7 - 3 - 4</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>He Prokuratovs</td><td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kL>3:6</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kW>6:4</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=br>41:40</td><td class=br>+1</td>
<td class=bc>7 - 0 - 7</td>
<td class=br><strong>14</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Zy Remeika</td><td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>8:1</td>
<td class=kW>3:0</td>
<td class=br>43:34</td><td class=br>+9</td>
<td class=bc>7 - 0 - 7</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Marg �bele</td><td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=br>29:54</td><td class=br>-25</td>
<td class=bc>4 - 2 - 8</td>
<td class=br><strong>10</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ro Kerns</td><td class=kL>1:10</td>
<td class=kL>0:4</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>4:6</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=br>31:50</td><td class=br>-19</td>
<td class=bc>4 - 1 - 9</td>
<td class=br><strong>9</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>J� Bitmanis</td><td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kT>0:0</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>5:4</td>
<td class=kW>5:0</td>
<td class=br>26:45</td><td class=br>-19</td>
<td class=bc>4 - 1 - 9</td>
<td class=br><strong>9</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Re Stac�vi�s</td><td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kW>1:0</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=br>20:49</td><td class=br>-29</td>
<td class=bc>3 - 1 - 10</td>
<td class=br><strong>7</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>D</td><td class=d>14.</td><td class=kt>Mi Myren</td><td class=kL>2:4</td>
<td class=kL>5:7</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>27:57</td><td class=br>-30</td>
<td class=bc>3 - 0 - 11</td>
<td class=br><strong>6</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Kr G�tmanis</td><td class=kL>2:7</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>5:9</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>17:71</td><td class=br>-54</td>
<td class=bc>0 - 0 - 14</td>
<td class=br><strong>0</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Mi Myren</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>5 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Mi Myren</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>1 : 10</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Mi Myren</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Mi Myren</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>Mi Myren</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Mi Myren</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>5 : 7</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>9 : 5</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Myren</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>1 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Mi Myren</td><td class=bc>4 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group Div 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>73.</td><td class=kt>Mi Saul�tis</td><td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kL>1:4</td>
<td class=kL>4:6</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=br>78:36</td><td class=br>+42</td>
<td class=bc>19 - 1 - 3</td>
<td class=br><strong>39</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>74.</td><td class=kt>Fi Buhtujevs</td><td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=br>74:39</td><td class=br>+35</td>
<td class=bc>15 - 3 - 5</td>
<td class=br><strong>33</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>75.</td><td class=kt>Sa Krasts</td><td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=br>61:32</td><td class=br>+29</td>
<td class=bc>13 - 6 - 4</td>
<td class=br><strong>32</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>76.</td><td class=kt>Zy Remeika</td><td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>7:0</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>7:2</td>
<td class=kW>7:1</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=br>86:51</td><td class=br>+35</td>
<td class=bc>14 - 3 - 6</td>
<td class=br><strong>31</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>77.</td><td class=kt>My Shalomayev</td><td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kL>0:2</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kW>1:0</td>
<td class=kW>6:3</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=br>72:48</td><td class=br>+24</td>
<td class=bc>15 - 1 - 7</td>
<td class=br><strong>31</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>78.</td><td class=kt>Ra Kuha�skis</td><td class=kL>1:5</td>
<td class=kW>5:3</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>8:2</td>
<td class=kW>6:4</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kW>6:0</td>
<td class=kW>4:3</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kW>3:2</td>
<td class=kW>9:3</td>
<td class=br>84:55</td><td class=br>+29</td>
<td class=bc>13 - 5 - 3</td>
<td class=br><strong>31</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>79.</td><td class=kt>Ma Satkus</td><td class=kW>4:1</td>
<td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=br>67:54</td><td class=br>+13</td>
<td class=bc>15 - 0 - 8</td>
<td class=br><strong>30</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>80.</td><td class=kt>Ro Iga</td><td class=kW>6:4</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=br>67:54</td><td class=br>+13</td>
<td class=bc>12 - 4 - 7</td>
<td class=br><strong>28</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>81.</td><td class=kt>Ar Salmi��</td><td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kL>0:4</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=br>52:57</td><td class=br>-5</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>82.</td><td class=kt>Kr Zem�ickis</td><td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kW>1:0</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kL>0:6</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=br>53:71</td><td class=br>-18</td>
<td class=bc>9 - 5 - 9</td>
<td class=br><strong>23</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>83.</td><td class=kt>My Verbytskyy</td><td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=br>60:58</td><td class=br>+2</td>
<td class=bc>10 - 3 - 10</td>
<td class=br><strong>23</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>84.</td><td class=kt>Po Kvasnikova</td><td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=br>55:47</td><td class=br>+8</td>
<td class=bc>9 - 5 - 9</td>
<td class=br><strong>23</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>85.</td><td class=kt>Ro Kerns</td><td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=br>40:47</td><td class=br>-7</td>
<td class=bc>9 - 4 - 10</td>
<td class=br><strong>22</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>86.</td><td class=kt>Marg �bele</td><td class=kL>0:4</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>0:7</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=br>52:64</td><td class=br>-12</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>87.</td><td class=kt>Au Pleikys</td><td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>2:8</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=br>54:69</td><td class=br>-15</td>
<td class=bc>8 - 4 - 11</td>
<td class=br><strong>20</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>88.</td><td class=kt>Gl Storozhenko</td><td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>4:6</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=br>50:56</td><td class=br>-6</td>
<td class=bc>7 - 5 - 11</td>
<td class=br><strong>19</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>89.</td><td class=kt>Kr Zarinieks</td><td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kW>4:0</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kT>5:5</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=k>&nbsp;</td>
<td class=kW>5:2</td>
<td class=br>55:59</td><td class=br>-4</td>
<td class=bc>7 - 5 - 10</td>
<td class=br><strong>19</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>90.</td><td class=kt>Ka Pirumshoeva</td><td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>0:7</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>6:0</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=br>47:60</td><td class=br>-13</td>
<td class=bc>7 - 3 - 13</td>
<td class=br><strong>17</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>91.</td><td class=kt>Li �sterman</td><td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>0:1</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=br>29:66</td><td class=br>-37</td>
<td class=bc>7 - 2 - 14</td>
<td class=br><strong>16</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>92.</td><td class=kt>Ed Putni��</td><td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>2:7</td>
<td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kW>6:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kT>0:0</td>
<td class=kT>5:5</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=br>61:73</td><td class=br>-12</td>
<td class=bc>5 - 6 - 12</td>
<td class=br><strong>16</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>93.</td><td class=kt>Mark �bele</td><td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>3:5</td>
<td class=k>&nbsp;</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>4:5</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=br>52:68</td><td class=br>-16</td>
<td class=bc>4 - 7 - 11</td>
<td class=br><strong>15</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>94.</td><td class=kt>Fr Platons</td><td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=k>&nbsp;</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kW>6:2</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=br>27:48</td><td class=br>-21</td>
<td class=bc>4 - 5 - 13</td>
<td class=br><strong>13</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>95.</td><td class=kt>�r Zaics</td><td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=k>&nbsp;</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>40:61</td><td class=br>-21</td>
<td class=bc>4 - 4 - 14</td>
<td class=br><strong>12</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>96.</td><td class=kt>L� Bezdel�ga</td><td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>3:9</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>30:73</td><td class=br>-43</td>
<td class=bc>3 - 2 - 18</td>
<td class=br><strong>8</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>�r Zaics</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Li �sterman</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Mark �bele</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Ro Iga</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>9 : 3</tr></td>
<tr><td class=brW>Ka Pirumshoeva</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�r Zaics</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Mark �bele</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Li �sterman</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Ro Iga</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�r Zaics</td><td class=bc>-</td><td class=blW>Mark �bele</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Li �sterman</td><td class=bc>-</td><td class=bl>Ro Iga</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ar Salmi��</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Mark �bele</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�r Zaics</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>Ro Iga</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Li �sterman</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Mark �bele</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Iga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�r Zaics</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Li �sterman</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Ro Iga</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�r Zaics</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Li �sterman</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ar Salmi��</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=bl>Ro Iga</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�r Zaics</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Li �sterman</td><td class=bc>-</td><td class=blW>Ka Pirumshoeva</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Ar Salmi��</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Ro Iga</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�r Zaics</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Li �sterman</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ro Iga</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�r Zaics</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Li �sterman</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ro Iga</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Mark �bele</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Ka Pirumshoeva</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�r Zaics</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ro Iga</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�r Zaics</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Li �sterman</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ro Iga</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Ka Pirumshoeva</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Ar Salmi��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Li �sterman</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�r Zaics</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Ka Pirumshoeva</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Iga</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mark �bele</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Li �sterman</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ro Iga</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Ar Salmi��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=blW>Li �sterman</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>�r Zaics</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Ka Pirumshoeva</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ro Iga</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Li �sterman</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>�r Zaics</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Li �sterman</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ro Iga</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>�r Zaics</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Ar Salmi��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Li �sterman</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ro Iga</td><td class=bc>-</td><td class=bl>�r Zaics</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mark �bele</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Ar Salmi��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Li �sterman</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>�r Zaics</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ro Iga</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ar Salmi��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Li �sterman</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>�r Zaics</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Iga</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>Mark �bele</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ar Salmi��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Li �sterman</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=bl>�r Zaics</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Mark �bele</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ro Iga</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Ar Salmi��</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Li �sterman</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ka Pirumshoeva</td><td class=bc>-</td><td class=bl>�r Zaics</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Mark �bele</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Li �sterman</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>�r Zaics</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Mark �bele</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Ro Iga</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Li �sterman</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ar Salmi��</td><td class=bc>-</td><td class=bl>�r Zaics</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Mark �bele</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Ro Iga</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Li �sterman</td><td class=bc>-</td><td class=bl>�r Zaics</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ar Salmi��</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Mark �bele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Ro Iga</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>�r Zaics</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Li �sterman</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ar Salmi��</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Mark �bele</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Ro Iga</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Po Kvasnikova</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>5 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group Div 3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>97.</td><td class=kt>J� Bitmanis</td><td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=br>40:18</td><td class=br>+22</td>
<td class=bc>10 - 3 - 2</td>
<td class=br><strong>23</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>98.</td><td class=kt>Al Pimenovs</td><td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=br>45:28</td><td class=br>+17</td>
<td class=bc>9 - 3 - 3</td>
<td class=br><strong>21</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>99.</td><td class=kt>Bi Karlsson</td><td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=br>42:23</td><td class=br>+19</td>
<td class=bc>9 - 3 - 3</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>100.</td><td class=kt>Ra Martu��ns</td><td class=kT>0:0</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>0:7</td>
<td class=kW>4:0</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=br>37:32</td><td class=br>+5</td>
<td class=bc>7 - 4 - 4</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>101.</td><td class=kt>Em Reinfelds</td><td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=br>39:29</td><td class=br>+10</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>102.</td><td class=kt>Da Baumanis</td><td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=br>43:38</td><td class=br>+5</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>103.</td><td class=kt>Il Pavlovskis</td><td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=br>34:28</td><td class=br>+6</td>
<td class=bc>6 - 5 - 4</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>104.</td><td class=kt>Re Stac�vi�s</td><td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=br>25:28</td><td class=br>-3</td>
<td class=bc>5 - 6 - 4</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>105.</td><td class=kt>Ri Kalni��</td><td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=k>&nbsp;</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=br>25:26</td><td class=br>-1</td>
<td class=bc>5 - 5 - 4</td>
<td class=br><strong>15</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>106.</td><td class=kt>Ni Sviklis</td><td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>7:0</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=br>46:41</td><td class=br>+5</td>
<td class=bc>5 - 5 - 5</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>107.</td><td class=kt>Hy Nechutny</td><td class=kT>0:0</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=k>&nbsp;</td>
<td class=kW>1:0</td>
<td class=br>20:22</td><td class=br>-2</td>
<td class=bc>5 - 4 - 5</td>
<td class=br><strong>14</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>108.</td><td class=kt>Gi Remeika</td><td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=k>&nbsp;</td>
<td class=kW>6:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=br>35:29</td><td class=br>+6</td>
<td class=bc>6 - 2 - 6</td>
<td class=br><strong>14</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>109.</td><td class=kt>Mi Margolis</td><td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=br>34:40</td><td class=br>-6</td>
<td class=bc>4 - 3 - 8</td>
<td class=br><strong>11</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>110.</td><td class=kt>Ro Purmalis</td><td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>10:5</td>
<td class=br>31:53</td><td class=br>-22</td>
<td class=bc>2 - 2 - 11</td>
<td class=br><strong>6</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>111.</td><td class=kt>Ja Hansson</td><td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=k>&nbsp;</td>
<td class=kW>3:2</td>
<td class=kL>0:6</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=br>19:47</td><td class=br>-28</td>
<td class=bc>2 - 1 - 11</td>
<td class=br><strong>5</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>112.</td><td class=kt>Zi �mits</td><td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>5:10</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=br>20:53</td><td class=br>-33</td>
<td class=bc>1 - 2 - 12</td>
<td class=br><strong>4</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Bi Karlsson</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ri Kalni��</td><td class=bc>-</td><td class=bl>Zi �mits</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=blW>Al Pimenovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Bi Karlsson</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Gi Remeika</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Zi �mits</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ri Kalni��</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Bi Karlsson</td><td class=bc>-</td><td class=bl>Zi �mits</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Al Pimenovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ri Kalni��</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=blW>Gi Remeika</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Zi �mits</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Bi Karlsson</td><td class=bc>-</td><td class=blW>Al Pimenovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Hy Nechutny</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Il Pavlovskis</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Em Reinfelds</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Gi Remeika</td><td class=bc>-</td><td class=bl>Zi �mits</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Bi Karlsson</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Em Reinfelds</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Zi �mits</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>5 : 10</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Al Pimenovs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Bi Karlsson</td><td class=bc>-</td><td class=blW>Em Reinfelds</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ri Kalni��</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Al Pimenovs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Zi �mits</td><td class=bc>-</td><td class=blW>Hy Nechutny</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Ja Hansson</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>Em Reinfelds</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Bi Karlsson</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Margolis</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Al Pimenovs</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Ja Hansson</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zi �mits</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Gi Remeika</td><td class=bc>-</td><td class=bl>Em Reinfelds</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Bi Karlsson</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Hy Nechutny</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Em Reinfelds</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Zi �mits</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Hy Nechutny</td><td class=bc>-</td><td class=bl>Em Reinfelds</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Zi �mits</td><td class=bc>-</td><td class=blW>Il Pavlovskis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Gi Remeika</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Bi Karlsson</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Em Reinfelds</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Hy Nechutny</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Al Pimenovs</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Zi �mits</td><td class=bc>-</td><td class=blW>Mi Margolis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Bi Karlsson</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ri Kalni��</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Il Pavlovskis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Hy Nechutny</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Bi Karlsson</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Zi �mits</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Ri Kalni��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Em Reinfelds</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Mi Margolis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Hy Nechutny</td><td class=bc>-</td><td class=blW>Bi Karlsson</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zi �mits</td><td class=bc>-</td><td class=blW>Ra Martu��ns</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Em Reinfelds</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Bi Karlsson</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Hy Nechutny</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Gi Remeika</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=blW>Mi Margolis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Bi Karlsson</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Ra Martu��ns</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Hy Nechutny</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Al Pimenovs</td><td class=bc>-</td><td class=bl>Zi �mits</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Bi Karlsson</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Em Reinfelds</td><td class=bc>-</td><td class=blW>Ra Martu��ns</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Zi �mits</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Hy Nechutny</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Bi Karlsson</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ri Kalni��</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Em Reinfelds</td><td class=bc>-</td><td class=bl>Zi �mits</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Al Pimenovs</td><td class=bc>2 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group Div 4</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>113.</td><td class=kt>Dm Stykailo</td><td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kL>4:5</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>10:0</td>
<td class=br>65:24</td><td class=br>+41</td>
<td class=bc>13 - 1 - 1</td>
<td class=br><strong>27</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>114.</td><td class=kt>Do Zupancic</td><td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>9:1</td>
<td class=kW>3:0</td>
<td class=kW>10:0</td>
<td class=br>54:19</td><td class=br>+35</td>
<td class=bc>13 - 0 - 2</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>115.</td><td class=kt>Vo Kvasnikov</td><td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>6:5</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>7:3</td>
<td class=kW>5:1</td>
<td class=kW>10:0</td>
<td class=br>66:35</td><td class=br>+31</td>
<td class=bc>10 - 2 - 3</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>116.</td><td class=kt>To Jakseboga</td><td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>5:6</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>6:4</td>
<td class=kL>2:6</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>10:0</td>
<td class=br>52:32</td><td class=br>+20</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>117.</td><td class=kt>�i Vazoli��</td><td class=kW>5:4</td>
<td class=kL>0:2</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kL>0:2</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>10:0</td>
<td class=br>51:33</td><td class=br>+18</td>
<td class=bc>8 - 3 - 4</td>
<td class=br><strong>19</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>118.</td><td class=kt>Iv �irsis</td><td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=kW>10:0</td>
<td class=br>56:32</td><td class=br>+24</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>119.</td><td class=kt>Ju Steisunas</td><td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>10:0</td>
<td class=br>41:35</td><td class=br>+6</td>
<td class=bc>7 - 3 - 5</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>120.</td><td class=kt>Il �irse</td><td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>8:3</td>
<td class=kW>10:0</td>
<td class=br>43:32</td><td class=br>+11</td>
<td class=bc>4 - 7 - 4</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>121.</td><td class=kt>Mi Myren</td><td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kL>4:6</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kW>10:0</td>
<td class=br>43:36</td><td class=br>+7</td>
<td class=bc>7 - 1 - 7</td>
<td class=br><strong>15</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>122.</td><td class=kt>Ja Janouskovec</td><td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kL>3:7</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kL>3:4</td>
<td class=kW>10:0</td>
<td class=br>49:35</td><td class=br>+14</td>
<td class=bc>5 - 3 - 7</td>
<td class=br><strong>13</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>123.</td><td class=kt>Ro Aseri��</td><td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=kW>10:0</td>
<td class=br>33:32</td><td class=br>+1</td>
<td class=bc>5 - 3 - 7</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>124.</td><td class=kt>J� Zem�ickis</td><td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>10:0</td>
<td class=br>34:34</td><td class=br>0</td>
<td class=bc>4 - 3 - 8</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>125.</td><td class=kt>To Ulis</td><td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>4:0</td>
<td class=kW>10:0</td>
<td class=br>35:48</td><td class=br>-13</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>126.</td><td class=kt>D� Vesele</td><td class=kL>0:4</td>
<td class=kL>1:9</td>
<td class=kL>3:7</td>
<td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>1:7</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>10:0</td>
<td class=br>33:58</td><td class=br>-25</td>
<td class=bc>3 - 2 - 10</td>
<td class=br><strong>8</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>127.</td><td class=kt>Kr G�tmanis</td><td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>3:8</td>
<td class=kL>0:1</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>10:0</td>
<td class=br>27:47</td><td class=br>-20</td>
<td class=bc>2 - 2 - 11</td>
<td class=br><strong>6</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>128.</td><td class=kt>Ar Tseluiko</td><td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kx>*</td>
<td class=br>0:150</td><td class=br>-150</td>
<td class=bc>0 - 0 - 15</td>
<td class=br><strong>0</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Dm Stykailo</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Ja Janouskovec</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Do Zupancic</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>Ju Steisunas</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Dm Stykailo</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Ja Janouskovec</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Ju Steisunas</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Do Zupancic</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>10 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Dm Stykailo</td><td class=bc>-</td><td class=bl>Ja Janouskovec</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Ju Steisunas</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Do Zupancic</td><td class=bc>-</td><td class=bl>Mi Myren</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Kr G�tmanis</td><td class=bc>-</td><td class=bl>Ja Janouskovec</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Dm Stykailo</td><td class=bc>-</td><td class=bl>Ju Steisunas</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Mi Myren</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>6 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>Ja Janouskovec</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=blW>Ju Steisunas</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Dm Stykailo</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>Mi Myren</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Do Zupancic</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ja Janouskovec</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Ju Steisunas</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kr G�tmanis</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Mi Myren</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Dm Stykailo</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Do Zupancic</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=blW>Ju Steisunas</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Janouskovec</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Mi Myren</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Do Zupancic</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Dm Stykailo</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ju Steisunas</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>To Ulis</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Ja Janouskovec</td><td class=bc>-</td><td class=blW>Mi Myren</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Do Zupancic</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=blW>Vo Kvasnikov</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Dm Stykailo</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>�i Vazoli��</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Ju Steisunas</td><td class=bc>-</td><td class=bl>Mi Myren</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Janouskovec</td><td class=bc>-</td><td class=blW>Do Zupancic</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>Vo Kvasnikov</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Mi Myren</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ju Steisunas</td><td class=bc>-</td><td class=blW>Do Zupancic</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=blW>Vo Kvasnikov</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ja Janouskovec</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr G�tmanis</td><td class=bc>-</td><td class=blW>Dm Stykailo</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Do Zupancic</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>�i Vazoli��</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ju Steisunas</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>To Ulis</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ja Janouskovec</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>Dm Stykailo</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Do Zupancic</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>Vo Kvasnikov</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>�i Vazoli��</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ju Steisunas</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=blW>Dm Stykailo</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ja Janouskovec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Do Zupancic</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Myren</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>�i Vazoli��</td><td class=bc>-</td><td class=bl>Dm Stykailo</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ju Steisunas</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>To Ulis</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ja Janouskovec</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Do Zupancic</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>Dm Stykailo</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ju Steisunas</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Do Zupancic</td><td class=bc>-</td><td class=blW>Dm Stykailo</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Mi Myren</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>�i Vazoli��</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ju Steisunas</td><td class=bc>-</td><td class=bl>Ja Janouskovec</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Dm Stykailo</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Do Zupancic</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Myren</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Ja Janouskovec</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>To Ulis</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Dm Stykailo</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Kr G�tmanis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Do Zupancic</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Ja Janouskovec</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Mi Myren</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Ju Steisunas</td><td class=bc>0 : 10</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
