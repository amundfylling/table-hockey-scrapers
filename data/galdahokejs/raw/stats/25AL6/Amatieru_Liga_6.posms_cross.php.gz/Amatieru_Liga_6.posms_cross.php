<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Amatieru Liga 6.posms</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../25AL6/Amatieru_Liga_6.posms_index.php">Amatieru Liga 6.posms, 3. May 2025</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group AL A grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>D� Vesele</td><td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=br>51:14</td><td class=br>+37</td>
<td class=bc>12 - 1 - 1</td>
<td class=br><strong>25</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ma Kalni��</td><td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kT>0:0</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kL>0:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=br>34:14</td><td class=br>+20</td>
<td class=bc>10 - 1 - 3</td>
<td class=br><strong>21</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ge Jansons</td><td class=kL>0:2</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kL>0:3</td>
<td class=br>35:19</td><td class=br>+16</td>
<td class=bc>8 - 3 - 3</td>
<td class=br><strong>19</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ag Pav�rs</td><td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=br>33:19</td><td class=br>+14</td>
<td class=bc>9 - 1 - 4</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Al Liepi��</td><td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=br>33:21</td><td class=br>+12</td>
<td class=bc>8 - 2 - 4</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ed Jansons</td><td class=kL>0:5</td>
<td class=kT>0:0</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=br>31:26</td><td class=br>+5</td>
<td class=bc>7 - 4 - 3</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>M� Timbers</td><td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>2:5</td>
<td class=kW>9:1</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kL>2:6</td>
<td class=br>39:30</td><td class=br>+9</td>
<td class=bc>7 - 0 - 7</td>
<td class=br><strong>14</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>T� Gor�anova</td><td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=br>26:34</td><td class=br>-8</td>
<td class=bc>7 - 0 - 7</td>
<td class=br><strong>14</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>�r Egl�tis</td><td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>23:27</td><td class=br>-4</td>
<td class=bc>6 - 1 - 7</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Al Sili��</td><td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kW>1:0</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=kL>1:9</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=kx>*</td>
<td class=kL>1:7</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=br>28:38</td><td class=br>-10</td>
<td class=bc>5 - 2 - 7</td>
<td class=br><strong>12</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Kr S�manis</td><td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>7:1</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kW>6:0</td>
<td class=br>31:42</td><td class=br>-11</td>
<td class=bc>3 - 2 - 9</td>
<td class=br><strong>8</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Da Vai�iul�ns</td><td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>0:1</td>
<td class=kW>1:0</td>
<td class=br>24:35</td><td class=br>-11</td>
<td class=bc>3 - 2 - 9</td>
<td class=br><strong>8</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Em Ka�s</td><td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>4:1</td>
<td class=br>23:40</td><td class=br>-17</td>
<td class=bc>3 - 1 - 10</td>
<td class=br><strong>7</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt>Ol Ozoli��-Karlsons</td><td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>14:41</td><td class=br>-27</td>
<td class=bc>2 - 3 - 9</td>
<td class=br><strong>7</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Ro Garda</td><td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kW>3:0</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kW>6:2</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>19:44</td><td class=br>-25</td>
<td class=bc>3 - 1 - 10</td>
<td class=br><strong>7</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Vai�iul�ns Daniels</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Timbers M�rti��</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Jansons Edvards</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Sili�� Alberts</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Ozoli��-Karlsons Olafs</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>S�manis Kri�j�nis</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Gor�anova T�na</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Jansons Edvards</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Ozoli��-Karlsons Olafs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>Timbers M�rti��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Sili�� Alberts</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Gor�anova T�na</td><td class=bc>-</td><td class=bl>Ozoli��-Karlsons Olafs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jansons Edvards</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Timbers M�rti��</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Ozoli��-Karlsons Olafs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Garda Roberts</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Gor�anova T�na</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Jansons Edvards</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>Ozoli��-Karlsons Olafs</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Ozoli��-Karlsons Olafs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Jansons Edvards</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Ozoli��-Karlsons Olafs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Jansons Edvards</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Gor�anova T�na</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Jansons Edvards</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Jansons Edvards</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=blW>Gor�anova T�na</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Garda Roberts</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=blW>Jansons Edvards</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Jansons Edvards</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=bl>Jansons Edvards</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Timbers M�rti��</td><td class=bc>1 : 9</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Jansons Edvards</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Garda Roberts</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=blW>Timbers M�rti��</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Gor�anova T�na</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Jansons Edvards</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Timbers M�rti��</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=blW>Sili�� Alberts</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Gor�anova T�na</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Jansons Edvards</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Sili�� Alberts</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>1 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group AL B grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>M� �irsis</td><td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Gu Skapsts</td><td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>An Kova��uks</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Da Belkovs</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>As Kocere</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>El Reinfelds</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Li Glanders</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Br Gor�anovs</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Fi Esta</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>D� Vai�iul�ns</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Kr Rudz�tis</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Ed Liepi��</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Ma Krauze</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt>Re Masulis</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Esta Filips</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Glanders Linards</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>Masulis Ren�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=bl>Liepi�� Edgars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Esta Filips</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Glanders Linards</td><td class=bc>-</td><td class=bl>Masulis Ren�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Liepi�� Edgars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Masulis Ren�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Esta Filips</td><td class=bc>-</td><td class=bl>Liepi�� Edgars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Glanders Linards</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Masulis Ren�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>Liepi�� Edgars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Esta Filips</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Glanders Linards</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Masulis Ren�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Liepi�� Edgars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Esta Filips</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Glanders Linards</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=bl>Liepi�� Edgars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Esta Filips</td><td class=bc>-</td><td class=bl>Glanders Linards</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>Glanders Linards</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Esta Filips</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Glanders Linards</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Esta Filips</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>Glanders Linards</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=bl>Esta Filips</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Glanders Linards</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Esta Filips</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>Glanders Linards</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=bl>Esta Filips</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Esta Filips</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Glanders Linards</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Masulis Ren�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Esta Filips</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Glanders Linards</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=bl>Masulis Ren�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Liepi�� Edgars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group AL Liga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/8</td><td class=d>1.</td><td class=kt>As Kocere</td><td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=br>37:19</td><td class=br>+18</td>
<td class=bc>9 - 1 - 2</td>
<td class=br><strong>19</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/8</td><td class=d>2.</td><td class=kt>�r Egl�tis</td><td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=br>33:20</td><td class=br>+13</td>
<td class=bc>8 - 2 - 2</td>
<td class=br><strong>18</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/8</td><td class=d>3.</td><td class=kt>Al Sili��</td><td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=br>28:16</td><td class=br>+12</td>
<td class=bc>7 - 3 - 2</td>
<td class=br><strong>17</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/8</td><td class=d>4.</td><td class=kt>Ro Garda</td><td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=br>31:24</td><td class=br>+7</td>
<td class=bc>7 - 2 - 3</td>
<td class=br><strong>16</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/8</td><td class=d>5.</td><td class=kt>Kr S�manis</td><td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=br>30:25</td><td class=br>+5</td>
<td class=bc>7 - 2 - 3</td>
<td class=br><strong>16</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/8</td><td class=d>6.</td><td class=kt>Ed Liepi��</td><td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=br>28:17</td><td class=br>+11</td>
<td class=bc>5 - 4 - 3</td>
<td class=br><strong>14</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/8</td><td class=d>7.</td><td class=kt>Ol Ozoli��-Karlsons</td><td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=br>30:27</td><td class=br>+3</td>
<td class=bc>5 - 3 - 4</td>
<td class=br><strong>13</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/8</td><td class=d>8.</td><td class=kt>Da Vai�iul�ns</td><td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=br>32:22</td><td class=br>+10</td>
<td class=bc>4 - 4 - 4</td>
<td class=br><strong>12</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/8</td><td class=d>9.</td><td class=kt>Kr Rudz�tis</td><td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=br>16:19</td><td class=br>-3</td>
<td class=bc>5 - 2 - 5</td>
<td class=br><strong>12</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/8</td><td class=d>10.</td><td class=kt>Em Ka�s</td><td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>11:0</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=br>31:29</td><td class=br>+2</td>
<td class=bc>4 - 2 - 6</td>
<td class=br><strong>10</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/8</td><td class=d>11.</td><td class=kt>Li Glanders</td><td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kL>2:6</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>0:11</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=br>15:45</td><td class=br>-30</td>
<td class=bc>2 - 1 - 9</td>
<td class=br><strong>5</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/8</td><td class=d>12.</td><td class=kt>Re Masulis</td><td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=br>7:27</td><td class=br>-20</td>
<td class=bc>1 - 1 - 10</td>
<td class=br><strong>3</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/8</td><td class=d>13.</td><td class=kt>Fi Esta</td><td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>0:7</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=br>7:35</td><td class=br>-28</td>
<td class=bc>0 - 1 - 11</td>
<td class=br><strong>1</strong></td><td class=d>13.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Esta Filips</td><td class=bc>-</td><td class=blW>Masulis Ren�rs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Ozoli��-Karlsons Olafs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Glanders Linards</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Liepi�� Edgars</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Garda Roberts</td><td class=bc>-</td><td class=bl>Masulis Ren�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Ozoli��-Karlsons Olafs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Esta Filips</td><td class=bc>-</td><td class=bl>Glanders Linards</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Liepi�� Edgars</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=bl>Ozoli��-Karlsons Olafs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Glanders Linards</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Esta Filips</td><td class=bc>-</td><td class=blW>Liepi�� Edgars</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=bl>Glanders Linards</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=bl>Liepi�� Edgars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Vai�iul�ns Daniels</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Esta Filips</td><td class=bc>-</td><td class=blW>Rudz�tis Kristaps</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Glanders Linards</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>0 : 11</tr></td>
<tr><td class=brW>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=bl>Liepi�� Edgars</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=blW>Vai�iul�ns Daniels</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>S�manis Kri�j�nis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Esta Filips</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Liepi�� Edgars</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Glanders Linards</td><td class=bc>-</td><td class=blW>Vai�iul�ns Daniels</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=blW>Rudz�tis Kristaps</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=blW>S�manis Kri�j�nis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Garda Roberts</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Rudz�tis Kristaps</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Glanders Linards</td><td class=bc>-</td><td class=blW>S�manis Kri�j�nis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=blW>Sili�� Alberts</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Garda Roberts</td><td class=bc>-</td><td class=bl>Esta Filips</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=blW>S�manis Kri�j�nis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Glanders Linards</td><td class=bc>-</td><td class=blW>Sili�� Alberts</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=bl>Esta Filips</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Masulis Ren�rs</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>S�manis Kri�j�nis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Esta Filips</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Glanders Linards</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ozoli��-Karlsons Olafs</td><td class=bc>-</td><td class=blW>Garda Roberts</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Sili�� Alberts</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Esta Filips</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Garda Roberts</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Glanders Linards</td><td class=bc>-</td><td class=bl>Masulis Ren�rs</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Esta Filips</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>Garda Roberts</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>Masulis Ren�rs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Ozoli��-Karlsons Olafs</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Esta Filips</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=blW>Garda Roberts</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Masulis Ren�rs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Ozoli��-Karlsons Olafs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>Glanders Linards</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Esta Filips</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Masulis Ren�rs</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Ozoli��-Karlsons Olafs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Glanders Linards</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>3 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
