<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Latvijas Kauss 2.posms</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../23LK2/Latvijas_Kauss_2.posms_index.php">Latvijas Kauss 2.posms - play-off </a></span></h2></div></div></div></div><p><div align="center">
<table border=0 cellpadding=2 cellspacing=0>
<tr><th colspan=11 class="hh"><font size="+1"><strong>Finals</strong></font></th></tr>
<tr><td class=br><b>Miglinieks Raivis</b>&nbsp;&nbsp;</td>
<td class=bl>- Kalnin� Rainers&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:4&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>2:1 P&nbsp;&nbsp;</td>
<td class=bl>2:1&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>1/2</strong></font></th></tr>
<tr><td class=ar><b>Miglinieks Raivis</b>&nbsp;&nbsp;</td>
<td class=al>- Ziemelis Didzis&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>4:0&nbsp;&nbsp;</td>
<td class=al>0:3&nbsp;&nbsp;</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>5:1&nbsp;&nbsp;</td>
<td class=al>2:4&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br>Lagzdin� Sandis Kristaps&nbsp;&nbsp;</td>
<td class=bl><b>- Kalnin� Rainers</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 4&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>6:5 P&nbsp;&nbsp;</td>
<td class=bl>7:3&nbsp;&nbsp;</td>
<td class=bl>1:7&nbsp;&nbsp;</td>
<td class=bl>3:5&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>1:4&nbsp;&nbsp;</td>
<td class=bl>2:4&nbsp;&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>3rd</strong></font></th></tr>
<tr><td class=ar>Ziemelis Didzis&nbsp;&nbsp;</td>
<td class=al><b>- Lagzdin� Sandis Kristaps</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>1:4&nbsp;&nbsp;</td>
<td class=al>1:7&nbsp;&nbsp;</td>
<td class=al>1:5&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>1/4</strong></font></th></tr>
<tr><td class=br><b>Miglinieks Raivis</b>&nbsp;&nbsp;</td>
<td class=bl>- Vazolin� Regnars&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>2:1&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>8:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Ziemelis Didzis</b>&nbsp;&nbsp;</td>
<td class=al>- Silin� Elvijs&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>5:1&nbsp;&nbsp;</td>
<td class=al>0:2&nbsp;&nbsp;</td>
<td class=al>1:4&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>0:5&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
</tr><tr><td class=br>Riekstin� Rolands&nbsp;&nbsp;</td>
<td class=bl><b>- Lagzdin� Sandis Kristaps</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 4&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:3 P&nbsp;&nbsp;</td>
<td class=bl>6:1&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>3:4&nbsp;&nbsp;</td>
<td class=bl>1:3&nbsp;&nbsp;</td>
<td class=bl>1:4&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar>Kamzols Rudolfs&nbsp;&nbsp;</td>
<td class=al><b>- Kalnin� Rainers</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;0 : 4&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>4:8&nbsp;&nbsp;</td>
<td class=al>0:5&nbsp;&nbsp;</td>
<td class=al>8:9 P&nbsp;&nbsp;</td>
<td class=al>2:5&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>1/8</strong></font></th></tr>
<tr><td class=br>Miglinieks Raivis (1)&nbsp;&nbsp;</td>
<td class=bl>- -&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar>Lagzdina Krista Annija (8)&nbsp;&nbsp;</td>
<td class=al><b>- Vazolin� Regnars (9)</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;1 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>1:5&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>1:4&nbsp;&nbsp;</td>
<td class=al>1:5&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br>Silin� Alvis (5)&nbsp;&nbsp;</td>
<td class=bl><b>- Ziemelis Didzis (12)</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:4 P&nbsp;&nbsp;</td>
<td class=bl>4:6&nbsp;&nbsp;</td>
<td class=bl>3:4&nbsp;&nbsp;</td>
<td class=bl>3:0&nbsp;&nbsp;</td>
<td class=bl>3:5&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar>Silin� Elvijs (4)&nbsp;&nbsp;</td>
<td class=al>- -&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br>Riekstin� Rolands (3)&nbsp;&nbsp;</td>
<td class=bl>- -&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Lagzdin� Sandis Kristaps (6)</b>&nbsp;&nbsp;</td>
<td class=al>- Riekstin� Kristaps (11)&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:1&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>5:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Kamzols Rudolfs (7)</b>&nbsp;&nbsp;</td>
<td class=bl>- Smagars Valts (10)&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 2&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>3:6&nbsp;&nbsp;</td>
<td class=bl>10:2&nbsp;&nbsp;</td>
<td class=bl>4:5 P&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar>Kalnin� Rainers (2)&nbsp;&nbsp;</td>
<td class=al>- -&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>1.liga / 2.liga Finals</strong></font></th></tr>
<tr><td class=br>Naglis Edgars&nbsp;&nbsp;</td>
<td class=bl><b>- Kaneps Ed�us</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>5:1&nbsp;&nbsp;</td>
<td class=bl>3:5&nbsp;&nbsp;</td>
<td class=bl>4:5 P&nbsp;&nbsp;</td>
<td class=bl>3:6&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>1.liga / 2.liga 1/2</strong></font></th></tr>
<tr><td class=ar>Radelis Marcis&nbsp;&nbsp;</td>
<td class=al><b>- Naglis Edgars</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>1:3&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>1:3&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Kaneps Ed�us</b>&nbsp;&nbsp;</td>
<td class=bl>- Neija Rainers&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:4&nbsp;&nbsp;</td>
<td class=bl>10:2&nbsp;&nbsp;</td>
<td class=bl>1:0&nbsp;&nbsp;</td>
<td class=bl>3:0&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>1.liga / 2.liga 3rd - NOT PLAYED</strong></font></th></tr>
<tr><td class=ar>Neija Rainers&nbsp;&nbsp;</td>
<td class=al>- Radelis Marcis&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>1.liga / 2.liga 1/4</strong></font></th></tr>
<tr><td class=br><b>Radelis Marcis (21)</b>&nbsp;&nbsp;</td>
<td class=bl>- Putnin� Edgars (4)&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>6:4&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Kaneps Ed�us (23)</b>&nbsp;&nbsp;</td>
<td class=al>- Apfelbaums Davis (2)&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:0&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>5:0&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br>Verbics Roberts (22)&nbsp;&nbsp;</td>
<td class=bl><b>- Neija Rainers (3)</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;1 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>0:2&nbsp;&nbsp;</td>
<td class=bl>1:5&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar>Vilums Kaspars (24)&nbsp;&nbsp;</td>
<td class=al><b>- Naglis Edgars (1)</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>1:3&nbsp;&nbsp;</td>
<td class=al>3:5&nbsp;&nbsp;</td>
<td class=al>3:5&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>2.liga / 3.liga Finals</strong></font></th></tr>
<tr><td class=br>Kerns Roberts&nbsp;&nbsp;</td>
<td class=bl><b>- Zasurcevs Arturs</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>0:5&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>2:8&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>2.liga / 3.liga 1/2</strong></font></th></tr>
<tr><td class=ar>Zemnickis Kri�janis&nbsp;&nbsp;</td>
<td class=al><b>- Kerns Roberts</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;1 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:5&nbsp;&nbsp;</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>4:5&nbsp;&nbsp;</td>
<td class=al>0:4&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Zasurcevs Arturs</b>&nbsp;&nbsp;</td>
<td class=bl>- Salmin� Arnis&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 2&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>3:4&nbsp;&nbsp;</td>
<td class=bl>2:1&nbsp;&nbsp;</td>
<td class=bl>3:0&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>2.liga / 3.liga 3rd - NOT PLAYED</strong></font></th></tr>
<tr><td class=ar>Salmin� Arnis&nbsp;&nbsp;</td>
<td class=al>- Zemnickis Kri�janis&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>2.liga / 3.liga 1/4</strong></font></th></tr>
<tr><td class=br>Lihacova Katrina (18)&nbsp;&nbsp;</td>
<td class=bl><b>- Zemnickis Kri�janis (4)</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>1:3&nbsp;&nbsp;</td>
<td class=bl>0:2&nbsp;&nbsp;</td>
<td class=bl>0:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar>Strods Patriks (20)&nbsp;&nbsp;</td>
<td class=al><b>- Zasurcevs Arturs (2)</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>0:10&nbsp;&nbsp;</td>
<td class=al>0:10&nbsp;&nbsp;</td>
<td class=al>0:10&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Salmin� Arnis (19)</b>&nbsp;&nbsp;</td>
<td class=bl>- Martu�ans Rainers (3)&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 2&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:1&nbsp;&nbsp;</td>
<td class=bl>1:2 P&nbsp;&nbsp;</td>
<td class=bl>0:4&nbsp;&nbsp;</td>
<td class=bl>7:4&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar>Gals Haralds (21)&nbsp;&nbsp;</td>
<td class=al><b>- Kerns Roberts (1)</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>0:10&nbsp;&nbsp;</td>
<td class=al>0:10&nbsp;&nbsp;</td>
<td class=al>0:10&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
