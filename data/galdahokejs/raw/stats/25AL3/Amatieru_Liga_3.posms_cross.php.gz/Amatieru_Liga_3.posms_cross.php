<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Amatieru Liga 3.posms</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../25AL3/Amatieru_Liga_3.posms_index.php">Amatieru Liga 3.posms, 11. January 2025</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group AL A grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>As Kocere</td><td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>7:3</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>10:1</td>
<td class=kW>7:1</td>
<td class=br>66:24</td><td class=br>+42</td>
<td class=bc>12 - 1 - 1</td>
<td class=br><strong>25</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ra St�lmanis</td><td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=br>41:20</td><td class=br>+21</td>
<td class=bc>10 - 2 - 2</td>
<td class=br><strong>22</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Al Sili��</td><td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kT>0:0</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=br>34:24</td><td class=br>+10</td>
<td class=bc>9 - 3 - 2</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Em Ka�s</td><td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>0:0</td>
<td class=kW>8:4</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=br>41:26</td><td class=br>+15</td>
<td class=bc>7 - 5 - 2</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Re Saul�tis</td><td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=br>36:25</td><td class=br>+11</td>
<td class=bc>8 - 3 - 3</td>
<td class=br><strong>19</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ma Krauze</td><td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>8:1</td>
<td class=kW>3:2</td>
<td class=br>42:26</td><td class=br>+16</td>
<td class=bc>8 - 2 - 4</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Le Hartmanis</td><td class=kL>3:7</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=br>35:33</td><td class=br>+2</td>
<td class=bc>7 - 1 - 6</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Br Gor�anovs</td><td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=br>39:34</td><td class=br>+5</td>
<td class=bc>6 - 3 - 5</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Ar Vasks</td><td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kT>0:0</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kT>1:1</td>
<td class=br>36:28</td><td class=br>+8</td>
<td class=bc>5 - 3 - 6</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>Da Vai�iul�ns</td><td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=br>23:34</td><td class=br>-11</td>
<td class=bc>3 - 3 - 8</td>
<td class=br><strong>9</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>A</td><td class=d>11.</td><td class=kt>�r Egl�tis</td><td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kL>4:8</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=br>25:43</td><td class=br>-18</td>
<td class=bc>3 - 3 - 8</td>
<td class=br><strong>9</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ro Garda</td><td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=br>19:43</td><td class=br>-24</td>
<td class=bc>3 - 1 - 10</td>
<td class=br><strong>7</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>M� Narti�s</td><td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=br>17:36</td><td class=br>-19</td>
<td class=bc>1 - 4 - 9</td>
<td class=br><strong>6</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Kr Rudz�tis</td><td class=kL>1:10</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>1:8</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=br>20:57</td><td class=br>-37</td>
<td class=bc>3 - 0 - 11</td>
<td class=br><strong>6</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>T� Gor�anova</td><td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=br>23:44</td><td class=br>-21</td>
<td class=bc>2 - 2 - 10</td>
<td class=br><strong>6</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Garda Roberts</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Hartmanis Leonels</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Narti�s M�rcis</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Sili�� Alberts</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=blW>Rudz�tis Kristaps</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Hartmanis Leonels</td><td class=bc>-</td><td class=bl>Narti�s M�rcis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vasks Artis</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Garda Roberts</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=bl>Narti�s M�rcis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hartmanis Leonels</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>3 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Narti�s M�rcis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Narti�s M�rcis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Vasks Artis</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Gor�anova T�na</td><td class=bc>-</td><td class=bl>Hartmanis Leonels</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Narti�s M�rcis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vasks Artis</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Hartmanis Leonels</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Narti�s M�rcis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sili�� Alberts</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>Hartmanis Leonels</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vasks Artis</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Narti�s M�rcis</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Hartmanis Leonels</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Kocere Asnate</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Narti�s M�rcis</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Hartmanis Leonels</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Hartmanis Leonels</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Narti�s M�rcis</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Vasks Artis</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Hartmanis Leonels</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Narti�s M�rcis</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Vasks Artis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Hartmanis Leonels</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Narti�s M�rcis</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Vai�iul�ns Daniels</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=blW>Gor�anova T�na</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Hartmanis Leonels</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>Vasks Artis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Narti�s M�rcis</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Sili�� Alberts</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Garda Roberts</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Hartmanis Leonels</td><td class=bc>-</td><td class=bl>Vasks Artis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Kocere Asnate</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Sili�� Alberts</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Narti�s M�rcis</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=bl>Vasks Artis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Hartmanis Leonels</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>8 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group AL B grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ag Pav�rs</td><td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>8:1</td>
<td class=kW>9:0</td>
<td class=br>68:17</td><td class=br>+51</td>
<td class=bc>12 - 1 - 1</td>
<td class=br><strong>25</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>El Reinfelds</td><td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>6:4</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>2:0</td>
<td class=kW>7:0</td>
<td class=kW>7:3</td>
<td class=kW>8:0</td>
<td class=kW>10:0</td>
<td class=br>71:23</td><td class=br>+48</td>
<td class=bc>12 - 0 - 2</td>
<td class=br><strong>24</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>M� �irsis</td><td class=kL>0:2</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=br>40:13</td><td class=br>+27</td>
<td class=bc>9 - 4 - 1</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Da Belkovs</td><td class=kL>3:4</td>
<td class=kL>4:6</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>8:1</td>
<td class=kW>6:1</td>
<td class=kW>7:0</td>
<td class=br>51:29</td><td class=br>+22</td>
<td class=bc>9 - 1 - 4</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ma P�tersons</td><td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kT>0:0</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=br>48:29</td><td class=br>+19</td>
<td class=bc>9 - 1 - 4</td>
<td class=br><strong>19</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Al Liepi��</td><td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kL>0:2</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=kW>10:0</td>
<td class=kW>11:0</td>
<td class=br>56:19</td><td class=br>+37</td>
<td class=bc>8 - 2 - 4</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Er Kalni��</td><td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>8:3</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kW>8:1</td>
<td class=kW>6:0</td>
<td class=br>49:33</td><td class=br>+16</td>
<td class=bc>7 - 1 - 6</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Gu Skapsts</td><td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>10:0</td>
<td class=kW>2:0</td>
<td class=br>37:28</td><td class=br>+9</td>
<td class=bc>7 - 1 - 6</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Au Liepi��</td><td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=br>32:28</td><td class=br>+4</td>
<td class=bc>7 - 0 - 7</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>Ge Jansons</td><td class=kT>2:2</td>
<td class=kL>0:7</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>0:5</td>
<td class=kL>3:8</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=br>42:42</td><td class=br>0</td>
<td class=bc>5 - 3 - 6</td>
<td class=br><strong>13</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>A</td><td class=d>11.</td><td class=kt>Ol Sirmais</td><td class=kL>1:7</td>
<td class=kL>0:2</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>7:0</td>
<td class=kW>6:0</td>
<td class=br>32:36</td><td class=br>-4</td>
<td class=bc>5 - 1 - 8</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>J� Ustups</td><td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=br>15:54</td><td class=br>-39</td>
<td class=bc>3 - 1 - 10</td>
<td class=br><strong>7</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>�d Erenpreiss</td><td class=kL>0:7</td>
<td class=kL>3:7</td>
<td class=kL>0:3</td>
<td class=kL>1:8</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=br>15:54</td><td class=br>-39</td>
<td class=bc>3 - 0 - 11</td>
<td class=br><strong>6</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Er Kr�mi��</td><td class=kL>1:8</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>0:7</td>
<td class=kL>0:10</td>
<td class=kL>1:8</td>
<td class=kL>0:10</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=br>4:81</td><td class=br>-77</td>
<td class=bc>1 - 0 - 13</td>
<td class=br><strong>2</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Ki Baranovs</td><td class=kL>0:9</td>
<td class=kL>0:10</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>0:11</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=br>3:77</td><td class=br>-74</td>
<td class=bc>0 - 0 - 14</td>
<td class=br><strong>0</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Baranovs Kirils</td><td class=bc>-</td><td class=blW>Ustups J�kabs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=blW>Skapsts Gustavs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Erenpreiss �dams</td><td class=bc>-</td><td class=blW>Sirmais Olivers</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>P�tersons Marks</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kr�mi�� Ernests</td><td class=bc>-</td><td class=blW>Liepi�� Augusts</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ustups J�kabs</td><td class=bc>-</td><td class=blW>Skapsts Gustavs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Baranovs Kirils</td><td class=bc>-</td><td class=blW>Sirmais Olivers</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Erenpreiss �dams</td><td class=bc>-</td><td class=blW>P�tersons Marks</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Liepi�� Augusts</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Sirmais Olivers</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ustups J�kabs</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Baranovs Kirils</td><td class=bc>-</td><td class=blW>P�tersons Marks</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Erenpreiss �dams</td><td class=bc>-</td><td class=blW>Liepi�� Augusts</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Kr�mi�� Ernests</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Sirmais Olivers</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>P�tersons Marks</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ustups J�kabs</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Baranovs Kirils</td><td class=bc>-</td><td class=blW>Liepi�� Augusts</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Erenpreiss �dams</td><td class=bc>-</td><td class=bl>Kr�mi�� Ernests</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>P�tersons Marks</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Sirmais Olivers</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>Liepi�� Augusts</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ustups J�kabs</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Baranovs Kirils</td><td class=bc>-</td><td class=blW>Kr�mi�� Ernests</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Belkovs Daniels</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Erenpreiss �dams</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>P�tersons Marks</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Liepi�� Augusts</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Sirmais Olivers</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Kr�mi�� Ernests</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Ustups J�kabs</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Baranovs Kirils</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Liepi�� Augusts</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>P�tersons Marks</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Kr�mi�� Ernests</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Sirmais Olivers</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ustups J�kabs</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Baranovs Kirils</td><td class=bc>-</td><td class=blW>Erenpreiss �dams</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Liepi�� Augusts</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Kr�mi�� Ernests</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>P�tersons Marks</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Sirmais Olivers</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Erenpreiss �dams</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ustups J�kabs</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Kr�mi�� Ernests</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Liepi�� Augusts</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>P�tersons Marks</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Erenpreiss �dams</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Sirmais Olivers</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Baranovs Kirils</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Kr�mi�� Ernests</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Liepi�� Augusts</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Erenpreiss �dams</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>P�tersons Marks</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Baranovs Kirils</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Sirmais Olivers</td><td class=bc>-</td><td class=bl>Ustups J�kabs</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kr�mi�� Ernests</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Erenpreiss �dams</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Liepi�� Augusts</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Baranovs Kirils</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>P�tersons Marks</td><td class=bc>-</td><td class=bl>Ustups J�kabs</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Skapsts Gustavs</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Erenpreiss �dams</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kr�mi�� Ernests</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Baranovs Kirils</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Liepi�� Augusts</td><td class=bc>-</td><td class=bl>Ustups J�kabs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>P�tersons Marks</td><td class=bc>-</td><td class=bl>Sirmais Olivers</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Erenpreiss �dams</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Baranovs Kirils</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr�mi�� Ernests</td><td class=bc>-</td><td class=blW>Ustups J�kabs</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Liepi�� Augusts</td><td class=bc>-</td><td class=bl>Sirmais Olivers</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Erenpreiss �dams</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Baranovs Kirils</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Ustups J�kabs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr�mi�� Ernests</td><td class=bc>-</td><td class=blW>Sirmais Olivers</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Liepi�� Augusts</td><td class=bc>-</td><td class=blW>P�tersons Marks</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Baranovs Kirils</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Erenpreiss �dams</td><td class=bc>-</td><td class=blW>Ustups J�kabs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Sirmais Olivers</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr�mi�� Ernests</td><td class=bc>-</td><td class=blW>P�tersons Marks</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>1 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group AL 1.l�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/8</td><td class=d>1.</td><td class=kt>Br Gor�anovs</td><td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>4:5</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>6:4</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>7:2</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>9:1</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=kW>11:0</td>
<td class=kW>8:0</td>
<td class=kW>2:0</td>
<td class=br>92:41</td><td class=br>+51</td>
<td class=bc>16 - 2 - 2</td>
<td class=br><strong>34</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/8</td><td class=d>2.</td><td class=kt>Al Liepi��</td><td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kL>0:4</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=br>77:26</td><td class=br>+51</td>
<td class=bc>16 - 2 - 2</td>
<td class=br><strong>34</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/8</td><td class=d>3.</td><td class=kt>Ar Vasks</td><td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=br>69:27</td><td class=br>+42</td>
<td class=bc>14 - 3 - 3</td>
<td class=br><strong>31</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/8</td><td class=d>4.</td><td class=kt>Ma Krauze</td><td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>2:6</td>
<td class=kT>0:0</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=kW>10:0</td>
<td class=kW>7:0</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=br>67:24</td><td class=br>+43</td>
<td class=bc>13 - 3 - 4</td>
<td class=br><strong>29</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/8</td><td class=d>5.</td><td class=kt>Er Kalni��</td><td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=kW>8:0</td>
<td class=kW>6:0</td>
<td class=br>69:25</td><td class=br>+44</td>
<td class=bc>14 - 1 - 5</td>
<td class=br><strong>29</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/8</td><td class=d>6.</td><td class=kt>Le Hartmanis</td><td class=kL>4:6</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=br>64:43</td><td class=br>+21</td>
<td class=bc>13 - 1 - 6</td>
<td class=br><strong>27</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/8</td><td class=d>7.</td><td class=kt>Re Saul�tis</td><td class=kL>3:4</td>
<td class=kW>4:0</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>4:5</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kT>0:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kW>9:1</td>
<td class=br>58:25</td><td class=br>+33</td>
<td class=bc>12 - 3 - 5</td>
<td class=br><strong>27</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/8</td><td class=d>8.</td><td class=kt>Au Liepi��</td><td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>6:5</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=br>68:44</td><td class=br>+24</td>
<td class=bc>12 - 2 - 6</td>
<td class=br><strong>26</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/8</td><td class=d>9.</td><td class=kt>Da Vai�iul�ns</td><td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>8:1</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=br>57:40</td><td class=br>+17</td>
<td class=bc>11 - 1 - 8</td>
<td class=br><strong>23</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/8</td><td class=d>10.</td><td class=kt>Gu Skapsts</td><td class=kW>3:0</td>
<td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kL>5:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kW>7:5</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kT>0:0</td>
<td class=kW>4:1</td>
<td class=kW>10:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>62:40</td><td class=br>+22</td>
<td class=bc>10 - 3 - 7</td>
<td class=br><strong>23</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/8</td><td class=d>11.</td><td class=kt>Ol Sirmais</td><td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=br>36:28</td><td class=br>+8</td>
<td class=bc>10 - 2 - 8</td>
<td class=br><strong>22</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/8</td><td class=d>12.</td><td class=kt>M� Narti�s</td><td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=br>40:37</td><td class=br>+3</td>
<td class=bc>8 - 2 - 10</td>
<td class=br><strong>18</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/8</td><td class=d>13.</td><td class=kt>Ro Garda</td><td class=kL>1:9</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kL>0:7</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>1:8</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kL>0:7</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=br>40:67</td><td class=br>-27</td>
<td class=bc>7 - 4 - 9</td>
<td class=br><strong>18</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/8</td><td class=d>14.</td><td class=kt>Ge Jansons</td><td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kL>0:10</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kL>1:6</td>
<td class=kL>5:7</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kW>7:0</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>7:0</td>
<td class=kW>11:1</td>
<td class=kT>1:1</td>
<td class=br>61:61</td><td class=br>0</td>
<td class=bc>7 - 3 - 10</td>
<td class=br><strong>17</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/8</td><td class=d>15.</td><td class=kt>Kr Rudz�tis</td><td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kT>0:0</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>2:0</td>
<td class=kL>0:4</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=br>37:58</td><td class=br>-21</td>
<td class=bc>7 - 2 - 11</td>
<td class=br><strong>16</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/8</td><td class=d>16.</td><td class=kt>�d Erenpreiss</td><td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kW>6:2</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=br>31:57</td><td class=br>-26</td>
<td class=bc>7 - 0 - 13</td>
<td class=br><strong>14</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>�r Egl�tis</td><td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kT>0:0</td>
<td class=kW>1:0</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>10:0</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=br>39:48</td><td class=br>-9</td>
<td class=bc>6 - 2 - 12</td>
<td class=br><strong>14</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>T� Gor�anova</td><td class=kL>3:6</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=br>28:69</td><td class=br>-41</td>
<td class=bc>4 - 0 - 16</td>
<td class=br><strong>8</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Er Kr�mi��</td><td class=kL>0:11</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>0:4</td>
<td class=kL>0:10</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kL>0:10</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=br>6:107</td><td class=br>-101</td>
<td class=bc>2 - 1 - 17</td>
<td class=br><strong>5</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>J� Ustups</td><td class=kL>0:8</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>0:8</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>1:11</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=br>19:90</td><td class=br>-71</td>
<td class=bc>1 - 1 - 18</td>
<td class=br><strong>3</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Ki Baranovs</td><td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>1:9</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=br>9:72</td><td class=br>-63</td>
<td class=bc>0 - 2 - 18</td>
<td class=br><strong>2</strong></td><td class=d>21.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Kr�mi�� Ernests</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Baranovs Kirils</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Sirmais Olivers</td><td class=bc>-</td><td class=bl>Erenpreiss �dams</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Hartmanis Leonels</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Narti�s M�rcis</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ustups J�kabs</td><td class=bc>-</td><td class=blW>Liepi�� Augusts</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Liepi�� Alans</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr�mi�� Ernests</td><td class=bc>-</td><td class=blW>Erenpreiss �dams</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Baranovs Kirils</td><td class=bc>-</td><td class=blW>Rudz�tis Kristaps</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Sirmais Olivers</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Hartmanis Leonels</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>Liepi�� Augusts</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Narti�s M�rcis</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ustups J�kabs</td><td class=bc>-</td><td class=blW>Gor�anova T�na</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Erenpreiss �dams</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Rudz�tis Kristaps</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kr�mi�� Ernests</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Baranovs Kirils</td><td class=bc>-</td><td class=blW>Vai�iul�ns Daniels</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Sirmais Olivers</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Hartmanis Leonels</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Liepi�� Augusts</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Narti�s M�rcis</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Erenpreiss �dams</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Vai�iul�ns Daniels</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kr�mi�� Ernests</td><td class=bc>-</td><td class=blW>Garda Roberts</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Baranovs Kirils</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Sirmais Olivers</td><td class=bc>-</td><td class=blW>Liepi�� Augusts</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Hartmanis Leonels</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Vasks Artis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Ustups J�kabs</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Erenpreiss �dams</td><td class=bc>-</td><td class=blW>Vai�iul�ns Daniels</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kr�mi�� Ernests</td><td class=bc>-</td><td class=blW>Liepi�� Augusts</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Baranovs Kirils</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Sirmais Olivers</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Hartmanis Leonels</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Ustups J�kabs</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Narti�s M�rcis</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Erenpreiss �dams</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Liepi�� Augusts</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kr�mi�� Ernests</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Baranovs Kirils</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Sirmais Olivers</td><td class=bc>-</td><td class=bl>Ustups J�kabs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Hartmanis Leonels</td><td class=bc>-</td><td class=bl>Narti�s M�rcis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Skapsts Gustavs</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Liepi�� Augusts</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Erenpreiss �dams</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Vasks Artis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr�mi�� Ernests</td><td class=bc>-</td><td class=bl>Ustups J�kabs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Baranovs Kirils</td><td class=bc>-</td><td class=bl>Narti�s M�rcis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Sirmais Olivers</td><td class=bc>-</td><td class=blW>Skapsts Gustavs</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Hartmanis Leonels</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>Liepi�� Augusts</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Gor�anova T�na</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Erenpreiss �dams</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Ustups J�kabs</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Narti�s M�rcis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Kr�mi�� Ernests</td><td class=bc>-</td><td class=blW>Skapsts Gustavs</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Baranovs Kirils</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Sirmais Olivers</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=bl>Liepi�� Augusts</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Vasks Artis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Ustups J�kabs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Erenpreiss �dams</td><td class=bc>-</td><td class=blW>Narti�s M�rcis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=blW>Skapsts Gustavs</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr�mi�� Ernests</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Baranovs Kirils</td><td class=bc>-</td><td class=blW>Hartmanis Leonels</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Liepi�� Augusts</td><td class=bc>-</td><td class=blW>Liepi�� Alans</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Ustups J�kabs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Narti�s M�rcis</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Skapsts Gustavs</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Erenpreiss �dams</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Hartmanis Leonels</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kr�mi�� Ernests</td><td class=bc>-</td><td class=blW>Sirmais Olivers</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Liepi�� Augusts</td><td class=bc>-</td><td class=bl>Vasks Artis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Ustups J�kabs</td><td class=bc>11 : 1</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Narti�s M�rcis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Erenpreiss �dams</td><td class=bc>-</td><td class=bl>Hartmanis Leonels</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Sirmais Olivers</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Baranovs Kirils</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Ustups J�kabs</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Liepi�� Augusts</td><td class=bc>-</td><td class=bl>Narti�s M�rcis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Skapsts Gustavs</td><td class=bc>5 : 7</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Hartmanis Leonels</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Sirmais Olivers</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Erenpreiss �dams</td><td class=bc>-</td><td class=bl>Baranovs Kirils</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Kr�mi�� Ernests</td><td class=bc>11 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Ustups J�kabs</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Narti�s M�rcis</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Liepi�� Augusts</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Garda Roberts</td><td class=bc>-</td><td class=bl>Hartmanis Leonels</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>Sirmais Olivers</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Baranovs Kirils</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Kr�mi�� Ernests</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Erenpreiss �dams</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ustups J�kabs</td><td class=bc>-</td><td class=blW>Narti�s M�rcis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Skapsts Gustavs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Liepi�� Augusts</td><td class=bc>-</td><td class=blW>Hartmanis Leonels</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Sirmais Olivers</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Garda Roberts</td><td class=bc>-</td><td class=bl>Baranovs Kirils</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Kr�mi�� Ernests</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Narti�s M�rcis</td><td class=bc>-</td><td class=blW>Skapsts Gustavs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ustups J�kabs</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Hartmanis Leonels</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Sirmais Olivers</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Liepi�� Augusts</td><td class=bc>-</td><td class=bl>Baranovs Kirils</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Kr�mi�� Ernests</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Garda Roberts</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Erenpreiss �dams</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Narti�s M�rcis</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ustups J�kabs</td><td class=bc>-</td><td class=blW>Hartmanis Leonels</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vasks Artis</td><td class=bc>-</td><td class=blW>Sirmais Olivers</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Gor�anova T�na</td><td class=bc>-</td><td class=bl>Baranovs Kirils</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Kr�mi�� Ernests</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Liepi�� Augusts</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Garda Roberts</td><td class=bc>-</td><td class=bl>Erenpreiss �dams</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>Hartmanis Leonels</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Narti�s M�rcis</td><td class=bc>-</td><td class=bl>Sirmais Olivers</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ustups J�kabs</td><td class=bc>-</td><td class=bl>Baranovs Kirils</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Kr�mi�� Ernests</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Liepi�� Augusts</td><td class=bc>-</td><td class=bl>Erenpreiss �dams</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Hartmanis Leonels</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Sirmais Olivers</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Baranovs Kirils</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Narti�s M�rcis</td><td class=bc>-</td><td class=bl>Kr�mi�� Ernests</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ustups J�kabs</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Gor�anova T�na</td><td class=bc>-</td><td class=bl>Erenpreiss �dams</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Liepi�� Augusts</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Vai�iul�ns Daniels</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Hartmanis Leonels</td><td class=bc>-</td><td class=bl>Sirmais Olivers</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Baranovs Kirils</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Kr�mi�� Ernests</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Narti�s M�rcis</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ustups J�kabs</td><td class=bc>-</td><td class=blW>Erenpreiss �dams</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Liepi�� Augusts</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Sirmais Olivers</td><td class=bc>-</td><td class=bl>Baranovs Kirils</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Hartmanis Leonels</td><td class=bc>-</td><td class=bl>Kr�mi�� Ernests</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>Erenpreiss �dams</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Narti�s M�rcis</td><td class=bc>-</td><td class=blW>Rudz�tis Kristaps</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ustups J�kabs</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Vasks Artis</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Garda Roberts</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Liepi�� Alans</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Baranovs Kirils</td><td class=bc>-</td><td class=blW>Kr�mi�� Ernests</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Sirmais Olivers</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Hartmanis Leonels</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Erenpreiss �dams</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Skapsts Gustavs</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Narti�s M�rcis</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ustups J�kabs</td><td class=bc>-</td><td class=blW>Garda Roberts</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Liepi�� Augusts</td><td class=bc>1 : 6</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
