<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>In�ukalns THC Challenge</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../THCCh/Incukalns_THC_Challenge_index.php">In�ukalns THC Challenge, 27. September 2025</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group A Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ra Kalni��</td><td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>8:1</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>8:0</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>8:2</td>
<td class=kW>8:1</td>
<td class=kW>10:0</td>
<td class=kW>10:0</td>
<td class=kW>8:0</td>
<td class=kW>10:1</td>
<td class=br>116:19</td><td class=br>+97</td>
<td class=bc>16 - 0 - 0</td>
<td class=br><strong>32</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>An Liepi��</td><td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>14:2</td>
<td class=kW>8:0</td>
<td class=br>71:25</td><td class=br>+46</td>
<td class=bc>14 - 0 - 2</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ed Ka�eps</td><td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>8:2</td>
<td class=kW>4:3</td>
<td class=kW>11:0</td>
<td class=br>56:34</td><td class=br>+22</td>
<td class=bc>11 - 1 - 4</td>
<td class=br><strong>23</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ja Sladek</td><td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>8:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=br>68:32</td><td class=br>+36</td>
<td class=bc>11 - 1 - 4</td>
<td class=br><strong>23</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Sa Kalni��</td><td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>2:8</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>7:0</td>
<td class=br>53:35</td><td class=br>+18</td>
<td class=bc>10 - 2 - 4</td>
<td class=br><strong>22</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ni Sviklis</td><td class=kL>1:8</td>
<td class=kL>1:6</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>8:4</td>
<td class=kW>7:4</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=br>64:47</td><td class=br>+17</td>
<td class=bc>10 - 1 - 5</td>
<td class=br><strong>21</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Al Skudr�tis</td><td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kL>3:7</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>9:0</td>
<td class=kW>5:3</td>
<td class=kW>8:0</td>
<td class=br>60:42</td><td class=br>+18</td>
<td class=bc>8 - 2 - 6</td>
<td class=br><strong>18</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Gu Hermansson</td><td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>9:0</td>
<td class=br>55:36</td><td class=br>+19</td>
<td class=bc>8 - 0 - 8</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ha Janvars</td><td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=br>34:49</td><td class=br>-15</td>
<td class=bc>6 - 3 - 7</td>
<td class=br><strong>15</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Jo Pleikys</td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=br>27:32</td><td class=br>-5</td>
<td class=bc>6 - 2 - 8</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>My Razkevich</td><td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kL>2:4</td>
<td class=kW>7:0</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=br>41:46</td><td class=br>-5</td>
<td class=bc>7 - 0 - 9</td>
<td class=br><strong>14</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Au Pleikys</td><td class=kL>2:8</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>4:8</td>
<td class=kW>7:3</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>8:1</td>
<td class=br>45:52</td><td class=br>-7</td>
<td class=bc>6 - 1 - 9</td>
<td class=br><strong>13</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>L� Bezdel�ga</td><td class=kL>1:8</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>4:7</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=br>26:54</td><td class=br>-28</td>
<td class=bc>4 - 2 - 10</td>
<td class=br><strong>10</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>An Kova��uks</td><td class=kL>0:10</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kL>0:1</td>
<td class=kW>4:2</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>6:0</td>
<td class=br>32:61</td><td class=br>-29</td>
<td class=bc>4 - 1 - 11</td>
<td class=br><strong>9</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>El Reinfelds</td><td class=kL>0:10</td>
<td class=kL>1:6</td>
<td class=kL>2:8</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>0:6</td>
<td class=kL>0:9</td>
<td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=br>23:72</td><td class=br>-49</td>
<td class=bc>2 - 2 - 12</td>
<td class=br><strong>6</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Ge Jansons</td><td class=kL>0:8</td>
<td class=kL>2:14</td>
<td class=kL>3:4</td>
<td class=kL>2:7</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=br>34:82</td><td class=br>-48</td>
<td class=bc>3 - 0 - 13</td>
<td class=br><strong>6</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Re Tomsons</td><td class=kL>1:10</td>
<td class=kL>0:8</td>
<td class=kL>0:11</td>
<td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>2:5</td>
<td class=kL>0:8</td>
<td class=kL>0:9</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>1:8</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=br>12:99</td><td class=br>-87</td>
<td class=bc>1 - 0 - 15</td>
<td class=br><strong>2</strong></td><td class=d>17.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Re Tomsons</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ha Janvars</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ja Sladek</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>My Razkevich</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Re Tomsons</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ha Janvars</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Jo Pleikys</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>My Razkevich</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Sladek</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Ge Jansons</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Re Tomsons</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Ha Janvars</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Re Tomsons</td><td class=bc>-</td><td class=blW>Ha Janvars</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Ja Sladek</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Ha Janvars</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Jo Pleikys</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Re Tomsons</td><td class=bc>-</td><td class=blW>My Razkevich</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ja Sladek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Ha Janvars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>My Razkevich</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Re Tomsons</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ja Sladek</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ha Janvars</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>My Razkevich</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Ja Sladek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Re Tomsons</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Jo Pleikys</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ha Janvars</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ja Sladek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>An Kova��uks</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Re Tomsons</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Jo Pleikys</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ha Janvars</td><td class=bc>-</td><td class=blW>Ja Sladek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Re Tomsons</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>Ja Sladek</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Jo Pleikys</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ha Janvars</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>2 : 14</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>0 : 10</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Ja Sladek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ha Janvars</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ge Jansons</td><td class=bc>-</td><td class=bl>Re Tomsons</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ja Sladek</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>My Razkevich</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ha Janvars</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Re Tomsons</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ja Sladek</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>Re Tomsons</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ha Janvars</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Ge Jansons</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ja Sladek</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Re Tomsons</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Jo Pleikys</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ha Janvars</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Ja Sladek</td><td class=bc>-</td><td class=bl>Re Tomsons</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>My Razkevich</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Re Tomsons</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ja Sladek</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>Ha Janvars</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Re Tomsons</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ja Sladek</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Ha Janvars</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>4 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group B Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ev Matantsev</td><td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kW>10:2</td>
<td class=kW>5:4</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>7:1</td>
<td class=kW>7:3</td>
<td class=kW>5:2</td>
<td class=kW>10:0</td>
<td class=kW>8:0</td>
<td class=br>90:27</td><td class=br>+63</td>
<td class=bc>14 - 1 - 1</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Kr Lagzdi�a</td><td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kL>5:6</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=br>73:26</td><td class=br>+47</td>
<td class=bc>13 - 0 - 3</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>In Garan�s</td><td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>6:5</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=kW>6:4</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=br>63:42</td><td class=br>+21</td>
<td class=bc>12 - 1 - 3</td>
<td class=br><strong>25</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Pe Fuchs</td><td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>57:26</td><td class=br>+31</td>
<td class=bc>11 - 2 - 3</td>
<td class=br><strong>24</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Kr Lebl</td><td class=kL>0:6</td>
<td class=kW>6:5</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kL>4:9</td>
<td class=kW>7:5</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kW>5:3</td>
<td class=kW>1:0</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=br>60:44</td><td class=br>+16</td>
<td class=bc>11 - 2 - 3</td>
<td class=br><strong>24</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ar Zaharovs</td><td class=kW>5:2</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>8:1</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=br>59:36</td><td class=br>+23</td>
<td class=bc>10 - 2 - 4</td>
<td class=br><strong>22</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Al Sili��</td><td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kT>4:4</td>
<td class=kW>6:0</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kW>8:3</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>9:0</td>
<td class=br>66:31</td><td class=br>+35</td>
<td class=bc>9 - 3 - 4</td>
<td class=br><strong>21</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ed Putni��</td><td class=kL>2:10</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>9:4</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>5:6</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=br>53:46</td><td class=br>+7</td>
<td class=bc>10 - 0 - 6</td>
<td class=br><strong>20</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Il �irse</td><td class=kL>4:5</td>
<td class=kW>3:2</td>
<td class=kL>5:6</td>
<td class=kL>3:5</td>
<td class=kL>5:7</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kW>6:5</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=br>59:52</td><td class=br>+7</td>
<td class=bc>8 - 2 - 6</td>
<td class=br><strong>18</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ro Kerns</td><td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:8</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=br>46:51</td><td class=br>-5</td>
<td class=bc>6 - 2 - 8</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ka Vi�ums</td><td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=br>27:55</td><td class=br>-28</td>
<td class=bc>5 - 3 - 8</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>D� Vesele</td><td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>4:6</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kT>0:0</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=br>35:47</td><td class=br>-12</td>
<td class=bc>5 - 3 - 8</td>
<td class=br><strong>13</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Kr S�manis</td><td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=br>30:60</td><td class=br>-30</td>
<td class=bc>3 - 0 - 13</td>
<td class=br><strong>6</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>As Kocere</td><td class=kL>3:7</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>3:8</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=br>35:67</td><td class=br>-32</td>
<td class=bc>2 - 1 - 13</td>
<td class=br><strong>5</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Em Uimonen</td><td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kT>0:0</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=br>26:47</td><td class=br>-21</td>
<td class=bc>2 - 1 - 13</td>
<td class=br><strong>5</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Ju Stei��nas</td><td class=kL>0:10</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>2:7</td>
<td class=kL>0:7</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=br>20:77</td><td class=br>-57</td>
<td class=bc>0 - 4 - 12</td>
<td class=br><strong>4</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Re Masulis</td><td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>0:9</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kW>1:0</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=br>5:70</td><td class=br>-65</td>
<td class=bc>1 - 1 - 14</td>
<td class=br><strong>3</strong></td><td class=d>17.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Em Uimonen</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>Re Masulis</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Em Uimonen</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr S�manis</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Em Uimonen</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>Em Uimonen</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>Em Uimonen</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>10 : 2</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Em Uimonen</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Em Uimonen</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>5 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Em Uimonen</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Em Uimonen</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Em Uimonen</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>5 : 7</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Em Uimonen</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=blW>Kr S�manis</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>9 : 4</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Em Uimonen</td><td class=bc>-</td><td class=blW>Kr S�manis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Em Uimonen</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ka Vi�ums</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ka Vi�ums</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Em Uimonen</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Em Uimonen</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ka Vi�ums</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Em Uimonen</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>5 : 6</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group C Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ed Caics</td><td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>7:3</td>
<td class=kW>9:5</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>10:2</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>8:1</td>
<td class=kW>5:0</td>
<td class=br>98:26</td><td class=br>+72</td>
<td class=bc>15 - 0 - 1</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ro Rieksti��</td><td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kL>4:5</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=kW>6:2</td>
<td class=kW>10:0</td>
<td class=br>74:25</td><td class=br>+49</td>
<td class=bc>13 - 1 - 2</td>
<td class=br><strong>27</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Lu Jurka</td><td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>7:3</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>10:0</td>
<td class=br>67:23</td><td class=br>+44</td>
<td class=bc>13 - 1 - 2</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>My Shalomayev</td><td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>9:2</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>9:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>67:32</td><td class=br>+35</td>
<td class=bc>11 - 2 - 3</td>
<td class=br><strong>24</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>An Fjermestad</td><td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:4</td>
<td class=kW>7:1</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>59:42</td><td class=br>+17</td>
<td class=bc>11 - 1 - 4</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>An Kuz�ecovs</td><td class=kL>3:7</td>
<td class=kW>5:4</td>
<td class=kL>3:7</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>6:5</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=br>67:46</td><td class=br>+21</td>
<td class=bc>10 - 2 - 4</td>
<td class=br><strong>22</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Pa Plesak</td><td class=kL>5:9</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>4:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>8:4</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=br>68:43</td><td class=br>+25</td>
<td class=bc>8 - 4 - 4</td>
<td class=br><strong>20</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ar Tseluiko</td><td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kL>1:7</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kW>6:4</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kW>8:0</td>
<td class=kT>2:2</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=br>65:42</td><td class=br>+23</td>
<td class=bc>8 - 3 - 5</td>
<td class=br><strong>19</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Si Pleikys</td><td class=kL>1:6</td>
<td class=kW>1:0</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kL>5:6</td>
<td class=kL>1:3</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=br>49:43</td><td class=br>+6</td>
<td class=bc>8 - 0 - 8</td>
<td class=br><strong>16</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Kr Zarinieks</td><td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>2:9</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>4:6</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>9:3</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>49:58</td><td class=br>-9</td>
<td class=bc>7 - 0 - 9</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ra Martu��ns</td><td class=kL>2:10</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>3:9</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>10:0</td>
<td class=br>50:50</td><td class=br>0</td>
<td class=bc>6 - 1 - 9</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>�i Vazoli��</td><td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>10:0</td>
<td class=br>35:48</td><td class=br>-13</td>
<td class=bc>6 - 0 - 10</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Al Liepi��</td><td class=kL>0:8</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>4:8</td>
<td class=kL>0:8</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>10:0</td>
<td class=br>32:66</td><td class=br>-34</td>
<td class=bc>4 - 0 - 12</td>
<td class=br><strong>8</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>J� Zem�ickis</td><td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=br>24:51</td><td class=br>-27</td>
<td class=bc>2 - 3 - 11</td>
<td class=br><strong>7</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Al Sili��</td><td class=kL>1:7</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>0:9</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>23:81</td><td class=br>-58</td>
<td class=bc>3 - 0 - 13</td>
<td class=br><strong>6</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>T� Gor�anova</td><td class=kL>1:8</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=br>25:71</td><td class=br>-46</td>
<td class=bc>2 - 0 - 14</td>
<td class=br><strong>4</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>M� Timbers</td><td class=kL>0:5</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=br>0:105</td><td class=br>-105</td>
<td class=bc>0 - 0 - 16</td>
<td class=br><strong>0</strong></td><td class=d>17.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>Ar Tseluiko</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Ra Martu��ns</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Ra Martu��ns</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ar Tseluiko</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Ra Martu��ns</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Ar Tseluiko</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Pa Plesak</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>9 : 3</tr></td>
<tr><td class=brW>�i Vazoli��</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Pa Plesak</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ar Tseluiko</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Pa Plesak</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Ar Tseluiko</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>2 : 10</tr></td>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>�i Vazoli��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ar Tseluiko</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>�i Vazoli��</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>5 : 9</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ar Tseluiko</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ar Tseluiko</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>6 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group D Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ra Miglinieks</td><td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>8:3</td>
<td class=kW>7:0</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=br>78:20</td><td class=br>+58</td>
<td class=bc>13 - 1 - 1</td>
<td class=br><strong>27</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>R� Kamzols</td><td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>9:2</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=kW>10:1</td>
<td class=br>75:26</td><td class=br>+49</td>
<td class=bc>12 - 2 - 1</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>He Prokuratovs</td><td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kW>9:6</td>
<td class=kT>5:5</td>
<td class=kW>5:2</td>
<td class=kW>9:4</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=br>70:37</td><td class=br>+33</td>
<td class=bc>11 - 2 - 2</td>
<td class=br><strong>24</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Al �ernovojs</td><td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>8:1</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=br>56:24</td><td class=br>+32</td>
<td class=bc>9 - 4 - 2</td>
<td class=br><strong>22</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ar Zasurcevs</td><td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>8:1</td>
<td class=kW>7:3</td>
<td class=kW>5:4</td>
<td class=kW>7:3</td>
<td class=kW>7:2</td>
<td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>9:2</td>
<td class=br>67:41</td><td class=br>+26</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>El R�cen�ja</td><td class=kL>3:8</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kL>1:8</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=kW>7:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=br>52:47</td><td class=br>+5</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Iv �irsis</td><td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>3:7</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>6:4</td>
<td class=kW>5:2</td>
<td class=br>48:51</td><td class=br>-3</td>
<td class=bc>9 - 0 - 6</td>
<td class=br><strong>18</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ra Kuha�skis</td><td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>6:9</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kW>5:1</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kW>7:1</td>
<td class=kW>7:2</td>
<td class=br>61:45</td><td class=br>+16</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ka �iha�ova</td><td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kT>5:5</td>
<td class=kT>4:4</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>11:1</td>
<td class=br>51:45</td><td class=br>+6</td>
<td class=bc>6 - 3 - 6</td>
<td class=br><strong>15</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Gi Lasmanis</td><td class=kL>1:6</td>
<td class=kL>2:9</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>2:7</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=kL>0:1</td>
<td class=kW>7:1</td>
<td class=br>51:49</td><td class=br>+2</td>
<td class=bc>7 - 0 - 8</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>J� Z�l�te</td><td class=kL>1:7</td>
<td class=kL>3:4</td>
<td class=kL>4:9</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>9:2</td>
<td class=br>48:57</td><td class=br>-9</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>M� �irsis</td><td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=br>17:52</td><td class=br>-35</td>
<td class=bc>3 - 2 - 10</td>
<td class=br><strong>8</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Fr Platons</td><td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=br>17:44</td><td class=br>-27</td>
<td class=bc>4 - 0 - 11</td>
<td class=br><strong>8</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Re Saul�tis</td><td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>1:8</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=br>15:59</td><td class=br>-44</td>
<td class=bc>2 - 1 - 12</td>
<td class=br><strong>5</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ol Ozoli��-Karlsons</td><td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>4:6</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kW>1:0</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=br>21:59</td><td class=br>-38</td>
<td class=bc>2 - 1 - 12</td>
<td class=br><strong>5</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Da Belkovs</td><td class=kL>1:7</td>
<td class=kL>1:10</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>2:9</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kL>1:11</td>
<td class=kL>1:7</td>
<td class=kL>2:9</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=br>23:94</td><td class=br>-71</td>
<td class=bc>1 - 0 - 14</td>
<td class=br><strong>2</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ol Ozoli��-Karlsons</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ol Ozoli��-Karlsons</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ol Ozoli��-Karlsons</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>9 : 4</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ol Ozoli��-Karlsons</td><td class=bc>-</td><td class=blW>Ka �iha�ova</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Ka �iha�ova</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ol Ozoli��-Karlsons</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>9 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Ka �iha�ova</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ol Ozoli��-Karlsons</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Ol Ozoli��-Karlsons</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>9 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ol Ozoli��-Karlsons</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ol Ozoli��-Karlsons</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ka �iha�ova</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>Ol Ozoli��-Karlsons</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Ol Ozoli��-Karlsons</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Ol Ozoli��-Karlsons</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Ka �iha�ova</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>11 : 1</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>Ol Ozoli��-Karlsons</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Ol Ozoli��-Karlsons</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ol Ozoli��-Karlsons</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Ka �iha�ova</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Ol Ozoli��-Karlsons</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group E Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Re Vazoli��</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=br>59:24</td><td class=br>+35</td>
<td class=bc>13 - 1 - 1</td>
<td class=br><strong>27</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>El �delis</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kT>5:5</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=kW>6:1</td>
<td class=br>54:26</td><td class=br>+28</td>
<td class=bc>11 - 2 - 2</td>
<td class=br><strong>24</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>K� Balodis</td><td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kW>6:3</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>8:0</td>
<td class=br>53:31</td><td class=br>+22</td>
<td class=bc>10 - 1 - 4</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>D� Apfelbaums</td><td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kL>1:4</td>
<td class=kW>7:1</td>
<td class=kW>2:0</td>
<td class=kW>10:1</td>
<td class=kW>11:0</td>
<td class=br>59:26</td><td class=br>+33</td>
<td class=bc>10 - 1 - 4</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Kr Naglis</td><td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>9:5</td>
<td class=kW>6:1</td>
<td class=br>62:38</td><td class=br>+24</td>
<td class=bc>9 - 3 - 3</td>
<td class=br><strong>21</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ar Matantsev</td><td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>7:4</td>
<td class=kW>8:2</td>
<td class=kW>4:3</td>
<td class=kW>9:1</td>
<td class=kW>11:0</td>
<td class=br>68:44</td><td class=br>+24</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Gl Storozhenko</td><td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>9:0</td>
<td class=br>43:25</td><td class=br>+18</td>
<td class=bc>7 - 4 - 4</td>
<td class=br><strong>18</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Sa Skarainis</td><td class=kL>2:4</td>
<td class=kT>5:5</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kW>8:1</td>
<td class=br>52:35</td><td class=br>+17</td>
<td class=bc>7 - 4 - 4</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Marg �bele</td><td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>8:2</td>
<td class=kW>5:1</td>
<td class=kW>8:2</td>
<td class=br>55:39</td><td class=br>+16</td>
<td class=bc>8 - 0 - 7</td>
<td class=br><strong>16</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>My Verbytskyy</td><td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=br>31:36</td><td class=br>-5</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ag Pav�rs</td><td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kL>0:8</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>6:1</td>
<td class=br>35:49</td><td class=br>-14</td>
<td class=bc>5 - 0 - 10</td>
<td class=br><strong>10</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>To Jakseboga</td><td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kL>4:7</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=br>33:48</td><td class=br>-15</td>
<td class=bc>4 - 2 - 9</td>
<td class=br><strong>10</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>On Gruncl</td><td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kW>7:1</td>
<td class=br>30:55</td><td class=br>-25</td>
<td class=bc>3 - 2 - 10</td>
<td class=br><strong>8</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ai Romals</td><td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:8</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>6:3</td>
<td class=br>29:51</td><td class=br>-22</td>
<td class=bc>3 - 1 - 11</td>
<td class=br><strong>7</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Br Gor�anovs</td><td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>2:3</td>
<td class=kL>1:10</td>
<td class=kL>5:9</td>
<td class=kL>1:9</td>
<td class=kL>0:3</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=br>24:75</td><td class=br>-51</td>
<td class=bc>2 - 0 - 13</td>
<td class=br><strong>4</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>K� Breidaks</td><td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>0:8</td>
<td class=kL>0:11</td>
<td class=kL>1:6</td>
<td class=kL>0:11</td>
<td class=kL>0:9</td>
<td class=kL>1:8</td>
<td class=kL>2:8</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kL>1:7</td>
<td class=kL>3:6</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=br>17:102</td><td class=br>-85</td>
<td class=bc>1 - 0 - 14</td>
<td class=br><strong>2</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>K� Breidaks</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>El �delis</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>K� Breidaks</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>K� Breidaks</td><td class=bc>-</td><td class=blW>On Gruncl</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=blW>El �delis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>K� Breidaks</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>El �delis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>K� Breidaks</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>El �delis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>El �delis</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>K� Breidaks</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=blW>El �delis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>K� Breidaks</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>El �delis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>K� Breidaks</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>K� Breidaks</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>El �delis</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>K� Breidaks</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>El �delis</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>K� Breidaks</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>On Gruncl</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>El �delis</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>K� Breidaks</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>El �delis</td><td class=bc>-</td><td class=bl>K� Breidaks</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>On Gruncl</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>K� Breidaks</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>El �delis</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>K� Breidaks</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>El �delis</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>K� Breidaks</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>9 : 5</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>El �delis</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group F Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>To Uimonen</td><td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kT>2:2</td>
<td class=kW>8:2</td>
<td class=kW>8:3</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>7:2</td>
<td class=kW>9:0</td>
<td class=br>75:30</td><td class=br>+45</td>
<td class=bc>12 - 3 - 0</td>
<td class=br><strong>27</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ol Korabel</td><td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>9:0</td>
<td class=kL>4:5</td>
<td class=kW>3:0</td>
<td class=kW>7:0</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=br>74:20</td><td class=br>+54</td>
<td class=bc>13 - 0 - 2</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ma Madera</td><td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>7:2</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>9:4</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>9:1</td>
<td class=br>65:35</td><td class=br>+30</td>
<td class=bc>11 - 0 - 4</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Va Dietze</td><td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>9:4</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>8:0</td>
<td class=br>63:39</td><td class=br>+24</td>
<td class=bc>10 - 1 - 4</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Kr Zem�ickis</td><td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kL>1:6</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>9:3</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=br>52:32</td><td class=br>+20</td>
<td class=bc>10 - 0 - 5</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Je Zaharovs</td><td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>2:7</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=br>54:33</td><td class=br>+21</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Em Liepi��</td><td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kW>7:0</td>
<td class=kW>12:4</td>
<td class=kW>5:2</td>
<td class=kW>8:1</td>
<td class=kW>6:1</td>
<td class=kW>12:0</td>
<td class=br>78:41</td><td class=br>+37</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>J� Bitmanis</td><td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kW>5:0</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>10:3</td>
<td class=br>50:33</td><td class=br>+17</td>
<td class=bc>9 - 0 - 6</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ra Pommerenke</td><td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>37:39</td><td class=br>-2</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ra Neija</td><td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>12:2</td>
<td class=br>47:42</td><td class=br>+5</td>
<td class=bc>5 - 4 - 6</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Kr Kurzemnieks</td><td class=kL>2:8</td>
<td class=kL>0:9</td>
<td class=kL>4:9</td>
<td class=kL>4:9</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>1:0</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=br>46:62</td><td class=br>-16</td>
<td class=bc>6 - 1 - 8</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Er Kalni��</td><td class=kL>3:8</td>
<td class=kW>5:4</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kL>4:12</td>
<td class=kL>1:7</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=br>39:74</td><td class=br>-35</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>He Petuch</td><td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=br>29:42</td><td class=br>-13</td>
<td class=bc>4 - 2 - 9</td>
<td class=br><strong>10</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Em Ka�s</td><td class=kL>2:6</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>3:9</td>
<td class=kL>0:7</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=br>25:79</td><td class=br>-54</td>
<td class=bc>2 - 1 - 12</td>
<td class=br><strong>5</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Vo Kvasnikov</td><td class=kL>2:7</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=br>27:66</td><td class=br>-39</td>
<td class=bc>1 - 0 - 14</td>
<td class=br><strong>2</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Ri D�cis</td><td class=kL>0:9</td>
<td class=kL>1:6</td>
<td class=kL>1:9</td>
<td class=kL>0:8</td>
<td class=kL>1:8</td>
<td class=kL>0:7</td>
<td class=kL>0:12</td>
<td class=kL>3:10</td>
<td class=kL>0:5</td>
<td class=kL>2:12</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=br>17:111</td><td class=br>-94</td>
<td class=bc>0 - 0 - 15</td>
<td class=br><strong>0</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>12 : 4</tr></td>
<tr><td class=brW>To Uimonen</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=blW>Kr Kurzemnieks</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=blW>Er Kalni��</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>To Uimonen</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Er Kalni��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>Vo Kvasnikov</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>To Uimonen</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Kr Kurzemnieks</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>2 : 12</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>To Uimonen</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Kr Kurzemnieks</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>To Uimonen</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>3 : 10</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>To Uimonen</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=blW>To Uimonen</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>To Uimonen</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>0 : 12</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ra Neija</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>To Uimonen</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>To Uimonen</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>4 : 9</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>To Uimonen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>To Uimonen</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ra Neija</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>To Uimonen</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>To Uimonen</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>To Uimonen</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>9 : 4</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group G Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ma Lezik</td><td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kW>14:0</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>7:2</td>
<td class=br>74:25</td><td class=br>+49</td>
<td class=bc>13 - 1 - 1</td>
<td class=br><strong>27</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>El Sili��</td><td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=br>54:17</td><td class=br>+37</td>
<td class=bc>13 - 1 - 1</td>
<td class=br><strong>27</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>J� Re�is</td><td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=br>56:22</td><td class=br>+34</td>
<td class=bc>13 - 0 - 2</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ma Jakseboga</td><td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=br>42:26</td><td class=br>+16</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ro Fa�ken�teins</td><td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=br>42:26</td><td class=br>+16</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Sa Krasts</td><td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>7:0</td>
<td class=br>42:22</td><td class=br>+20</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Se Mihejevs</td><td class=kL>3:5</td>
<td class=kL>0:2</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=br>45:28</td><td class=br>+17</td>
<td class=bc>7 - 3 - 5</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Il Pavlovskis</td><td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>11:0</td>
<td class=br>43:32</td><td class=br>+11</td>
<td class=bc>6 - 5 - 4</td>
<td class=br><strong>17</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Di Ziemelis</td><td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>7:5</td>
<td class=kW>4:3</td>
<td class=kW>9:1</td>
<td class=kW>7:1</td>
<td class=kW>5:4</td>
<td class=kW>8:1</td>
<td class=br>53:37</td><td class=br>+16</td>
<td class=bc>7 - 3 - 5</td>
<td class=br><strong>17</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Da Baumanis</td><td class=kL>1:7</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kL>1:6</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=br>41:42</td><td class=br>-1</td>
<td class=bc>7 - 2 - 6</td>
<td class=br><strong>16</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Le Maz�rs</td><td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>5:7</td>
<td class=kW>6:1</td>
<td class=kx>*</td>
<td class=kL>6:7</td>
<td class=kW>7:2</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kW>10:2</td>
<td class=br>65:46</td><td class=br>+19</td>
<td class=bc>6 - 0 - 9</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ma Krauze</td><td class=kL>4:5</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kW>7:6</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=br>27:53</td><td class=br>-26</td>
<td class=bc>4 - 0 - 11</td>
<td class=br><strong>8</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Au Breidaks</td><td class=kL>0:14</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kW>3:1</td>
<td class=kL>1:7</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>1:9</td>
<td class=kL>1:6</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=br>22:83</td><td class=br>-61</td>
<td class=bc>3 - 1 - 11</td>
<td class=br><strong>7</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Gi Remeika</td><td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kW>3:0</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=br>21:53</td><td class=br>-32</td>
<td class=bc>3 - 1 - 11</td>
<td class=br><strong>7</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ma Kalni��</td><td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>4:5</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>13:58</td><td class=br>-45</td>
<td class=bc>1 - 0 - 14</td>
<td class=br><strong>2</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Da Ra�ko</td><td class=kL>2:7</td>
<td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>0:8</td>
<td class=kL>0:11</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kL>2:10</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>13:83</td><td class=br>-70</td>
<td class=bc>0 - 1 - 14</td>
<td class=br><strong>1</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Da Ra�ko</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Au Breidaks</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ma Lezik</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Le Maz�rs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Da Ra�ko</td><td class=bc>-</td><td class=bl>Au Breidaks</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ma Lezik</td><td class=bc>-</td><td class=bl>Le Maz�rs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Au Breidaks</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Da Ra�ko</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Le Maz�rs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ma Lezik</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Au Breidaks</td><td class=bc>-</td><td class=blW>Il Pavlovskis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Da Ra�ko</td><td class=bc>-</td><td class=blW>Gi Remeika</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Le Maz�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Lezik</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Il Pavlovskis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>Gi Remeika</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Au Breidaks</td><td class=bc>-</td><td class=blW>Le Maz�rs</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Da Ra�ko</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Ma Lezik</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>Le Maz�rs</td><td class=bc>7 : 6</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Au Breidaks</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Da Ra�ko</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Ma Lezik</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Le Maz�rs</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Au Breidaks</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Da Ra�ko</td><td class=bc>-</td><td class=blW>Ma Lezik</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Le Maz�rs</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>Ma Lezik</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Au Breidaks</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Da Ra�ko</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Le Maz�rs</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Ma Lezik</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Au Breidaks</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Da Ra�ko</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Ma Lezik</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Le Maz�rs</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>5 : 7</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>Da Ra�ko</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Au Breidaks</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Ma Lezik</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Le Maz�rs</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Da Ra�ko</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>Au Breidaks</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Le Maz�rs</td><td class=bc>-</td><td class=bl>Da Ra�ko</td><td class=bc>10 : 2</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Au Breidaks</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ma Lezik</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Da Ra�ko</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Au Breidaks</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Le Maz�rs</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Gi Remeika</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ma Lezik</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Da Ra�ko</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Au Breidaks</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Le Maz�rs</td><td class=bc>-</td><td class=blW>Il Pavlovskis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Da Ra�ko</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ma Lezik</td><td class=bc>-</td><td class=bl>Au Breidaks</td><td class=bc>14 : 0</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Le Maz�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Da Ra�ko</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Au Breidaks</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ma Lezik</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Le Maz�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group H Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ed Naglis</td><td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>8:3</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>10:2</td>
<td class=kW>11:1</td>
<td class=kW>7:4</td>
<td class=kW>10:0</td>
<td class=kW>13:0</td>
<td class=br>91:27</td><td class=br>+64</td>
<td class=bc>12 - 1 - 2</td>
<td class=br><strong>25</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Kr Rieksti��</td><td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=br>49:24</td><td class=br>+25</td>
<td class=bc>10 - 2 - 3</td>
<td class=br><strong>22</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Mi Saul�tis</td><td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>7:0</td>
<td class=br>53:35</td><td class=br>+18</td>
<td class=bc>10 - 1 - 4</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Va Smagars</td><td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kT>0:0</td>
<td class=kT>3:3</td>
<td class=kW>8:3</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>7:0</td>
<td class=kW>5:4</td>
<td class=kW>8:1</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=br>62:30</td><td class=br>+32</td>
<td class=bc>9 - 3 - 3</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Da Nyg�rd</td><td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>8:2</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>8:0</td>
<td class=br>48:26</td><td class=br>+22</td>
<td class=bc>7 - 4 - 4</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ma Zenisek</td><td class=kL>2:7</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>8:0</td>
<td class=br>40:32</td><td class=br>+8</td>
<td class=bc>6 - 6 - 3</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Am Fylling</td><td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kT>0:0</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>8:1</td>
<td class=kW>8:1</td>
<td class=br>51:31</td><td class=br>+20</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Zy Remeika</td><td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>8:1</td>
<td class=br>42:35</td><td class=br>+7</td>
<td class=bc>7 - 3 - 5</td>
<td class=br><strong>17</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ma Satkus</td><td class=kL>3:8</td>
<td class=kL>1:6</td>
<td class=kW>4:3</td>
<td class=kL>3:8</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>2:7</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>8:2</td>
<td class=br>47:48</td><td class=br>-1</td>
<td class=bc>7 - 3 - 5</td>
<td class=br><strong>17</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Vi Lapi��</td><td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kL>0:5</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kW>8:2</td>
<td class=kW>7:2</td>
<td class=br>41:36</td><td class=br>+5</td>
<td class=bc>7 - 1 - 7</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ro Aseri��</td><td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=br>27:32</td><td class=br>-5</td>
<td class=bc>5 - 3 - 7</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Al Hermansson</td><td class=kL>2:10</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:7</td>
<td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kW>5:0</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>37:50</td><td class=br>-13</td>
<td class=bc>6 - 1 - 8</td>
<td class=br><strong>13</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>�v Vikmanis</td><td class=kL>1:11</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=br>31:57</td><td class=br>-26</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Vl Voronov</td><td class=kL>4:7</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=br>31:62</td><td class=br>-31</td>
<td class=bc>3 - 0 - 12</td>
<td class=br><strong>6</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ed Liepi��</td><td class=kL>0:10</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:8</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>2:8</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=br>20:66</td><td class=br>-46</td>
<td class=bc>1 - 1 - 13</td>
<td class=br><strong>3</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Em Vi��akovs</td><td class=kL>0:13</td>
<td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>2:5</td>
<td class=kL>0:8</td>
<td class=kL>0:8</td>
<td class=kL>1:8</td>
<td class=kL>1:8</td>
<td class=kL>2:8</td>
<td class=kL>2:7</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=br>14:93</td><td class=br>-79</td>
<td class=bc>0 - 2 - 13</td>
<td class=br><strong>2</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>13 : 0</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Da Nyg�rd</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Vi Lapi��</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Da Nyg�rd</td><td class=bc>-</td><td class=blW>Vi Lapi��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Vi Lapi��</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Da Nyg�rd</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Vl Voronov</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Al Hermansson</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Vi Lapi��</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Da Nyg�rd</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Vi Lapi��</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Da Nyg�rd</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Al Hermansson</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Vi Lapi��</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Da Nyg�rd</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Al Hermansson</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Vi Lapi��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Da Nyg�rd</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Vi Lapi��</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Al Hermansson</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>Da Nyg�rd</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Vi Lapi��</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Da Nyg�rd</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Al Hermansson</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Da Nyg�rd</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vi Lapi��</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Al Hermansson</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 11</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Vi Lapi��</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Al Hermansson</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 10</tr></td>
<tr><td class=brW>Vl Voronov</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Da Nyg�rd</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vi Lapi��</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Al Hermansson</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vl Voronov</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Da Nyg�rd</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Vi Lapi��</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Al Hermansson</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Da Nyg�rd</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Ma Zenisek</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vi Lapi��</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Al Hermansson</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Da Nyg�rd</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vi Lapi��</td><td class=bc>-</td><td class=blW>Al Hermansson</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Da Nyg�rd</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vi Lapi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group 1.league</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>31</td>
<td class=ic>32</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Ra Kalni��</td><td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>6:4</td>
<td class=kW>6:2</td>
<td class=kL>3:4</td>
<td class=kW>6:3</td>
<td class=kW>7:1 K</td>
<td class=kW>4:2 K</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kT>5:5</td>
<td class=kW>7:3 K</td>
<td class=kW>8:1 K</td>
<td class=kW>5:1</td>
<td class=kW>5:2 K</td>
<td class=kW>3:0</td>
<td class=kW>7:2 K</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>5:1 K</td>
<td class=kW>5:2</td>
<td class=kW>9:2</td>
<td class=br>154:71</td><td class=br>+83</td>
<td class=bc>25 - 2 - 4</td>
<td class=br><strong>52</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Ed Naglis</td><td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kT>3:3 K</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3 K</td>
<td class=kT>1:1</td>
<td class=kW>6:3</td>
<td class=kW>4:0 K</td>
<td class=kW>5:3 K</td>
<td class=kW>5:4</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kW>6:1</td>
<td class=kL>1:5</td>
<td class=kW>4:2 K</td>
<td class=kW>7:2 K</td>
<td class=kW>5:1 K</td>
<td class=kW>6:0</td>
<td class=kL>0:2</td>
<td class=kW>5:1</td>
<td class=kW>9:1</td>
<td class=br>118:68</td><td class=br>+50</td>
<td class=bc>20 - 5 - 6</td>
<td class=br><strong>45</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Ar Matantsev</td><td class=kW>5:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kL>3:5</td>
<td class=kL>1:5 K</td>
<td class=kT>6:6</td>
<td class=kL>1:3 K</td>
<td class=kW>4:1 K</td>
<td class=kL>3:6 K</td>
<td class=kW>7:3</td>
<td class=kW>5:3</td>
<td class=kW>8:2</td>
<td class=kW>5:2</td>
<td class=kT>4:4 K</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kT>6:6</td>
<td class=kL>1:4 K</td>
<td class=kL>1:4</td>
<td class=kW>5:3 K</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=br>127:81</td><td class=br>+46</td>
<td class=bc>19 - 5 - 7</td>
<td class=br><strong>43</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>Ra Miglinieks</td><td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:0 K</td>
<td class=kW>4:1</td>
<td class=kW>7:4</td>
<td class=kL>2:4 K</td>
<td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kW>6:1 K</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kT>4:4 K</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kT>0:0</td>
<td class=kL>4:7</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>8:3 K</td>
<td class=kW>2:0</td>
<td class=kW>3:1 K</td>
<td class=kW>7:0 K</td>
<td class=br>105:71</td><td class=br>+34</td>
<td class=bc>19 - 4 - 8</td>
<td class=br><strong>42</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Al �ernovojs</td><td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>0:3 K</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>1:0</td>
<td class=kL>1:2 K</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kT>0:0</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kW>5:0 K</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kT>4:4 K</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kT>2:2 K</td>
<td class=kW>4:1</td>
<td class=kT>2:2 K</td>
<td class=kW>3:0 K</td>
<td class=br>76:61</td><td class=br>+15</td>
<td class=bc>14 - 9 - 8</td>
<td class=br><strong>37</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>Va Smagars</td><td class=kL>3:6</td>
<td class=kT>3:3 K</td>
<td class=kW>5:3</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>3:1 K</td>
<td class=kW>6:1</td>
<td class=kW>5:4</td>
<td class=kT>0:0 K</td>
<td class=kL>3:4 K</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=kW>8:0</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1 K</td>
<td class=kL>2:3 K</td>
<td class=kT>3:3 K</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>6:5</td>
<td class=br>102:85</td><td class=br>+17</td>
<td class=bc>16 - 4 - 11</td>
<td class=br><strong>36</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Re Vazoli��</td><td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>5:1 K</td>
<td class=kL>4:7</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>2:2 K</td>
<td class=kL>2:5 K</td>
<td class=kW>4:2 K</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>2:1 K</td>
<td class=kW>6:0</td>
<td class=kL>3:6</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>2:6</td>
<td class=kW>4:1 K</td>
<td class=kW>7:1</td>
<td class=kW>4:2 K</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kW>7:1</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=br>101:81</td><td class=br>+20</td>
<td class=bc>16 - 4 - 11</td>
<td class=br><strong>36</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>He Prokuratovs</td><td class=kL>4:6</td>
<td class=kT>1:1</td>
<td class=kT>6:6</td>
<td class=kW>4:2 K</td>
<td class=kW>2:1 K</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>5:5</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>3:8</td>
<td class=kW>5:4</td>
<td class=kT>4:4 K</td>
<td class=kW>7:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:3 K</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kW>8:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>3:5 K</td>
<td class=kT>3:3</td>
<td class=kW>9:6 K</td>
<td class=kW>3:2 K</td>
<td class=br>112:98</td><td class=br>+14</td>
<td class=bc>13 - 9 - 9</td>
<td class=br><strong>35</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>El �delis</td><td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kW>3:1 K</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2 K</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:2 K</td>
<td class=kW>4:3 K</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>1:4 K</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kL>0:3 K</td>
<td class=kL>1:3</td>
<td class=kT>5:5 K</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=br>85:84</td><td class=br>+1</td>
<td class=bc>15 - 4 - 12</td>
<td class=br><strong>34</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Kr Naglis</td><td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kL>1:4 K</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>5:2 K</td>
<td class=kT>5:5</td>
<td class=kL>2:4 K</td>
<td class=kx>*</td>
<td class=kT>4:4 K</td>
<td class=kW>7:1</td>
<td class=kT>4:4</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>2:3 K</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>1:8</td>
<td class=kT>3:3</td>
<td class=kT>4:4 K</td>
<td class=kW>4:3</td>
<td class=kT>3:3 K</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>6:5</td>
<td class=kW>8:0</td>
<td class=br>109:97</td><td class=br>+12</td>
<td class=bc>12 - 10 - 9</td>
<td class=br><strong>34</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>K� Balodis</td><td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kW>6:3 K</td>
<td class=kL>1:5</td>
<td class=kT>0:0</td>
<td class=kT>3:3</td>
<td class=kL>2:4 K</td>
<td class=kT>3:3</td>
<td class=kL>3:4 K</td>
<td class=kT>4:4 K</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kW>2:1 K</td>
<td class=kT>5:5</td>
<td class=kT>2:2</td>
<td class=kL>3:8</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>3:4 K</td>
<td class=kT>1:1</td>
<td class=kL>3:4 K</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kL>3:6</td>
<td class=kW>5:3</td>
<td class=br>98:88</td><td class=br>+10</td>
<td class=bc>12 - 9 - 10</td>
<td class=br><strong>33</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>Ed Ka�eps</td><td class=kL>1:7 K</td>
<td class=kL>1:6</td>
<td class=kL>3:7</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>3:3 K</td>
<td class=kT>3:3</td>
<td class=kL>3:9</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>1:4 K</td>
<td class=kL>2:6 K</td>
<td class=kW>2:1</td>
<td class=kW>4:3 K</td>
<td class=kW>4:3</td>
<td class=kW>1:0 K</td>
<td class=kW>2:1</td>
<td class=kW>8:1</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1 K</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=br>86:96</td><td class=br>-10</td>
<td class=bc>15 - 3 - 13</td>
<td class=br><strong>33</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>Al Skudr�tis</td><td class=kL>2:4 K</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>8:3</td>
<td class=kT>4:4</td>
<td class=kT>4:4</td>
<td class=kL>1:7</td>
<td class=kT>3:3 K</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>2:3 K</td>
<td class=kW>4:3 K</td>
<td class=kT>3:3</td>
<td class=kW>4:1 K</td>
<td class=kW>6:1</td>
<td class=kW>5:3 K</td>
<td class=kL>1:5</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kL>1:2 K</td>
<td class=kL>2:4</td>
<td class=kW>7:1</td>
<td class=br>101:91</td><td class=br>+10</td>
<td class=bc>13 - 6 - 12</td>
<td class=br><strong>32</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>Kr Rieksti��</td><td class=kL>2:7</td>
<td class=kW>3:1 K</td>
<td class=kL>2:8</td>
<td class=kL>0:2</td>
<td class=kT>0:0</td>
<td class=kL>1:3 K</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kW>6:1 K</td>
<td class=kW>2:1 K</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2 K</td>
<td class=kW>3:0 K</td>
<td class=kL>2:5</td>
<td class=kW>6:2</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=br>75:77</td><td class=br>-2</td>
<td class=bc>13 - 6 - 12</td>
<td class=br><strong>32</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>Ar Zasurcevs</td><td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>1:6 K</td>
<td class=kL>0:5 K</td>
<td class=kL>1:6</td>
<td class=kT>4:4</td>
<td class=kT>4:4 K</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kL>1:5</td>
<td class=kW>9:3</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3 K</td>
<td class=kT>2:2</td>
<td class=kW>7:3</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>8:1 K</td>
<td class=kT>3:3</td>
<td class=kW>5:4 K</td>
<td class=kW>7:3 K</td>
<td class=br>101:97</td><td class=br>+4</td>
<td class=bc>11 - 9 - 11</td>
<td class=br><strong>31</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>D� Apfelbaums</td><td class=kL>3:5</td>
<td class=kL>3:6</td>
<td class=kT>4:4 K</td>
<td class=kL>0:1</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kL>1:2 K</td>
<td class=kL>2:7</td>
<td class=kW>4:1 K</td>
<td class=kW>3:2 K</td>
<td class=kL>1:2 K</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>6:4</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kW>2:1 K</td>
<td class=kL>1:5</td>
<td class=kW>2:1 K</td>
<td class=kL>2:8</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=br>75:83</td><td class=br>-8</td>
<td class=bc>13 - 5 - 13</td>
<td class=br><strong>31</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Am Fylling</td><td class=kL>1:6</td>
<td class=kL>0:4 K</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kT>0:0 K</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kT>5:5</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kL>1:6 K</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>3:4 K</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>2:6 K</td>
<td class=kT>1:1 K</td>
<td class=kW>2:0 K</td>
<td class=kW>9:1</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=br>80:86</td><td class=br>-6</td>
<td class=bc>12 - 7 - 12</td>
<td class=br><strong>31</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Mi Saul�tis</td><td class=kL>1:7</td>
<td class=kL>3:5 K</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kW>4:3 K</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kL>1:2 K</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3 K</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=kL>0:1</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kW>7:2</td>
<td class=kT>2:2 K</td>
<td class=kL>1:2 K</td>
<td class=kW>5:3 K</td>
<td class=kL>2:5</td>
<td class=kW>5:2</td>
<td class=kL>1:8</td>
<td class=kW>2:0</td>
<td class=br>85:85</td><td class=br>0</td>
<td class=bc>12 - 6 - 13</td>
<td class=br><strong>30</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>R� Kamzols</td><td class=kT>5:5</td>
<td class=kL>4:5</td>
<td class=kL>2:7</td>
<td class=kT>4:4 K</td>
<td class=kT>4:4 K</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>3:1 K</td>
<td class=kW>5:0</td>
<td class=kT>4:4</td>
<td class=kW>8:3</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2 K</td>
<td class=kL>4:6</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>9:0</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>4:8</td>
<td class=kT>1:1</td>
<td class=kL>3:8</td>
<td class=kW>7:3</td>
<td class=kL>3:4 K</td>
<td class=kL>3:5</td>
<td class=kW>6:1 K</td>
<td class=kW>6:0 K</td>
<td class=br>113:96</td><td class=br>+17</td>
<td class=bc>11 - 8 - 12</td>
<td class=br><strong>30</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>An Liepi��</td><td class=kL>3:7 K</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>8:1</td>
<td class=kL>2:3</td>
<td class=kW>4:1 K</td>
<td class=kW>3:2 K</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>6:1 K</td>
<td class=kW>5:2</td>
<td class=kW>4:3 K</td>
<td class=kL>1:3</td>
<td class=kW>2:1 K</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kL>2:4</td>
<td class=kW>3:0 K</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=br>91:78</td><td class=br>+13</td>
<td class=bc>14 - 1 - 16</td>
<td class=br><strong>29</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Ni Sviklis</td><td class=kL>1:8 K</td>
<td class=kW>6:3</td>
<td class=kT>6:6</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>6:2 K</td>
<td class=kL>3:4 K</td>
<td class=kW>3:2</td>
<td class=kL>3:7</td>
<td class=kW>5:1</td>
<td class=kL>4:5</td>
<td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kL>1:6 K</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>2:2 K</td>
<td class=kW>4:2</td>
<td class=kL>1:3 K</td>
<td class=kL>0:6</td>
<td class=kW>6:4</td>
<td class=kW>5:3</td>
<td class=kL>4:6</td>
<td class=kL>0:4 K</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=br>97:116</td><td class=br>-19</td>
<td class=bc>12 - 5 - 14</td>
<td class=br><strong>29</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Gl Storozhenko</td><td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kW>4:1 K</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>0:8</td>
<td class=kL>1:4 K</td>
<td class=kL>3:4</td>
<td class=kW>3:0 K</td>
<td class=kT>4:4 K</td>
<td class=kW>4:3 K</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>1:2 K</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kL>0:9</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>1:1 K</td>
<td class=kL>0:1</td>
<td class=kW>1:0</td>
<td class=kW>6:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=br>70:84</td><td class=br>-14</td>
<td class=bc>11 - 7 - 13</td>
<td class=br><strong>29</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Ja Sladek</td><td class=kL>2:5 K</td>
<td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>6:2</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>3:4 K</td>
<td class=kL>1:4 K</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>3:4 K</td>
<td class=kT>2:2 K</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>5:3 K</td>
<td class=kL>0:6</td>
<td class=kW>3:2</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kW>8:2 K</td>
<td class=kW>7:2</td>
<td class=kL>1:3</td>
<td class=br>92:95</td><td class=br>-3</td>
<td class=bc>11 - 6 - 14</td>
<td class=br><strong>28</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Sa Skarainis</td><td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>3:5 K</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kL>2:4 K</td>
<td class=kW>3:2</td>
<td class=kT>5:5 K</td>
<td class=kT>3:3 K</td>
<td class=kW>4:3 K</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kL>1:2 K</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kT>1:1 K</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kL>0:4</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=br>78:93</td><td class=br>-15</td>
<td class=bc>12 - 4 - 15</td>
<td class=br><strong>28</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt>Gu Hermansson</td><td class=kL>2:7 K</td>
<td class=kW>5:1</td>
<td class=kL>1:5</td>
<td class=kT>0:0</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>0:1 K</td>
<td class=kL>3:5 K</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>8:2</td>
<td class=kT>4:4</td>
<td class=kL>2:7</td>
<td class=kW>8:4</td>
<td class=kL>1:2 K</td>
<td class=kW>3:1 K</td>
<td class=kW>1:0</td>
<td class=kL>3:5 K</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>3:4 K</td>
<td class=kL>2:7</td>
<td class=kW>3:2</td>
<td class=br>83:98</td><td class=br>-15</td>
<td class=bc>11 - 5 - 15</td>
<td class=br><strong>27</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt>Da Nyg�rd</td><td class=kT>3:3</td>
<td class=kL>2:4 K</td>
<td class=kT>2:2</td>
<td class=kW>7:4</td>
<td class=kL>1:3</td>
<td class=kL>1:2 K</td>
<td class=kW>4:1</td>
<td class=kL>3:8</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2 K</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>6:2 K</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kW>6:0</td>
<td class=kL>0:1</td>
<td class=kW>6:0</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kL>1:2 K</td>
<td class=kW>6:3</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=br>76:86</td><td class=br>-10</td>
<td class=bc>9 - 7 - 15</td>
<td class=br><strong>25</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt>Ma Zenisek</td><td class=kL>1:6</td>
<td class=kL>2:7 K</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2 K</td>
<td class=kL>1:7</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kT>2:2 K</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kT>1:1 K</td>
<td class=kW>2:1 K</td>
<td class=kW>8:3</td>
<td class=kL>0:6</td>
<td class=kL>4:6</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kT>1:1 K</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kL>0:3</td>
<td class=kW>7:2</td>
<td class=br>68:110</td><td class=br>-42</td>
<td class=bc>9 - 7 - 15</td>
<td class=br><strong>25</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt>Zy Remeika</td><td class=kL>2:4</td>
<td class=kL>1:5 K</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kT>3:3 K</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>0:3 K</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kL>0:2 K</td>
<td class=kL>3:5 K</td>
<td class=kL>3:7</td>
<td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>2:1 K</td>
<td class=kT>1:1 K</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=br>72:102</td><td class=br>-30</td>
<td class=bc>7 - 8 - 16</td>
<td class=br><strong>22</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt>El R�cen�ja</td><td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>3:8 K</td>
<td class=kT>2:2 K</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kW>5:3 K</td>
<td class=kL>2:5</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kL>1:8 K</td>
<td class=kT>4:4</td>
<td class=kL>1:9</td>
<td class=kW>5:2</td>
<td class=kW>4:3 K</td>
<td class=kW>4:2</td>
<td class=kW>6:4</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:5 K</td>
<td class=kL>2:4 K</td>
<td class=br>78:126</td><td class=br>-48</td>
<td class=bc>9 - 3 - 19</td>
<td class=br><strong>21</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt>Sa Kalni��</td><td class=kL>1:5 K</td>
<td class=kW>2:0</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>1:5 K</td>
<td class=kW>2:1 K</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kL>0:3 K</td>
<td class=kW>4:0 K</td>
<td class=kW>4:2</td>
<td class=kL>2:8 K</td>
<td class=kW>4:0</td>
<td class=kW>4:3 K</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=br>59:94</td><td class=br>-35</td>
<td class=bc>8 - 5 - 18</td>
<td class=br><strong>21</strong></td><td class=d>30.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>31.</td><td class=kt>Ra Kuha�skis</td><td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:3 K</td>
<td class=kT>2:2 K</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>6:9 K</td>
<td class=kL>1:2</td>
<td class=kL>5:6</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>4:5</td>
<td class=kL>4:5 K</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>8:1</td>
<td class=kL>1:6 K</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kW>7:2</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>5:1 K</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kL>3:6 K</td>
<td class=br>92:110</td><td class=br>-18</td>
<td class=bc>8 - 3 - 20</td>
<td class=br><strong>19</strong></td><td class=d>31.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>32.</td><td class=kt>Iv �irsis</td><td class=kL>2:9</td>
<td class=kL>1:9</td>
<td class=kL>3:5</td>
<td class=kL>0:7 K</td>
<td class=kL>0:3 K</td>
<td class=kL>5:6</td>
<td class=kL>3:5</td>
<td class=kL>2:3 K</td>
<td class=kL>2:5</td>
<td class=kL>0:8</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>3:7 K</td>
<td class=kL>0:4</td>
<td class=kW>2:0</td>
<td class=kL>0:2</td>
<td class=kL>0:6 K</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kW>4:2 K</td>
<td class=kW>3:1</td>
<td class=kW>6:3 K</td>
<td class=kx>*</td>
<td class=br>65:136</td><td class=br>-71</td>
<td class=bc>6 - 0 - 25</td>
<td class=br><strong>12</strong></td><td class=d>32.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>El �delis</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ja Sladek</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Da Nyg�rd</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>El �delis</td><td class=bc>-</td><td class=bl>Da Nyg�rd</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Sladek</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Da Nyg�rd</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>El �delis</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ja Sladek</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=bl>Da Nyg�rd</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>El �delis</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ja Sladek</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Da Nyg�rd</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>El �delis</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Ja Sladek</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ja Sladek</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Da Nyg�rd</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>El �delis</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>Da Nyg�rd</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ja Sladek</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>El �delis</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>El �delis</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ja Sladek</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Re Vazoli��</td><td class=bc>-</td><td class=blW>Da Nyg�rd</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Da Nyg�rd</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>El �delis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ja Sladek</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>6 : 6</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Da Nyg�rd</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>El �delis</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ja Sladek</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Da Nyg�rd</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ja Sladek</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>El �delis</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Da Nyg�rd</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ja Sladek</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Da Nyg�rd</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ja Sladek</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Da Nyg�rd</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ja Sladek</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Kr Rieksti��</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>Da Nyg�rd</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ja Sladek</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Kr Rieksti��</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Da Nyg�rd</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ja Sladek</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>El �delis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Ja Sladek</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Da Nyg�rd</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>El �delis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=blW>Ja Sladek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Da Nyg�rd</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Ja Sladek</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Da Nyg�rd</td><td class=bc>-</td><td class=bl>Ra Kalni��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>El �delis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Ja Sladek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Nyg�rd</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Nyg�rd</td><td class=bc>-</td><td class=bl>Ja Sladek</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Da Nyg�rd</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>El �delis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ja Sladek</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>6 : 6</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Da Nyg�rd</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>El �delis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ja Sladek</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kr Rieksti��</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Kr Rieksti��</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>El �delis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Nyg�rd</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Ja Sladek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>3 : 6</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 2.league</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>31</td>
<td class=ic>32</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Ol Korabel</td><td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kL>5:6</td>
<td class=kW>3:0</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kT>4:4</td>
<td class=kL>3:5 K</td>
<td class=kW>4:3</td>
<td class=kW>6:0 K</td>
<td class=kW>7:1</td>
<td class=kW>2:1 K</td>
<td class=kW>7:0</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1 K</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>3:1 K</td>
<td class=kW>8:4</td>
<td class=kW>4:1 K</td>
<td class=kW>6:1 K</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=br>133:50</td><td class=br>+83</td>
<td class=bc>26 - 2 - 3</td>
<td class=br><strong>54</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Ed Caics</td><td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>0:5</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>6:3</td>
<td class=kW>4:1 K</td>
<td class=kW>6:2</td>
<td class=kL>2:5 K</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>7:5</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>7:3 K</td>
<td class=kW>5:0</td>
<td class=kW>7:5</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1 K</td>
<td class=kW>4:2 K</td>
<td class=kW>7:1 K</td>
<td class=kW>4:1</td>
<td class=kW>9:5 K</td>
<td class=kW>3:0</td>
<td class=kW>8:0</td>
<td class=br>140:63</td><td class=br>+77</td>
<td class=bc>26 - 1 - 4</td>
<td class=br><strong>53</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Ev Matantsev</td><td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=kx>*</td>
<td class=kW>3:0 K</td>
<td class=kL>3:4</td>
<td class=kW>4:3 K</td>
<td class=kL>2:5 K</td>
<td class=kW>8:1</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kW>6:0 K</td>
<td class=kL>4:5</td>
<td class=kW>6:2</td>
<td class=kW>6:2 K</td>
<td class=kW>4:1</td>
<td class=kW>8:4</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>7:3</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>5:1 K</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>10:2 K</td>
<td class=br>159:64</td><td class=br>+95</td>
<td class=bc>25 - 0 - 6</td>
<td class=br><strong>50</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>Al Sili��</td><td class=kW>6:5</td>
<td class=kL>2:4</td>
<td class=kL>0:3 K</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>3:4 K</td>
<td class=kL>1:3 K</td>
<td class=kW>5:4</td>
<td class=kW>5:1</td>
<td class=kL>5:8</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>4:3</td>
<td class=kT>3:3 K</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>5:2 K</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>2:1 K</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kL>2:3 K</td>
<td class=br>111:76</td><td class=br>+35</td>
<td class=bc>20 - 4 - 7</td>
<td class=br><strong>44</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>El Sili��</td><td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>0:1</td>
<td class=kL>2:4 K</td>
<td class=kL>2:3</td>
<td class=kW>3:2 K</td>
<td class=kW>8:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>2:1 K</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kW>2:0 K</td>
<td class=kL>4:5</td>
<td class=kL>3:4</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1 K</td>
<td class=kT>2:2 K</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>5:1 K</td>
<td class=kW>7:1</td>
<td class=br>106:59</td><td class=br>+47</td>
<td class=bc>21 - 1 - 9</td>
<td class=br><strong>43</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>Kr Lagzdi�a</td><td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kL>3:4 K</td>
<td class=kW>4:3 K</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:1 K</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kT>5:5</td>
<td class=kT>3:3</td>
<td class=kL>5:6 K</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>5:0 K</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>7:4</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kW>2:1 K</td>
<td class=kW>5:4</td>
<td class=kW>6:1</td>
<td class=kW>6:1 K</td>
<td class=br>108:77</td><td class=br>+31</td>
<td class=bc>18 - 5 - 8</td>
<td class=br><strong>41</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Ar Zaharovs</td><td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kW>5:2 K</td>
<td class=kW>3:1 K</td>
<td class=kW>1:0</td>
<td class=kL>1:4 K</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>1:4 K</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kL>3:4 K</td>
<td class=kW>3:2</td>
<td class=kL>4:5</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>3:5 K</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>4:1 K</td>
<td class=br>90:69</td><td class=br>+21</td>
<td class=bc>19 - 3 - 9</td>
<td class=br><strong>41</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Ma Lezik</td><td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>1:8</td>
<td class=kL>4:5</td>
<td class=kW>4:2 K</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>2:0 K</td>
<td class=kW>7:2</td>
<td class=kL>3:5</td>
<td class=kL>5:7</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>5:1 K</td>
<td class=kT>4:4</td>
<td class=kW>7:4</td>
<td class=kW>5:3 K</td>
<td class=kT>4:4</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>3:2 K</td>
<td class=kL>2:5 K</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kT>3:3 K</td>
<td class=kW>3:1</td>
<td class=br>114:90</td><td class=br>+24</td>
<td class=bc>15 - 9 - 7</td>
<td class=br><strong>39</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>To Uimonen</td><td class=kW>5:3 K</td>
<td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:0 K</td>
<td class=kT>2:2</td>
<td class=kW>3:2 K</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kT>3:3 K</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=kW>4:2 K</td>
<td class=kL>1:6</td>
<td class=kW>3:2 K</td>
<td class=kW>4:3 K</td>
<td class=kW>5:1</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>6:4</td>
<td class=br>91:91</td><td class=br>0</td>
<td class=bc>17 - 5 - 9</td>
<td class=br><strong>39</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>J� Re�is</td><td class=kL>3:4</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kW>8:5</td>
<td class=kL>2:3 K</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>0:2 K</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kT>1:1</td>
<td class=kL>4:7</td>
<td class=kW>6:0</td>
<td class=kL>1:5</td>
<td class=kW>4:1 K</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>6:2 K</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kW>2:1 K</td>
<td class=kW>3:1 K</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>6:5</td>
<td class=kW>4:3 K</td>
<td class=kW>6:2</td>
<td class=br>111:86</td><td class=br>+25</td>
<td class=bc>17 - 5 - 9</td>
<td class=br><strong>39</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Ma Madera</td><td class=kL>0:6 K</td>
<td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kL>3:6</td>
<td class=kL>1:8</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kL>2:7</td>
<td class=kL>0:3 K</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>5:3 K</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>7:2 K</td>
<td class=kW>2:1</td>
<td class=kT>0:0</td>
<td class=kW>2:1 K</td>
<td class=kW>4:2</td>
<td class=kL>1:3 K</td>
<td class=kL>2:3 K</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>5:4</td>
<td class=br>92:86</td><td class=br>+6</td>
<td class=bc>16 - 5 - 10</td>
<td class=br><strong>37</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>Lu Jurka</td><td class=kL>1:7</td>
<td class=kL>1:4 K</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kL>0:2 K</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>7:3 K</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>6:2 K</td>
<td class=kW>2:1 K</td>
<td class=kW>3:2 K</td>
<td class=kW>4:1</td>
<td class=kT>3:3 K</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=br>82:72</td><td class=br>+10</td>
<td class=bc>16 - 4 - 11</td>
<td class=br><strong>36</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>Em Liepi��</td><td class=kL>1:2 K</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kT>5:5</td>
<td class=kT>3:3</td>
<td class=kW>7:5</td>
<td class=kL>2:3 K</td>
<td class=kW>7:4</td>
<td class=kL>3:5 K</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kL>1:6 K</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>5:3 K</td>
<td class=kW>7:2</td>
<td class=kL>3:4 K</td>
<td class=kT>4:4 K</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kT>6:6</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>9:2</td>
<td class=kW>4:3</td>
<td class=br>124:99</td><td class=br>+25</td>
<td class=bc>15 - 5 - 11</td>
<td class=br><strong>35</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>Ro Rieksti��</td><td class=kL>0:7</td>
<td class=kW>5:2 K</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kL>0:6</td>
<td class=kW>3:1</td>
<td class=kW>2:0 K</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>4:5 K</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kW>3:2 K</td>
<td class=kW>3:2 K</td>
<td class=kW>5:2 K</td>
<td class=kL>1:4</td>
<td class=kT>4:4 K</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=br>84:84</td><td class=br>0</td>
<td class=bc>15 - 3 - 13</td>
<td class=br><strong>33</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>Kr Lebl</td><td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kL>0:6 K</td>
<td class=kT>3:3 K</td>
<td class=kL>1:3</td>
<td class=kW>6:5 K</td>
<td class=kW>4:1 K</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:7</td>
<td class=kL>2:4 K</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kW>7:0</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kL>4:9 K</td>
<td class=br>88:90</td><td class=br>-2</td>
<td class=bc>12 - 8 - 11</td>
<td class=br><strong>32</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>Ma Jakseboga</td><td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=kL>1:2 K</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kL>1:5 K</td>
<td class=kL>1:3</td>
<td class=kL>1:4 K</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1 K</td>
<td class=kT>0:0</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>3:2 K</td>
<td class=kW>2:1 K</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=br>76:77</td><td class=br>-1</td>
<td class=bc>9 - 13 - 9</td>
<td class=br><strong>31</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Je Zaharovs</td><td class=kL>1:2 K</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kT>3:3 K</td>
<td class=kL>3:5</td>
<td class=kL>2:7 K</td>
<td class=kW>5:3</td>
<td class=kW>6:1 K</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kL>0:5 K</td>
<td class=kW>5:1</td>
<td class=kW>3:1 K</td>
<td class=kW>3:2 K</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kL>3:6</td>
<td class=kW>7:3</td>
<td class=kL>3:7</td>
<td class=kW>7:1</td>
<td class=br>100:102</td><td class=br>-2</td>
<td class=bc>12 - 5 - 14</td>
<td class=br><strong>29</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>In Garan�s</td><td class=kL>0:6</td>
<td class=kL>5:7</td>
<td class=kL>2:6 K</td>
<td class=kL>2:5 K</td>
<td class=kW>3:2</td>
<td class=kL>0:5 K</td>
<td class=kW>4:3 K</td>
<td class=kL>4:7</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kW>4:2 K</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kT>1:1 K</td>
<td class=kW>6:3</td>
<td class=kW>6:2</td>
<td class=kW>3:2 K</td>
<td class=br>85:104</td><td class=br>-19</td>
<td class=bc>13 - 3 - 15</td>
<td class=br><strong>29</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Se Mihejevs</td><td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>0:2 K</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>3:5 K</td>
<td class=kL>3:6</td>
<td class=kL>2:6 K</td>
<td class=kT>0:0</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>1:5 K</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kW>4:1</td>
<td class=kT>2:2 K</td>
<td class=kL>0:1 K</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1</td>
<td class=br>59:79</td><td class=br>-20</td>
<td class=bc>11 - 6 - 14</td>
<td class=br><strong>28</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>J� Bitmanis</td><td class=kL>1:3 K</td>
<td class=kL>0:3</td>
<td class=kL>4:8</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kW>2:0</td>
<td class=kW>5:4</td>
<td class=kT>4:4</td>
<td class=kL>2:4 K</td>
<td class=kT>2:2</td>
<td class=kL>1:2 K</td>
<td class=kL>2:3</td>
<td class=kL>3:5 K</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kT>0:0</td>
<td class=kW>5:0 K</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kL>0:3 K</td>
<td class=kL>2:4 K</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=br>82:79</td><td class=br>+3</td>
<td class=bc>11 - 6 - 14</td>
<td class=br><strong>28</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>An Kuz�ecovs</td><td class=kL>4:8</td>
<td class=kL>3:7 K</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>3:7 K</td>
<td class=kL>2:7</td>
<td class=kW>5:4 K</td>
<td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>9:2</td>
<td class=kW>9:2</td>
<td class=kW>5:3</td>
<td class=kT>2:2 K</td>
<td class=kL>2:4 K</td>
<td class=kL>3:4 K</td>
<td class=kW>5:4</td>
<td class=kT>3:3 K</td>
<td class=kW>4:0</td>
<td class=kW>6:5</td>
<td class=br>109:123</td><td class=br>-14</td>
<td class=bc>11 - 5 - 15</td>
<td class=br><strong>27</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Kr Zem�ickis</td><td class=kL>1:4 K</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kW>4:0</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kL>2:3 K</td>
<td class=kW>5:3</td>
<td class=kW>3:1 K</td>
<td class=kT>1:1</td>
<td class=kW>4:3 K</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kL>0:3</td>
<td class=kL>1:3 K</td>
<td class=kL>3:5</td>
<td class=kW>5:0</td>
<td class=kW>3:0 K</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>3:2 K</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=br>69:88</td><td class=br>-19</td>
<td class=bc>12 - 3 - 16</td>
<td class=br><strong>27</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Va Dietze</td><td class=kL>1:6 K</td>
<td class=kL>5:7</td>
<td class=kL>3:7</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>4:7</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>3:4 K</td>
<td class=kL>3:4</td>
<td class=kW>3:2 K</td>
<td class=kL>0:2</td>
<td class=kT>4:4 K</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kL>2:3 K</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kW>4:2 K</td>
<td class=kL>2:9</td>
<td class=kL>2:3 K</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kT>4:4</td>
<td class=kW>7:3</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=br>99:105</td><td class=br>-6</td>
<td class=bc>11 - 2 - 18</td>
<td class=br><strong>24</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Ro Fa�ken�teins</td><td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>1:4 K</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>2:3 K</td>
<td class=kL>1:5</td>
<td class=kL>1:2 K</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kL>0:7</td>
<td class=kL>2:3 K</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kL>2:9</td>
<td class=kW>4:1</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>2:1 K</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>5:3 K</td>
<td class=kL>0:4</td>
<td class=br>64:108</td><td class=br>-44</td>
<td class=bc>9 - 5 - 17</td>
<td class=br><strong>23</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt>Sa Krasts</td><td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2 K</td>
<td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kW>5:2 K</td>
<td class=kW>6:2</td>
<td class=kL>1:3 K</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>1:2 K</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>1:0 K</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kL>1:2 K</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1 K</td>
<td class=kW>4:3</td>
<td class=br>61:77</td><td class=br>-16</td>
<td class=bc>9 - 5 - 17</td>
<td class=br><strong>23</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt>My Shalomayev</td><td class=kL>3:5</td>
<td class=kL>1:5 K</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>2:6 K</td>
<td class=kW>3:2</td>
<td class=kL>2:3 K</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2 K</td>
<td class=kW>3:0</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kT>4:4 K</td>
<td class=kW>6:2 K</td>
<td class=kW>3:2</td>
<td class=kW>3:1 K</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=br>76:96</td><td class=br>-20</td>
<td class=bc>8 - 6 - 17</td>
<td class=br><strong>22</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt>Ar Tseluiko</td><td class=kL>2:4</td>
<td class=kL>2:4 K</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kL>1:2 K</td>
<td class=kL>1:6</td>
<td class=kL>2:3 K</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kW>4:2 K</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kL>0:3</td>
<td class=kT>4:4 K</td>
<td class=kx>*</td>
<td class=kL>1:7 K</td>
<td class=kW>2:1</td>
<td class=kW>5:2 K</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=br>74:113</td><td class=br>-39</td>
<td class=bc>8 - 4 - 19</td>
<td class=br><strong>20</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt>An Fjermestad</td><td class=kL>1:3</td>
<td class=kL>1:7 K</td>
<td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>2:3 K</td>
<td class=kT>6:6</td>
<td class=kL>2:5 K</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kL>4:5</td>
<td class=kL>1:6</td>
<td class=kW>4:3 K</td>
<td class=kW>4:0</td>
<td class=kL>3:7</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kL>2:6 K</td>
<td class=kW>7:1 K</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:4 K</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=br>79:126</td><td class=br>-47</td>
<td class=bc>6 - 6 - 19</td>
<td class=br><strong>18</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt>Pe Fuchs</td><td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>1:5 K</td>
<td class=kL>1:2 K</td>
<td class=kL>0:4</td>
<td class=kL>1:2 K</td>
<td class=kW>5:3 K</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>3:0 K</td>
<td class=br>56:97</td><td class=br>-41</td>
<td class=bc>4 - 7 - 20</td>
<td class=br><strong>15</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt>Pa Plesak</td><td class=kL>0:4</td>
<td class=kL>5:9 K</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kL>5:6</td>
<td class=kL>0:4</td>
<td class=kT>3:3 K</td>
<td class=kL>2:6</td>
<td class=kT>4:4 K</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>3:7</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kT>3:3 K</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>1:3 K</td>
<td class=kL>2:5 K</td>
<td class=kL>4:5 K</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=br>79:124</td><td class=br>-45</td>
<td class=bc>3 - 8 - 20</td>
<td class=br><strong>14</strong></td><td class=d>30.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>31.</td><td class=kt>Il Pavlovskis</td><td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>1:5 K</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kT>3:3 K</td>
<td class=kL>2:4</td>
<td class=kL>3:4 K</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>2:9</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kT>1:1 K</td>
<td class=kW>7:3</td>
<td class=kL>2:6</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>3:5 K</td>
<td class=kL>1:3 K</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>8:2</td>
<td class=br>54:132</td><td class=br>-78</td>
<td class=bc>2 - 5 - 24</td>
<td class=br><strong>9</strong></td><td class=d>31.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>32.</td><td class=kt>Ed Putni��</td><td class=kL>3:4</td>
<td class=kL>0:8</td>
<td class=kL>2:10 K</td>
<td class=kW>3:2 K</td>
<td class=kL>1:7</td>
<td class=kL>1:6 K</td>
<td class=kL>1:4 K</td>
<td class=kL>1:3</td>
<td class=kL>4:6</td>
<td class=kL>2:6</td>
<td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kW>9:4 K</td>
<td class=kT>2:2</td>
<td class=kL>1:7</td>
<td class=kL>2:3 K</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>5:6</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kW>4:0</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kL>0:3 K</td>
<td class=kL>4:5</td>
<td class=kL>2:8</td>
<td class=kx>*</td>
<td class=br>73:142</td><td class=br>-69</td>
<td class=bc>4 - 1 - 26</td>
<td class=br><strong>9</strong></td><td class=d>32.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>To Uimonen</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ma Lezik</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Pa Plesak</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>To Uimonen</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>Ma Lezik</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>9 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>To Uimonen</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ma Lezik</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>To Uimonen</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=bl>Ma Lezik</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>To Uimonen</td><td class=bc>-</td><td class=blW>Ma Lezik</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Ar Tseluiko</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>To Uimonen</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Ar Tseluiko</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=blW>Ma Lezik</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ma Lezik</td><td class=bc>7 : 5</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>To Uimonen</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>5 : 7</tr></td>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ar Tseluiko</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Ma Lezik</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=blW>Il Pavlovskis</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>To Uimonen</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ma Lezik</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ar Tseluiko</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>To Uimonen</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=bl>Ma Lezik</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>To Uimonen</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Ma Lezik</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>El Sili��</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>To Uimonen</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Ma Lezik</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>To Uimonen</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Ma Lezik</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>To Uimonen</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Ma Lezik</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>To Uimonen</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Ma Lezik</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>In Garan�s</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>To Uimonen</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>Ma Lezik</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ar Tseluiko</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Il Pavlovskis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>To Uimonen</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>In Garan�s</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>To Uimonen</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ma Lezik</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>8 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ma Lezik</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>6 : 6</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>To Uimonen</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Lezik</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>8 : 5</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=bl>To Uimonen</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ma Lezik</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=bl>To Uimonen</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Lezik</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>To Uimonen</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>In Garan�s</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=bl>To Uimonen</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Lezik</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>To Uimonen</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>7 : 5</tr></td>
<tr><td class=brW>Ma Lezik</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>To Uimonen</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>In Garan�s</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ar Tseluiko</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Il Pavlovskis</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Lezik</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>2 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 3.league</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt>Di Ziemelis</td><td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=kL>4:5</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>6:4</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>7:4</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=br>102:43</td><td class=br>+59</td>
<td class=bc>22 - 0 - 1</td>
<td class=br><strong>44</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt>Gi Lasmanis</td><td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>8:2</td>
<td class=kW>4:1</td>
<td class=kW>9:4</td>
<td class=kW>8:4</td>
<td class=kW>5:4</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>8:0</td>
<td class=br>107:50</td><td class=br>+57</td>
<td class=bc>17 - 1 - 5</td>
<td class=br><strong>35</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt>Si Pleikys</td><td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kW>7:3</td>
<td class=kW>3:1</td>
<td class=kW>8:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>7:0</td>
<td class=kW>3:2</td>
<td class=br>84:52</td><td class=br>+32</td>
<td class=bc>15 - 2 - 6</td>
<td class=br><strong>32</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt>Le Maz�rs</td><td class=kW>5:4</td>
<td class=kL>2:8</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kL>5:6</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=br>86:64</td><td class=br>+22</td>
<td class=bc>14 - 3 - 6</td>
<td class=br><strong>31</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ro Kerns</td><td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=br>63:50</td><td class=br>+13</td>
<td class=bc>12 - 4 - 7</td>
<td class=br><strong>28</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Da Baumanis</td><td class=kL>1:3</td>
<td class=kL>4:9</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kT>5:5</td>
<td class=kW>7:3</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>6:4</td>
<td class=kW>3:2</td>
<td class=br>74:70</td><td class=br>+4</td>
<td class=bc>11 - 5 - 7</td>
<td class=br><strong>27</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Ma Satkus</td><td class=kL>3:4</td>
<td class=kL>4:8</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>2:7</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kW>8:7</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=br>77:81</td><td class=br>-4</td>
<td class=bc>11 - 3 - 9</td>
<td class=br><strong>25</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ra Neija</td><td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kW>2:0</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kL>2:7</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kL>4:6</td>
<td class=kW>5:1</td>
<td class=kL>5:7</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>8:2</td>
<td class=br>81:75</td><td class=br>+6</td>
<td class=bc>10 - 4 - 9</td>
<td class=br><strong>24</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ra Martu��ns</td><td class=kL>4:6</td>
<td class=kL>2:5</td>
<td class=kL>3:7</td>
<td class=kW>6:5</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=br>64:67</td><td class=br>-3</td>
<td class=bc>10 - 4 - 9</td>
<td class=br><strong>24</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Vi Lapi��</td><td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kL>0:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>3:5</td>
<td class=kW>3:0</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=br>59:58</td><td class=br>+1</td>
<td class=bc>11 - 1 - 11</td>
<td class=br><strong>23</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ka �iha�ova</td><td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>2:8</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kL>4:7</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=br>72:66</td><td class=br>+6</td>
<td class=bc>10 - 2 - 11</td>
<td class=br><strong>22</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>My Razkevich</td><td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kT>5:5</td>
<td class=kW>7:2</td>
<td class=kW>6:4</td>
<td class=kW>5:1</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=br>65:74</td><td class=br>-9</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>My Verbytskyy</td><td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>3:7</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kW>1:0</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=br>50:63</td><td class=br>-13</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>J� Z�l�te</td><td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kL>3:5</td>
<td class=kW>7:5</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kL>3:5</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=br>69:74</td><td class=br>-5</td>
<td class=bc>9 - 2 - 12</td>
<td class=br><strong>20</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Kr Kurzemnieks</td><td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kW>4:0</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=br>57:70</td><td class=br>-13</td>
<td class=bc>9 - 2 - 12</td>
<td class=br><strong>20</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Marg �bele</td><td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>7:8</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>0:5</td>
<td class=kT>0:0</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=br>58:76</td><td class=br>-18</td>
<td class=bc>6 - 7 - 10</td>
<td class=br><strong>19</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Il �irse</td><td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=br>58:75</td><td class=br>-17</td>
<td class=bc>8 - 3 - 12</td>
<td class=br><strong>19</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Ka Vi�ums</td><td class=kL>4:7</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kL>0:5</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=br>62:72</td><td class=br>-10</td>
<td class=bc>8 - 2 - 13</td>
<td class=br><strong>18</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Ro Aseri��</td><td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kW>5:3</td>
<td class=kL>0:1</td>
<td class=kT>0:0</td>
<td class=kW>1:0</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=br>41:62</td><td class=br>-21</td>
<td class=bc>7 - 3 - 13</td>
<td class=br><strong>17</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Kr Zarinieks</td><td class=kL>1:6</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kW>5:4</td>
<td class=kW>7:4</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kL>5:6</td>
<td class=br>73:96</td><td class=br>-23</td>
<td class=bc>8 - 1 - 14</td>
<td class=br><strong>17</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Ra Pommerenke</td><td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=br>50:60</td><td class=br>-10</td>
<td class=bc>5 - 7 - 11</td>
<td class=br><strong>17</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Jo Pleikys</td><td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=br>56:66</td><td class=br>-10</td>
<td class=bc>7 - 3 - 13</td>
<td class=br><strong>17</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Ha Janvars</td><td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kL>0:7</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>4:6</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=br>50:67</td><td class=br>-17</td>
<td class=bc>7 - 3 - 13</td>
<td class=br><strong>17</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Ag Pav�rs</td><td class=kL>0:3</td>
<td class=kL>0:8</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>2:8</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kW>6:5</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=br>54:81</td><td class=br>-27</td>
<td class=bc>7 - 0 - 16</td>
<td class=br><strong>14</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ha Janvars</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Le Maz�rs</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ka �iha�ova</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>My Razkevich</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>Vi Lapi��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Le Maz�rs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ha Janvars</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=blW>Ra Martu��ns</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>My Razkevich</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Vi Lapi��</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Le Maz�rs</td><td class=bc>-</td><td class=blW>Kr Kurzemnieks</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ha Janvars</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ka �iha�ova</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Vi Lapi��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Le Maz�rs</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ha Janvars</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Vi Lapi��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Le Maz�rs</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>My Razkevich</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ha Janvars</td><td class=bc>-</td><td class=blW>Vi Lapi��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ka �iha�ova</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Ra Martu��ns</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Le Maz�rs</td><td class=bc>-</td><td class=bl>Vi Lapi��</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ha Janvars</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Vi Lapi��</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Le Maz�rs</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ha Janvars</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=blW>Jo Pleikys</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>7 : 8</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ka Vi�ums</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=blW>Vi Lapi��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Le Maz�rs</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ha Janvars</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>Vi Lapi��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Le Maz�rs</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ha Janvars</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ka �iha�ova</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Vi Lapi��</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>My Razkevich</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Jo Pleikys</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Le Maz�rs</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ha Janvars</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>8 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Vi Lapi��</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>My Razkevich</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Le Maz�rs</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ha Janvars</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ra Neija</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>4 : 9</tr></td>
<tr><td class=br>Vi Lapi��</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ka Vi�ums</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Le Maz�rs</td><td class=bc>-</td><td class=blW>Ka �iha�ova</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ha Janvars</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vi Lapi��</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ka Vi�ums</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Ka �iha�ova</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Le Maz�rs</td><td class=bc>-</td><td class=bl>Ha Janvars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Jo Pleikys</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vi Lapi��</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Ka �iha�ova</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Ha Janvars</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Le Maz�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Jo Pleikys</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Vi Lapi��</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Ha Janvars</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Le Maz�rs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ra Neija</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Vi Lapi��</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>Ha Janvars</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ka Vi�ums</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Le Maz�rs</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Ha Janvars</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Vi Lapi��</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>My Razkevich</td><td class=bc>-</td><td class=bl>Le Maz�rs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Kr Kurzemnieks</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ra Martu��ns</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Jo Pleikys</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Ka �iha�ova</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Ha Janvars</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ra Neija</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Le Maz�rs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vi Lapi��</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>My Razkevich</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ra Martu��ns</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Ha Janvars</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Le Maz�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ra Neija</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vi Lapi��</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>My Razkevich</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Ka �iha�ova</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Jo Pleikys</td><td class=bc>-</td><td class=bl>Ha Janvars</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Le Maz�rs</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>5 : 7</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Ra Martu��ns</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vi Lapi��</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ha Janvars</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>Le Maz�rs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ra Martu��ns</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ra Neija</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Vi Lapi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=brW>Ka �iha�ova</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Ha Janvars</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Le Maz�rs</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Jo Pleikys</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Ra Martu��ns</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>My Razkevich</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=blW>Vi Lapi��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Ha Janvars</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ka �iha�ova</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>Le Maz�rs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>Ra Martu��ns</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Vi Lapi��</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Le Maz�rs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ka �iha�ova</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ra Martu��ns</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Vi Lapi��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 4.league</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt>Au Pleikys</td><td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=br>88:38</td><td class=br>+50</td>
<td class=bc>17 - 4 - 2</td>
<td class=br><strong>38</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt>Al Hermansson</td><td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>11:4</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=br>91:44</td><td class=br>+47</td>
<td class=bc>19 - 0 - 4</td>
<td class=br><strong>38</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt>Ma Krauze</td><td class=kL>1:2</td>
<td class=kW>7:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>0:6</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=br>70:39</td><td class=br>+31</td>
<td class=bc>15 - 3 - 5</td>
<td class=br><strong>33</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt>He Petuch</td><td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>7:4</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>7:3</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>6:0</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=br>73:45</td><td class=br>+28</td>
<td class=bc>13 - 5 - 5</td>
<td class=br><strong>31</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Vl Voronov</td><td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kT>4:4</td>
<td class=kW>6:4</td>
<td class=kT>5:5</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=br>69:53</td><td class=br>+16</td>
<td class=bc>12 - 5 - 6</td>
<td class=br><strong>29</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ai Romals</td><td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>4:7</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>8:0</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>7:1</td>
<td class=kL>2:4</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>8:3</td>
<td class=kL>1:2</td>
<td class=kW>6:2</td>
<td class=br>78:61</td><td class=br>+17</td>
<td class=bc>12 - 4 - 7</td>
<td class=br><strong>28</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>M� �irsis</td><td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>7:0</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=br>63:49</td><td class=br>+14</td>
<td class=bc>10 - 8 - 5</td>
<td class=br><strong>28</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>To Jakseboga</td><td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>4:6</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=br>58:40</td><td class=br>+18</td>
<td class=bc>12 - 3 - 8</td>
<td class=br><strong>27</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>On Gruncl</td><td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kT>5:5</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>7:2</td>
<td class=kL>0:1</td>
<td class=kW>3:0</td>
<td class=br>65:53</td><td class=br>+12</td>
<td class=bc>10 - 7 - 6</td>
<td class=br><strong>27</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>�v Vikmanis</td><td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kW>4:2</td>
<td class=kL>3:7</td>
<td class=kW>4:2</td>
<td class=kL>0:8</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=br>63:65</td><td class=br>-2</td>
<td class=bc>10 - 5 - 8</td>
<td class=br><strong>25</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>D� Vesele</td><td class=kL>3:4</td>
<td class=kL>2:7</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=br>63:63</td><td class=br>0</td>
<td class=bc>8 - 9 - 6</td>
<td class=br><strong>25</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Gi Remeika</td><td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kW>6:0</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>65:52</td><td class=br>+13</td>
<td class=bc>10 - 3 - 10</td>
<td class=br><strong>23</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Re Saul�tis</td><td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>1:6</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=br>58:56</td><td class=br>+2</td>
<td class=bc>9 - 4 - 10</td>
<td class=br><strong>22</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Fr Platons</td><td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>8:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=br>54:51</td><td class=br>+3</td>
<td class=bc>8 - 5 - 10</td>
<td class=br><strong>21</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Er Kalni��</td><td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kW>7:1</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=br>60:58</td><td class=br>+2</td>
<td class=bc>6 - 8 - 9</td>
<td class=br><strong>20</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>L� Bezdel�ga</td><td class=kW>4:3</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kW>6:3</td>
<td class=br>50:63</td><td class=br>-13</td>
<td class=bc>8 - 3 - 12</td>
<td class=br><strong>19</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>�i Vazoli��</td><td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=br>44:62</td><td class=br>-18</td>
<td class=bc>7 - 5 - 11</td>
<td class=br><strong>19</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>J� Zem�ickis</td><td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=br>34:54</td><td class=br>-20</td>
<td class=bc>5 - 8 - 10</td>
<td class=br><strong>18</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>An Kova��uks</td><td class=kL>1:3</td>
<td class=kL>4:11</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kL>1:7</td>
<td class=kW>4:2</td>
<td class=kL>0:7</td>
<td class=kT>2:2</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>2:6</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=br>63:86</td><td class=br>-23</td>
<td class=bc>6 - 6 - 11</td>
<td class=br><strong>18</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Al Liepi��</td><td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=br>40:71</td><td class=br>-31</td>
<td class=bc>5 - 6 - 12</td>
<td class=br><strong>16</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Em Ka�s</td><td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kL>4:6</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=br>39:73</td><td class=br>-34</td>
<td class=bc>7 - 1 - 15</td>
<td class=br><strong>15</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>As Kocere</td><td class=kL>2:7</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>3:8</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>2:8</td>
<td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kL>0:3</td>
<td class=kW>6:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=br>62:94</td><td class=br>-32</td>
<td class=bc>6 - 2 - 15</td>
<td class=br><strong>14</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Kr S�manis</td><td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>31:63</td><td class=br>-32</td>
<td class=bc>5 - 3 - 15</td>
<td class=br><strong>13</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Au Breidaks</td><td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>34:82</td><td class=br>-48</td>
<td class=bc>1 - 3 - 19</td>
<td class=br><strong>5</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>�i Vazoli��</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Al Hermansson</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>11 : 4</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr S�manis</td><td class=bc>-</td><td class=bl>Au Breidaks</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Vl Voronov</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Al Hermansson</td><td class=bc>-</td><td class=bl>Au Breidaks</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kr S�manis</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vl Voronov</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>�i Vazoli��</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=bl>Au Breidaks</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Hermansson</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Gi Remeika</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vl Voronov</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Au Breidaks</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Al Hermansson</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Kr S�manis</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Gi Remeika</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vl Voronov</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Au Breidaks</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>On Gruncl</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Al Hermansson</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vl Voronov</td><td class=bc>-</td><td class=bl>Au Breidaks</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>Au Breidaks</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>Au Breidaks</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>On Gruncl</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Gi Remeika</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Vl Voronov</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>Al Hermansson</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>Au Breidaks</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Gi Remeika</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>�i Vazoli��</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>Au Breidaks</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>An Kova��uks</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>On Gruncl</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>Kr S�manis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Al Hermansson</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Au Breidaks</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>Al Hermansson</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Er Kalni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vl Voronov</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>On Gruncl</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Au Breidaks</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>An Kova��uks</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Al Hermansson</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Vl Voronov</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Au Breidaks</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Al Hermansson</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Al Hermansson</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Au Breidaks</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Er Kalni��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Vl Voronov</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Al Hermansson</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>On Gruncl</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Au Breidaks</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Vl Voronov</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>Al Hermansson</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Au Breidaks</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Vl Voronov</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kr S�manis</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>On Gruncl</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Au Breidaks</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Al Hermansson</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>�i Vazoli��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>On Gruncl</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Au Breidaks</td><td class=bc>-</td><td class=blW>Gi Remeika</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>An Kova��uks</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Al Hermansson</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=blW>Gi Remeika</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Au Breidaks</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Al Hermansson</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>Vl Voronov</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Gi Remeika</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Au Breidaks</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>�i Vazoli��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Al Hermansson</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Gi Remeika</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>On Gruncl</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Au Breidaks</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Gi Remeika</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Al Hermansson</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>On Gruncl</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Au Breidaks</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>�i Vazoli��</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Gi Remeika</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Al Hermansson</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>As Kocere</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>On Gruncl</td><td class=bc>-</td><td class=bl>Au Breidaks</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>�i Vazoli��</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Al Hermansson</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=bl>Au Breidaks</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 5.league</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt>Em Uimonen</td><td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>8:2</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=br>64:14</td><td class=br>+50</td>
<td class=bc>18 - 0 - 0</td>
<td class=br><strong>36</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt>Vo Kvasnikov</td><td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=br>62:23</td><td class=br>+39</td>
<td class=bc>14 - 1 - 3</td>
<td class=br><strong>29</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt>Ge Jansons</td><td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kL>4:6</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=br>51:23</td><td class=br>+28</td>
<td class=bc>14 - 0 - 4</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt>Br Gor�anovs</td><td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>8:3</td>
<td class=kW>5:3</td>
<td class=kW>7:3</td>
<td class=kW>6:4</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=br>74:42</td><td class=br>+32</td>
<td class=bc>12 - 1 - 5</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>El Reinfelds</td><td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=kL>1:6</td>
<td class=kW>7:1</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=br>58:42</td><td class=br>+16</td>
<td class=bc>10 - 3 - 5</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ma Kalni��</td><td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kT>0:0</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>45:29</td><td class=br>+16</td>
<td class=bc>11 - 1 - 6</td>
<td class=br><strong>23</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Ed Liepi��</td><td class=kL>0:1</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kT>0:0</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=br>49:34</td><td class=br>+15</td>
<td class=bc>10 - 2 - 6</td>
<td class=br><strong>22</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Da Belkovs</td><td class=kL>2:8</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>8:3</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>8:3</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>60:52</td><td class=br>+8</td>
<td class=bc>9 - 2 - 7</td>
<td class=br><strong>20</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>T� Gor�anova</td><td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kL>3:8</td>
<td class=kx>*</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>42:39</td><td class=br>+3</td>
<td class=bc>8 - 3 - 7</td>
<td class=br><strong>19</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Al Sili��</td><td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>3:8</td>
<td class=kW>5:0</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kW>6:1</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>43:38</td><td class=br>+5</td>
<td class=bc>8 - 2 - 8</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ol Ozoli��-Karlsons</td><td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>43:42</td><td class=br>+1</td>
<td class=bc>7 - 4 - 7</td>
<td class=br><strong>18</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Re Tomsons</td><td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>3:7</td>
<td class=kL>0:7</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>36:36</td><td class=br>0</td>
<td class=bc>8 - 1 - 9</td>
<td class=br><strong>17</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ju Stei��nas</td><td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kW>6:4</td>
<td class=kL>4:6</td>
<td class=kW>6:1</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>49:54</td><td class=br>-5</td>
<td class=bc>4 - 6 - 8</td>
<td class=br><strong>14</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Em Vi��akovs</td><td class=kL>3:4</td>
<td class=kL>0:6</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kL>1:7</td>
<td class=kL>0:2</td>
<td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>3:0</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kT>0:0</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kW>5:0</td>
<td class=br>29:40</td><td class=br>-11</td>
<td class=bc>3 - 6 - 9</td>
<td class=br><strong>12</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Da Ra�ko</td><td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kL>3:8</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kW>5:0</td>
<td class=br>34:62</td><td class=br>-28</td>
<td class=bc>5 - 2 - 11</td>
<td class=br><strong>12</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Ri D�cis</td><td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kL>3:5</td>
<td class=kT>0:0</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=br>29:47</td><td class=br>-18</td>
<td class=bc>3 - 5 - 10</td>
<td class=br><strong>11</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Re Masulis</td><td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>20:52</td><td class=br>-32</td>
<td class=bc>3 - 3 - 12</td>
<td class=br><strong>9</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>K� Breidaks</td><td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>0:7</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kT>0:0</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=br>25:54</td><td class=br>-29</td>
<td class=bc>2 - 2 - 14</td>
<td class=br><strong>6</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>M� Timbers</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=br>0:90</td><td class=br>-90</td>
<td class=bc>0 - 0 - 18</td>
<td class=br><strong>0</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>El Reinfelds</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Em Uimonen</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Re Tomsons</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ol Ozoli��-Karlsons</td><td class=bc>-</td><td class=blW>Em Vi��akovs</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Da Ra�ko</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>K� Breidaks</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ed Liepi��</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Re Masulis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>El Reinfelds</td><td class=bc>-</td><td class=bl>Re Tomsons</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Em Uimonen</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Da Ra�ko</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ol Ozoli��-Karlsons</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>K� Breidaks</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ed Liepi��</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>Re Tomsons</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Em Vi��akovs</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>El Reinfelds</td><td class=bc>-</td><td class=bl>Da Ra�ko</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Em Uimonen</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>K� Breidaks</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ol Ozoli��-Karlsons</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Re Tomsons</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=bl>Da Ra�ko</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Ri D�cis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>El Reinfelds</td><td class=bc>-</td><td class=bl>K� Breidaks</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Em Uimonen</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ol Ozoli��-Karlsons</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Ge Jansons</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Em Vi��akovs</td><td class=bc>-</td><td class=bl>Da Ra�ko</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Re Tomsons</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Re Masulis</td><td class=bc>-</td><td class=bl>K� Breidaks</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Da Belkovs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Em Uimonen</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ge Jansons</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ol Ozoli��-Karlsons</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Ma Kalni��</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Da Ra�ko</td><td class=bc>-</td><td class=blW>Ri D�cis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=bl>K� Breidaks</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Re Tomsons</td><td class=bc>-</td><td class=blW>Da Belkovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Ju Stei��nas</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ge Jansons</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Em Uimonen</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ma Kalni��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ol Ozoli��-Karlsons</td><td class=bc>-</td><td class=blW>Vo Kvasnikov</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=bl>K� Breidaks</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Ra�ko</td><td class=bc>-</td><td class=blW>Da Belkovs</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Re Tomsons</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>Ge Jansons</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>El Reinfelds</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Em Uimonen</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>3 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>K� Breidaks</td><td class=bc>-</td><td class=blW>Da Belkovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Ra�ko</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Ge Jansons</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Re Tomsons</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>Ma Kalni��</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Vo Kvasnikov</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Em Uimonen</td><td class=bc>-</td><td class=bl>Ol Ozoli��-Karlsons</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>K� Breidaks</td><td class=bc>-</td><td class=blW>Ju Stei��nas</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>Ge Jansons</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Ra�ko</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Ma Kalni��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Re Tomsons</td><td class=bc>-</td><td class=blW>Vo Kvasnikov</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Ol Ozoli��-Karlsons</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>T� Gor�anova</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>Ge Jansons</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>K� Breidaks</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Da Ra�ko</td><td class=bc>-</td><td class=blW>Vo Kvasnikov</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Re Tomsons</td><td class=bc>-</td><td class=blW>Ol Ozoli��-Karlsons</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Em Uimonen</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ju Stei��nas</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>Ma Kalni��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>K� Breidaks</td><td class=bc>-</td><td class=blW>Vo Kvasnikov</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Da Ra�ko</td><td class=bc>-</td><td class=bl>Ol Ozoli��-Karlsons</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Re Tomsons</td><td class=bc>-</td><td class=blW>Em Uimonen</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Re Masulis</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ge Jansons</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=blW>Ma Kalni��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Vo Kvasnikov</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>K� Breidaks</td><td class=bc>-</td><td class=blW>Ol Ozoli��-Karlsons</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Ra�ko</td><td class=bc>-</td><td class=blW>Em Uimonen</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Re Tomsons</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ed Liepi��</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ge Jansons</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Ol Ozoli��-Karlsons</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>K� Breidaks</td><td class=bc>-</td><td class=blW>Em Uimonen</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Da Ra�ko</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Re Masulis</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>Vo Kvasnikov</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ge Jansons</td><td class=bc>-</td><td class=bl>Ol Ozoli��-Karlsons</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Em Uimonen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>K� Breidaks</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ri D�cis</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Da Ra�ko</td><td class=bc>-</td><td class=bl>Re Tomsons</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>Ol Ozoli��-Karlsons</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Em Uimonen</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ju Stei��nas</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>T� Gor�anova</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>K� Breidaks</td><td class=bc>-</td><td class=blW>Re Tomsons</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Ol Ozoli��-Karlsons</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>Em Uimonen</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ge Jansons</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=bl>Re Tomsons</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>K� Breidaks</td><td class=bc>-</td><td class=bl>Da Ra�ko</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ol Ozoli��-Karlsons</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Em Uimonen</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ed Liepi��</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ge Jansons</td><td class=bc>-</td><td class=bl>Re Tomsons</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Da Ra�ko</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Em Uimonen</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ol Ozoli��-Karlsons</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>Re Tomsons</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Ge Jansons</td><td class=bc>-</td><td class=bl>Da Ra�ko</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>T� Gor�anova</td><td class=bc>-</td><td class=bl>K� Breidaks</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Em Uimonen</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ol Ozoli��-Karlsons</td><td class=bc>-</td><td class=bl>Re Masulis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Re Tomsons</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>Da Ra�ko</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ed Liepi��</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ge Jansons</td><td class=bc>-</td><td class=bl>K� Breidaks</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>4 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
