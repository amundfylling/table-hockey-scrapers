<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Open Individual (O)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../24EChO/Open_Individual_(O)_index.php">Open Individual (O)</a></span></h2></div></div></div></div><h3 align="right">Final Groups&nbsp;&nbsp;</h3>
<p><div align="center">
<div align=center><p><a href="Open_Individual_(O)_crossB.php#basic">Basic groups</a><br>
<a href="Open_Individual_(O)_crossF.php#final">Final groups</a><br>
<hr><a name="final"><p class=vm>Final Groups</p></a>
<p class=v>Group OpenA1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>31</td>
<td class=ic>32</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=4&x=-61&p=Ed%20Caics">Ed Caics</a></td><td class=kx>*</td>
<td class=kL>2:5 K</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2 K</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kW>7:2</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>5:1 K</td>
<td class=kW>5:3 K</td>
<td class=kW>4:1</td>
<td class=kW>4:2 K</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1 K</td>
<td class=kW>6:2</td>
<td class=kW>9:2</td>
<td class=kW>6:2</td>
<td class=kW>3:0 K</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=br>120:58</td><td class=br>+62</td>
<td class=bc>24 - 3 - 4</td>
<td class=br><strong>51</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=368&x=-61&p=An%20Umanskyy">An Umanskyy</a></td><td class=kW>5:2 K</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3 K</td>
<td class=kL>1:3</td>
<td class=kW>10:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>5:2 K</td>
<td class=kW>8:3 K</td>
<td class=kW>2:1</td>
<td class=kL>1:2 K</td>
<td class=kL>0:2</td>
<td class=kW>5:2</td>
<td class=kL>2:3 K</td>
<td class=kW>6:2</td>
<td class=kW>7:2</td>
<td class=kW>7:3</td>
<td class=kW>5:3 K</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=br>126:64</td><td class=br>+62</td>
<td class=bc>21 - 1 - 9</td>
<td class=br><strong>43</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=101&x=-61&p=Ev%20Matantsev">Ev Matantsev</a></td><td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>6:5</td>
<td class=kW>4:3</td>
<td class=kT>4:4 K</td>
<td class=kL>2:3</td>
<td class=kL>2:3 K</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>6:3 K</td>
<td class=kW>5:4</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2 K</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=kW>3:1 K</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kW>6:3 K</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>9:5 K</td>
<td class=kW>4:1</td>
<td class=kW>7:4</td>
<td class=br>120:88</td><td class=br>+32</td>
<td class=bc>19 - 4 - 8</td>
<td class=br><strong>42</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=27&x=-61&p=El%20Sili%C5%86%C5%A1">El Sili��</a></td><td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kL>1:3 K</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kW>5:2 K</td>
<td class=kL>2:5 K</td>
<td class=kW>5:1 K</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:2 K</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>7:4</td>
<td class=kT>2:2</td>
<td class=kW>6:2 K</td>
<td class=kW>3:1 K</td>
<td class=br>90:69</td><td class=br>+21</td>
<td class=bc>18 - 6 - 7</td>
<td class=br><strong>42</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=92&x=-61&p=Va%20Smagars">Va Smagars</a></td><td class=kL>2:3 K</td>
<td class=kW>3:2 K</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kT>5:5</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>6:0</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kW>7:1 K</td>
<td class=kW>5:1 K</td>
<td class=kW>5:4</td>
<td class=kT>3:3 K</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>5:2 K</td>
<td class=kL>3:5</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kW>6:3 K</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=br>107:74</td><td class=br>+33</td>
<td class=bc>17 - 7 - 7</td>
<td class=br><strong>41</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=227&x=-61&p=Ha%20%C3%96sterman">Ha �sterman</a></td><td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>5:6</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kT>4:4 K</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=kW>3:1 K</td>
<td class=kW>1:0 K</td>
<td class=kW>4:0 K</td>
<td class=kW>6:1</td>
<td class=kL>2:5</td>
<td class=kW>2:0</td>
<td class=kL>2:3 K</td>
<td class=kW>6:1</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kL>1:4 K</td>
<td class=kW>2:0</td>
<td class=kW>4:3 K</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=br>93:65</td><td class=br>+28</td>
<td class=bc>19 - 3 - 9</td>
<td class=br><strong>41</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=423&x=-61&p=Ol%20Blume">Ol Blume</a></td><td class=kW>4:1</td>
<td class=kL>1:10</td>
<td class=kL>3:4</td>
<td class=kW>3:1 K</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>4:3 K</td>
<td class=kL>0:2 K</td>
<td class=kL>1:2 K</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>3:0 K</td>
<td class=kW>6:0</td>
<td class=kL>2:4</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>4:1 K</td>
<td class=kW>6:3 K</td>
<td class=br>91:76</td><td class=br>+15</td>
<td class=bc>17 - 4 - 10</td>
<td class=br><strong>38</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=240&x=-61&p=Ol%20Korabel">Ol Korabel</a></td><td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4 K</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>2:5 K</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kW>6:1</td>
<td class=kW>6:0 K</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=kL>2:3 K</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2 K</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kW>3:1 K</td>
<td class=kW>7:4</td>
<td class=kW>6:3</td>
<td class=kL>1:2 K</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=br>108:71</td><td class=br>+37</td>
<td class=bc>18 - 2 - 11</td>
<td class=br><strong>38</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=109&x=-61&p=Mi%20Kobrle">Mi Kobrle</a></td><td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kT>5:5</td>
<td class=kT>4:4 K</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>6:1 K</td>
<td class=kW>6:3 K</td>
<td class=kW>10:1 K</td>
<td class=kT>3:3</td>
<td class=kT>6:6</td>
<td class=kL>3:4</td>
<td class=kW>6:2 K</td>
<td class=kW>7:4</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kL>3:6 K</td>
<td class=kL>2:6</td>
<td class=kW>3:1 K</td>
<td class=kW>8:1</td>
<td class=kW>5:1</td>
<td class=kW>9:0</td>
<td class=kT>2:2</td>
<td class=br>122:90</td><td class=br>+32</td>
<td class=bc>12 - 12 - 7</td>
<td class=br><strong>36</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=212&x=-61&p=Di%20Ziemelis">Di Ziemelis</a></td><td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>3:2 K</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>5:2 K</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2 K</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kL>0:6</td>
<td class=kT>2:2 K</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kW>5:1 K</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>2:0 K</td>
<td class=kW>4:2</td>
<td class=kW>7:3</td>
<td class=kW>1:0 K</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=br>87:69</td><td class=br>+18</td>
<td class=bc>14 - 8 - 9</td>
<td class=br><strong>36</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=83&x=-61&p=To%20Baumanis">To Baumanis</a></td><td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>2:5 K</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kL>3:4 K</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>1:0 K</td>
<td class=kW>4:1 K</td>
<td class=kT>1:1</td>
<td class=kL>4:5</td>
<td class=kW>6:3</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>6:3</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kT>0:0 K</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kL>4:6</td>
<td class=kW>3:2</td>
<td class=kW>9:3</td>
<td class=kW>3:2 K</td>
<td class=kT>2:2 K</td>
<td class=br>90:74</td><td class=br>+16</td>
<td class=bc>12 - 12 - 7</td>
<td class=br><strong>36</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=28&x=-61&p=Sa%20Lagzdi%C5%86%C5%A1">Sa Lagzdi��</a></td><td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>5:2 K</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>2:0 K</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>0:1 K</td>
<td class=kx>*</td>
<td class=kL>2:5 K</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kL>2:3 K</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kW>6:3</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>3:2 K</td>
<td class=kW>7:1 K</td>
<td class=br>82:55</td><td class=br>+27</td>
<td class=bc>16 - 4 - 11</td>
<td class=br><strong>36</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt><a href="stats.php?idpl=239&x=-61&p=Be%20Suominen">Be Suominen</a></td><td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kL>1:5 K</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kW>2:1 K</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4 K</td>
<td class=kW>5:2 K</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>6:2</td>
<td class=kL>3:6</td>
<td class=kT>3:3 K</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kW>5:1 K</td>
<td class=kW>8:0 K</td>
<td class=br>87:84</td><td class=br>+3</td>
<td class=bc>14 - 7 - 10</td>
<td class=br><strong>35</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt><a href="stats.php?idpl=39&x=-61&p=Kr%20Rieksti%C5%86%C5%A1">Kr Rieksti��</a></td><td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kL>3:6 K</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kL>0:6 K</td>
<td class=kT>2:2</td>
<td class=kW>2:1 K</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3 K</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>3:1 K</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>4:5 K</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=br>75:72</td><td class=br>+3</td>
<td class=bc>13 - 8 - 10</td>
<td class=br><strong>34</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt><a href="stats.php?idpl=213&x=-61&p=Ed%20Ka%C5%86eps">Ed Ka�eps</a></td><td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>1:3 K</td>
<td class=kT>4:4</td>
<td class=kL>0:4</td>
<td class=kL>1:6 K</td>
<td class=kW>4:3</td>
<td class=kW>5:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kT>4:4 K</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>3:0 K</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>4:2 K</td>
<td class=kW>4:2</td>
<td class=kW>5:4 K</td>
<td class=kT>4:4</td>
<td class=kW>1:0</td>
<td class=kL>0:1</td>
<td class=kW>5:4</td>
<td class=br>84:84</td><td class=br>0</td>
<td class=bc>13 - 8 - 10</td>
<td class=br><strong>34</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt><a href="stats.php?idpl=97&x=-61&p=Gi%20Lasmanis">Gi Lasmanis</a></td><td class=kL>2:7</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>0:1 K</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>3:6 K</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kT>6:6 K</td>
<td class=kL>1:5</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2 K</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>4:3 K</td>
<td class=kT>2:2</td>
<td class=kW>7:2 K</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=br>86:86</td><td class=br>0</td>
<td class=bc>13 - 5 - 13</td>
<td class=br><strong>31</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="stats.php?idpl=30&x=-61&p=Ma%20Jakseboga">Ma Jakseboga</a></td><td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>0:4 K</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>1:10 K</td>
<td class=kW>6:0</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>4:4 K</td>
<td class=kT>6:6 K</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1 K</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1 K</td>
<td class=kL>2:4</td>
<td class=kL>1:3 K</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=br>80:92</td><td class=br>-12</td>
<td class=bc>10 - 10 - 11</td>
<td class=br><strong>30</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt><a href="stats.php?idpl=341&x=-61&p=J%C4%81%20Kaln%C4%93vics">J� Kaln�vics</a></td><td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>2:4 K</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kW>3:2 K</td>
<td class=kT>3:3</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3 K</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kL>0:3 K</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>1:2 K</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kW>4:0 K</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=br>73:77</td><td class=br>-4</td>
<td class=bc>9 - 12 - 10</td>
<td class=br><strong>30</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt><a href="stats.php?idpl=400&x=-61&p=Ja%20Matysek">Ja Matysek</a></td><td class=kL>1:5 K</td>
<td class=kL>2:5 K</td>
<td class=kL>1:5</td>
<td class=kW>5:4</td>
<td class=kL>1:7 K</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kT>6:6</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:2 K</td>
<td class=kW>5:3</td>
<td class=kL>0:2 K</td>
<td class=kT>0:0</td>
<td class=kT>3:3</td>
<td class=kT>1:1 K</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>5:4</td>
<td class=kL>3:6 K</td>
<td class=kL>3:6</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=br>73:91</td><td class=br>-18</td>
<td class=bc>10 - 10 - 11</td>
<td class=br><strong>30</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt><a href="stats.php?idpl=390&x=-61&p=Pe%20Miettinen">Pe Miettinen</a></td><td class=kL>3:5 K</td>
<td class=kL>3:8 K</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:5 K</td>
<td class=kL>0:2</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kL>2:3 K</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:3 K</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kL>1:2 K</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>3:1 K</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=br>75:87</td><td class=br>-12</td>
<td class=bc>13 - 3 - 15</td>
<td class=br><strong>29</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt><a href="stats.php?idpl=369&x=-61&p=My%20Spivakovskyy">My Spivakovskyy</a></td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kW>3:2 K</td>
<td class=kW>3:2</td>
<td class=kL>4:5</td>
<td class=kL>2:6 K</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kL>0:3 K</td>
<td class=kL>2:3 K</td>
<td class=kL>1:2 K</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>1:0 K</td>
<td class=kW>3:1</td>
<td class=kW>4:2 K</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=br>73:81</td><td class=br>-8</td>
<td class=bc>10 - 8 - 13</td>
<td class=br><strong>28</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt><a href="stats.php?idpl=103&x=-61&p=Ro%20Rieksti%C5%86%C5%A1">Ro Rieksti��</a></td><td class=kL>2:4 K</td>
<td class=kW>2:1 K</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kT>3:3 K</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kL>4:7</td>
<td class=kW>5:3</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>2:0 K</td>
<td class=kL>3:4 K</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>0:0</td>
<td class=kT>2:2 K</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kL>1:4 K</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=br>76:86</td><td class=br>-10</td>
<td class=bc>11 - 6 - 14</td>
<td class=br><strong>28</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt><a href="stats.php?idpl=431&x=-61&p=An%20Jalneskog">An Jalneskog</a></td><td class=kL>0:1</td>
<td class=kW>2:0</td>
<td class=kL>2:5</td>
<td class=kW>2:1 K</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>0:3 K</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kT>0:0 K</td>
<td class=kW>3:2 K</td>
<td class=kT>3:3 K</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kT>0:0</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>7:2</td>
<td class=kL>0:3</td>
<td class=kW>5:3 K</td>
<td class=kW>2:1 K</td>
<td class=br>56:71</td><td class=br>-15</td>
<td class=bc>9 - 8 - 14</td>
<td class=br><strong>26</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt><a href="stats.php?idpl=34&x=-61&p=J%C4%93%20Re%C4%B7is">J� Re�is</a></td><td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3 K</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>2:4 K</td>
<td class=kT>4:4</td>
<td class=kL>1:5 K</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kL>1:6</td>
<td class=kL>1:3 K</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>3:0 K</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kL>2:4</td>
<td class=kT>0:0</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kT>3:3 K</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kL>0:2 K</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=br>60:75</td><td class=br>-15</td>
<td class=bc>7 - 10 - 14</td>
<td class=br><strong>24</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt><a href="stats.php?idpl=403&x=-61&p=Mi%20Cernoch">Mi Cernoch</a></td><td class=kL>1:4 K</td>
<td class=kW>3:2 K</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>2:5 K</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1 K</td>
<td class=kW>2:1 K</td>
<td class=kL>0:3</td>
<td class=kT>2:2 K</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4 K</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kW>5:0</td>
<td class=br>58:88</td><td class=br>-30</td>
<td class=bc>8 - 7 - 16</td>
<td class=br><strong>23</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt><a href="stats.php?idpl=121&x=-61&p=Gu%20Hermansson">Gu Hermansson</a></td><td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>4:1 K</td>
<td class=kW>6:0</td>
<td class=kL>0:4</td>
<td class=kW>6:3 K</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kW>1:0</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>2:4 K</td>
<td class=kL>3:4 K</td>
<td class=kL>1:3 K</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>0:1 K</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:3 K</td>
<td class=kT>5:5</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=br>70:85</td><td class=br>-15</td>
<td class=bc>10 - 3 - 18</td>
<td class=br><strong>23</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt><a href="stats.php?idpl=377&x=-61&p=Bj%20Axelsen">Bj Axelsen</a></td><td class=kL>2:9</td>
<td class=kL>2:7</td>
<td class=kL>3:6 K</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kL>1:3 K</td>
<td class=kW>6:2</td>
<td class=kL>0:2 K</td>
<td class=kT>1:1</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kT>1:1 K</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1 K</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3 K</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2 K</td>
<td class=kW>4:1</td>
<td class=kL>2:6</td>
<td class=br>62:92</td><td class=br>-30</td>
<td class=bc>7 - 7 - 17</td>
<td class=br><strong>21</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt><a href="stats.php?idpl=112&x=-61&p=Ma%20Saveljeva">Ma Saveljeva</a></td><td class=kL>2:6</td>
<td class=kL>3:7</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>3:4 K</td>
<td class=kL>2:4</td>
<td class=kL>4:7</td>
<td class=kL>1:3 K</td>
<td class=kL>2:4</td>
<td class=kW>6:4</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>4:5 K</td>
<td class=kL>2:7 K</td>
<td class=kW>3:1 K</td>
<td class=kW>4:1</td>
<td class=kL>4:5</td>
<td class=kL>2:6</td>
<td class=kL>2:4 K</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kW>3:1 K</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=br>83:116</td><td class=br>-33</td>
<td class=bc>9 - 2 - 20</td>
<td class=br><strong>20</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt><a href="stats.php?idpl=384&x=-61&p=Fr%20Hagerup">Fr Hagerup</a></td><td class=kL>0:3 K</td>
<td class=kL>3:5 K</td>
<td class=kW>3:1</td>
<td class=kL>4:7</td>
<td class=kL>3:6 K</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kL>1:8</td>
<td class=kL>3:7</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kW>6:3 K</td>
<td class=kL>1:3 K</td>
<td class=kT>1:1</td>
<td class=kW>4:1 K</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kW>4:2 K</td>
<td class=kT>5:5</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=br>76:118</td><td class=br>-42</td>
<td class=bc>8 - 4 - 19</td>
<td class=br><strong>20</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt><a href="stats.php?idpl=432&x=-61&p=Gu%20Fagerberg">Gu Fagerberg</a></td><td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>5:9 K</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1 K</td>
<td class=kL>1:5</td>
<td class=kL>0:1 K</td>
<td class=kL>3:9</td>
<td class=kL>0:5</td>
<td class=kT>4:4</td>
<td class=kW>5:4 K</td>
<td class=kL>0:1</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kL>0:4 K</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kW>3:0</td>
<td class=kW>2:0 K</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2 K</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=br>59:106</td><td class=br>-47</td>
<td class=bc>7 - 4 - 20</td>
<td class=br><strong>18</strong></td><td class=d>30.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>31.</td><td class=kt><a href="stats.php?idpl=383&x=-61&p=Ve%20Klippen">Ve Klippen</a></td><td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>2:6 K</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4 K</td>
<td class=kL>2:3</td>
<td class=kL>0:9</td>
<td class=kL>1:2</td>
<td class=kL>2:3 K</td>
<td class=kL>2:3 K</td>
<td class=kL>1:5 K</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>3:5 K</td>
<td class=kL>1:2</td>
<td class=kW>6:2</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kT>3:3 K</td>
<td class=br>58:98</td><td class=br>-40</td>
<td class=bc>6 - 5 - 20</td>
<td class=br><strong>17</strong></td><td class=d>31.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>32.</td><td class=kt><a href="stats.php?idpl=79&x=-61&p=Mi%20Saul%C4%ABtis">Mi Saul�tis</a></td><td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>4:7</td>
<td class=kL>1:3 K</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>3:6 K</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kT>2:2 K</td>
<td class=kL>1:7 K</td>
<td class=kL>0:8 K</td>
<td class=kL>0:3</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>1:2 K</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kL>1:3</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kT>3:3 K</td>
<td class=kx>*</td>
<td class=br>58:116</td><td class=br>-58</td>
<td class=bc>3 - 5 - 23</td>
<td class=br><strong>11</strong></td><td class=d>32.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Matysek Jakub</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Ziemelis Didzis</td><td class=bc>-</td><td class=bl>Hagerup Frode</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>�sterman Hans</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=blW>Miettinen Petrus</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>Suominen Benjamin</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Cernoch Miroslav</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Saveljeva Maria</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Baumanis Toms</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>2 : 9</tr></td>
<tr><td class=brW>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=bl>Blume Olof</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Hagerup Frode</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Miettinen Petrus</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ziemelis Didzis</td><td class=bc>-</td><td class=bl>Cernoch Miroslav</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>�sterman Hans</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Umanskyy Anton</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Saveljeva Maria</td><td class=bc>-</td><td class=bl>Baumanis Toms</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Blume Olof</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Matysek Jakub</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Miettinen Petrus</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Cernoch Miroslav</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ziemelis Didzis</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>�sterman Hans</td><td class=bc>-</td><td class=blW>Jalneskog Anton</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>Baumanis Toms</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Caics Edgars</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Blume Olof</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Matysek Jakub</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Saveljeva Maria</td><td class=bc>-</td><td class=blW>Klippen Vegard</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Hagerup Frode</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=bl>Cernoch Miroslav</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=blW>Jalneskog Anton</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Baumanis Toms</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ziemelis Didzis</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>�sterman Hans</td><td class=bc>-</td><td class=blW>Blume Olof</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Matysek Jakub</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=blW>Hagerup Frode</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=blW>Miettinen Petrus</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Saveljeva Maria</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Cernoch Miroslav</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Saveljeva Maria</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=bl>Baumanis Toms</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=blW>Blume Olof</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ziemelis Didzis</td><td class=bc>-</td><td class=blW>Matysek Jakub</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>�sterman Hans</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Hagerup Frode</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Miettinen Petrus</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Umanskyy Anton</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Suominen Benjamin</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Matysek Jakub</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>�sterman Hans</td><td class=bc>-</td><td class=blW>Baumanis Toms</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=blW>Hagerup Frode</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>Blume Olof</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ziemelis Didzis</td><td class=bc>-</td><td class=bl>Miettinen Petrus</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>Klippen Vegard</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Cernoch Miroslav</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Saveljeva Maria</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Saveljeva Maria</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Fagerberg Gustaf</td><td class=bc>-</td><td class=bl>Matysek Jakub</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Baumanis Toms</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Hagerup Frode</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Blume Olof</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Miettinen Petrus</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Cernoch Miroslav</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ziemelis Didzis</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>�sterman Hans</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ziemelis Didzis</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>�sterman Hans</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=blW>Matysek Jakub</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Baumanis Toms</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Hagerup Frode</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Saveljeva Maria</td><td class=bc>-</td><td class=blW>Blume Olof</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Miettinen Petrus</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Cernoch Miroslav</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=blW>Suominen Benjamin</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Caics Edgars</td><td class=bc>-</td><td class=blW>Blume Olof</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=bl>Baumanis Toms</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Miettinen Petrus</td><td class=bc>-</td><td class=blW>Suominen Benjamin</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Hagerup Frode</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Matysek Jakub</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ziemelis Didzis</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=blW>Saveljeva Maria</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Spivakovskyy Mykhaylo</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Matysek Jakub</td><td class=bc>-</td><td class=bl>Baumanis Toms</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Umanskyy Anton</td><td class=bc>-</td><td class=blW>Suominen Benjamin</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Miettinen Petrus</td><td class=bc>-</td><td class=blW>Klippen Vegard</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Blume Olof</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ziemelis Didzis</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Spivakovskyy Mykhaylo</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Jalneskog Anton</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Matysek Jakub</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Caics Edgars</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Blume Olof</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Miettinen Petrus</td><td class=bc>-</td><td class=blW>Baumanis Toms</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ziemelis Didzis</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Miettinen Petrus</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Matysek Jakub</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Blume Olof</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Umanskyy Anton</td><td class=bc>-</td><td class=blW>Baumanis Toms</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=blW>Jalneskog Anton</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ziemelis Didzis</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Miettinen Petrus</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Hagerup Frode</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Matysek Jakub</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=bl>Blume Olof</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Baumanis Toms</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Umanskyy Anton</td><td class=bc>-</td><td class=blW>Jalneskog Anton</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Saveljeva Maria</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ziemelis Didzis</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Umanskyy Anton</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=blW>Suominen Benjamin</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Miettinen Petrus</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Matysek Jakub</td><td class=bc>-</td><td class=bl>Blume Olof</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Caics Edgars</td><td class=bc>-</td><td class=bl>Baumanis Toms</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Spivakovskyy Mykhaylo</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>�sterman Hans</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Ziemelis Didzis</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=blW>Klippen Vegard</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Miettinen Petrus</td><td class=bc>-</td><td class=bl>Blume Olof</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Baumanis Toms</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Matysek Jakub</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ziemelis Didzis</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Blume Olof</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=blW>Baumanis Toms</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Miettinen Petrus</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Matysek Jakub</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Fagerberg Gustaf</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ziemelis Didzis</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Blume Olof</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>�sterman Hans</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Baumanis Toms</td><td class=bc>-</td><td class=bl>Ziemelis Didzis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Jalneskog Anton</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Kaln�vics J�nis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Miettinen Petrus</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Suominen Benjamin</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Matysek Jakub</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Klippen Vegard</td><td class=bc>-</td><td class=blW>Axelsen Bjarne</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Matysek Jakub</td><td class=bc>-</td><td class=bl>�sterman Hans</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Klippen Vegard</td><td class=bc>-</td><td class=blW>Ziemelis Didzis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Blume Olof</td><td class=bc>-</td><td class=bl>Korabel Oleksii</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Baumanis Toms</td><td class=bc>-</td><td class=bl>Rieksti�� Kristaps</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Jalneskog Anton</td><td class=bc>-</td><td class=blW>Kaln�vics J�nis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Miettinen Petrus</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Suominen Benjamin</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>4 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Matysek Jakub</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Klippen Vegard</td><td class=bc>-</td><td class=bl>Rieksti�� Kristaps</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Blume Olof</td><td class=bc>-</td><td class=bl>Kaln�vics J�nis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Baumanis Toms</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jalneskog Anton</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Matantsev Evgeniy</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Miettinen Petrus</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Suominen Benjamin</td><td class=bc>-</td><td class=bl>Ziemelis Didzis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Miettinen Petrus</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Suominen Benjamin</td><td class=bc>-</td><td class=bl>Rieksti�� Kristaps</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Saveljeva Maria</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Kaln�vics J�nis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Matysek Jakub</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Klippen Vegard</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Blume Olof</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Baumanis Toms</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Jalneskog Anton</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Umanskyy Anton</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Ziemelis Didzis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Korabel Oleksii</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Rieksti�� Kristaps</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Miettinen Petrus</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Suominen Benjamin</td><td class=bc>-</td><td class=bl>Kaln�vics J�nis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Matysek Jakub</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Klippen Vegard</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Blume Olof</td><td class=bc>-</td><td class=blW>Axelsen Bjarne</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Baumanis Toms</td><td class=bc>-</td><td class=bl>Matantsev Evgeniy</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Jalneskog Anton</td><td class=bc>-</td><td class=bl>Ziemelis Didzis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Korabel Oleksii</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Kaln�vics J�nis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Miettinen Petrus</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Suominen Benjamin</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Matysek Jakub</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>6 : 6</tr></td>
<tr><td class=br>Klippen Vegard</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Caics Edgars</td><td class=bc>-</td><td class=bl>�sterman Hans</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Blume Olof</td><td class=bc>-</td><td class=bl>Ziemelis Didzis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Baumanis Toms</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Jalneskog Anton</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Jalneskog Anton</td><td class=bc>-</td><td class=blW>Fagerberg Gustaf</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=blW>Spivakovskyy Mykhaylo</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Miettinen Petrus</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Suominen Benjamin</td><td class=bc>-</td><td class=bl>Matantsev Evgeniy</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Ziemelis Didzis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Matysek Jakub</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Klippen Vegard</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Caics Edgars</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Blume Olof</td><td class=bc>-</td><td class=bl>Rieksti�� Kristaps</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Saveljeva Maria</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Baumanis Toms</td><td class=bc>-</td><td class=blW>Kaln�vics J�nis</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Baumanis Toms</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jalneskog Anton</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Matantsev Evgeniy</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=blW>Ziemelis Didzis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Miettinen Petrus</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Suominen Benjamin</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Matysek Jakub</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Klippen Vegard</td><td class=bc>-</td><td class=bl>Kaln�vics J�nis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Blume Olof</td><td class=bc>-</td><td class=blW>Fagerberg Gustaf</td><td class=bc>2 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group OpenA2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>31</td>
<td class=ic>32</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=7&x=-61&p=Ra%20Kalni%C5%86%C5%A1">Ra Kalni��</a></td><td class=kx>*</td>
<td class=kW>9:1</td>
<td class=kT>2:2</td>
<td class=kW>6:4 K</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>6:5 K</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>8:1</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=kW>9:3 K</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1 K</td>
<td class=kW>6:3</td>
<td class=kW>2:0 K</td>
<td class=kW>7:4 K</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=kW>8:0</td>
<td class=kW>3:2 K</td>
<td class=kW>5:3</td>
<td class=br>152:55</td><td class=br>+97</td>
<td class=bc>28 - 3 - 0</td>
<td class=br><strong>59</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=105&x=-61&p=Pa%20Petr">Pa Petr</a></td><td class=kL>1:9</td>
<td class=kx>*</td>
<td class=kL>0:6</td>
<td class=kT>5:5</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>6:5 K</td>
<td class=kW>7:2</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kW>7:4 K</td>
<td class=kT>3:3</td>
<td class=kW>6:1 K</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kW>5:4 K</td>
<td class=kW>7:0</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>5:2 K</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0 K</td>
<td class=kW>5:0 K</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=br>138:72</td><td class=br>+66</td>
<td class=bc>25 - 2 - 4</td>
<td class=br><strong>52</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=269&x=-61&p=Ke%20Eriksson">Ke Eriksson</a></td><td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1 K</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>5:2 K</td>
<td class=kW>5:2</td>
<td class=kW>4:2 K</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>2:1 K</td>
<td class=kW>7:4 K</td>
<td class=kW>3:2</td>
<td class=kW>4:1 K</td>
<td class=kL>1:4</td>
<td class=kW>8:4</td>
<td class=kW>7:4</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>9:1 K</td>
<td class=kL>0:2</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=br>125:60</td><td class=br>+65</td>
<td class=bc>22 - 4 - 5</td>
<td class=br><strong>48</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=116&x=-61&p=Ar%20Matantsev">Ar Matantsev</a></td><td class=kL>4:6 K</td>
<td class=kT>5:5</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>4:0 K</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kL>2:6</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>4:2 K</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>4:1 K</td>
<td class=kW>5:2</td>
<td class=kW>3:2 K</td>
<td class=kW>4:3 K</td>
<td class=kW>5:4</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>2:1 K</td>
<td class=kW>5:0</td>
<td class=br>107:67</td><td class=br>+40</td>
<td class=bc>19 - 4 - 8</td>
<td class=br><strong>42</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=104&x=-61&p=Ed%20Nilsson">Ed Nilsson</a></td><td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:4 K</td>
<td class=kL>2:4</td>
<td class=kL>1:4 K</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0 K</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kW>4:2 K</td>
<td class=kW>2:0 K</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>8:3</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1 K</td>
<td class=kT>4:4</td>
<td class=kW>5:1 K</td>
<td class=br>97:68</td><td class=br>+29</td>
<td class=bc>19 - 3 - 9</td>
<td class=br><strong>41</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=29&x=-61&p=Kr%20Lagzdi%C5%86a">Kr Lagzdi�a</a></td><td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>1:3 K</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kT>1:1 K</td>
<td class=kW>3:1</td>
<td class=kW>4:3 K</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=kL>3:7</td>
<td class=kW>5:1 K</td>
<td class=kT>3:3 K</td>
<td class=kL>3:4</td>
<td class=kW>6:2 K</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>3:2 K</td>
<td class=kW>7:2</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=br>97:71</td><td class=br>+26</td>
<td class=bc>17 - 5 - 9</td>
<td class=br><strong>39</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=229&x=-61&p=Un%20%C3%96sterman">Un �sterman</a></td><td class=kL>5:6 K</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>0:4 K</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=kW>5:4 K</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kT>1:1 K</td>
<td class=kL>2:3</td>
<td class=kW>2:1 K</td>
<td class=kT>2:2 K</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>8:1</td>
<td class=kT>1:1</td>
<td class=kW>5:1 K</td>
<td class=kW>3:0</td>
<td class=br>100:75</td><td class=br>+25</td>
<td class=bc>16 - 6 - 9</td>
<td class=br><strong>38</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=381&x=-61&p=Ma%20Klippen">Ma Klippen</a></td><td class=kL>1:2</td>
<td class=kL>5:6 K</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kL>1:3 K</td>
<td class=kW>3:1</td>
<td class=kL>3:4 K</td>
<td class=kL>0:5</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>3:2 K</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kL>3:4 K</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kL>0:3 K</td>
<td class=kW>6:3 K</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=br>83:73</td><td class=br>+10</td>
<td class=bc>16 - 3 - 12</td>
<td class=br><strong>35</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=123&x=-61&p=Lu%20Jurka">Lu Jurka</a></td><td class=kL>1:6</td>
<td class=kL>2:7</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>4:1 K</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2 K</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kL>0:4 K</td>
<td class=kL>1:6</td>
<td class=kW>7:2</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>3:2 K</td>
<td class=kL>1:2 K</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>7:0</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kT>0:0 K</td>
<td class=kW>4:1</td>
<td class=kW>5:0 K</td>
<td class=br>88:74</td><td class=br>+14</td>
<td class=bc>15 - 5 - 11</td>
<td class=br><strong>35</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=44&x=-61&p=Kr%20Naglis">Kr Naglis</a></td><td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>2:5 K</td>
<td class=kL>0:6</td>
<td class=kW>4:2</td>
<td class=kT>1:1 K</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>1:6 K</td>
<td class=kL>1:6</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kT>3:3 K</td>
<td class=kL>3:5 K</td>
<td class=kL>3:5</td>
<td class=kW>3:1 K</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1 K</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>6:0</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=br>92:85</td><td class=br>+7</td>
<td class=bc>14 - 7 - 10</td>
<td class=br><strong>35</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=419&x=-61&p=Pe%20%C3%96stlund">Pe �stlund</a></td><td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kW>6:2</td>
<td class=kW>4:1 K</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3 K</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kW>4:2 K</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kT>1:1 K</td>
<td class=kW>4:1 K</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kL>1:4 K</td>
<td class=kW>5:1</td>
<td class=kW>4:1 K</td>
<td class=br>89:70</td><td class=br>+19</td>
<td class=bc>17 - 1 - 13</td>
<td class=br><strong>35</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=40&x=-61&p=Al%20Sili%C5%86%C5%A1">Al Sili��</a></td><td class=kL>1:8</td>
<td class=kL>3:7</td>
<td class=kL>2:4 K</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>3:4 K</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kW>6:1 K</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3 K</td>
<td class=kL>1:2 K</td>
<td class=kW>4:2</td>
<td class=kW>5:1 K</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kW>6:0</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kT>3:3 K</td>
<td class=kL>3:6</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=br>96:85</td><td class=br>+11</td>
<td class=bc>15 - 4 - 12</td>
<td class=br><strong>34</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt><a href="stats.php?idpl=43&x=-61&p=Ed%20Naglis">Ed Naglis</a></td><td class=kL>2:4</td>
<td class=kL>4:7 K</td>
<td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>3:1 K</td>
<td class=kL>0:2</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>3:4 K</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kT>5:5</td>
<td class=kW>6:4</td>
<td class=kT>2:2 K</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>4:5 K</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kW>4:3 K</td>
<td class=kW>4:2 K</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>6:1</td>
<td class=br>103:94</td><td class=br>+9</td>
<td class=bc>14 - 4 - 13</td>
<td class=br><strong>32</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt><a href="stats.php?idpl=108&x=-61&p=Ma%20Madera">Ma Madera</a></td><td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>0:3 K</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>4:0 K</td>
<td class=kL>1:4</td>
<td class=kL>2:4 K</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>6:0</td>
<td class=kL>1:6</td>
<td class=kW>5:2 K</td>
<td class=kW>4:2 K</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>7:1 K</td>
<td class=kW>7:0</td>
<td class=kW>4:1 K</td>
<td class=br>88:83</td><td class=br>+5</td>
<td class=bc>12 - 8 - 11</td>
<td class=br><strong>32</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt><a href="stats.php?idpl=42&x=-61&p=Em%20Liepi%C5%86%C5%A1">Em Liepi��</a></td><td class=kL>1:5</td>
<td class=kL>1:6 K</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>7:3</td>
<td class=kL>2:5</td>
<td class=kW>4:3 K</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>4:3 K</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kL>1:5 K</td>
<td class=kW>2:1</td>
<td class=kT>5:5</td>
<td class=kL>4:5</td>
<td class=kL>3:4 K</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kW>5:1 K</td>
<td class=kW>8:4 K</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=br>104:100</td><td class=br>+4</td>
<td class=bc>13 - 5 - 13</td>
<td class=br><strong>31</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt><a href="stats.php?idpl=186&x=-61&p=R%C5%AB%20Kamzols">R� Kamzols</a></td><td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:2 K</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>1:5 K</td>
<td class=kL>2:6</td>
<td class=kW>5:0</td>
<td class=kL>2:7</td>
<td class=kT>3:3 K</td>
<td class=kW>4:3</td>
<td class=kT>3:3 K</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>5:1 K</td>
<td class=kW>4:0</td>
<td class=kW>5:3 K</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>4:9</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kW>6:3</td>
<td class=kT>3:3 K</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=br>89:95</td><td class=br>-6</td>
<td class=bc>13 - 5 - 13</td>
<td class=br><strong>31</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="stats.php?idpl=382&x=-61&p=Oy%20Klippen">Oy Klippen</a></td><td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kL>4:7 K</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3 K</td>
<td class=kL>3:6</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kW>5:3 K</td>
<td class=kL>1:6</td>
<td class=kW>2:1 K</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kL>1:5 K</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kT>5:5 K</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>7:0</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>1:0 K</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kT>5:5</td>
<td class=kW>5:0</td>
<td class=br>93:100</td><td class=br>-7</td>
<td class=bc>11 - 8 - 12</td>
<td class=br><strong>30</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt><a href="stats.php?idpl=235&x=-61&p=An%20Fjermestad">An Fjermestad</a></td><td class=kL>3:9 K</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>2:4 K</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>4:5 K</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kT>5:5</td>
<td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>2:7 K</td>
<td class=kW>4:1</td>
<td class=kT>3:3 K</td>
<td class=kT>1:1 K</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2 K</td>
<td class=kW>3:0</td>
<td class=br>86:96</td><td class=br>-10</td>
<td class=bc>12 - 5 - 14</td>
<td class=br><strong>29</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt><a href="stats.php?idpl=420&x=-61&p=He%20Steen">He Steen</a></td><td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>1:4 K</td>
<td class=kL>0:3</td>
<td class=kW>5:1</td>
<td class=kL>2:6 K</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3 K</td>
<td class=kW>3:0</td>
<td class=kL>1:5 K</td>
<td class=kL>4:6</td>
<td class=kL>0:6</td>
<td class=kW>3:2</td>
<td class=kL>3:5 K</td>
<td class=kT>5:5 K</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>1:5 K</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=br>78:91</td><td class=br>-13</td>
<td class=bc>12 - 4 - 15</td>
<td class=br><strong>28</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt><a href="stats.php?idpl=430&x=-61&p=Ni%20Blomberg">Ni Blomberg</a></td><td class=kL>2:4</td>
<td class=kL>4:5 K</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kT>4:4</td>
<td class=kL>2:3 K</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kT>2:2 K</td>
<td class=kW>6:1</td>
<td class=kW>5:1 K</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>6:1 K</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>3:1 K</td>
<td class=kL>2:3 K</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kW>2:0</td>
<td class=br>81:75</td><td class=br>+6</td>
<td class=bc>10 - 8 - 13</td>
<td class=br><strong>28</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt><a href="stats.php?idpl=114&x=-61&p=An%20Bo%C5%BEi%C4%8D">An Bo�i�</a></td><td class=kL>2:3</td>
<td class=kL>0:7</td>
<td class=kL>4:8</td>
<td class=kW>3:2</td>
<td class=kL>2:4 K</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kL>2:5</td>
<td class=kL>2:3 K</td>
<td class=kL>2:5</td>
<td class=kT>1:1 K</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5 K</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>4:2 K</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1 K</td>
<td class=kW>4:2</td>
<td class=kL>3:4 K</td>
<td class=br>76:88</td><td class=br>-12</td>
<td class=bc>12 - 4 - 15</td>
<td class=br><strong>28</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt><a href="stats.php?idpl=32&x=-61&p=Sa%20Skarainis">Sa Skarainis</a></td><td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>4:7</td>
<td class=kL>2:6</td>
<td class=kL>0:2 K</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kW>2:1 K</td>
<td class=kL>3:4</td>
<td class=kL>1:4 K</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kL>2:4 K</td>
<td class=kT>5:5</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>2:4 K</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kL>1:2 K</td>
<td class=kW>2:1</td>
<td class=kT>2:2 K</td>
<td class=br>71:92</td><td class=br>-21</td>
<td class=bc>11 - 5 - 15</td>
<td class=br><strong>27</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt><a href="stats.php?idpl=111&x=-61&p=Em%20Larsson">Em Larsson</a></td><td class=kL>1:3 K</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>1:4 K</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>5:4</td>
<td class=kW>9:4</td>
<td class=kL>0:7</td>
<td class=kW>7:2 K</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>1:4 K</td>
<td class=kT>2:2 K</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>4:0 K</td>
<td class=kW>5:0</td>
<td class=br>80:101</td><td class=br>-21</td>
<td class=bc>10 - 6 - 15</td>
<td class=br><strong>26</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt><a href="stats.php?idpl=151&x=-61&p=Kr%20Lebl">Kr Lebl</a></td><td class=kL>3:6</td>
<td class=kL>2:5 K</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>4:3 K</td>
<td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kW>5:4 K</td>
<td class=kT>2:2</td>
<td class=kW>4:3 K</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kL>1:6 K</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kL>1:6</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kT>4:4 K</td>
<td class=kT>2:2 K</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=br>75:111</td><td class=br>-36</td>
<td class=bc>10 - 5 - 16</td>
<td class=br><strong>25</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt><a href="stats.php?idpl=113&x=-61&p=Ha%20Ivantsova">Ha Ivantsova</a></td><td class=kL>0:2 K</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kL>2:3 K</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kL>1:2 K</td>
<td class=kL>1:2</td>
<td class=kL>0:7</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kT>4:4</td>
<td class=kT>3:3 K</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>4:1 K</td>
<td class=kW>6:1</td>
<td class=kx>*</td>
<td class=kW>3:1 K</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kL>1:4</td>
<td class=kW>7:4 K</td>
<td class=kW>7:2</td>
<td class=br>75:77</td><td class=br>-2</td>
<td class=bc>10 - 4 - 17</td>
<td class=br><strong>24</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt><a href="stats.php?idpl=65&x=-61&p=Ig%20Saveljev">Ig Saveljev</a></td><td class=kL>4:7 K</td>
<td class=kL>0:6</td>
<td class=kW>3:2</td>
<td class=kL>3:4 K</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2 K</td>
<td class=kW>1:0</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kT>1:1 K</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kT>2:2 K</td>
<td class=kL>1:2</td>
<td class=kL>1:3 K</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kT>3:3 K</td>
<td class=kW>3:1</td>
<td class=br>55:71</td><td class=br>-16</td>
<td class=bc>8 - 8 - 15</td>
<td class=br><strong>24</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt><a href="stats.php?idpl=379&x=-61&p=Da%20Nyg%C3%A5rd">Da Nyg�rd</a></td><td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:9 K</td>
<td class=kL>4:5</td>
<td class=kL>3:8</td>
<td class=kL>2:3 K</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>1:4 K</td>
<td class=kL>0:1</td>
<td class=kT>3:3 K</td>
<td class=kL>4:5</td>
<td class=kT>3:3</td>
<td class=kL>0:6</td>
<td class=kT>3:3 K</td>
<td class=kL>0:1 K</td>
<td class=kT>3:3</td>
<td class=kW>5:1 K</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>5:5</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kT>0:0</td>
<td class=br>73:104</td><td class=br>-31</td>
<td class=bc>6 - 9 - 16</td>
<td class=br><strong>21</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt><a href="stats.php?idpl=115&x=-61&p=My%20Shalomayev">My Shalomayev</a></td><td class=kL>2:5</td>
<td class=kL>0:4 K</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kL>3:6</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kW>3:0 K</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kW>6:3</td>
<td class=kL>3:4 K</td>
<td class=kW>3:2</td>
<td class=kL>1:5 K</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>1:3 K</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>4:4 K</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:1 K</td>
<td class=kW>1:0</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=br>69:96</td><td class=br>-27</td>
<td class=bc>8 - 4 - 19</td>
<td class=br><strong>20</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt><a href="stats.php?idpl=124&x=-61&p=Ne%20Skrlep">Ne Skrlep</a></td><td class=kL>2:7</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kL>1:8</td>
<td class=kL>3:6 K</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>2:4 K</td>
<td class=kL>1:3</td>
<td class=kL>4:8 K</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kW>3:2 K</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2 K</td>
<td class=kL>1:6</td>
<td class=kW>4:2</td>
<td class=kT>5:5</td>
<td class=kL>1:5 K</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=br>67:128</td><td class=br>-61</td>
<td class=bc>8 - 4 - 19</td>
<td class=br><strong>20</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt><a href="stats.php?idpl=67&x=-61&p=Ti%20Mihhaljov">Ti Mihhaljov</a></td><td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>1:3 K</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kT>0:0 K</td>
<td class=kL>0:6</td>
<td class=kW>4:1 K</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:7 K</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>1:3 K</td>
<td class=kW>2:1 K</td>
<td class=kW>3:0</td>
<td class=kL>0:5</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>0:2 K</td>
<td class=br>53:93</td><td class=br>-40</td>
<td class=bc>7 - 4 - 20</td>
<td class=br><strong>18</strong></td><td class=d>30.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>31.</td><td class=kt><a href="stats.php?idpl=118&x=-61&p=Da%20Landa">Da Landa</a></td><td class=kL>2:3 K</td>
<td class=kL>2:7</td>
<td class=kL>0:7</td>
<td class=kL>1:2 K</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kL>1:5 K</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kL>0:7</td>
<td class=kL>4:5</td>
<td class=kL>2:5</td>
<td class=kT>5:5</td>
<td class=kL>2:4 K</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>0:4 K</td>
<td class=kL>2:4</td>
<td class=kL>4:7 K</td>
<td class=kT>3:3 K</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>75:122</td><td class=br>-47</td>
<td class=bc>5 - 8 - 18</td>
<td class=br><strong>18</strong></td><td class=d>31.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>32.</td><td class=kt><a href="stats.php?idpl=122&x=-61&p=Vi%20Henttonen">Vi Henttonen</a></td><td class=kL>3:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:5 K</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5</td>
<td class=kL>1:4 K</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>1:4 K</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kW>4:3 K</td>
<td class=kT>2:2 K</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>2:0 K</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>31:114</td><td class=br>-83</td>
<td class=bc>2 - 3 - 26</td>
<td class=br><strong>7</strong></td><td class=d>32.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Steen Herman</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Nyg�rd Daniel</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Blomberg Niklas</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>�sterman Uno</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Lebl Kry�tof</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Klippen Oystein</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Klippen Magnus</td><td class=bc>-</td><td class=bl>Jurka Lukass</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>�stlund Peter</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=blW>Eriksson Kevin</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Skrlep Nejc</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=bl>Nyg�rd Daniel</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Skrlep Nejc</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Blomberg Niklas</td><td class=bc>-</td><td class=blW>Mihhaljov Timur</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>�sterman Uno</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Klippen Oystein</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Lebl Kry�tof</td><td class=bc>-</td><td class=bl>Jurka Lukass</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Eriksson Kevin</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Klippen Magnus</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=blW>Steen Herman</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Skrlep Nejc</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=bl>Klippen Oystein</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Blomberg Niklas</td><td class=bc>-</td><td class=bl>Jurka Lukass</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>�sterman Uno</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Eriksson Kevin</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Lebl Kry�tof</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Steen Herman</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Nyg�rd Daniel</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Klippen Magnus</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Klippen Magnus</td><td class=bc>-</td><td class=blW>Mihhaljov Timur</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=bl>Klippen Oystein</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Skrlep Nejc</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=blW>Eriksson Kevin</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Blomberg Niklas</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>�sterman Uno</td><td class=bc>-</td><td class=bl>Steen Herman</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Nyg�rd Daniel</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Lebl Kry�tof</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>9 : 4</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Klippen Magnus</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Klippen Oystein</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Jurka Lukass</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Skrlep Nejc</td><td class=bc>-</td><td class=blW>�stlund Peter</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Eriksson Kevin</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Steen Herman</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Blomberg Niklas</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>�sterman Uno</td><td class=bc>-</td><td class=bl>Nyg�rd Daniel</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Lebl Kry�tof</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Klippen Magnus</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Klippen Oystein</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Skrlep Nejc</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=blW>Eriksson Kevin</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Jurka Lukass</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=bl>Steen Herman</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Blomberg Niklas</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Nyg�rd Daniel</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Lebl Kry�tof</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>�sterman Uno</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>�sterman Uno</td><td class=bc>-</td><td class=bl>Klippen Oystein</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Lebl Kry�tof</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Eriksson Kevin</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Steen Herman</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Klippen Magnus</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Nyg�rd Daniel</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Landa Daniil</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Skrlep Nejc</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Blomberg Niklas</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Blomberg Niklas</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>�sterman Uno</td><td class=bc>-</td><td class=blW>Eriksson Kevin</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Jurka Lukass</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Steen Herman</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Lebl Kry�tof</td><td class=bc>-</td><td class=blW>�stlund Peter</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Nyg�rd Daniel</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Klippen Magnus</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Skrlep Nejc</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Klippen Oystein</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Klippen Oystein</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>�sterman Uno</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Klippen Magnus</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Landa Daniil</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Eriksson Kevin</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Klippen Oystein</td><td class=bc>-</td><td class=blW>Mihhaljov Timur</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>�sterman Uno</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Klippen Magnus</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Skrlep Nejc</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Klippen Oystein</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>�stlund Peter</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=blW>Lebl Kry�tof</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Klippen Magnus</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>�sterman Uno</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Nyg�rd Daniel</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Klippen Oystein</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>�stlund Peter</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Lebl Kry�tof</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=blW>Klippen Magnus</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=blW>Skrlep Nejc</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�sterman Uno</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Klippen Oystein</td><td class=bc>-</td><td class=blW>�stlund Peter</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=blW>Klippen Magnus</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Landa Daniil</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>�sterman Uno</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Steen Herman</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Jurka Lukass</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Klippen Oystein</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=bl>Klippen Magnus</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>�sterman Uno</td><td class=bc>-</td><td class=blW>Lebl Kry�tof</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Klippen Oystein</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=blW>�stlund Peter</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Steen Herman</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>�sterman Uno</td><td class=bc>-</td><td class=bl>Klippen Magnus</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Skrlep Nejc</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Jurka Lukass</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Klippen Oystein</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Landa Daniil</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Klippen Magnus</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>�sterman Uno</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=bl>Kalni�� Rainers</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Matantsev Artem</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Klippen Oystein</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=blW>�sterman Uno</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mihhaljov Timur</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Klippen Magnus</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Saveljev Igor</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Nyg�rd Daniel</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Fjermestad Andreas</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Steen Herman</td><td class=bc>-</td><td class=blW>Skrlep Nejc</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Landa Daniil</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Steen Herman</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Madera Martin</td><td class=bc>-</td><td class=bl>�sterman Uno</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Klippen Oystein</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Klippen Magnus</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mihhaljov Timur</td><td class=bc>-</td><td class=blW>Fjermestad Andreas</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Landa Daniil</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>�sterman Uno</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Klippen Magnus</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Klippen Oystein</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=blW>Fjermestad Andreas</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Landa Daniil</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mihhaljov Timur</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Ivantsova Hanna</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Steen Herman</td><td class=bc>-</td><td class=blW>Klippen Magnus</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Saveljev Igor</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Eriksson Kevin</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=bl>Fjermestad Andreas</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Landa Daniil</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Klippen Oystein</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mihhaljov Timur</td><td class=bc>-</td><td class=bl>�sterman Uno</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Lebl Kry�tof</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mihhaljov Timur</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=blW>Klippen Magnus</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Steen Herman</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Fjermestad Andreas</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Madera Martin</td><td class=bc>-</td><td class=bl>Landa Daniil</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>�stlund Peter</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Klippen Oystein</td><td class=bc>-</td><td class=blW>Blomberg Niklas</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=bl>Matantsev Artem</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=blW>�sterman Uno</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Klippen Magnus</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mihhaljov Timur</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Fjermestad Andreas</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Landa Daniil</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Eriksson Kevin</td><td class=bc>-</td><td class=blW>Blomberg Niklas</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=bl>Matantsev Artem</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>�stlund Peter</td><td class=bc>-</td><td class=blW>�sterman Uno</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Klippen Oystein</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Jurka Lukass</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Klippen Oystein</td><td class=bc>-</td><td class=blW>Klippen Magnus</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Jurka Lukass</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Fjermestad Andreas</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Skrlep Nejc</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mihhaljov Timur</td><td class=bc>-</td><td class=bl>Landa Daniil</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Nyg�rd Daniel</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Matantsev Artem</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>�sterman Uno</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Fjermestad Andreas</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Klippen Oystein</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Jurka Lukass</td><td class=bc>-</td><td class=bl>Landa Daniil</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Kalni�� Rainers</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mihhaljov Timur</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>�sterman Uno</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Steen Herman</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Klippen Magnus</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>1 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group OpenB</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>65</td>
<td class=ic>66</td>
<td class=ic>67</td>
<td class=ic>68</td>
<td class=ic>69</td>
<td class=ic>70</td>
<td class=ic>71</td>
<td class=ic>72</td>
<td class=ic>73</td>
<td class=ic>74</td>
<td class=ic>75</td>
<td class=ic>76</td>
<td class=ic>77</td>
<td class=ic>78</td>
<td class=ic>79</td>
<td class=ic>80</td>
<td class=ic>81</td>
<td class=ic>82</td>
<td class=ic>83</td>
<td class=ic>84</td>
<td class=ic>85</td>
<td class=ic>86</td>
<td class=ic>87</td>
<td class=ic>88</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>65.</td><td class=kt><a href="stats.php?idpl=5&x=-61&p=Re%20Vazoli%C5%86%C5%A1">Re Vazoli��</a></td><td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>6:5</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>7:0</td>
<td class=kW>2:0</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kL>4:9</td>
<td class=kW>9:1</td>
<td class=kW>6:1</td>
<td class=kW>5:0 K</td>
<td class=br>84:40</td><td class=br>+44</td>
<td class=bc>18 - 1 - 4</td>
<td class=br><strong>37</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>66.</td><td class=kt><a href="stats.php?idpl=422&x=-61&p=Ri%20Pedersen">Ri Pedersen</a></td><td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kL>3:7</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>7:4</td>
<td class=kW>5:3</td>
<td class=kW>9:3</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kW>6:2</td>
<td class=kW>5:0 K</td>
<td class=br>91:53</td><td class=br>+38</td>
<td class=bc>15 - 6 - 2</td>
<td class=br><strong>36</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>67.</td><td class=kt><a href="stats.php?idpl=401&x=-61&p=Ma%20Lezik">Ma Lezik</a></td><td class=kL>2:4</td>
<td class=kW>7:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kW>6:2</td>
<td class=kW>8:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0 K</td>
<td class=br>91:43</td><td class=br>+48</td>
<td class=bc>16 - 3 - 4</td>
<td class=br><strong>35</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>68.</td><td class=kt><a href="stats.php?idpl=66&x=-61&p=Da%20Hrustaljova">Da Hrustaljova</a></td><td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>6:5</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kL>0:6</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=kW>8:1</td>
<td class=kW>5:0 K</td>
<td class=br>79:43</td><td class=br>+36</td>
<td class=bc>14 - 6 - 3</td>
<td class=br><strong>34</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>69.</td><td class=kt><a href="stats.php?idpl=425&x=-61&p=An%20Kimberg">An Kimberg</a></td><td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kW>5:0 K</td>
<td class=br>58:35</td><td class=br>+23</td>
<td class=bc>13 - 6 - 4</td>
<td class=br><strong>32</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>70.</td><td class=kt><a href="stats.php?idpl=163&x=-61&p=Zy%20Remeika">Zy Remeika</a></td><td class=kL>5:6</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>5:6</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>5:3</td>
<td class=kL>4:7</td>
<td class=kW>6:4</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0 K</td>
<td class=br>84:62</td><td class=br>+22</td>
<td class=bc>11 - 7 - 5</td>
<td class=br><strong>29</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>71.</td><td class=kt><a href="stats.php?idpl=236&x=-61&p=Am%20Fylling">Am Fylling</a></td><td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kT>5:5</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>5:0 K</td>
<td class=br>68:53</td><td class=br>+15</td>
<td class=bc>11 - 7 - 5</td>
<td class=br><strong>29</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>72.</td><td class=kt><a href="stats.php?idpl=427&x=-61&p=Ja%20Forsberg">Ja Forsberg</a></td><td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>5:0 K</td>
<td class=br>61:51</td><td class=br>+10</td>
<td class=bc>10 - 7 - 6</td>
<td class=br><strong>27</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>73.</td><td class=kt><a href="stats.php?idpl=392&x=-61&p=La%20Mets%C3%A4l%C3%A4">La Mets�l�</a></td><td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>5:0 K</td>
<td class=br>61:48</td><td class=br>+13</td>
<td class=bc>10 - 6 - 7</td>
<td class=br><strong>26</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>74.</td><td class=kt><a href="stats.php?idpl=404&x=-61&p=Da%20Matysek">Da Matysek</a></td><td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0 K</td>
<td class=br>63:44</td><td class=br>+19</td>
<td class=bc>10 - 5 - 8</td>
<td class=br><strong>25</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>75.</td><td class=kt><a href="stats.php?idpl=402&x=-61&p=Pe%20Fuchs">Pe Fuchs</a></td><td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kW>6:5</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>7:3</td>
<td class=kW>6:3</td>
<td class=kL>1:4</td>
<td class=kW>5:0 K</td>
<td class=br>65:52</td><td class=br>+13</td>
<td class=bc>9 - 7 - 7</td>
<td class=br><strong>25</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>76.</td><td class=kt><a href="stats.php?idpl=117&x=-61&p=Tr%20M%C3%A5nsson">Tr M�nsson</a></td><td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>1:0</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>8:2</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0 K</td>
<td class=br>60:43</td><td class=br>+17</td>
<td class=bc>9 - 6 - 8</td>
<td class=br><strong>24</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>77.</td><td class=kt><a href="stats.php?idpl=405&x=-61&p=Va%20Pikl">Va Pikl</a></td><td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>0:6</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>5:0 K</td>
<td class=br>65:64</td><td class=br>+1</td>
<td class=bc>9 - 4 - 10</td>
<td class=br><strong>22</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>78.</td><td class=kt><a href="stats.php?idpl=139&x=-61&p=Po%20Kvasnikova">Po Kvasnikova</a></td><td class=kW>1:0</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kW>1:0</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kT>0:0</td>
<td class=kL>0:6</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kT>0:0</td>
<td class=kW>5:0 K</td>
<td class=br>37:48</td><td class=br>-11</td>
<td class=bc>8 - 6 - 9</td>
<td class=br><strong>22</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>79.</td><td class=kt><a href="stats.php?idpl=241&x=-61&p=Pa%20Plesak">Pa Plesak</a></td><td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>8:4</td>
<td class=kW>5:0 K</td>
<td class=br>56:61</td><td class=br>-5</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>80.</td><td class=kt><a href="stats.php?idpl=156&x=-61&p=Gl%20Storozhenko">Gl Storozhenko</a></td><td class=kL>0:3</td>
<td class=kL>4:7</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>5:0 K</td>
<td class=br>50:63</td><td class=br>-13</td>
<td class=bc>8 - 4 - 11</td>
<td class=br><strong>20</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>81.</td><td class=kt><a href="stats.php?idpl=136&x=-61&p=Da%20Sippo">Da Sippo</a></td><td class=kL>0:7</td>
<td class=kL>3:5</td>
<td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kT>5:5</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>6:7</td>
<td class=kT>3:3</td>
<td class=kW>5:0 K</td>
<td class=br>58:73</td><td class=br>-15</td>
<td class=bc>9 - 2 - 12</td>
<td class=br><strong>20</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>82.</td><td class=kt><a href="stats.php?idpl=391&x=-61&p=To%20Uimonen">To Uimonen</a></td><td class=kL>0:2</td>
<td class=kL>3:9</td>
<td class=kL>1:4</td>
<td class=kW>6:0</td>
<td class=kL>0:4</td>
<td class=kW>7:4</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>5:6</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>5:3</td>
<td class=kL>3:6</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>5:0 K</td>
<td class=br>65:67</td><td class=br>-2</td>
<td class=bc>8 - 4 - 11</td>
<td class=br><strong>20</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>83.</td><td class=kt><a href="stats.php?idpl=378&x=-61&p=Ni%20Lyksholm">Ni Lyksholm</a></td><td class=kW>5:4</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>4:6</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>0:7</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kW>6:0</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>10:2</td>
<td class=kW>5:0 K</td>
<td class=br>56:68</td><td class=br>-12</td>
<td class=bc>8 - 2 - 13</td>
<td class=br><strong>18</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>84.</td><td class=kt><a href="stats.php?idpl=226&x=-61&p=Ka%20Pirumshoieva">Ka Pirumshoieva</a></td><td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>5:0 K</td>
<td class=br>54:60</td><td class=br>-6</td>
<td class=bc>4 - 7 - 12</td>
<td class=br><strong>15</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>85.</td><td class=kt><a href="stats.php?idpl=380&x=-61&p=Be%20Nyg%C3%A5rd">Be Nyg�rd</a></td><td class=kW>9:4</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>1:7</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>3:7</td>
<td class=kL>2:8</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>5:0 K</td>
<td class=br>60:83</td><td class=br>-23</td>
<td class=bc>6 - 3 - 14</td>
<td class=br><strong>15</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>86.</td><td class=kt><a href="stats.php?idpl=414&x=-61&p=Ei%20Rompa">Ei Rompa</a></td><td class=kL>1:9</td>
<td class=kL>4:5</td>
<td class=kL>2:8</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>1:7</td>
<td class=kL>3:6</td>
<td class=kL>0:6</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>7:6</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:0 K</td>
<td class=br>57:100</td><td class=br>-43</td>
<td class=bc>4 - 3 - 16</td>
<td class=br><strong>11</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>87.</td><td class=kt><a href="stats.php?idpl=162&x=-61&p=Gi%20Remeika">Gi Remeika</a></td><td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>1:8</td>
<td class=kL>0:1</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kT>0:0</td>
<td class=kL>4:8</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>2:10</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:0 K</td>
<td class=br>41:95</td><td class=br>-54</td>
<td class=bc>3 - 3 - 17</td>
<td class=br><strong>9</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>88.</td><td class=kt><a href="stats.php?idpl=70&x=-61&p=An%20Kuz%C5%86ecovs">An Kuz�ecovs</a></td><td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kx>*</td>
<td class=br>0:115</td><td class=br>-115</td>
<td class=bc>0 - 0 - 23</td>
<td class=br><strong>0</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Mets�l� Lari</td><td class=bc>-</td><td class=blW>Kvasnikova Polina</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Nyg�rd Benjamin</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=blW>Sippo Daniel</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Lyksholm Nico</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lezik Matej</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Uimonen Tomi</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Pedersen Richard</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>0 : 5 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kvasnikova Polina</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mets�l� Lari</td><td class=bc>-</td><td class=blW>Nyg�rd Benjamin</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=blW>Sippo Daniel</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lezik Matej</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Uimonen Tomi</td><td class=bc>-</td><td class=blW>Pedersen Richard</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>6 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Nyg�rd Benjamin</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=blW>Sippo Daniel</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mets�l� Lari</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Matysek Daniel</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>Pedersen Richard</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Lezik Matej</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Uimonen Tomi</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 0 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Nyg�rd Benjamin</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kvasnikova Polina</td><td class=bc>-</td><td class=bl>Sippo Daniel</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mets�l� Lari</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=blW>Pedersen Richard</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Lezik Matej</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Uimonen Tomi</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Sippo Daniel</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kvasnikova Polina</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Mets�l� Lari</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=blW>Pedersen Richard</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Matysek Daniel</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Lezik Matej</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Sippo Daniel</td><td class=bc>-</td><td class=blW>Lyksholm Nico</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=bl>Pedersen Richard</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mets�l� Lari</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pikl Vaclav</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>Uimonen Tomi</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Lyksholm Nico</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Sippo Daniel</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Forsberg James-John</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=blW>Pedersen Richard</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mets�l� Lari</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=bl>Uimonen Tomi</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=bl>Lezik Matej</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Rompa Eike</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Sippo Daniel</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Pedersen Richard</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mets�l� Lari</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pikl Vaclav</td><td class=bc>-</td><td class=bl>Uimonen Tomi</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Lezik Matej</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=blW>Fylling Amund Risa</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Rompa Eike</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=blW>Forsberg James-John</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Pedersen Richard</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Sippo Daniel</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Uimonen Tomi</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Mets�l� Lari</td><td class=bc>-</td><td class=blW>Lezik Matej</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=blW>Fylling Amund Risa</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Forsberg James-John</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Pedersen Richard</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Sippo Daniel</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=bl>Uimonen Tomi</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Lezik Matej</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=bl>Fylling Amund Risa</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mets�l� Lari</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pikl Vaclav</td><td class=bc>-</td><td class=bl>Matysek Daniel</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=bl>Pedersen Richard</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sippo Daniel</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Nyg�rd Benjamin</td><td class=bc>-</td><td class=bl>Uimonen Tomi</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Lezik Matej</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Kvasnikova Polina</td><td class=bc>-</td><td class=bl>Fylling Amund Risa</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=blW>Matysek Daniel</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mets�l� Lari</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Pedersen Richard</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Rompa Eike</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Uimonen Tomi</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Sippo Daniel</td><td class=bc>-</td><td class=blW>Lezik Matej</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Fylling Amund Risa</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=blW>Matysek Daniel</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Pedersen Richard</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Uimonen Tomi</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Lezik Matej</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Fylling Amund Risa</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Sippo Daniel</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Matysek Daniel</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=blW>Pikl Vaclav</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Mets�l� Lari</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pedersen Richard</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=bl>Uimonen Tomi</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Lezik Matej</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Fylling Amund Risa</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Matysek Daniel</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Sippo Daniel</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Pikl Vaclav</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Mets�l� Lari</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Uimonen Tomi</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pedersen Richard</td><td class=bc>-</td><td class=blW>Lezik Matej</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=bl>Fylling Amund Risa</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Matysek Daniel</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Pikl Vaclav</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Sippo Daniel</td><td class=bc>-</td><td class=blW>Mets�l� Lari</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Uimonen Tomi</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Lezik Matej</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Fylling Amund Risa</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pedersen Richard</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=blW>Matysek Daniel</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Pikl Vaclav</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Mets�l� Lari</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Sippo Daniel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Kvasnikova Polina</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Uimonen Tomi</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=blW>Lezik Matej</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Fylling Amund Risa</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=bl>Matysek Daniel</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pedersen Richard</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Mets�l� Lari</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Lyksholm Nico</td><td class=bc>-</td><td class=bl>Kvasnikova Polina</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Sippo Daniel</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Uimonen Tomi</td><td class=bc>-</td><td class=blW>Lezik Matej</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Fylling Amund Risa</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Matysek Daniel</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pedersen Richard</td><td class=bc>-</td><td class=bl>Mets�l� Lari</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Kvasnikova Polina</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=bl>Nyg�rd Benjamin</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Lezik Matej</td><td class=bc>-</td><td class=bl>Fylling Amund Risa</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Uimonen Tomi</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Matysek Daniel</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Pikl Vaclav</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Mets�l� Lari</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pedersen Richard</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Kvasnikova Polina</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Nyg�rd Benjamin</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=blW>Sippo Daniel</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Lezik Matej</td><td class=bc>-</td><td class=bl>Matysek Daniel</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Uimonen Tomi</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Mets�l� Lari</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=bl>Kvasnikova Polina</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pedersen Richard</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Nyg�rd Benjamin</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Rompa Eike</td><td class=bc>-</td><td class=bl>Sippo Daniel</td><td class=bc>7 : 6</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Lyksholm Nico</td><td class=bc>2 : 10</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Matysek Daniel</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Lezik Matej</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Uimonen Tomi</td><td class=bc>-</td><td class=blW>Mets�l� Lari</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Kvasnikova Polina</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Nyg�rd Benjamin</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pedersen Richard</td><td class=bc>-</td><td class=bl>Sippo Daniel</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Pirumshoieva Karyna</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Pikl Vaclav</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>Mets�l� Lari</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Lezik Matej</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Uimonen Tomi</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>Kvasnikova Polina</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Nyg�rd Benjamin</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Sippo Daniel</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Pedersen Richard</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=blW>Mets�l� Lari</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Lezik Matej</td><td class=bc>-</td><td class=bl>Kvasnikova Polina</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Uimonen Tomi</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>Nyg�rd Benjamin</td><td class=bc>4 : 9</tr></td>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Sippo Daniel</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Lyksholm Nico</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>Pedersen Richard</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=bl>Mets�l� Lari</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Kvasnikova Polina</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Fylling Amund Risa</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Lezik Matej</td><td class=bc>-</td><td class=bl>Nyg�rd Benjamin</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Uimonen Tomi</td><td class=bc>-</td><td class=blW>Sippo Daniel</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>Lyksholm Nico</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Forsberg James-John</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=brW>Mets�l� Lari</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=bl>Kvasnikova Polina</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Matysek Daniel</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Nyg�rd Benjamin</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>Sippo Daniel</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Lezik Matej</td><td class=bc>-</td><td class=blW>Lyksholm Nico</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Uimonen Tomi</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Forsberg James-John</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Pedersen Richard</td><td class=bc>2 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group OpenC</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>89</td>
<td class=ic>90</td>
<td class=ic>91</td>
<td class=ic>92</td>
<td class=ic>93</td>
<td class=ic>94</td>
<td class=ic>95</td>
<td class=ic>96</td>
<td class=ic>97</td>
<td class=ic>98</td>
<td class=ic>99</td>
<td class=ic>100</td>
<td class=ic>101</td>
<td class=ic>102</td>
<td class=ic>103</td>
<td class=ic>104</td>
<td class=ic>105</td>
<td class=ic>106</td>
<td class=ic>107</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>89.</td><td class=kt><a href="stats.php?idpl=145&x=-61&p=Ma%20Zenisek">Ma Zenisek</a></td><td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kW>7:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=br>60:35</td><td class=br>+25</td>
<td class=bc>13 - 2 - 3</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>90.</td><td class=kt><a href="stats.php?idpl=407&x=-61&p=Vl%20Kraus">Vl Kraus</a></td><td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>7:3</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>9:2</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kL>4:5</td>
<td class=kW>5:1</td>
<td class=br>66:37</td><td class=br>+29</td>
<td class=bc>13 - 0 - 5</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>91.</td><td class=kt><a href="stats.php?idpl=125&x=-61&p=Si%20Thomas">Si Thomas</a></td><td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>0:4</td>
<td class=kW>6:3</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>5:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>8:2</td>
<td class=kT>4:4</td>
<td class=kW>6:4</td>
<td class=kW>5:2</td>
<td class=kW>7:3</td>
<td class=br>61:45</td><td class=br>+16</td>
<td class=bc>10 - 3 - 5</td>
<td class=br><strong>23</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>92.</td><td class=kt><a href="stats.php?idpl=426&x=-61&p=Wi%20Wallin">Wi Wallin</a></td><td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>5:6</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=br>58:47</td><td class=br>+11</td>
<td class=bc>11 - 1 - 6</td>
<td class=br><strong>23</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>93.</td><td class=kt><a href="stats.php?idpl=393&x=-61&p=Ju%20Itkonen">Ju Itkonen</a></td><td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kL>0:1</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=br>54:35</td><td class=br>+19</td>
<td class=bc>10 - 2 - 6</td>
<td class=br><strong>22</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>94.</td><td class=kt><a href="stats.php?idpl=127&x=-61&p=Mi%20Sevr">Mi Sevr</a></td><td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>9:1</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kW>5:3</td>
<td class=kW>7:5</td>
<td class=kW>5:1</td>
<td class=kW>6:5</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>8:0</td>
<td class=br>77:54</td><td class=br>+23</td>
<td class=bc>10 - 2 - 6</td>
<td class=br><strong>22</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>95.</td><td class=kt><a href="stats.php?idpl=367&x=-61&p=Ol%20Pylypenko">Ol Pylypenko</a></td><td class=kW>3:2</td>
<td class=kL>3:7</td>
<td class=kW>5:2</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:9</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=br>54:49</td><td class=br>+5</td>
<td class=bc>10 - 2 - 6</td>
<td class=br><strong>22</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>96.</td><td class=kt><a href="stats.php?idpl=202&x=-61&p=Vl%20Voronov">Vl Voronov</a></td><td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>6:5</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=br>48:48</td><td class=br>0</td>
<td class=bc>9 - 3 - 6</td>
<td class=br><strong>21</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>97.</td><td class=kt><a href="stats.php?idpl=413&x=-61&p=Fr%20Bruneske">Fr Bruneske</a></td><td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>6:4</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kL>0:2</td>
<td class=kW>4:3</td>
<td class=br>46:43</td><td class=br>+3</td>
<td class=bc>9 - 3 - 6</td>
<td class=br><strong>21</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>98.</td><td class=kt><a href="stats.php?idpl=416&x=-61&p=He%20Petuch">He Petuch</a></td><td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>0:5</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=br>55:46</td><td class=br>+9</td>
<td class=bc>8 - 3 - 7</td>
<td class=br><strong>19</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>99.</td><td class=kt><a href="stats.php?idpl=135&x=-61&p=Mi%20Margolis">Mi Margolis</a></td><td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kL>2:5</td>
<td class=kL>5:6</td>
<td class=kL>4:6</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=br>53:57</td><td class=br>-4</td>
<td class=bc>8 - 2 - 8</td>
<td class=br><strong>18</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>100.</td><td class=kt><a href="stats.php?idpl=133&x=-61&p=Au%20Pleikys">Au Pleikys</a></td><td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>8:2</td>
<td class=kW>5:2</td>
<td class=br>48:35</td><td class=br>+13</td>
<td class=bc>7 - 4 - 7</td>
<td class=br><strong>18</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>101.</td><td class=kt><a href="stats.php?idpl=394&x=-61&p=Em%20Uimonen">Em Uimonen</a></td><td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>6:5</td>
<td class=kL>0:2</td>
<td class=kL>5:7</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=br>53:50</td><td class=br>+3</td>
<td class=bc>8 - 2 - 8</td>
<td class=br><strong>18</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>102.</td><td class=kt><a href="stats.php?idpl=218&x=-61&p=Dm%20Stykailo">Dm Stykailo</a></td><td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>41:50</td><td class=br>-9</td>
<td class=bc>6 - 2 - 10</td>
<td class=br><strong>14</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>103.</td><td class=kt><a href="stats.php?idpl=364&x=-61&p=Er%20Bernhauser">Er Bernhauser</a></td><td class=kL>3:7</td>
<td class=kL>2:9</td>
<td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>5:6</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=br>50:65</td><td class=br>-15</td>
<td class=bc>5 - 3 - 10</td>
<td class=br><strong>13</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>104.</td><td class=kt><a href="stats.php?idpl=131&x=-61&p=My%20Verbytskyy">My Verbytskyy</a></td><td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=br>40:57</td><td class=br>-17</td>
<td class=bc>3 - 5 - 10</td>
<td class=br><strong>11</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>105.</td><td class=kt><a href="stats.php?idpl=220&x=-61&p=Jo%20Pleikys">Jo Pleikys</a></td><td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kL>4:6</td>
<td class=kW>2:1</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kW>1:0</td>
<td class=kT>0:0</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=br>25:47</td><td class=br>-22</td>
<td class=bc>4 - 3 - 11</td>
<td class=br><strong>11</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>106.</td><td class=kt><a href="stats.php?idpl=154&x=-61&p=Ju%20Steisunas">Ju Steisunas</a></td><td class=kL>3:4</td>
<td class=kW>5:4</td>
<td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kW>2:0</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>2:8</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>32:77</td><td class=br>-45</td>
<td class=bc>4 - 0 - 14</td>
<td class=br><strong>8</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>107.</td><td class=kt><a href="stats.php?idpl=152&x=-61&p=To%20Ulis">To Ulis</a></td><td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:8</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>29:73</td><td class=br>-44</td>
<td class=bc>2 - 0 - 16</td>
<td class=br><strong>4</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Kraus Vladimir</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Itkonen Juho</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Bruneske Frank</td><td class=bc>-</td><td class=bl>Stykailo Dmitri</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Margolis Mihail</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Sevr Milos</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Bernhauser Erik</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kraus Vladimir</td><td class=bc>-</td><td class=blW>Steisunas Julius</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Stykailo Dmitri</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Itkonen Juho</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Bruneske Frank</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Margolis Mihail</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Sevr Milos</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Zenisek Martin</td><td class=bc>-</td><td class=blW>Wallin Wilton</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Uimonen Emil</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Stykailo Dmitri</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kraus Vladimir</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Itkonen Juho</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=bl>Sevr Milos</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Margolis Mihail</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Wallin Wilton</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>Voronov Vladimir</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Stykailo Dmitri</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Uimonen Emil</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Bernhauser Erik</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kraus Vladimir</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Sevr Milos</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Itkonen Juho</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Bruneske Frank</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Margolis Mihail</td><td class=bc>-</td><td class=blW>Voronov Vladimir</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Steisunas Julius</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Uimonen Emil</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Sevr Milos</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Kraus Vladimir</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Itkonen Juho</td><td class=bc>-</td><td class=blW>Voronov Vladimir</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Margolis Mihail</td><td class=bc>-</td><td class=blW>Pylypenko Oleksandr</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=blW>Pleikys Jonas</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Sevr Milos</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kraus Vladimir</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Itkonen Juho</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ulis Tomas</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Sevr Milos</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Wallin Wilton</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Uimonen Emil</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Kraus Vladimir</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Itkonen Juho</td><td class=bc>-</td><td class=bl>Margolis Mihail</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Sevr Milos</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Wallin Wilton</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Stykailo Dmitri</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Pylypenko Oleksandr</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kraus Vladimir</td><td class=bc>-</td><td class=bl>Margolis Mihail</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Sevr Milos</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Voronov Vladimir</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Stykailo Dmitri</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Margolis Mihail</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Bruneske Frank</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kraus Vladimir</td><td class=bc>-</td><td class=blW>Itkonen Juho</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Wallin Wilton</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sevr Milos</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ulis Tomas</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=blW>Margolis Mihail</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Steisunas Julius</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Itkonen Juho</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>2 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=blW>Voronov Vladimir</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Sevr Milos</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Margolis Mihail</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Bruneske Frank</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=bl>Itkonen Juho</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Kraus Vladimir</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Sevr Milos</td><td class=bc>-</td><td class=blW>Margolis Mihail</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Bruneske Frank</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Itkonen Juho</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=blW>Kraus Vladimir</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Bernhauser Erik</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Zenisek Martin</td><td class=bc>-</td><td class=blW>Pylypenko Oleksandr</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>Margolis Mihail</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Petuch Hermann</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Sevr Milos</td><td class=bc>-</td><td class=blW>Itkonen Juho</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Kraus Vladimir</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=blW>Uimonen Emil</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zenisek Martin</td><td class=bc>-</td><td class=bl>Margolis Mihail</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>Itkonen Juho</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Sevr Milos</td><td class=bc>-</td><td class=blW>Kraus Vladimir</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Uimonen Emil</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Steisunas Julius</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Margolis Mihail</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Itkonen Juho</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>Kraus Vladimir</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Petuch Hermann</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Sevr Milos</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>7 : 5</tr></td>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Stykailo Dmitri</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Margolis Mihail</td><td class=bc>-</td><td class=blW>Bruneske Frank</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Itkonen Juho</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Kraus Vladimir</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Bernhauser Erik</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=blW>Uimonen Emil</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Petuch Hermann</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Sevr Milos</td><td class=bc>-</td><td class=bl>Stykailo Dmitri</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Verbytskyy Mykola</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Bruneske Frank</td><td class=bc>-</td><td class=bl>Itkonen Juho</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Margolis Mihail</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Kraus Vladimir</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>Stykailo Dmitri</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Sevr Milos</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>8 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Itkonen Juho</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Bruneske Frank</td><td class=bc>-</td><td class=bl>Kraus Vladimir</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Margolis Mihail</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Stykailo Dmitri</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Petuch Hermann</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>Kraus Vladimir</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Itkonen Juho</td><td class=bc>-</td><td class=blW>Bernhauser Erik</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=blW>Uimonen Emil</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Margolis Mihail</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Stykailo Dmitri</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=blW>Sevr Milos</td><td class=bc>3 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</table></div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
