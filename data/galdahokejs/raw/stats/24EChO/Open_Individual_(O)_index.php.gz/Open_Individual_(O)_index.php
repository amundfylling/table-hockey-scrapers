<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Open Individual (O)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span>Open Individual (O)</span></h2></div></div></div></div><p><div align="center">
<h2 class="page-title">Open Individual (O), 15. j�nijs 2024</h2>
<div align=center>
<a href="Open_Individual_(O)_cross.php">Basic and placement groups</a><br>
<a href="Open_Individual_(O)_playoff.php">Placement matches</a><br>
<a href="Open_Individual_(O)_offence.php">Best forwards</a><br>
<a href="Open_Individual_(O)_defence.php">Best defenders</a><br>
</div>
<p class=v>Final table<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0 class="rnk">
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">M</th>
<th align="center">+</th>
<th align="center">=</th>
<th align="center">-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">Pts</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al><a href="stats.php?idpl=4&x=-61&p=Caics%20Edgars">Caics Edgars</a></td>
<td class=al>LAT</td>
<td class=ar>62</td>
<td class=ar>50</td>
<td class=ar>3</td>
<td class=ar>9</td>
<td class=ar>259</td>
<td class=al>&nbsp;:&nbsp;132</td>
<td class=ar>103</td>
</tr><tr><td class=br>2.</td>
<td class=bl><a href="stats.php?idpl=7&x=-61&p=Kalni%C5%86%C5%A1%20Rainers">Kalni�� Rainers</a></td>
<td class=bl>LAT</td>
<td class=br>59</td>
<td class=br>49</td>
<td class=br>3</td>
<td class=br>7</td>
<td class=br>284</td>
<td class=bl>&nbsp;:&nbsp;127</td>
<td class=br>101</td>
</tr><tr><td class=ar>3.</td>
<td class=al><a href="stats.php?idpl=368&x=-61&p=Umanskyy%20Anton">Umanskyy Anton</a></td>
<td class=al>UKR</td>
<td class=ar>61</td>
<td class=ar>40</td>
<td class=ar>2</td>
<td class=ar>19</td>
<td class=ar>234</td>
<td class=al>&nbsp;:&nbsp;126</td>
<td class=ar>82</td>
</tr><tr><td class=br>4.</td>
<td class=bl><a href="stats.php?idpl=101&x=-61&p=Matantsev%20Evgeniy">Matantsev Evgeniy</a></td>
<td class=bl>UKR</td>
<td class=br>59</td>
<td class=br>40</td>
<td class=br>4</td>
<td class=br>15</td>
<td class=br>260</td>
<td class=bl>&nbsp;:&nbsp;145</td>
<td class=br>84</td>
</tr><tr><td class=ar>5.</td>
<td class=al><a href="stats.php?idpl=105&x=-61&p=Petr%20Patrik">Petr Patrik</a></td>
<td class=al>CZE</td>
<td class=ar>52</td>
<td class=ar>38</td>
<td class=ar>2</td>
<td class=ar>12</td>
<td class=ar>220</td>
<td class=al>&nbsp;:&nbsp;134</td>
<td class=ar>78</td>
</tr><tr><td class=br>6.</td>
<td class=bl><a href="stats.php?idpl=269&x=-61&p=Eriksson%20Kevin">Eriksson Kevin</a></td>
<td class=bl>FIN</td>
<td class=br>52</td>
<td class=br>35</td>
<td class=br>5</td>
<td class=br>12</td>
<td class=br>183</td>
<td class=bl>&nbsp;:&nbsp;96</td>
<td class=br>75</td>
</tr><tr><td class=ar>7.</td>
<td class=al><a href="stats.php?idpl=116&x=-61&p=Matantsev%20Artem">Matantsev Artem</a></td>
<td class=al>UKR</td>
<td class=ar>52</td>
<td class=ar>32</td>
<td class=ar>4</td>
<td class=ar>16</td>
<td class=ar>177</td>
<td class=al>&nbsp;:&nbsp;112</td>
<td class=ar>68</td>
</tr><tr><td class=br>8.</td>
<td class=bl><a href="stats.php?idpl=43&x=-61&p=Naglis%20Edgars">Naglis Edgars</a></td>
<td class=bl>LAT</td>
<td class=br>50</td>
<td class=br>25</td>
<td class=br>5</td>
<td class=br>20</td>
<td class=br>169</td>
<td class=bl>&nbsp;:&nbsp;158</td>
<td class=br>55</td>
</tr><tr><td class=ar>9.</td>
<td class=al><a href="stats.php?idpl=92&x=-61&p=Smagars%20Valts">Smagars Valts</a></td>
<td class=al>LAT</td>
<td class=ar>48</td>
<td class=ar>27</td>
<td class=ar>7</td>
<td class=ar>14</td>
<td class=ar>166</td>
<td class=al>&nbsp;:&nbsp;120</td>
<td class=ar>61</td>
</tr><tr><td class=br>10.</td>
<td class=bl><a href="stats.php?idpl=104&x=-61&p=Nilsson%20Eddie">Nilsson Eddie</a></td>
<td class=bl>SWE</td>
<td class=br>47</td>
<td class=br>25</td>
<td class=br>5</td>
<td class=br>17</td>
<td class=br>141</td>
<td class=bl>&nbsp;:&nbsp;112</td>
<td class=br>55</td>
</tr><tr><td class=ar>11.</td>
<td class=al><a href="stats.php?idpl=227&x=-61&p=%C3%96sterman%20Hans">�sterman Hans</a></td>
<td class=al>SWE</td>
<td class=ar>48</td>
<td class=ar>30</td>
<td class=ar>3</td>
<td class=ar>15</td>
<td class=ar>155</td>
<td class=al>&nbsp;:&nbsp;97</td>
<td class=ar>63</td>
</tr><tr><td class=br>12.</td>
<td class=bl><a href="stats.php?idpl=229&x=-61&p=%C3%96sterman%20Uno">�sterman Uno</a></td>
<td class=bl>SWE</td>
<td class=br>46</td>
<td class=br>25</td>
<td class=br>7</td>
<td class=br>14</td>
<td class=br>153</td>
<td class=bl>&nbsp;:&nbsp;118</td>
<td class=br>57</td>
</tr><tr><td class=ar>13.</td>
<td class=al><a href="stats.php?idpl=423&x=-61&p=Blume%20Olof">Blume Olof</a></td>
<td class=al>SWE</td>
<td class=ar>48</td>
<td class=ar>30</td>
<td class=ar>4</td>
<td class=ar>14</td>
<td class=ar>144</td>
<td class=al>&nbsp;:&nbsp;107</td>
<td class=ar>64</td>
</tr><tr><td class=br>14.</td>
<td class=bl><a href="stats.php?idpl=240&x=-61&p=Korabel%20Oleksii">Korabel Oleksii</a></td>
<td class=bl>UKR</td>
<td class=br>46</td>
<td class=br>28</td>
<td class=br>3</td>
<td class=br>15</td>
<td class=br>170</td>
<td class=bl>&nbsp;:&nbsp;104</td>
<td class=br>59</td>
</tr><tr><td class=ar>15.</td>
<td class=al><a href="stats.php?idpl=109&x=-61&p=Kobrle%20Michal">Kobrle Michal</a></td>
<td class=al>CZE</td>
<td class=ar>50</td>
<td class=ar>24</td>
<td class=ar>12</td>
<td class=ar>14</td>
<td class=ar>197</td>
<td class=al>&nbsp;:&nbsp;147</td>
<td class=ar>60</td>
</tr><tr><td class=br>16.</td>
<td class=bl><a href="stats.php?idpl=83&x=-61&p=Baumanis%20Toms">Baumanis Toms</a></td>
<td class=bl>LAT</td>
<td class=br>47</td>
<td class=br>22</td>
<td class=br>12</td>
<td class=br>13</td>
<td class=br>149</td>
<td class=bl>&nbsp;:&nbsp;116</td>
<td class=br>56</td>
</tr><tr><td class=ar>17.</td>
<td class=al><a href="stats.php?idpl=27&x=-61&p=Sili%C5%86%C5%A1%20Elvijs">Sili�� Elvijs</a></td>
<td class=al>LAT</td>
<td class=ar>43</td>
<td class=ar>25</td>
<td class=ar>6</td>
<td class=ar>12</td>
<td class=ar>131</td>
<td class=al>&nbsp;:&nbsp;100</td>
<td class=ar>56</td>
</tr><tr><td class=br>18.</td>
<td class=bl><a href="stats.php?idpl=29&x=-61&p=Lagzdi%C5%86a%20Krista%20Annija">Lagzdi�a Krista Annija</a></td>
<td class=bl>LAT</td>
<td class=br>42</td>
<td class=br>24</td>
<td class=br>5</td>
<td class=br>13</td>
<td class=br>128</td>
<td class=bl>&nbsp;:&nbsp;92</td>
<td class=br>53</td>
</tr><tr><td class=ar>19.</td>
<td class=al><a href="stats.php?idpl=381&x=-61&p=Klippen%20Magnus">Klippen Magnus</a></td>
<td class=al>NOR</td>
<td class=ar>43</td>
<td class=ar>24</td>
<td class=ar>3</td>
<td class=ar>16</td>
<td class=ar>126</td>
<td class=al>&nbsp;:&nbsp;101</td>
<td class=ar>51</td>
</tr><tr><td class=br>20.</td>
<td class=bl><a href="stats.php?idpl=123&x=-61&p=Jurka%20Lukass">Jurka Lukass</a></td>
<td class=bl>LAT</td>
<td class=br>40</td>
<td class=br>18</td>
<td class=br>7</td>
<td class=br>15</td>
<td class=br>110</td>
<td class=bl>&nbsp;:&nbsp;93</td>
<td class=br>43</td>
</tr><tr><td class=ar>21.</td>
<td class=al><a href="stats.php?idpl=212&x=-61&p=Ziemelis%20Didzis">Ziemelis Didzis</a></td>
<td class=al>LAT</td>
<td class=ar>41</td>
<td class=ar>18</td>
<td class=ar>8</td>
<td class=ar>15</td>
<td class=ar>116</td>
<td class=al>&nbsp;:&nbsp;92</td>
<td class=ar>44</td>
</tr><tr><td class=br>22.</td>
<td class=bl><a href="stats.php?idpl=44&x=-61&p=Naglis%20Kristaps">Naglis Kristaps</a></td>
<td class=bl>LAT</td>
<td class=br>40</td>
<td class=br>16</td>
<td class=br>9</td>
<td class=br>15</td>
<td class=br>112</td>
<td class=bl>&nbsp;:&nbsp;110</td>
<td class=br>41</td>
</tr><tr><td class=ar>23.</td>
<td class=al><a href="stats.php?idpl=419&x=-61&p=%C3%96stlund%20Peter">�stlund Peter</a></td>
<td class=al>SWE</td>
<td class=ar>42</td>
<td class=ar>23</td>
<td class=ar>2</td>
<td class=ar>17</td>
<td class=ar>113</td>
<td class=al>&nbsp;:&nbsp;91</td>
<td class=ar>48</td>
</tr><tr><td class=br>24.</td>
<td class=bl><a href="stats.php?idpl=28&x=-61&p=Lagzdi%C5%86%C5%A1%20Sandis%20Kristaps">Lagzdi�� Sandis Kristaps</a></td>
<td class=bl>LAT</td>
<td class=br>44</td>
<td class=br>24</td>
<td class=br>4</td>
<td class=br>16</td>
<td class=br>127</td>
<td class=bl>&nbsp;:&nbsp;81</td>
<td class=br>52</td>
</tr><tr><td class=ar>25.</td>
<td class=al><a href="stats.php?idpl=40&x=-61&p=Sili%C5%86%C5%A1%20Alvis">Sili�� Alvis</a></td>
<td class=al>LAT</td>
<td class=ar>41</td>
<td class=ar>20</td>
<td class=ar>5</td>
<td class=ar>16</td>
<td class=ar>124</td>
<td class=al>&nbsp;:&nbsp;111</td>
<td class=ar>45</td>
</tr><tr><td class=br>26.</td>
<td class=bl><a href="stats.php?idpl=239&x=-61&p=Suominen%20Benjamin">Suominen Benjamin</a></td>
<td class=bl>FIN</td>
<td class=br>42</td>
<td class=br>18</td>
<td class=br>8</td>
<td class=br>16</td>
<td class=br>117</td>
<td class=bl>&nbsp;:&nbsp;117</td>
<td class=br>44</td>
</tr><tr><td class=ar>27.</td>
<td class=al><a href="stats.php?idpl=39&x=-61&p=Rieksti%C5%86%C5%A1%20Kristaps">Rieksti�� Kristaps</a></td>
<td class=al>LAT</td>
<td class=ar>42</td>
<td class=ar>20</td>
<td class=ar>8</td>
<td class=ar>14</td>
<td class=ar>103</td>
<td class=al>&nbsp;:&nbsp;95</td>
<td class=ar>48</td>
</tr><tr><td class=br>28.</td>
<td class=bl><a href="stats.php?idpl=108&x=-61&p=Madera%20Martin">Madera Martin</a></td>
<td class=bl>CZE</td>
<td class=br>40</td>
<td class=br>17</td>
<td class=br>8</td>
<td class=br>15</td>
<td class=br>120</td>
<td class=bl>&nbsp;:&nbsp;109</td>
<td class=br>42</td>
</tr><tr><td class=ar>29.</td>
<td class=al><a href="stats.php?idpl=213&x=-61&p=Ka%C5%86eps%20Ed%C5%BEus">Ka�eps Ed�us</a></td>
<td class=al>LAT</td>
<td class=ar>42</td>
<td class=ar>20</td>
<td class=ar>8</td>
<td class=ar>14</td>
<td class=ar>124</td>
<td class=al>&nbsp;:&nbsp;114</td>
<td class=ar>48</td>
</tr><tr><td class=br>30.</td>
<td class=bl><a href="stats.php?idpl=42&x=-61&p=Liepi%C5%86%C5%A1%20Em%C4%ABls">Liepi�� Em�ls</a></td>
<td class=bl>LAT</td>
<td class=br>41</td>
<td class=br>18</td>
<td class=br>5</td>
<td class=br>18</td>
<td class=br>138</td>
<td class=bl>&nbsp;:&nbsp;129</td>
<td class=br>41</td>
</tr><tr><td class=ar>31.</td>
<td class=al><a href="stats.php?idpl=97&x=-61&p=Lasmanis%20Gints">Lasmanis Gints</a></td>
<td class=al>LAT</td>
<td class=ar>42</td>
<td class=ar>20</td>
<td class=ar>5</td>
<td class=ar>17</td>
<td class=ar>130</td>
<td class=al>&nbsp;:&nbsp;125</td>
<td class=ar>45</td>
</tr><tr><td class=br>32.</td>
<td class=bl><a href="stats.php?idpl=186&x=-61&p=Kamzols%20R%C5%ABdolfs">Kamzols R�dolfs</a></td>
<td class=bl>LAT</td>
<td class=br>40</td>
<td class=br>16</td>
<td class=br>6</td>
<td class=br>18</td>
<td class=br>116</td>
<td class=bl>&nbsp;:&nbsp;131</td>
<td class=br>38</td>
</tr><tr><td class=ar>33.</td>
<td class=al><a href="stats.php?idpl=382&x=-61&p=Klippen%20Oystein">Klippen Oystein</a></td>
<td class=al>NOR</td>
<td class=ar>36</td>
<td class=ar>14</td>
<td class=ar>9</td>
<td class=ar>13</td>
<td class=ar>109</td>
<td class=al>&nbsp;:&nbsp;108</td>
<td class=ar>37</td>
</tr><tr><td class=br>34.</td>
<td class=bl><a href="stats.php?idpl=30&x=-61&p=Jakseboga%20Mat%C4%ABss">Jakseboga Mat�ss</a></td>
<td class=bl>LAT</td>
<td class=br>37</td>
<td class=br>14</td>
<td class=br>11</td>
<td class=br>12</td>
<td class=br>96</td>
<td class=bl>&nbsp;:&nbsp;101</td>
<td class=br>39</td>
</tr><tr><td class=ar>35.</td>
<td class=al><a href="stats.php?idpl=341&x=-61&p=Kaln%C4%93vics%20J%C4%81nis">Kaln�vics J�nis</a></td>
<td class=al>LAT</td>
<td class=ar>36</td>
<td class=ar>13</td>
<td class=ar>12</td>
<td class=ar>11</td>
<td class=ar>87</td>
<td class=al>&nbsp;:&nbsp;84</td>
<td class=ar>38</td>
</tr><tr><td class=br>36.</td>
<td class=bl><a href="stats.php?idpl=235&x=-61&p=Fjermestad%20Andreas">Fjermestad Andreas</a></td>
<td class=bl>NOR</td>
<td class=br>36</td>
<td class=br>15</td>
<td class=br>7</td>
<td class=br>14</td>
<td class=br>103</td>
<td class=bl>&nbsp;:&nbsp;108</td>
<td class=br>37</td>
</tr><tr><td class=ar>37.</td>
<td class=al><a href="stats.php?idpl=400&x=-61&p=Matysek%20Jakub">Matysek Jakub</a></td>
<td class=al>CZE</td>
<td class=ar>37</td>
<td class=ar>15</td>
<td class=ar>10</td>
<td class=ar>12</td>
<td class=ar>107</td>
<td class=al>&nbsp;:&nbsp;104</td>
<td class=ar>40</td>
</tr><tr><td class=br>38.</td>
<td class=bl><a href="stats.php?idpl=420&x=-61&p=Steen%20Herman">Steen Herman</a></td>
<td class=bl>SWE</td>
<td class=br>36</td>
<td class=br>17</td>
<td class=br>4</td>
<td class=br>15</td>
<td class=br>101</td>
<td class=bl>&nbsp;:&nbsp;99</td>
<td class=br>38</td>
</tr><tr><td class=ar>39.</td>
<td class=al><a href="stats.php?idpl=390&x=-61&p=Miettinen%20Petrus">Miettinen Petrus</a></td>
<td class=al>FIN</td>
<td class=ar>37</td>
<td class=ar>18</td>
<td class=ar>4</td>
<td class=ar>15</td>
<td class=ar>103</td>
<td class=al>&nbsp;:&nbsp;89</td>
<td class=ar>40</td>
</tr><tr><td class=br>40.</td>
<td class=bl><a href="stats.php?idpl=430&x=-61&p=Blomberg%20Niklas">Blomberg Niklas</a></td>
<td class=bl>SWE</td>
<td class=br>36</td>
<td class=br>14</td>
<td class=br>9</td>
<td class=br>13</td>
<td class=br>107</td>
<td class=bl>&nbsp;:&nbsp;85</td>
<td class=br>37</td>
</tr><tr><td class=ar>41.</td>
<td class=al><a href="stats.php?idpl=369&x=-61&p=Spivakovskyy%20Mykhaylo">Spivakovskyy Mykhaylo</a></td>
<td class=al>UKR</td>
<td class=ar>37</td>
<td class=ar>14</td>
<td class=ar>9</td>
<td class=ar>14</td>
<td class=ar>98</td>
<td class=al>&nbsp;:&nbsp;92</td>
<td class=ar>37</td>
</tr><tr><td class=br>42.</td>
<td class=bl><a href="stats.php?idpl=114&x=-61&p=Bo%C5%BEi%C4%8D%20An%C5%BEe">Bo�i� An�e</a></td>
<td class=bl>SLO</td>
<td class=br>36</td>
<td class=br>14</td>
<td class=br>7</td>
<td class=br>15</td>
<td class=br>88</td>
<td class=bl>&nbsp;:&nbsp;97</td>
<td class=br>35</td>
</tr><tr><td class=ar>43.</td>
<td class=al><a href="stats.php?idpl=103&x=-61&p=Rieksti%C5%86%C5%A1%20Rolands">Rieksti�� Rolands</a></td>
<td class=al>LAT</td>
<td class=ar>37</td>
<td class=ar>17</td>
<td class=ar>6</td>
<td class=ar>14</td>
<td class=ar>106</td>
<td class=al>&nbsp;:&nbsp;99</td>
<td class=ar>40</td>
</tr><tr><td class=br>44.</td>
<td class=bl><a href="stats.php?idpl=32&x=-61&p=Skarainis%20Salvis">Skarainis Salvis</a></td>
<td class=bl>LAT</td>
<td class=br>36</td>
<td class=br>15</td>
<td class=br>5</td>
<td class=br>16</td>
<td class=br>87</td>
<td class=bl>&nbsp;:&nbsp;103</td>
<td class=br>35</td>
</tr><tr><td class=ar>45.</td>
<td class=al><a href="stats.php?idpl=431&x=-61&p=Jalneskog%20Anton">Jalneskog Anton</a></td>
<td class=al>SWE</td>
<td class=ar>37</td>
<td class=ar>13</td>
<td class=ar>8</td>
<td class=ar>16</td>
<td class=ar>75</td>
<td class=al>&nbsp;:&nbsp;85</td>
<td class=ar>34</td>
</tr><tr><td class=br>46.</td>
<td class=bl><a href="stats.php?idpl=111&x=-61&p=Larsson%20Emil">Larsson Emil</a></td>
<td class=bl>SWE</td>
<td class=br>36</td>
<td class=br>14</td>
<td class=br>6</td>
<td class=br>16</td>
<td class=br>100</td>
<td class=bl>&nbsp;:&nbsp;109</td>
<td class=br>34</td>
</tr><tr><td class=ar>47.</td>
<td class=al><a href="stats.php?idpl=151&x=-61&p=Lebl%20Kry%C5%A1tof">Lebl Kry�tof</a></td>
<td class=al>CZE</td>
<td class=ar>36</td>
<td class=ar>13</td>
<td class=ar>6</td>
<td class=ar>17</td>
<td class=ar>93</td>
<td class=al>&nbsp;:&nbsp;122</td>
<td class=ar>32</td>
</tr><tr><td class=br>48.</td>
<td class=bl><a href="stats.php?idpl=34&x=-61&p=Re%C4%B7is%20J%C4%93kabs">Re�is J�kabs</a></td>
<td class=bl>LAT</td>
<td class=br>36</td>
<td class=br>12</td>
<td class=br>10</td>
<td class=br>14</td>
<td class=br>79</td>
<td class=bl>&nbsp;:&nbsp;83</td>
<td class=br>34</td>
</tr><tr><td class=ar>49.</td>
<td class=al><a href="stats.php?idpl=113&x=-61&p=Ivantsova%20Hanna">Ivantsova Hanna</a></td>
<td class=al>UKR</td>
<td class=ar>36</td>
<td class=ar>12</td>
<td class=ar>7</td>
<td class=ar>17</td>
<td class=ar>90</td>
<td class=al>&nbsp;:&nbsp;88</td>
<td class=ar>31</td>
</tr><tr><td class=br>50.</td>
<td class=bl><a href="stats.php?idpl=403&x=-61&p=Cernoch%20Miroslav">Cernoch Miroslav</a></td>
<td class=bl>CZE</td>
<td class=br>37</td>
<td class=br>12</td>
<td class=br>8</td>
<td class=br>17</td>
<td class=br>75</td>
<td class=bl>&nbsp;:&nbsp;99</td>
<td class=br>32</td>
</tr><tr><td class=ar>51.</td>
<td class=al><a href="stats.php?idpl=65&x=-61&p=Saveljev%20Igor">Saveljev Igor</a></td>
<td class=al>EST</td>
<td class=ar>36</td>
<td class=ar>12</td>
<td class=ar>8</td>
<td class=ar>16</td>
<td class=ar>78</td>
<td class=al>&nbsp;:&nbsp;82</td>
<td class=ar>32</td>
</tr><tr><td class=br>52.</td>
<td class=bl><a href="stats.php?idpl=121&x=-61&p=Hermansson%20Gustaf">Hermansson Gustaf</a></td>
<td class=bl>SWE</td>
<td class=br>37</td>
<td class=br>16</td>
<td class=br>3</td>
<td class=br>18</td>
<td class=br>96</td>
<td class=bl>&nbsp;:&nbsp;92</td>
<td class=br>35</td>
</tr><tr><td class=ar>53.</td>
<td class=al><a href="stats.php?idpl=377&x=-61&p=Axelsen%20Bjarne">Axelsen Bjarne</a></td>
<td class=al>DEN</td>
<td class=ar>36</td>
<td class=ar>10</td>
<td class=ar>7</td>
<td class=ar>19</td>
<td class=ar>75</td>
<td class=al>&nbsp;:&nbsp;102</td>
<td class=ar>27</td>
</tr><tr><td class=br>54.</td>
<td class=bl><a href="stats.php?idpl=379&x=-61&p=Nyg%C3%A5rd%20Daniel">Nyg�rd Daniel</a></td>
<td class=bl>NOR</td>
<td class=br>36</td>
<td class=br>10</td>
<td class=br>9</td>
<td class=br>17</td>
<td class=br>93</td>
<td class=bl>&nbsp;:&nbsp;117</td>
<td class=br>29</td>
</tr><tr><td class=ar>55.</td>
<td class=al><a href="stats.php?idpl=115&x=-61&p=Shalomayev%20Mykhaylo">Shalomayev Mykhaylo</a></td>
<td class=al>UKR</td>
<td class=ar>36</td>
<td class=ar>11</td>
<td class=ar>6</td>
<td class=ar>19</td>
<td class=ar>85</td>
<td class=al>&nbsp;:&nbsp;101</td>
<td class=ar>28</td>
</tr><tr><td class=br>56.</td>
<td class=bl><a href="stats.php?idpl=112&x=-61&p=Saveljeva%20Maria">Saveljeva Maria</a></td>
<td class=bl>EST</td>
<td class=br>37</td>
<td class=br>15</td>
<td class=br>2</td>
<td class=br>20</td>
<td class=br>107</td>
<td class=bl>&nbsp;:&nbsp;121</td>
<td class=br>32</td>
</tr><tr><td class=ar>57.</td>
<td class=al><a href="stats.php?idpl=384&x=-61&p=Hagerup%20Frode">Hagerup Frode</a></td>
<td class=al>NOR</td>
<td class=ar>37</td>
<td class=ar>11</td>
<td class=ar>6</td>
<td class=ar>20</td>
<td class=ar>98</td>
<td class=al>&nbsp;:&nbsp;137</td>
<td class=ar>28</td>
</tr><tr><td class=br>58.</td>
<td class=bl><a href="stats.php?idpl=124&x=-61&p=Skrlep%20Nejc">Skrlep Nejc</a></td>
<td class=bl>SLO</td>
<td class=br>36</td>
<td class=br>12</td>
<td class=br>5</td>
<td class=br>19</td>
<td class=br>91</td>
<td class=bl>&nbsp;:&nbsp;137</td>
<td class=br>29</td>
</tr><tr><td class=ar>59.</td>
<td class=al><a href="stats.php?idpl=67&x=-61&p=Mihhaljov%20Timur">Mihhaljov Timur</a></td>
<td class=al>EST</td>
<td class=ar>36</td>
<td class=ar>11</td>
<td class=ar>5</td>
<td class=ar>20</td>
<td class=ar>66</td>
<td class=al>&nbsp;:&nbsp;98</td>
<td class=ar>27</td>
</tr><tr><td class=br>60.</td>
<td class=bl><a href="stats.php?idpl=432&x=-61&p=Fagerberg%20Gustaf">Fagerberg Gustaf</a></td>
<td class=bl>SWE</td>
<td class=br>36</td>
<td class=br>9</td>
<td class=br>6</td>
<td class=br>21</td>
<td class=br>68</td>
<td class=bl>&nbsp;:&nbsp;116</td>
<td class=br>24</td>
</tr><tr><td class=ar>61.</td>
<td class=al><a href="stats.php?idpl=118&x=-61&p=Landa%20Daniil">Landa Daniil</a></td>
<td class=al>EST</td>
<td class=ar>36</td>
<td class=ar>9</td>
<td class=ar>9</td>
<td class=ar>18</td>
<td class=ar>93</td>
<td class=al>&nbsp;:&nbsp;131</td>
<td class=ar>27</td>
</tr><tr><td class=br>62.</td>
<td class=bl><a href="stats.php?idpl=383&x=-61&p=Klippen%20Vegard">Klippen Vegard</a></td>
<td class=bl>NOR</td>
<td class=br>37</td>
<td class=br>11</td>
<td class=br>6</td>
<td class=br>20</td>
<td class=br>81</td>
<td class=bl>&nbsp;:&nbsp;110</td>
<td class=br>28</td>
</tr><tr><td class=ar>63.</td>
<td class=al><a href="stats.php?idpl=79&x=-61&p=Saul%C4%ABtis%20Mikus">Saul�tis Mikus</a></td>
<td class=al>LAT</td>
<td class=ar>37</td>
<td class=ar>8</td>
<td class=ar>5</td>
<td class=ar>24</td>
<td class=ar>81</td>
<td class=al>&nbsp;:&nbsp;124</td>
<td class=ar>21</td>
</tr><tr><td class=br>64.</td>
<td class=bl><a href="stats.php?idpl=122&x=-61&p=Henttonen%20Ville">Henttonen Ville</a></td>
<td class=bl>FIN</td>
<td class=br>36</td>
<td class=br>5</td>
<td class=br>4</td>
<td class=br>27</td>
<td class=br>43</td>
<td class=bl>&nbsp;:&nbsp;122</td>
<td class=br>14</td>
</tr><tr><td class=ar>65.</td>
<td class=al><a href="stats.php?idpl=5&x=-61&p=Vazoli%C5%86%C5%A1%20Regn%C4%81rs">Vazoli�� Regn�rs</a></td>
<td class=al>LAT</td>
<td class=ar>42</td>
<td class=ar>23</td>
<td class=ar>4</td>
<td class=ar>15</td>
<td class=ar>132</td>
<td class=al>&nbsp;:&nbsp;97</td>
<td class=ar>50</td>
</tr><tr><td class=br>66.</td>
<td class=bl><a href="stats.php?idpl=422&x=-61&p=Pedersen%20Richard">Pedersen Richard</a></td>
<td class=bl>SWE</td>
<td class=br>38</td>
<td class=br>17</td>
<td class=br>9</td>
<td class=br>12</td>
<td class=br>115</td>
<td class=bl>&nbsp;:&nbsp;104</td>
<td class=br>43</td>
</tr><tr><td class=ar>67.</td>
<td class=al><a href="stats.php?idpl=401&x=-61&p=Lezik%20Matej">Lezik Matej</a></td>
<td class=al>CZE</td>
<td class=ar>42</td>
<td class=ar>27</td>
<td class=ar>3</td>
<td class=ar>12</td>
<td class=ar>149</td>
<td class=al>&nbsp;:&nbsp;98</td>
<td class=ar>57</td>
</tr><tr><td class=br>68.</td>
<td class=bl><a href="stats.php?idpl=66&x=-61&p=Hrustaljova%20Darja">Hrustaljova Darja</a></td>
<td class=bl>EST</td>
<td class=br>39</td>
<td class=br>17</td>
<td class=br>10</td>
<td class=br>12</td>
<td class=br>112</td>
<td class=bl>&nbsp;:&nbsp;91</td>
<td class=br>44</td>
</tr><tr><td class=ar>69.</td>
<td class=al><a href="stats.php?idpl=425&x=-61&p=Kimberg%20Anton">Kimberg Anton</a></td>
<td class=al>SWE</td>
<td class=ar>35</td>
<td class=ar>16</td>
<td class=ar>10</td>
<td class=ar>9</td>
<td class=ar>85</td>
<td class=al>&nbsp;:&nbsp;64</td>
<td class=ar>42</td>
</tr><tr><td class=br>70.</td>
<td class=bl><a href="stats.php?idpl=163&x=-61&p=Remeika%20Zygimantas">Remeika Zygimantas</a></td>
<td class=bl>LTU</td>
<td class=br>35</td>
<td class=br>13</td>
<td class=br>8</td>
<td class=br>14</td>
<td class=br>106</td>
<td class=bl>&nbsp;:&nbsp;94</td>
<td class=br>34</td>
</tr><tr><td class=ar>71.</td>
<td class=al><a href="stats.php?idpl=236&x=-61&p=Fylling%20Amund%20Risa">Fylling Amund Risa</a></td>
<td class=al>NOR</td>
<td class=ar>34</td>
<td class=ar>13</td>
<td class=ar>11</td>
<td class=ar>10</td>
<td class=ar>86</td>
<td class=al>&nbsp;:&nbsp;80</td>
<td class=ar>37</td>
</tr><tr><td class=br>72.</td>
<td class=bl><a href="stats.php?idpl=427&x=-61&p=Forsberg%20James-John">Forsberg James-John</a></td>
<td class=bl>SWE</td>
<td class=br>35</td>
<td class=br>14</td>
<td class=br>8</td>
<td class=br>13</td>
<td class=br>88</td>
<td class=bl>&nbsp;:&nbsp;85</td>
<td class=br>36</td>
</tr><tr><td class=ar>73.</td>
<td class=al><a href="stats.php?idpl=392&x=-61&p=Mets%C3%A4l%C3%A4%20Lari">Mets�l� Lari</a></td>
<td class=al>FIN</td>
<td class=ar>34</td>
<td class=ar>13</td>
<td class=ar>8</td>
<td class=ar>13</td>
<td class=ar>86</td>
<td class=al>&nbsp;:&nbsp;86</td>
<td class=ar>34</td>
</tr><tr><td class=br>74.</td>
<td class=bl><a href="stats.php?idpl=404&x=-61&p=Matysek%20Daniel">Matysek Daniel</a></td>
<td class=bl>CZE</td>
<td class=br>35</td>
<td class=br>13</td>
<td class=br>8</td>
<td class=br>14</td>
<td class=br>82</td>
<td class=bl>&nbsp;:&nbsp;76</td>
<td class=br>34</td>
</tr><tr><td class=ar>75.</td>
<td class=al><a href="stats.php?idpl=402&x=-61&p=Fuchs%20Petr">Fuchs Petr</a></td>
<td class=al>CZE</td>
<td class=ar>34</td>
<td class=ar>12</td>
<td class=ar>8</td>
<td class=ar>14</td>
<td class=ar>85</td>
<td class=al>&nbsp;:&nbsp;87</td>
<td class=ar>32</td>
</tr><tr><td class=br>76.</td>
<td class=bl><a href="stats.php?idpl=117&x=-61&p=M%C3%A5nsson%20Truls">M�nsson Truls</a></td>
<td class=bl>SWE</td>
<td class=br>34</td>
<td class=br>12</td>
<td class=br>9</td>
<td class=br>13</td>
<td class=br>80</td>
<td class=bl>&nbsp;:&nbsp;74</td>
<td class=br>33</td>
</tr><tr><td class=ar>77.</td>
<td class=al><a href="stats.php?idpl=405&x=-61&p=Pikl%20Vaclav">Pikl Vaclav</a></td>
<td class=al>CZE</td>
<td class=ar>34</td>
<td class=ar>12</td>
<td class=ar>6</td>
<td class=ar>16</td>
<td class=ar>86</td>
<td class=al>&nbsp;:&nbsp;92</td>
<td class=ar>30</td>
</tr><tr><td class=br>78.</td>
<td class=bl><a href="stats.php?idpl=139&x=-61&p=Kvasnikova%20Polina">Kvasnikova Polina</a></td>
<td class=bl>UKR</td>
<td class=br>35</td>
<td class=br>12</td>
<td class=br>7</td>
<td class=br>16</td>
<td class=br>60</td>
<td class=bl>&nbsp;:&nbsp;83</td>
<td class=br>31</td>
</tr><tr><td class=ar>79.</td>
<td class=al><a href="stats.php?idpl=241&x=-61&p=Plesak%20Pavel">Plesak Pavel</a></td>
<td class=al>CZE</td>
<td class=ar>34</td>
<td class=ar>12</td>
<td class=ar>5</td>
<td class=ar>17</td>
<td class=ar>88</td>
<td class=al>&nbsp;:&nbsp;97</td>
<td class=ar>29</td>
</tr><tr><td class=br>80.</td>
<td class=bl><a href="stats.php?idpl=156&x=-61&p=Storozhenko%20Glib">Storozhenko Glib</a></td>
<td class=bl>UKR</td>
<td class=br>34</td>
<td class=br>9</td>
<td class=br>7</td>
<td class=br>18</td>
<td class=br>70</td>
<td class=bl>&nbsp;:&nbsp;102</td>
<td class=br>25</td>
</tr><tr><td class=ar>81.</td>
<td class=al><a href="stats.php?idpl=136&x=-61&p=Sippo%20Daniel">Sippo Daniel</a></td>
<td class=al>EST</td>
<td class=ar>35</td>
<td class=ar>11</td>
<td class=ar>2</td>
<td class=ar>22</td>
<td class=ar>85</td>
<td class=al>&nbsp;:&nbsp;131</td>
<td class=ar>24</td>
</tr><tr><td class=br>82.</td>
<td class=bl><a href="stats.php?idpl=391&x=-61&p=Uimonen%20Tomi">Uimonen Tomi</a></td>
<td class=bl>FIN</td>
<td class=br>34</td>
<td class=br>11</td>
<td class=br>5</td>
<td class=br>18</td>
<td class=br>88</td>
<td class=bl>&nbsp;:&nbsp;111</td>
<td class=br>27</td>
</tr><tr><td class=ar>83.</td>
<td class=al><a href="stats.php?idpl=378&x=-61&p=Lyksholm%20Nico">Lyksholm Nico</a></td>
<td class=al>DEN</td>
<td class=ar>35</td>
<td class=ar>10</td>
<td class=ar>5</td>
<td class=ar>20</td>
<td class=ar>80</td>
<td class=al>&nbsp;:&nbsp;120</td>
<td class=ar>25</td>
</tr><tr><td class=br>84.</td>
<td class=bl><a href="stats.php?idpl=226&x=-61&p=Pirumshoieva%20Karyna">Pirumshoieva Karyna</a></td>
<td class=bl>UKR</td>
<td class=br>34</td>
<td class=br>5</td>
<td class=br>9</td>
<td class=br>20</td>
<td class=br>75</td>
<td class=bl>&nbsp;:&nbsp;102</td>
<td class=br>19</td>
</tr><tr><td class=ar>85.</td>
<td class=al><a href="stats.php?idpl=380&x=-61&p=Nyg%C3%A5rd%20Benjamin">Nyg�rd Benjamin</a></td>
<td class=al>NOR</td>
<td class=ar>34</td>
<td class=ar>7</td>
<td class=ar>4</td>
<td class=ar>23</td>
<td class=ar>83</td>
<td class=al>&nbsp;:&nbsp;127</td>
<td class=ar>18</td>
</tr><tr><td class=br>86.</td>
<td class=bl><a href="stats.php?idpl=414&x=-61&p=Rompa%20Eike">Rompa Eike</a></td>
<td class=bl>GER</td>
<td class=br>34</td>
<td class=br>5</td>
<td class=br>5</td>
<td class=br>24</td>
<td class=br>74</td>
<td class=bl>&nbsp;:&nbsp;138</td>
<td class=br>15</td>
</tr><tr><td class=ar>87.</td>
<td class=al><a href="stats.php?idpl=162&x=-61&p=Remeika%20Gintautas">Remeika Gintautas</a></td>
<td class=al>LTU</td>
<td class=ar>34</td>
<td class=ar>4</td>
<td class=ar>5</td>
<td class=ar>25</td>
<td class=ar>60</td>
<td class=al>&nbsp;:&nbsp;145</td>
<td class=ar>13</td>
</tr><tr><td class=br>88.</td>
<td class=bl><a href="stats.php?idpl=70&x=-61&p=Kuz%C5%86ecovs%20Andrejs">Kuz�ecovs Andrejs</a></td>
<td class=bl>LAT</td>
<td class=br>13</td>
<td class=br>6</td>
<td class=br>0</td>
<td class=br>7</td>
<td class=br>49</td>
<td class=bl>&nbsp;:&nbsp;42</td>
<td class=br>12</td>
</tr><tr><td class=ar>89.</td>
<td class=al><a href="stats.php?idpl=145&x=-61&p=Zenisek%20Martin">Zenisek Martin</a></td>
<td class=al>CZE</td>
<td class=ar>41</td>
<td class=ar>20</td>
<td class=ar>4</td>
<td class=ar>17</td>
<td class=ar>122</td>
<td class=al>&nbsp;:&nbsp;114</td>
<td class=ar>44</td>
</tr><tr><td class=br>90.</td>
<td class=bl><a href="stats.php?idpl=407&x=-61&p=Kraus%20Vladimir">Kraus Vladimir</a></td>
<td class=bl>CZE</td>
<td class=br>39</td>
<td class=br>21</td>
<td class=br>2</td>
<td class=br>16</td>
<td class=br>109</td>
<td class=bl>&nbsp;:&nbsp;104</td>
<td class=br>44</td>
</tr><tr><td class=ar>91.</td>
<td class=al><a href="stats.php?idpl=125&x=-61&p=Thomas%20Simon">Thomas Simon</a></td>
<td class=al>IRL</td>
<td class=ar>34</td>
<td class=ar>12</td>
<td class=ar>5</td>
<td class=ar>17</td>
<td class=ar>94</td>
<td class=al>&nbsp;:&nbsp;101</td>
<td class=ar>29</td>
</tr><tr><td class=br>92.</td>
<td class=bl><a href="stats.php?idpl=426&x=-61&p=Wallin%20Wilton">Wallin Wilton</a></td>
<td class=bl>SWE</td>
<td class=br>35</td>
<td class=br>13</td>
<td class=br>5</td>
<td class=br>17</td>
<td class=br>96</td>
<td class=bl>&nbsp;:&nbsp;117</td>
<td class=br>31</td>
</tr><tr><td class=ar>93.</td>
<td class=al><a href="stats.php?idpl=393&x=-61&p=Itkonen%20Juho">Itkonen Juho</a></td>
<td class=al>FIN</td>
<td class=ar>30</td>
<td class=ar>13</td>
<td class=ar>2</td>
<td class=ar>15</td>
<td class=ar>77</td>
<td class=al>&nbsp;:&nbsp;79</td>
<td class=ar>28</td>
</tr><tr><td class=br>94.</td>
<td class=bl><a href="stats.php?idpl=127&x=-61&p=Sevr%20Milos">Sevr Milos</a></td>
<td class=bl>CZE</td>
<td class=br>31</td>
<td class=br>13</td>
<td class=br>2</td>
<td class=br>16</td>
<td class=br>109</td>
<td class=bl>&nbsp;:&nbsp;101</td>
<td class=br>28</td>
</tr><tr><td class=ar>95.</td>
<td class=al><a href="stats.php?idpl=367&x=-61&p=Pylypenko%20Oleksandr">Pylypenko Oleksandr</a></td>
<td class=al>UKR</td>
<td class=ar>30</td>
<td class=ar>12</td>
<td class=ar>4</td>
<td class=ar>14</td>
<td class=ar>76</td>
<td class=al>&nbsp;:&nbsp;92</td>
<td class=ar>28</td>
</tr><tr><td class=br>96.</td>
<td class=bl><a href="stats.php?idpl=202&x=-61&p=Voronov%20Vladimir">Voronov Vladimir</a></td>
<td class=bl>LTU</td>
<td class=br>30</td>
<td class=br>11</td>
<td class=br>4</td>
<td class=br>15</td>
<td class=br>65</td>
<td class=bl>&nbsp;:&nbsp;90</td>
<td class=br>26</td>
</tr><tr><td class=ar>97.</td>
<td class=al><a href="stats.php?idpl=413&x=-61&p=Bruneske%20Frank">Bruneske Frank</a></td>
<td class=al>GER</td>
<td class=ar>31</td>
<td class=ar>12</td>
<td class=ar>5</td>
<td class=ar>14</td>
<td class=ar>72</td>
<td class=al>&nbsp;:&nbsp;98</td>
<td class=ar>29</td>
</tr><tr><td class=br>98.</td>
<td class=bl><a href="stats.php?idpl=416&x=-61&p=Petuch%20Hermann">Petuch Hermann</a></td>
<td class=bl>GER</td>
<td class=br>30</td>
<td class=br>9</td>
<td class=br>5</td>
<td class=br>16</td>
<td class=br>77</td>
<td class=bl>&nbsp;:&nbsp;103</td>
<td class=br>23</td>
</tr><tr><td class=ar>99.</td>
<td class=al><a href="stats.php?idpl=135&x=-61&p=Margolis%20Mihail">Margolis Mihail</a></td>
<td class=al>ISR</td>
<td class=ar>31</td>
<td class=ar>10</td>
<td class=ar>4</td>
<td class=ar>17</td>
<td class=ar>74</td>
<td class=al>&nbsp;:&nbsp;113</td>
<td class=ar>24</td>
</tr><tr><td class=br>100.</td>
<td class=bl><a href="stats.php?idpl=133&x=-61&p=Pleikys%20Audrius">Pleikys Audrius</a></td>
<td class=bl>LTU</td>
<td class=br>30</td>
<td class=br>9</td>
<td class=br>4</td>
<td class=br>17</td>
<td class=br>72</td>
<td class=bl>&nbsp;:&nbsp;91</td>
<td class=br>22</td>
</tr><tr><td class=ar>101.</td>
<td class=al><a href="stats.php?idpl=394&x=-61&p=Uimonen%20Emil">Uimonen Emil</a></td>
<td class=al>FIN</td>
<td class=ar>31</td>
<td class=ar>8</td>
<td class=ar>3</td>
<td class=ar>20</td>
<td class=ar>73</td>
<td class=al>&nbsp;:&nbsp;115</td>
<td class=ar>19</td>
</tr><tr><td class=br>102.</td>
<td class=bl><a href="stats.php?idpl=218&x=-61&p=Stykailo%20Dmitri">Stykailo Dmitri</a></td>
<td class=bl>EST</td>
<td class=br>31</td>
<td class=br>7</td>
<td class=br>5</td>
<td class=br>19</td>
<td class=br>65</td>
<td class=bl>&nbsp;:&nbsp;109</td>
<td class=br>19</td>
</tr><tr><td class=ar>103.</td>
<td class=al><a href="stats.php?idpl=364&x=-61&p=Bernhauser%20Erik">Bernhauser Erik</a></td>
<td class=al>SVK</td>
<td class=ar>31</td>
<td class=ar>5</td>
<td class=ar>4</td>
<td class=ar>22</td>
<td class=ar>68</td>
<td class=al>&nbsp;:&nbsp;139</td>
<td class=ar>14</td>
</tr><tr><td class=br>104.</td>
<td class=bl><a href="stats.php?idpl=131&x=-61&p=Verbytskyy%20Mykola">Verbytskyy Mykola</a></td>
<td class=bl>UKR</td>
<td class=br>30</td>
<td class=br>5</td>
<td class=br>7</td>
<td class=br>18</td>
<td class=br>56</td>
<td class=bl>&nbsp;:&nbsp;84</td>
<td class=br>17</td>
</tr><tr><td class=ar>105.</td>
<td class=al><a href="stats.php?idpl=220&x=-61&p=Pleikys%20Jonas">Pleikys Jonas</a></td>
<td class=al>LTU</td>
<td class=ar>31</td>
<td class=ar>6</td>
<td class=ar>4</td>
<td class=ar>21</td>
<td class=ar>38</td>
<td class=al>&nbsp;:&nbsp;98</td>
<td class=ar>16</td>
</tr><tr><td class=br>106.</td>
<td class=bl><a href="stats.php?idpl=154&x=-61&p=Steisunas%20Julius">Steisunas Julius</a></td>
<td class=bl>LTU</td>
<td class=br>31</td>
<td class=br>4</td>
<td class=br>0</td>
<td class=br>27</td>
<td class=br>43</td>
<td class=bl>&nbsp;:&nbsp;177</td>
<td class=br>8</td>
</tr><tr><td class=ar>107.</td>
<td class=al><a href="stats.php?idpl=152&x=-61&p=Ulis%20Tomas">Ulis Tomas</a></td>
<td class=al>LTU</td>
<td class=ar>30</td>
<td class=ar>3</td>
<td class=ar>0</td>
<td class=ar>27</td>
<td class=ar>44</td>
<td class=al>&nbsp;:&nbsp;151</td>
<td class=ar>6</td>
</tr><tr><td class=br>108.</td>
<td class=bl><a href="stats.php?idpl=223&x=-61&p=Zamiatin%20Igor">Zamiatin Igor</a></td>
<td class=bl>ISR</td>
<td class=br>0</td>
<td class=br>0</td>
<td class=br>0</td>
<td class=br>0</td>
<td class=br>0</td>
<td class=bl>&nbsp;:&nbsp;0</td>
<td class=br>0</td>
</tr><tr><td class=ar>109.</td>
<td class=al><a href="stats.php?idpl=396&x=-61&p=Hamdamov%20Vafa">Hamdamov Vafa</a></td>
<td class=al>EST</td>
<td class=ar>0</td>
<td class=ar>0</td>
<td class=ar>0</td>
<td class=ar>0</td>
<td class=ar>0</td>
<td class=al>&nbsp;:&nbsp;0</td>
<td class=ar>0</td>
</tr></table></td></tr></table></div></p>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
