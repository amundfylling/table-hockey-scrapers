<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Open Individual (O)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Open_Individual_(O)_list.php">Open Individual (O)</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group Open5</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=109&x=-61&p=Mi%20Kobrle">Mi Kobrle</a></td><td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>6:3</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kL>3:6</td>
<td class=kW>10:1</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>7:3</td>
<td class=kW>9:0</td>
<td class=kW>5:1</td>
<td class=br>71:28</td><td class=br>+43</td>
<td class=bc>11 - 1 - 1</td>
<td class=br><strong>23</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=227&x=-61&p=Ha%20%C3%96sterman">Ha �sterman</a></td><td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kW>8:1</td>
<td class=kW>7:0</td>
<td class=kW>6:1</td>
<td class=kW>10:1</td>
<td class=br>58:20</td><td class=br>+38</td>
<td class=bc>10 - 1 - 2</td>
<td class=br><strong>21</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=97&x=-61&p=Gi%20Lasmanis">Gi Lasmanis</a></td><td class=kL>3:6</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>7:2</td>
<td class=kW>4:3</td>
<td class=kT>6:6</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=br>57:32</td><td class=br>+25</td>
<td class=bc>9 - 2 - 2</td>
<td class=br><strong>20</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=213&x=-61&p=Ed%20Ka%C5%86eps">Ed Ka�eps</a></td><td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>8:0</td>
<td class=kW>7:2</td>
<td class=br>48:30</td><td class=br>+18</td>
<td class=bc>9 - 2 - 2</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=112&x=-61&p=Ma%20Saveljeva">Ma Saveljeva</a></td><td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>2:7</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=br>42:30</td><td class=br>+12</td>
<td class=bc>8 - 0 - 5</td>
<td class=br><strong>16</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=121&x=-61&p=Gu%20Hermansson">Gu Hermansson</a></td><td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=br>43:26</td><td class=br>+17</td>
<td class=bc>8 - 0 - 5</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=30&x=-61&p=Ma%20Jakseboga">Ma Jakseboga</a></td><td class=kL>1:10</td>
<td class=kL>0:4</td>
<td class=kT>6:6</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=br>33:38</td><td class=br>-5</td>
<td class=bc>6 - 3 - 4</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=369&x=-61&p=My%20Spivakovskyy">My Spivakovskyy</a></td><td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kL>3:5</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=br>38:29</td><td class=br>+9</td>
<td class=bc>7 - 1 - 5</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=404&x=-61&p=Da%20Matysek">Da Matysek</a></td><td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=br>24:32</td><td class=br>-8</td>
<td class=bc>4 - 3 - 6</td>
<td class=br><strong>11</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=163&x=-61&p=Zy%20Remeika">Zy Remeika</a></td><td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kT>0:0</td>
<td class=kW>7:1</td>
<td class=br>27:32</td><td class=br>-5</td>
<td class=bc>3 - 1 - 9</td>
<td class=br><strong>7</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=136&x=-61&p=Da%20Sippo">Da Sippo</a></td><td class=kL>3:4</td>
<td class=kL>1:8</td>
<td class=kL>2:6</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kW>5:3</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kL>0:2</td>
<td class=kW>4:2</td>
<td class=br>32:58</td><td class=br>-26</td>
<td class=bc>3 - 0 - 10</td>
<td class=br><strong>6</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=135&x=-61&p=Mi%20Margolis">Mi Margolis</a></td><td class=kL>3:7</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=br>21:56</td><td class=br>-35</td>
<td class=bc>2 - 2 - 9</td>
<td class=br><strong>6</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt><a href="stats.php?idpl=220&x=-61&p=Jo%20Pleikys">Jo Pleikys</a></td><td class=kL>0:9</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>0:8</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kT>0:0</td>
<td class=kW>2:0</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>13:51</td><td class=br>-38</td>
<td class=bc>2 - 1 - 10</td>
<td class=br><strong>5</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt><a href="stats.php?idpl=394&x=-61&p=Em%20Uimonen">Em Uimonen</a></td><td class=kL>1:5</td>
<td class=kL>1:10</td>
<td class=kL>1:7</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>20:65</td><td class=br>-45</td>
<td class=bc>0 - 1 - 12</td>
<td class=br><strong>1</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>�sterman Hans</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Saveljeva Maria</td><td class=bc>-</td><td class=bl>Sippo Daniel</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Margolis Mihail</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=bl>�sterman Hans</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Sippo Daniel</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Margolis Mihail</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Saveljeva Maria</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>6 : 6</tr></td>
<tr><td class=brW>Matysek Daniel</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Sippo Daniel</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=bl>Margolis Mihail</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Saveljeva Maria</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>�sterman Hans</td><td class=bc>-</td><td class=bl>Sippo Daniel</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Margolis Mihail</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Saveljeva Maria</td><td class=bc>-</td><td class=bl>Matysek Daniel</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Sippo Daniel</td><td class=bc>-</td><td class=bl>Margolis Mihail</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>�sterman Hans</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>Matysek Daniel</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Margolis Mihail</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Sippo Daniel</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>�sterman Hans</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Matysek Daniel</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>Saveljeva Maria</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Margolis Mihail</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sippo Daniel</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>�sterman Hans</td><td class=bc>-</td><td class=bl>Matysek Daniel</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Margolis Mihail</td><td class=bc>-</td><td class=bl>Matysek Daniel</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sippo Daniel</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>�sterman Hans</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Matysek Daniel</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Margolis Mihail</td><td class=bc>-</td><td class=blW>Saveljeva Maria</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Sippo Daniel</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>�sterman Hans</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Spivakovskyy Mykhaylo</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Matysek Daniel</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Margolis Mihail</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Sippo Daniel</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>�sterman Hans</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Margolis Mihail</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sippo Daniel</td><td class=bc>-</td><td class=blW>Pleikys Jonas</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Saveljeva Maria</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Spivakovskyy Mykhaylo</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Margolis Mihail</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Saveljeva Maria</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Pleikys Jonas</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Sippo Daniel</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Saveljeva Maria</td><td class=bc>-</td><td class=blW>Spivakovskyy Mykhaylo</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Matysek Daniel</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Sippo Daniel</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Margolis Mihail</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>Spivakovskyy Mykhaylo</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Saveljeva Maria</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Matysek Daniel</td><td class=bc>-</td><td class=bl>Sippo Daniel</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Margolis Mihail</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
