<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Open Individual (O)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Open_Individual_(O)_list.php">Open Individual (O)</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group Open1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=101&x=-61&p=Ev%20Matantsev">Ev Matantsev</a></td><td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kW>9:5</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kW>9:1</td>
<td class=kW>7:2</td>
<td class=kW>9:0</td>
<td class=kW>4:0</td>
<td class=br>68:25</td><td class=br>+43</td>
<td class=bc>10 - 1 - 1</td>
<td class=br><strong>21</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=212&x=-61&p=Di%20Ziemelis">Di Ziemelis</a></td><td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kW>7:0</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>37:16</td><td class=br>+21</td>
<td class=bc>8 - 1 - 3</td>
<td class=br><strong>17</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=240&x=-61&p=Ol%20Korabel">Ol Korabel</a></td><td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>9:3</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=br>53:27</td><td class=br>+26</td>
<td class=bc>7 - 2 - 3</td>
<td class=br><strong>16</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=39&x=-61&p=Kr%20Rieksti%C5%86%C5%A1">Kr Rieksti��</a></td><td class=kL>3:6</td>
<td class=kW>2:1</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=br>34:31</td><td class=br>+3</td>
<td class=bc>7 - 2 - 3</td>
<td class=br><strong>16</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=341&x=-61&p=J%C4%81%20Kaln%C4%93vics">J� Kaln�vics</a></td><td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=br>29:23</td><td class=br>+6</td>
<td class=bc>6 - 2 - 4</td>
<td class=br><strong>14</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=432&x=-61&p=Gu%20Fagerberg">Gu Fagerberg</a></td><td class=kL>5:9</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=br>25:31</td><td class=br>-6</td>
<td class=bc>5 - 3 - 4</td>
<td class=br><strong>13</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=34&x=-61&p=J%C4%93%20Re%C4%B7is">J� Re�is</a></td><td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=br>30:28</td><td class=br>+2</td>
<td class=bc>6 - 1 - 5</td>
<td class=br><strong>13</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=377&x=-61&p=Bj%20Axelsen">Bj Axelsen</a></td><td class=kL>3:6</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=br>25:28</td><td class=br>-3</td>
<td class=bc>4 - 3 - 5</td>
<td class=br><strong>11</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=402&x=-61&p=Pe%20Fuchs">Pe Fuchs</a></td><td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=br>25:35</td><td class=br>-10</td>
<td class=bc>4 - 1 - 7</td>
<td class=br><strong>9</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=391&x=-61&p=To%20Uimonen">To Uimonen</a></td><td class=kL>1:9</td>
<td class=kL>0:7</td>
<td class=kL>3:9</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=br>28:44</td><td class=br>-16</td>
<td class=bc>4 - 1 - 7</td>
<td class=br><strong>9</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=414&x=-61&p=Ei%20Rompa">Ei Rompa</a></td><td class=kL>2:7</td>
<td class=kW>4:3</td>
<td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=br>22:38</td><td class=br>-16</td>
<td class=bc>2 - 2 - 8</td>
<td class=br><strong>6</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=407&x=-61&p=Vl%20Kraus">Vl Kraus</a></td><td class=kL>0:9</td>
<td class=kL>1:2</td>
<td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=br>17:42</td><td class=br>-25</td>
<td class=bc>2 - 2 - 8</td>
<td class=br><strong>6</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt><a href="stats.php?idpl=202&x=-61&p=Vl%20Voronov">Vl Voronov</a></td><td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=br>17:42</td><td class=br>-25</td>
<td class=bc>2 - 1 - 9</td>
<td class=br><strong>5</strong></td><td class=d>13.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=blW>Kraus Vladimir</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=blW>Axelsen Bjarne</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Uimonen Tomi</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ziemelis Didzis</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Korabel Oleksii</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Kraus Vladimir</td><td class=bc>-</td><td class=blW>Axelsen Bjarne</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=blW>Fagerberg Gustaf</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Uimonen Tomi</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>Ziemelis Didzis</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kraus Vladimir</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=bl>Korabel Oleksii</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Rieksti�� Kristaps</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Uimonen Tomi</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ziemelis Didzis</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Fagerberg Gustaf</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kraus Vladimir</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Uimonen Tomi</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>1 : 9</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Fagerberg Gustaf</td><td class=bc>-</td><td class=bl>Rieksti�� Kristaps</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Kraus Vladimir</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Ziemelis Didzis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Rieksti�� Kristaps</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Fagerberg Gustaf</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Kraus Vladimir</td><td class=bc>-</td><td class=blW>Ziemelis Didzis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Uimonen Tomi</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Ziemelis Didzis</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Uimonen Tomi</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kraus Vladimir</td><td class=bc>-</td><td class=blW>Kaln�vics J�nis</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=blW>Ziemelis Didzis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Uimonen Tomi</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Kaln�vics J�nis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Rompa Eike</td><td class=bc>-</td><td class=bl>Ziemelis Didzis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Uimonen Tomi</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=blW>Kaln�vics J�nis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=bl>Kraus Vladimir</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=blW>Ziemelis Didzis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Uimonen Tomi</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Kaln�vics J�nis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Kraus Vladimir</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ziemelis Didzis</td><td class=bc>-</td><td class=bl>Uimonen Tomi</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Kaln�vics J�nis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Rompa Eike</td><td class=bc>-</td><td class=bl>Kraus Vladimir</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=blW>Fagerberg Gustaf</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Uimonen Tomi</td><td class=bc>-</td><td class=bl>Kaln�vics J�nis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ziemelis Didzis</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Kraus Vladimir</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Uimonen Tomi</td><td class=bc>-</td><td class=bl>Kraus Vladimir</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ziemelis Didzis</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>9 : 5</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>1 : 6</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
