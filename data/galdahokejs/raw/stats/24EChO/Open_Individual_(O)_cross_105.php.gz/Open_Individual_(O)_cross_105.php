<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Open Individual (O)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Open_Individual_(O)_list.php">Open Individual (O)</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group OpenC</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>89</td>
<td class=ic>90</td>
<td class=ic>91</td>
<td class=ic>92</td>
<td class=ic>93</td>
<td class=ic>94</td>
<td class=ic>95</td>
<td class=ic>96</td>
<td class=ic>97</td>
<td class=ic>98</td>
<td class=ic>99</td>
<td class=ic>100</td>
<td class=ic>101</td>
<td class=ic>102</td>
<td class=ic>103</td>
<td class=ic>104</td>
<td class=ic>105</td>
<td class=ic>106</td>
<td class=ic>107</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>89.</td><td class=kt><a href="stats.php?idpl=145&x=-61&p=Ma%20Zenisek">Ma Zenisek</a></td><td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kW>7:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=br>60:35</td><td class=br>+25</td>
<td class=bc>13 - 2 - 3</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>90.</td><td class=kt><a href="stats.php?idpl=407&x=-61&p=Vl%20Kraus">Vl Kraus</a></td><td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>7:3</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>9:2</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kL>4:5</td>
<td class=kW>5:1</td>
<td class=br>66:37</td><td class=br>+29</td>
<td class=bc>13 - 0 - 5</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>91.</td><td class=kt><a href="stats.php?idpl=125&x=-61&p=Si%20Thomas">Si Thomas</a></td><td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>0:4</td>
<td class=kW>6:3</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>5:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>8:2</td>
<td class=kT>4:4</td>
<td class=kW>6:4</td>
<td class=kW>5:2</td>
<td class=kW>7:3</td>
<td class=br>61:45</td><td class=br>+16</td>
<td class=bc>10 - 3 - 5</td>
<td class=br><strong>23</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>92.</td><td class=kt><a href="stats.php?idpl=426&x=-61&p=Wi%20Wallin">Wi Wallin</a></td><td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>5:6</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=br>58:47</td><td class=br>+11</td>
<td class=bc>11 - 1 - 6</td>
<td class=br><strong>23</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>93.</td><td class=kt><a href="stats.php?idpl=393&x=-61&p=Ju%20Itkonen">Ju Itkonen</a></td><td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kL>0:1</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=br>54:35</td><td class=br>+19</td>
<td class=bc>10 - 2 - 6</td>
<td class=br><strong>22</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>94.</td><td class=kt><a href="stats.php?idpl=127&x=-61&p=Mi%20Sevr">Mi Sevr</a></td><td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>9:1</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kW>5:3</td>
<td class=kW>7:5</td>
<td class=kW>5:1</td>
<td class=kW>6:5</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>8:0</td>
<td class=br>77:54</td><td class=br>+23</td>
<td class=bc>10 - 2 - 6</td>
<td class=br><strong>22</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>95.</td><td class=kt><a href="stats.php?idpl=367&x=-61&p=Ol%20Pylypenko">Ol Pylypenko</a></td><td class=kW>3:2</td>
<td class=kL>3:7</td>
<td class=kW>5:2</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:9</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=br>54:49</td><td class=br>+5</td>
<td class=bc>10 - 2 - 6</td>
<td class=br><strong>22</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>96.</td><td class=kt><a href="stats.php?idpl=202&x=-61&p=Vl%20Voronov">Vl Voronov</a></td><td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>6:5</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=br>48:48</td><td class=br>0</td>
<td class=bc>9 - 3 - 6</td>
<td class=br><strong>21</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>97.</td><td class=kt><a href="stats.php?idpl=413&x=-61&p=Fr%20Bruneske">Fr Bruneske</a></td><td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>6:4</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kL>0:2</td>
<td class=kW>4:3</td>
<td class=br>46:43</td><td class=br>+3</td>
<td class=bc>9 - 3 - 6</td>
<td class=br><strong>21</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>98.</td><td class=kt><a href="stats.php?idpl=416&x=-61&p=He%20Petuch">He Petuch</a></td><td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>0:5</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=br>55:46</td><td class=br>+9</td>
<td class=bc>8 - 3 - 7</td>
<td class=br><strong>19</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>99.</td><td class=kt><a href="stats.php?idpl=135&x=-61&p=Mi%20Margolis">Mi Margolis</a></td><td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kL>2:5</td>
<td class=kL>5:6</td>
<td class=kL>4:6</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=br>53:57</td><td class=br>-4</td>
<td class=bc>8 - 2 - 8</td>
<td class=br><strong>18</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>100.</td><td class=kt><a href="stats.php?idpl=133&x=-61&p=Au%20Pleikys">Au Pleikys</a></td><td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>8:2</td>
<td class=kW>5:2</td>
<td class=br>48:35</td><td class=br>+13</td>
<td class=bc>7 - 4 - 7</td>
<td class=br><strong>18</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>101.</td><td class=kt><a href="stats.php?idpl=394&x=-61&p=Em%20Uimonen">Em Uimonen</a></td><td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>6:5</td>
<td class=kL>0:2</td>
<td class=kL>5:7</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=br>53:50</td><td class=br>+3</td>
<td class=bc>8 - 2 - 8</td>
<td class=br><strong>18</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>102.</td><td class=kt><a href="stats.php?idpl=218&x=-61&p=Dm%20Stykailo">Dm Stykailo</a></td><td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>41:50</td><td class=br>-9</td>
<td class=bc>6 - 2 - 10</td>
<td class=br><strong>14</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>103.</td><td class=kt><a href="stats.php?idpl=364&x=-61&p=Er%20Bernhauser">Er Bernhauser</a></td><td class=kL>3:7</td>
<td class=kL>2:9</td>
<td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>5:6</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=br>50:65</td><td class=br>-15</td>
<td class=bc>5 - 3 - 10</td>
<td class=br><strong>13</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>104.</td><td class=kt><a href="stats.php?idpl=131&x=-61&p=My%20Verbytskyy">My Verbytskyy</a></td><td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=br>40:57</td><td class=br>-17</td>
<td class=bc>3 - 5 - 10</td>
<td class=br><strong>11</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>105.</td><td class=kt><a href="stats.php?idpl=220&x=-61&p=Jo%20Pleikys">Jo Pleikys</a></td><td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kL>4:6</td>
<td class=kW>2:1</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kW>1:0</td>
<td class=kT>0:0</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=br>25:47</td><td class=br>-22</td>
<td class=bc>4 - 3 - 11</td>
<td class=br><strong>11</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>106.</td><td class=kt><a href="stats.php?idpl=154&x=-61&p=Ju%20Steisunas">Ju Steisunas</a></td><td class=kL>3:4</td>
<td class=kW>5:4</td>
<td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kW>2:0</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>2:8</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>32:77</td><td class=br>-45</td>
<td class=bc>4 - 0 - 14</td>
<td class=br><strong>8</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>107.</td><td class=kt><a href="stats.php?idpl=152&x=-61&p=To%20Ulis">To Ulis</a></td><td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:8</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>29:73</td><td class=br>-44</td>
<td class=bc>2 - 0 - 16</td>
<td class=br><strong>4</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Kraus Vladimir</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Itkonen Juho</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Bruneske Frank</td><td class=bc>-</td><td class=bl>Stykailo Dmitri</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Margolis Mihail</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Sevr Milos</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Bernhauser Erik</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kraus Vladimir</td><td class=bc>-</td><td class=blW>Steisunas Julius</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Stykailo Dmitri</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Itkonen Juho</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Bruneske Frank</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Margolis Mihail</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Sevr Milos</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Zenisek Martin</td><td class=bc>-</td><td class=blW>Wallin Wilton</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Uimonen Emil</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Stykailo Dmitri</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kraus Vladimir</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Itkonen Juho</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=bl>Sevr Milos</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Margolis Mihail</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Wallin Wilton</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>Voronov Vladimir</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Stykailo Dmitri</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Uimonen Emil</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Bernhauser Erik</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kraus Vladimir</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Sevr Milos</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Itkonen Juho</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Bruneske Frank</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Margolis Mihail</td><td class=bc>-</td><td class=blW>Voronov Vladimir</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Steisunas Julius</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Uimonen Emil</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Sevr Milos</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Kraus Vladimir</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Itkonen Juho</td><td class=bc>-</td><td class=blW>Voronov Vladimir</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Margolis Mihail</td><td class=bc>-</td><td class=blW>Pylypenko Oleksandr</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=blW>Pleikys Jonas</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Sevr Milos</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kraus Vladimir</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Itkonen Juho</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ulis Tomas</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Sevr Milos</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Wallin Wilton</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Uimonen Emil</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Kraus Vladimir</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Itkonen Juho</td><td class=bc>-</td><td class=bl>Margolis Mihail</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Sevr Milos</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Wallin Wilton</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Stykailo Dmitri</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Pylypenko Oleksandr</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kraus Vladimir</td><td class=bc>-</td><td class=bl>Margolis Mihail</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Sevr Milos</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Voronov Vladimir</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Stykailo Dmitri</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Margolis Mihail</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Bruneske Frank</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kraus Vladimir</td><td class=bc>-</td><td class=blW>Itkonen Juho</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Wallin Wilton</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sevr Milos</td><td class=bc>-</td><td class=bl>Voronov Vladimir</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ulis Tomas</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=blW>Margolis Mihail</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Steisunas Julius</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Itkonen Juho</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>2 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=blW>Voronov Vladimir</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Sevr Milos</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Margolis Mihail</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Bruneske Frank</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=bl>Itkonen Juho</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Kraus Vladimir</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Zenisek Martin</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Sevr Milos</td><td class=bc>-</td><td class=blW>Margolis Mihail</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Bruneske Frank</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Itkonen Juho</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=blW>Kraus Vladimir</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Bernhauser Erik</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Zenisek Martin</td><td class=bc>-</td><td class=blW>Pylypenko Oleksandr</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Pleikys Audrius</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>Margolis Mihail</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Petuch Hermann</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Sevr Milos</td><td class=bc>-</td><td class=blW>Itkonen Juho</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Kraus Vladimir</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=blW>Uimonen Emil</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zenisek Martin</td><td class=bc>-</td><td class=bl>Margolis Mihail</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>Itkonen Juho</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Sevr Milos</td><td class=bc>-</td><td class=blW>Kraus Vladimir</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Uimonen Emil</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Steisunas Julius</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Margolis Mihail</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Itkonen Juho</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>Kraus Vladimir</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Petuch Hermann</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Sevr Milos</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>7 : 5</tr></td>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Stykailo Dmitri</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Margolis Mihail</td><td class=bc>-</td><td class=blW>Bruneske Frank</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Itkonen Juho</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Kraus Vladimir</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=blW>Bernhauser Erik</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=blW>Uimonen Emil</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Petuch Hermann</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Sevr Milos</td><td class=bc>-</td><td class=bl>Stykailo Dmitri</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Verbytskyy Mykola</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Bruneske Frank</td><td class=bc>-</td><td class=bl>Itkonen Juho</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Margolis Mihail</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Kraus Vladimir</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>Stykailo Dmitri</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Sevr Milos</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>8 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Itkonen Juho</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Bruneske Frank</td><td class=bc>-</td><td class=bl>Kraus Vladimir</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Margolis Mihail</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Stykailo Dmitri</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Petuch Hermann</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>Kraus Vladimir</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Itkonen Juho</td><td class=bc>-</td><td class=blW>Bernhauser Erik</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=blW>Uimonen Emil</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Margolis Mihail</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Stykailo Dmitri</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Voronov Vladimir</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=blW>Sevr Milos</td><td class=bc>3 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
