<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Open Individual (O)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Open_Individual_(O)_list.php">Open Individual (O) - play-off </a></span></h2></div></div></div></div><p><div align="center">
<table border=0 cellpadding=2 cellspacing=0>
<tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>Finals</strong></font></th></tr>
<tr><td class=br><a href="stats.php?idpl=4&x=-61&p=Caics%20Edgars"><b>Caics Edgars</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=7&x=-61&p=Kalni%C5%86%C5%A1%20Rainers">Kalni�� Rainers</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:4 P&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>1/2</strong></font></th></tr>
<tr><td class=ar><a href="stats.php?idpl=4&x=-61&p=Caics%20Edgars"><b>Caics Edgars</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=101&x=-61&p=Matantsev%20Evgeniy">Matantsev Evgeniy</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>1:5&nbsp;&nbsp;</td>
<td class=al>5:4 P&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>6:3&nbsp;&nbsp;</td>
<td class=al>0:3&nbsp;&nbsp;</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="stats.php?idpl=368&x=-61&p=Umanskyy%20Anton">Umanskyy Anton</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=7&x=-61&p=Kalni%C5%86%C5%A1%20Rainers"><b>Kalni�� Rainers</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;0 : 4&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:3 P&nbsp;&nbsp;</td>
<td class=bl>2:3 P&nbsp;&nbsp;</td>
<td class=bl>2:3 P&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>3rd</strong></font></th></tr>
<tr><td class=ar><a href="stats.php?idpl=101&x=-61&p=Matantsev%20Evgeniy">Matantsev Evgeniy</a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=368&x=-61&p=Umanskyy%20Anton"><b>Umanskyy Anton</b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:5&nbsp;&nbsp;</td>
<td class=al>7:0&nbsp;&nbsp;</td>
<td class=al>5:2&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>2:3 P&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>1/4</strong></font></th></tr>
<tr><td class=br><a href="stats.php?idpl=4&x=-61&p=Caics%20Edgars"><b>Caics Edgars</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=116&x=-61&p=Matantsev%20Artem">Matantsev Artem</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:2 P&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>6:1&nbsp;&nbsp;</td>
<td class=bl>3:2 P&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="stats.php?idpl=101&x=-61&p=Matantsev%20Evgeniy"><b>Matantsev Evgeniy</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=105&x=-61&p=Petr%20Patrik">Petr Patrik</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>9:3&nbsp;&nbsp;</td>
<td class=al>8:3&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>8:3&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="stats.php?idpl=368&x=-61&p=Umanskyy%20Anton"><b>Umanskyy Anton</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=269&x=-61&p=Eriksson%20Kevin">Eriksson Kevin</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>3:2 P&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>1:0 P&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="stats.php?idpl=43&x=-61&p=Naglis%20Edgars">Naglis Edgars</a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=7&x=-61&p=Kalni%C5%86%C5%A1%20Rainers"><b>Kalni�� Rainers</b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;0 : 4&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>5:9&nbsp;&nbsp;</td>
<td class=al>0:7&nbsp;&nbsp;</td>
<td class=al>1:9&nbsp;&nbsp;</td>
<td class=al>3:6&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>1/8</strong></font></th></tr>
<tr><td class=br><a href="stats.php?idpl=4&x=-61&p=Caics%20Edgars"><b>Caics Edgars</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=109&x=-61&p=Kobrle%20Michal">Kobrle Michal</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 2&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:5&nbsp;&nbsp;</td>
<td class=bl>7:5&nbsp;&nbsp;</td>
<td class=bl>3:2 P&nbsp;&nbsp;</td>
<td class=bl>5:1&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="stats.php?idpl=116&x=-61&p=Matantsev%20Artem"><b>Matantsev Artem</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=92&x=-61&p=Smagars%20Valts">Smagars Valts</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>7:1&nbsp;&nbsp;</td>
<td class=al>5:1&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>3:4&nbsp;&nbsp;</td>
<td class=al>3:1&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="stats.php?idpl=101&x=-61&p=Matantsev%20Evgeniy"><b>Matantsev Evgeniy</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=83&x=-61&p=Baumanis%20Toms">Baumanis Toms</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:0&nbsp;&nbsp;</td>
<td class=bl>5:1&nbsp;&nbsp;</td>
<td class=bl>4:3 P&nbsp;&nbsp;</td>
<td class=bl>5:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="stats.php?idpl=105&x=-61&p=Petr%20Patrik"><b>Petr Patrik</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=423&x=-61&p=Blume%20Olof">Blume Olof</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>4:0&nbsp;&nbsp;</td>
<td class=al>7:1&nbsp;&nbsp;</td>
<td class=al>4:5&nbsp;&nbsp;</td>
<td class=al>0:1&nbsp;&nbsp;</td>
<td class=al>1:3&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
</tr><tr><td class=br><a href="stats.php?idpl=368&x=-61&p=Umanskyy%20Anton"><b>Umanskyy Anton</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=229&x=-61&p=%C3%96sterman%20Uno">�sterman Uno</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>5:1&nbsp;&nbsp;</td>
<td class=bl>4:0&nbsp;&nbsp;</td>
<td class=bl>3:7&nbsp;&nbsp;</td>
<td class=bl>5:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="stats.php?idpl=269&x=-61&p=Eriksson%20Kevin"><b>Eriksson Kevin</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=227&x=-61&p=%C3%96sterman%20Hans">�sterman Hans</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>1:3&nbsp;&nbsp;</td>
<td class=al>3:0&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
<td class=al>5:3&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="stats.php?idpl=43&x=-61&p=Naglis%20Edgars"><b>Naglis Edgars</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=104&x=-61&p=Nilsson%20Eddie">Nilsson Eddie</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>6:2&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>5:4&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="stats.php?idpl=7&x=-61&p=Kalni%C5%86%C5%A1%20Rainers"><b>Kalni�� Rainers</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=240&x=-61&p=Korabel%20Oleksii">Korabel Oleksii</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>0:4&nbsp;&nbsp;</td>
<td class=al>2:3 P&nbsp;&nbsp;</td>
<td class=al>2:0&nbsp;&nbsp;</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>4:3 P&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>1/16</strong></font></th></tr>
<tr><td class=br><a href="stats.php?idpl=4&x=-61&p=Caics%20Edgars%20%28A1%2F1%29"><b>Caics Edgars (A1/1)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=186&x=-61&p=Kamzols%20R%C5%ABdolfs%20%28A2%2F16%29">Kamzols R�dolfs (A2/16)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>6:3&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>5:0&nbsp;&nbsp;</td>
<td class=bl>10:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="stats.php?idpl=109&x=-61&p=Kobrle%20Michal%20%28A1%2F9%29"><b>Kobrle Michal (A1/9)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=381&x=-61&p=Klippen%20Magnus%20%28A2%2F8%29">Klippen Magnus (A2/8)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>3:4 P&nbsp;&nbsp;</td>
<td class=al>4:5&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>3:4 P&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
</tr><tr><td class=br><a href="stats.php?idpl=116&x=-61&p=Matantsev%20Artem%20%28A2%2F4%29"><b>Matantsev Artem (A2/4)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=239&x=-61&p=Suominen%20Benjamin%20%28A1%2F13%29">Suominen Benjamin (A1/13)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>6:1&nbsp;&nbsp;</td>
<td class=bl>2:0&nbsp;&nbsp;</td>
<td class=bl>2:0&nbsp;&nbsp;</td>
<td class=bl>3:4&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="stats.php?idpl=92&x=-61&p=Smagars%20Valts%20%28A1%2F5%29"><b>Smagars Valts (A1/5)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=40&x=-61&p=Sili%C5%86%C5%A1%20Alvis%20%28A2%2F12%29">Sili�� Alvis (A2/12)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>6:3&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="stats.php?idpl=101&x=-61&p=Matantsev%20Evgeniy%20%28A1%2F3%29"><b>Matantsev Evgeniy (A1/3)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=108&x=-61&p=Madera%20Martin%20%28A2%2F14%29">Madera Martin (A2/14)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>8:1&nbsp;&nbsp;</td>
<td class=bl>4:0&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>4:0&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="stats.php?idpl=29&x=-61&p=Lagzdi%C5%86a%20Krista%20Annija%20%28A2%2F6%29">Lagzdi�a Krista Annija (A2/6)</a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=83&x=-61&p=Baumanis%20Toms%20%28A1%2F11%29"><b>Baumanis Toms (A1/11)</b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;2 : 4&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>1:2&nbsp;&nbsp;</td>
<td class=al>0:4&nbsp;&nbsp;</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>2:0&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>1:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="stats.php?idpl=105&x=-61&p=Petr%20Patrik%20%28A2%2F2%29"><b>Petr Patrik (A2/2)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=213&x=-61&p=Ka%C5%86eps%20Ed%C5%BEus%20%28A1%2F15%29">Ka�eps Ed�us (A1/15)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>3:4&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>3:2 P&nbsp;&nbsp;</td>
<td class=bl>6:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="stats.php?idpl=423&x=-61&p=Blume%20Olof%20%28A1%2F7%29"><b>Blume Olof (A1/7)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=44&x=-61&p=Naglis%20Kristaps%20%28A2%2F10%29">Naglis Kristaps (A2/10)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>5:1&nbsp;&nbsp;</td>
<td class=al>2:0&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="stats.php?idpl=368&x=-61&p=Umanskyy%20Anton%20%28A1%2F2%29"><b>Umanskyy Anton (A1/2)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=42&x=-61&p=Liepi%C5%86%C5%A1%20Em%C4%ABls%20%28A2%2F15%29">Liepi�� Em�ls (A2/15)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:1&nbsp;&nbsp;</td>
<td class=bl>6:0&nbsp;&nbsp;</td>
<td class=bl>8:1&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>3:0&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="stats.php?idpl=229&x=-61&p=%C3%96sterman%20Uno%20%28A2%2F7%29"><b>�sterman Uno (A2/7)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=212&x=-61&p=Ziemelis%20Didzis%20%28A1%2F10%29">Ziemelis Didzis (A1/10)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>5:3&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>3:4 P&nbsp;&nbsp;</td>
<td class=al>2:1 P&nbsp;&nbsp;</td>
<td class=al>3:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="stats.php?idpl=269&x=-61&p=Eriksson%20Kevin%20%28A2%2F3%29"><b>Eriksson Kevin (A2/3)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=39&x=-61&p=Rieksti%C5%86%C5%A1%20Kristaps%20%28A1%2F14%29">Rieksti�� Kristaps (A1/14)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 2&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:1 P&nbsp;&nbsp;</td>
<td class=bl>0:1 P&nbsp;&nbsp;</td>
<td class=bl>5:2&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>3:2 P&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="stats.php?idpl=227&x=-61&p=%C3%96sterman%20Hans%20%28A1%2F6%29"><b>�sterman Hans (A1/6)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=419&x=-61&p=%C3%96stlund%20Peter%20%28A2%2F11%29">�stlund Peter (A2/11)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:0&nbsp;&nbsp;</td>
<td class=al>2:5&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>0:3&nbsp;&nbsp;</td>
<td class=al>4:0&nbsp;&nbsp;</td>
<td class=al>2:1 P&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="stats.php?idpl=27&x=-61&p=Sili%C5%86%C5%A1%20Elvijs%20%28A1%2F4%29">Sili�� Elvijs (A1/4)</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=43&x=-61&p=Naglis%20Edgars%20%28A2%2F13%29"><b>Naglis Edgars (A2/13)</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 4&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:0&nbsp;&nbsp;</td>
<td class=bl>1:6&nbsp;&nbsp;</td>
<td class=bl>1:3&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>3:5&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="stats.php?idpl=104&x=-61&p=Nilsson%20Eddie%20%28A2%2F5%29"><b>Nilsson Eddie (A2/5)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=28&x=-61&p=Lagzdi%C5%86%C5%A1%20Sandis%20Kristaps%20%28A1%2F12%29">Lagzdi�� Sandis Kristaps (A1/12)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>1:2&nbsp;&nbsp;</td>
<td class=al>1:4&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>5:1&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
</tr><tr><td class=br><a href="stats.php?idpl=7&x=-61&p=Kalni%C5%86%C5%A1%20Rainers%20%28A2%2F1%29"><b>Kalni�� Rainers (A2/1)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=97&x=-61&p=Lasmanis%20Gints%20%28A1%2F16%29">Lasmanis Gints (A1/16)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>9:2&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>7:2&nbsp;&nbsp;</td>
<td class=bl>7:3&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="stats.php?idpl=123&x=-61&p=Jurka%20Lukass%20%28A2%2F9%29">Jurka Lukass (A2/9)</a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=240&x=-61&p=Korabel%20Oleksii%20%28A1%2F8%29"><b>Korabel Oleksii (A1/8)</b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;0 : 4&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>1:3&nbsp;&nbsp;</td>
<td class=al>2:4&nbsp;&nbsp;</td>
<td class=al>3:4 P&nbsp;&nbsp;</td>
<td class=al>1:4&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>OpenB Finals</strong></font></th></tr>
<tr><td class=br><a href="stats.php?idpl=5&x=-61&p=Vazoli%C5%86%C5%A1%20Regn%C4%81rs">Vazoli�� Regn�rs</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=401&x=-61&p=Lezik%20Matej"><b>Lezik Matej</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:4&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>2:5&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>OpenB 1/2</strong></font></th></tr>
<tr><td class=ar><a href="stats.php?idpl=5&x=-61&p=Vazoli%C5%86%C5%A1%20Regn%C4%81rs%20%281%29"><b>Vazoli�� Regn�rs (1)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=66&x=-61&p=Hrustaljova%20Darja%20%284%29">Hrustaljova Darja (4)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>6:1&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>3:5&nbsp;&nbsp;</td>
<td class=al>2:1 P&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="stats.php?idpl=422&x=-61&p=Pedersen%20Richard%20%282%29">Pedersen Richard (2)</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=401&x=-61&p=Lezik%20Matej%20%283%29"><b>Lezik Matej (3)</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;1 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:4&nbsp;&nbsp;</td>
<td class=bl>1:2 P&nbsp;&nbsp;</td>
<td class=bl>3:2 P&nbsp;&nbsp;</td>
<td class=bl>2:6&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>OpenC Finals</strong></font></th></tr>
<tr><td class=br><a href="stats.php?idpl=145&x=-61&p=Zenisek%20Martin">Zenisek Martin</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=407&x=-61&p=Kraus%20Vladimir"><b>Kraus Vladimir</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>1:5&nbsp;&nbsp;</td>
<td class=bl>8:1&nbsp;&nbsp;</td>
<td class=bl>2:6&nbsp;&nbsp;</td>
<td class=bl>2:1&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>OpenC 1/2</strong></font></th></tr>
<tr><td class=ar><a href="stats.php?idpl=145&x=-61&p=Zenisek%20Martin%20%281%29"><b>Zenisek Martin (1)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="stats.php?idpl=426&x=-61&p=Wallin%20Wilton%20%284%29">Wallin Wilton (4)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:3 P&nbsp;&nbsp;</td>
<td class=al>0:3&nbsp;&nbsp;</td>
<td class=al>5:4 P&nbsp;&nbsp;</td>
<td class=al>8:1&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="stats.php?idpl=407&x=-61&p=Kraus%20Vladimir%20%282%29"><b>Kraus Vladimir (2)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="stats.php?idpl=125&x=-61&p=Thomas%20Simon%20%283%29">Thomas Simon (3)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:5&nbsp;&nbsp;</td>
<td class=bl>4:3 P&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>2:1 P&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
