<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Open Individual (O)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Open_Individual_(O)_list.php">Open Individual (O)</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group OpenB</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>65</td>
<td class=ic>66</td>
<td class=ic>67</td>
<td class=ic>68</td>
<td class=ic>69</td>
<td class=ic>70</td>
<td class=ic>71</td>
<td class=ic>72</td>
<td class=ic>73</td>
<td class=ic>74</td>
<td class=ic>75</td>
<td class=ic>76</td>
<td class=ic>77</td>
<td class=ic>78</td>
<td class=ic>79</td>
<td class=ic>80</td>
<td class=ic>81</td>
<td class=ic>82</td>
<td class=ic>83</td>
<td class=ic>84</td>
<td class=ic>85</td>
<td class=ic>86</td>
<td class=ic>87</td>
<td class=ic>88</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>65.</td><td class=kt><a href="stats.php?idpl=5&x=-61&p=Re%20Vazoli%C5%86%C5%A1">Re Vazoli��</a></td><td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>6:5</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>7:0</td>
<td class=kW>2:0</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kL>4:9</td>
<td class=kW>9:1</td>
<td class=kW>6:1</td>
<td class=kW>5:0 K</td>
<td class=br>84:40</td><td class=br>+44</td>
<td class=bc>18 - 1 - 4</td>
<td class=br><strong>37</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>66.</td><td class=kt><a href="stats.php?idpl=422&x=-61&p=Ri%20Pedersen">Ri Pedersen</a></td><td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kL>3:7</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>7:4</td>
<td class=kW>5:3</td>
<td class=kW>9:3</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kW>6:2</td>
<td class=kW>5:0 K</td>
<td class=br>91:53</td><td class=br>+38</td>
<td class=bc>15 - 6 - 2</td>
<td class=br><strong>36</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>67.</td><td class=kt><a href="stats.php?idpl=401&x=-61&p=Ma%20Lezik">Ma Lezik</a></td><td class=kL>2:4</td>
<td class=kW>7:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kW>6:2</td>
<td class=kW>8:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0 K</td>
<td class=br>91:43</td><td class=br>+48</td>
<td class=bc>16 - 3 - 4</td>
<td class=br><strong>35</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>68.</td><td class=kt><a href="stats.php?idpl=66&x=-61&p=Da%20Hrustaljova">Da Hrustaljova</a></td><td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>6:5</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kL>0:6</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=kW>8:1</td>
<td class=kW>5:0 K</td>
<td class=br>79:43</td><td class=br>+36</td>
<td class=bc>14 - 6 - 3</td>
<td class=br><strong>34</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>69.</td><td class=kt><a href="stats.php?idpl=425&x=-61&p=An%20Kimberg">An Kimberg</a></td><td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kW>5:0 K</td>
<td class=br>58:35</td><td class=br>+23</td>
<td class=bc>13 - 6 - 4</td>
<td class=br><strong>32</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>70.</td><td class=kt><a href="stats.php?idpl=163&x=-61&p=Zy%20Remeika">Zy Remeika</a></td><td class=kL>5:6</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>5:6</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>5:3</td>
<td class=kL>4:7</td>
<td class=kW>6:4</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0 K</td>
<td class=br>84:62</td><td class=br>+22</td>
<td class=bc>11 - 7 - 5</td>
<td class=br><strong>29</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>71.</td><td class=kt><a href="stats.php?idpl=236&x=-61&p=Am%20Fylling">Am Fylling</a></td><td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kT>5:5</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>5:0 K</td>
<td class=br>68:53</td><td class=br>+15</td>
<td class=bc>11 - 7 - 5</td>
<td class=br><strong>29</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>72.</td><td class=kt><a href="stats.php?idpl=427&x=-61&p=Ja%20Forsberg">Ja Forsberg</a></td><td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>5:0 K</td>
<td class=br>61:51</td><td class=br>+10</td>
<td class=bc>10 - 7 - 6</td>
<td class=br><strong>27</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>73.</td><td class=kt><a href="stats.php?idpl=392&x=-61&p=La%20Mets%C3%A4l%C3%A4">La Mets�l�</a></td><td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>5:0 K</td>
<td class=br>61:48</td><td class=br>+13</td>
<td class=bc>10 - 6 - 7</td>
<td class=br><strong>26</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>74.</td><td class=kt><a href="stats.php?idpl=404&x=-61&p=Da%20Matysek">Da Matysek</a></td><td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0 K</td>
<td class=br>63:44</td><td class=br>+19</td>
<td class=bc>10 - 5 - 8</td>
<td class=br><strong>25</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>75.</td><td class=kt><a href="stats.php?idpl=402&x=-61&p=Pe%20Fuchs">Pe Fuchs</a></td><td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kW>6:5</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>7:3</td>
<td class=kW>6:3</td>
<td class=kL>1:4</td>
<td class=kW>5:0 K</td>
<td class=br>65:52</td><td class=br>+13</td>
<td class=bc>9 - 7 - 7</td>
<td class=br><strong>25</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>76.</td><td class=kt><a href="stats.php?idpl=117&x=-61&p=Tr%20M%C3%A5nsson">Tr M�nsson</a></td><td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>1:0</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>8:2</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0 K</td>
<td class=br>60:43</td><td class=br>+17</td>
<td class=bc>9 - 6 - 8</td>
<td class=br><strong>24</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>77.</td><td class=kt><a href="stats.php?idpl=405&x=-61&p=Va%20Pikl">Va Pikl</a></td><td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>0:6</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>5:0 K</td>
<td class=br>65:64</td><td class=br>+1</td>
<td class=bc>9 - 4 - 10</td>
<td class=br><strong>22</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>78.</td><td class=kt><a href="stats.php?idpl=139&x=-61&p=Po%20Kvasnikova">Po Kvasnikova</a></td><td class=kW>1:0</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kW>1:0</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kT>0:0</td>
<td class=kL>0:6</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kT>0:0</td>
<td class=kW>5:0 K</td>
<td class=br>37:48</td><td class=br>-11</td>
<td class=bc>8 - 6 - 9</td>
<td class=br><strong>22</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>79.</td><td class=kt><a href="stats.php?idpl=241&x=-61&p=Pa%20Plesak">Pa Plesak</a></td><td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>8:4</td>
<td class=kW>5:0 K</td>
<td class=br>56:61</td><td class=br>-5</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>80.</td><td class=kt><a href="stats.php?idpl=156&x=-61&p=Gl%20Storozhenko">Gl Storozhenko</a></td><td class=kL>0:3</td>
<td class=kL>4:7</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>5:0 K</td>
<td class=br>50:63</td><td class=br>-13</td>
<td class=bc>8 - 4 - 11</td>
<td class=br><strong>20</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>81.</td><td class=kt><a href="stats.php?idpl=136&x=-61&p=Da%20Sippo">Da Sippo</a></td><td class=kL>0:7</td>
<td class=kL>3:5</td>
<td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kT>5:5</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>6:7</td>
<td class=kT>3:3</td>
<td class=kW>5:0 K</td>
<td class=br>58:73</td><td class=br>-15</td>
<td class=bc>9 - 2 - 12</td>
<td class=br><strong>20</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>82.</td><td class=kt><a href="stats.php?idpl=391&x=-61&p=To%20Uimonen">To Uimonen</a></td><td class=kL>0:2</td>
<td class=kL>3:9</td>
<td class=kL>1:4</td>
<td class=kW>6:0</td>
<td class=kL>0:4</td>
<td class=kW>7:4</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>5:6</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>5:3</td>
<td class=kL>3:6</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>5:0 K</td>
<td class=br>65:67</td><td class=br>-2</td>
<td class=bc>8 - 4 - 11</td>
<td class=br><strong>20</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>83.</td><td class=kt><a href="stats.php?idpl=378&x=-61&p=Ni%20Lyksholm">Ni Lyksholm</a></td><td class=kW>5:4</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>4:6</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>0:7</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kW>6:0</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>10:2</td>
<td class=kW>5:0 K</td>
<td class=br>56:68</td><td class=br>-12</td>
<td class=bc>8 - 2 - 13</td>
<td class=br><strong>18</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>84.</td><td class=kt><a href="stats.php?idpl=226&x=-61&p=Ka%20Pirumshoieva">Ka Pirumshoieva</a></td><td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>5:0 K</td>
<td class=br>54:60</td><td class=br>-6</td>
<td class=bc>4 - 7 - 12</td>
<td class=br><strong>15</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>85.</td><td class=kt><a href="stats.php?idpl=380&x=-61&p=Be%20Nyg%C3%A5rd">Be Nyg�rd</a></td><td class=kW>9:4</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>1:7</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>3:7</td>
<td class=kL>2:8</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>5:0 K</td>
<td class=br>60:83</td><td class=br>-23</td>
<td class=bc>6 - 3 - 14</td>
<td class=br><strong>15</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>86.</td><td class=kt><a href="stats.php?idpl=414&x=-61&p=Ei%20Rompa">Ei Rompa</a></td><td class=kL>1:9</td>
<td class=kL>4:5</td>
<td class=kL>2:8</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>1:7</td>
<td class=kL>3:6</td>
<td class=kL>0:6</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>7:6</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:0 K</td>
<td class=br>57:100</td><td class=br>-43</td>
<td class=bc>4 - 3 - 16</td>
<td class=br><strong>11</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>87.</td><td class=kt><a href="stats.php?idpl=162&x=-61&p=Gi%20Remeika">Gi Remeika</a></td><td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>1:8</td>
<td class=kL>0:1</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kT>0:0</td>
<td class=kL>4:8</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>2:10</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:0 K</td>
<td class=br>41:95</td><td class=br>-54</td>
<td class=bc>3 - 3 - 17</td>
<td class=br><strong>9</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>88.</td><td class=kt><a href="stats.php?idpl=70&x=-61&p=An%20Kuz%C5%86ecovs">An Kuz�ecovs</a></td><td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kx>*</td>
<td class=br>0:115</td><td class=br>-115</td>
<td class=bc>0 - 0 - 23</td>
<td class=br><strong>0</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Mets�l� Lari</td><td class=bc>-</td><td class=blW>Kvasnikova Polina</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Nyg�rd Benjamin</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=blW>Sippo Daniel</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Lyksholm Nico</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lezik Matej</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Uimonen Tomi</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Pedersen Richard</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>0 : 5 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kvasnikova Polina</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mets�l� Lari</td><td class=bc>-</td><td class=blW>Nyg�rd Benjamin</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=blW>Sippo Daniel</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lezik Matej</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Uimonen Tomi</td><td class=bc>-</td><td class=blW>Pedersen Richard</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>6 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Nyg�rd Benjamin</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=blW>Sippo Daniel</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mets�l� Lari</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Matysek Daniel</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>Pedersen Richard</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Lezik Matej</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Uimonen Tomi</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 0 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Nyg�rd Benjamin</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kvasnikova Polina</td><td class=bc>-</td><td class=bl>Sippo Daniel</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mets�l� Lari</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=blW>Pedersen Richard</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Lezik Matej</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Uimonen Tomi</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Sippo Daniel</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kvasnikova Polina</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Mets�l� Lari</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=blW>Pedersen Richard</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Matysek Daniel</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Lezik Matej</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Sippo Daniel</td><td class=bc>-</td><td class=blW>Lyksholm Nico</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=bl>Pedersen Richard</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mets�l� Lari</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pikl Vaclav</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>Uimonen Tomi</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Lyksholm Nico</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Sippo Daniel</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Forsberg James-John</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=blW>Pedersen Richard</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mets�l� Lari</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=bl>Uimonen Tomi</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=bl>Lezik Matej</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Rompa Eike</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Sippo Daniel</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Pedersen Richard</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mets�l� Lari</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pikl Vaclav</td><td class=bc>-</td><td class=bl>Uimonen Tomi</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Lezik Matej</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=blW>Fylling Amund Risa</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Rompa Eike</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=blW>Forsberg James-John</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Pedersen Richard</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Sippo Daniel</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Uimonen Tomi</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Mets�l� Lari</td><td class=bc>-</td><td class=blW>Lezik Matej</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=blW>Fylling Amund Risa</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Forsberg James-John</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Pedersen Richard</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Sippo Daniel</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=bl>Uimonen Tomi</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Lezik Matej</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=bl>Fylling Amund Risa</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mets�l� Lari</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pikl Vaclav</td><td class=bc>-</td><td class=bl>Matysek Daniel</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=bl>Pedersen Richard</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sippo Daniel</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Nyg�rd Benjamin</td><td class=bc>-</td><td class=bl>Uimonen Tomi</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Lezik Matej</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Kvasnikova Polina</td><td class=bc>-</td><td class=bl>Fylling Amund Risa</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=blW>Matysek Daniel</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mets�l� Lari</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Pedersen Richard</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Rompa Eike</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Uimonen Tomi</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Sippo Daniel</td><td class=bc>-</td><td class=blW>Lezik Matej</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Fylling Amund Risa</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=blW>Matysek Daniel</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Pedersen Richard</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Uimonen Tomi</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Lezik Matej</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Fylling Amund Risa</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Sippo Daniel</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Matysek Daniel</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=blW>Pikl Vaclav</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Mets�l� Lari</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pedersen Richard</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=bl>Uimonen Tomi</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Lezik Matej</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Fylling Amund Risa</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Matysek Daniel</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Sippo Daniel</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Pikl Vaclav</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Mets�l� Lari</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Uimonen Tomi</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pedersen Richard</td><td class=bc>-</td><td class=blW>Lezik Matej</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=bl>Fylling Amund Risa</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Matysek Daniel</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Pikl Vaclav</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Sippo Daniel</td><td class=bc>-</td><td class=blW>Mets�l� Lari</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Uimonen Tomi</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Lezik Matej</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Fylling Amund Risa</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pedersen Richard</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=blW>Matysek Daniel</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Pikl Vaclav</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Mets�l� Lari</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Sippo Daniel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Kvasnikova Polina</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Uimonen Tomi</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=blW>Lezik Matej</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Fylling Amund Risa</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=bl>Matysek Daniel</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pedersen Richard</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Mets�l� Lari</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Lyksholm Nico</td><td class=bc>-</td><td class=bl>Kvasnikova Polina</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Sippo Daniel</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Uimonen Tomi</td><td class=bc>-</td><td class=blW>Lezik Matej</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Fylling Amund Risa</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Matysek Daniel</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pedersen Richard</td><td class=bc>-</td><td class=bl>Mets�l� Lari</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Kvasnikova Polina</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=bl>Nyg�rd Benjamin</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Lezik Matej</td><td class=bc>-</td><td class=bl>Fylling Amund Risa</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Uimonen Tomi</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Matysek Daniel</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Pikl Vaclav</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Mets�l� Lari</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pedersen Richard</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Kvasnikova Polina</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Nyg�rd Benjamin</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=blW>Sippo Daniel</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Lezik Matej</td><td class=bc>-</td><td class=bl>Matysek Daniel</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Uimonen Tomi</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Mets�l� Lari</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=bl>Kvasnikova Polina</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pedersen Richard</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Nyg�rd Benjamin</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Rompa Eike</td><td class=bc>-</td><td class=bl>Sippo Daniel</td><td class=bc>7 : 6</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Lyksholm Nico</td><td class=bc>2 : 10</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Matysek Daniel</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Lezik Matej</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Uimonen Tomi</td><td class=bc>-</td><td class=blW>Mets�l� Lari</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Kvasnikova Polina</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Nyg�rd Benjamin</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pedersen Richard</td><td class=bc>-</td><td class=bl>Sippo Daniel</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Rompa Eike</td><td class=bc>-</td><td class=blW>Pirumshoieva Karyna</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Pikl Vaclav</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>Mets�l� Lari</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Lezik Matej</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Uimonen Tomi</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>Kvasnikova Polina</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Nyg�rd Benjamin</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Sippo Daniel</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Pedersen Richard</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=blW>Mets�l� Lari</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Lezik Matej</td><td class=bc>-</td><td class=bl>Kvasnikova Polina</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Uimonen Tomi</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>Nyg�rd Benjamin</td><td class=bc>4 : 9</tr></td>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Sippo Daniel</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Lyksholm Nico</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>Pedersen Richard</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=bl>Mets�l� Lari</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Matysek Daniel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Kvasnikova Polina</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Fylling Amund Risa</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Lezik Matej</td><td class=bc>-</td><td class=bl>Nyg�rd Benjamin</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Uimonen Tomi</td><td class=bc>-</td><td class=blW>Sippo Daniel</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>Lyksholm Nico</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Forsberg James-John</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=brW>Mets�l� Lari</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=bl>Kvasnikova Polina</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Matysek Daniel</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Nyg�rd Benjamin</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>Sippo Daniel</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Lezik Matej</td><td class=bc>-</td><td class=blW>Lyksholm Nico</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Uimonen Tomi</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Rompa Eike</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Forsberg James-John</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Pedersen Richard</td><td class=bc>2 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
