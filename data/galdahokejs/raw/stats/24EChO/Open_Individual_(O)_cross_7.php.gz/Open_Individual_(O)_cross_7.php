<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Open Individual (O)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Open_Individual_(O)_list.php">Open Individual (O)</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group Open7</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=108&x=-61&p=Ma%20Madera">Ma Madera</a></td><td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kL>0:3</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>8:2</td>
<td class=kW>7:1</td>
<td class=kW>2:0</td>
<td class=kW>5:0 K</td>
<td class=br>59:18</td><td class=br>+41</td>
<td class=bc>11 - 0 - 2</td>
<td class=br><strong>22</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=419&x=-61&p=Pe%20%C3%96stlund">Pe �stlund</a></td><td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0 K</td>
<td class=br>38:20</td><td class=br>+18</td>
<td class=bc>9 - 2 - 2</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=123&x=-61&p=Lu%20Jurka">Lu Jurka</a></td><td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>0:0</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0 K</td>
<td class=br>36:15</td><td class=br>+21</td>
<td class=bc>8 - 3 - 2</td>
<td class=br><strong>19</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=104&x=-61&p=Ed%20Nilsson">Ed Nilsson</a></td><td class=kW>3:0</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kW>8:2</td>
<td class=kW>2:0</td>
<td class=kW>5:0 K</td>
<td class=br>41:23</td><td class=br>+18</td>
<td class=bc>8 - 2 - 3</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=67&x=-61&p=Ti%20Mihhaljov">Ti Mihhaljov</a></td><td class=kL>1:7</td>
<td class=kW>4:1</td>
<td class=kT>0:0</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>5:0 K</td>
<td class=br>27:22</td><td class=br>+5</td>
<td class=bc>7 - 2 - 4</td>
<td class=br><strong>16</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=122&x=-61&p=Vi%20Henttonen">Vi Henttonen</a></td><td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>5:0 K</td>
<td class=br>28:31</td><td class=br>-3</td>
<td class=bc>6 - 2 - 5</td>
<td class=br><strong>14</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=114&x=-61&p=An%20Bo%C5%BEi%C4%8D">An Bo�i�</a></td><td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>5:0 K</td>
<td class=br>34:29</td><td class=br>+5</td>
<td class=bc>5 - 4 - 4</td>
<td class=br><strong>14</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=32&x=-61&p=Sa%20Skarainis">Sa Skarainis</a></td><td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>5:0 K</td>
<td class=br>31:30</td><td class=br>+1</td>
<td class=bc>6 - 1 - 6</td>
<td class=br><strong>13</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=236&x=-61&p=Am%20Fylling">Am Fylling</a></td><td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>5:0 K</td>
<td class=br>28:27</td><td class=br>+1</td>
<td class=bc>4 - 4 - 5</td>
<td class=br><strong>12</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=422&x=-61&p=Ri%20Pedersen">Ri Pedersen</a></td><td class=kL>2:7</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>5:0 K</td>
<td class=br>26:37</td><td class=br>-11</td>
<td class=bc>3 - 3 - 7</td>
<td class=br><strong>9</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=156&x=-61&p=Gl%20Storozhenko">Gl Storozhenko</a></td><td class=kL>2:8</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>5:0 K</td>
<td class=br>30:39</td><td class=br>-9</td>
<td class=bc>3 - 3 - 7</td>
<td class=br><strong>9</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=367&x=-61&p=Ol%20Pylypenko">Ol Pylypenko</a></td><td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>2:8</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:0 K</td>
<td class=br>27:43</td><td class=br>-16</td>
<td class=bc>3 - 2 - 8</td>
<td class=br><strong>8</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt><a href="stats.php?idpl=131&x=-61&p=My%20Verbytskyy">My Verbytskyy</a></td><td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:0 K</td>
<td class=br>21:27</td><td class=br>-6</td>
<td class=bc>3 - 2 - 8</td>
<td class=br><strong>8</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt><a href="stats.php?idpl=223&x=-61&p=Ig%20Zamiatin">Ig Zamiatin</a></td><td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kx>*</td>
<td class=br>0:65</td><td class=br>-65</td>
<td class=bc>0 - 0 - 13</td>
<td class=br><strong>0</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Jurka Lukass</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mihhaljov Timur</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pedersen Richard</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Jurka Lukass</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fylling Amund Risa</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mihhaljov Timur</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pedersen Richard</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>5 : 0 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mihhaljov Timur</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Pedersen Richard</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Madera Martin</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Jurka Lukass</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Mihhaljov Timur</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Madera Martin</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Jurka Lukass</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fylling Amund Risa</td><td class=bc>-</td><td class=blW>�stlund Peter</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mihhaljov Timur</td><td class=bc>-</td><td class=bl>Pedersen Richard</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Madera Martin</td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Jurka Lukass</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>Pedersen Richard</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>�stlund Peter</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Madera Martin</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=bl>Pedersen Richard</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Fylling Amund Risa</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Zamiatin Igor</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>�stlund Peter</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Pedersen Richard</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Madera Martin</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=blW>�stlund Peter</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Pedersen Richard</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Madera Martin</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=bl>Fylling Amund Risa</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=blW>Pedersen Richard</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Mihhaljov Timur</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Fylling Amund Risa</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Pedersen Richard</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=blW>Mihhaljov Timur</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Fylling Amund Risa</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Pedersen Richard</td><td class=bc>-</td><td class=blW>Pylypenko Oleksandr</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Mihhaljov Timur</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=blW>Fylling Amund Risa</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>Mihhaljov Timur</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pedersen Richard</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Fylling Amund Risa</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>�stlund Peter</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Mihhaljov Timur</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>Fylling Amund Risa</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pedersen Richard</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Fylling Amund Risa</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mihhaljov Timur</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Pedersen Richard</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>�stlund Peter</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Zamiatin Igor</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>0 : 5 K</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
