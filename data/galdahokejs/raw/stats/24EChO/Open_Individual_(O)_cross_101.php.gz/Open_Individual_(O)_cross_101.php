<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Open Individual (O)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Open_Individual_(O)_list.php">Open Individual (O)</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group OpenA1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>31</td>
<td class=ic>32</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=4&x=-61&p=Ed%20Caics">Ed Caics</a></td><td class=kx>*</td>
<td class=kL>2:5 K</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2 K</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kW>7:2</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>5:1 K</td>
<td class=kW>5:3 K</td>
<td class=kW>4:1</td>
<td class=kW>4:2 K</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1 K</td>
<td class=kW>6:2</td>
<td class=kW>9:2</td>
<td class=kW>6:2</td>
<td class=kW>3:0 K</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=br>120:58</td><td class=br>+62</td>
<td class=bc>24 - 3 - 4</td>
<td class=br><strong>51</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=368&x=-61&p=An%20Umanskyy">An Umanskyy</a></td><td class=kW>5:2 K</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3 K</td>
<td class=kL>1:3</td>
<td class=kW>10:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>5:2 K</td>
<td class=kW>8:3 K</td>
<td class=kW>2:1</td>
<td class=kL>1:2 K</td>
<td class=kL>0:2</td>
<td class=kW>5:2</td>
<td class=kL>2:3 K</td>
<td class=kW>6:2</td>
<td class=kW>7:2</td>
<td class=kW>7:3</td>
<td class=kW>5:3 K</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=br>126:64</td><td class=br>+62</td>
<td class=bc>21 - 1 - 9</td>
<td class=br><strong>43</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=101&x=-61&p=Ev%20Matantsev">Ev Matantsev</a></td><td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>6:5</td>
<td class=kW>4:3</td>
<td class=kT>4:4 K</td>
<td class=kL>2:3</td>
<td class=kL>2:3 K</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>6:3 K</td>
<td class=kW>5:4</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2 K</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=kW>3:1 K</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kW>6:3 K</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>9:5 K</td>
<td class=kW>4:1</td>
<td class=kW>7:4</td>
<td class=br>120:88</td><td class=br>+32</td>
<td class=bc>19 - 4 - 8</td>
<td class=br><strong>42</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=27&x=-61&p=El%20Sili%C5%86%C5%A1">El Sili��</a></td><td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kL>1:3 K</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kW>5:2 K</td>
<td class=kL>2:5 K</td>
<td class=kW>5:1 K</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:2 K</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>7:4</td>
<td class=kT>2:2</td>
<td class=kW>6:2 K</td>
<td class=kW>3:1 K</td>
<td class=br>90:69</td><td class=br>+21</td>
<td class=bc>18 - 6 - 7</td>
<td class=br><strong>42</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=92&x=-61&p=Va%20Smagars">Va Smagars</a></td><td class=kL>2:3 K</td>
<td class=kW>3:2 K</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kT>5:5</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>6:0</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kW>7:1 K</td>
<td class=kW>5:1 K</td>
<td class=kW>5:4</td>
<td class=kT>3:3 K</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>5:2 K</td>
<td class=kL>3:5</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kW>6:3 K</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=br>107:74</td><td class=br>+33</td>
<td class=bc>17 - 7 - 7</td>
<td class=br><strong>41</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=227&x=-61&p=Ha%20%C3%96sterman">Ha �sterman</a></td><td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>5:6</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kT>4:4 K</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=kW>3:1 K</td>
<td class=kW>1:0 K</td>
<td class=kW>4:0 K</td>
<td class=kW>6:1</td>
<td class=kL>2:5</td>
<td class=kW>2:0</td>
<td class=kL>2:3 K</td>
<td class=kW>6:1</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kL>1:4 K</td>
<td class=kW>2:0</td>
<td class=kW>4:3 K</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=br>93:65</td><td class=br>+28</td>
<td class=bc>19 - 3 - 9</td>
<td class=br><strong>41</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=423&x=-61&p=Ol%20Blume">Ol Blume</a></td><td class=kW>4:1</td>
<td class=kL>1:10</td>
<td class=kL>3:4</td>
<td class=kW>3:1 K</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>4:3 K</td>
<td class=kL>0:2 K</td>
<td class=kL>1:2 K</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>3:0 K</td>
<td class=kW>6:0</td>
<td class=kL>2:4</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>4:1 K</td>
<td class=kW>6:3 K</td>
<td class=br>91:76</td><td class=br>+15</td>
<td class=bc>17 - 4 - 10</td>
<td class=br><strong>38</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=240&x=-61&p=Ol%20Korabel">Ol Korabel</a></td><td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4 K</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>2:5 K</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kW>6:1</td>
<td class=kW>6:0 K</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=kL>2:3 K</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2 K</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kW>3:1 K</td>
<td class=kW>7:4</td>
<td class=kW>6:3</td>
<td class=kL>1:2 K</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=br>108:71</td><td class=br>+37</td>
<td class=bc>18 - 2 - 11</td>
<td class=br><strong>38</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=109&x=-61&p=Mi%20Kobrle">Mi Kobrle</a></td><td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kT>5:5</td>
<td class=kT>4:4 K</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>6:1 K</td>
<td class=kW>6:3 K</td>
<td class=kW>10:1 K</td>
<td class=kT>3:3</td>
<td class=kT>6:6</td>
<td class=kL>3:4</td>
<td class=kW>6:2 K</td>
<td class=kW>7:4</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kL>3:6 K</td>
<td class=kL>2:6</td>
<td class=kW>3:1 K</td>
<td class=kW>8:1</td>
<td class=kW>5:1</td>
<td class=kW>9:0</td>
<td class=kT>2:2</td>
<td class=br>122:90</td><td class=br>+32</td>
<td class=bc>12 - 12 - 7</td>
<td class=br><strong>36</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=212&x=-61&p=Di%20Ziemelis">Di Ziemelis</a></td><td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>3:2 K</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>5:2 K</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2 K</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kL>0:6</td>
<td class=kT>2:2 K</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kW>5:1 K</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>2:0 K</td>
<td class=kW>4:2</td>
<td class=kW>7:3</td>
<td class=kW>1:0 K</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=br>87:69</td><td class=br>+18</td>
<td class=bc>14 - 8 - 9</td>
<td class=br><strong>36</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=83&x=-61&p=To%20Baumanis">To Baumanis</a></td><td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>2:5 K</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kL>3:4 K</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>1:0 K</td>
<td class=kW>4:1 K</td>
<td class=kT>1:1</td>
<td class=kL>4:5</td>
<td class=kW>6:3</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>6:3</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kT>0:0 K</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kL>4:6</td>
<td class=kW>3:2</td>
<td class=kW>9:3</td>
<td class=kW>3:2 K</td>
<td class=kT>2:2 K</td>
<td class=br>90:74</td><td class=br>+16</td>
<td class=bc>12 - 12 - 7</td>
<td class=br><strong>36</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=28&x=-61&p=Sa%20Lagzdi%C5%86%C5%A1">Sa Lagzdi��</a></td><td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>5:2 K</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>2:0 K</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>0:1 K</td>
<td class=kx>*</td>
<td class=kL>2:5 K</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kL>2:3 K</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kW>6:3</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>3:2 K</td>
<td class=kW>7:1 K</td>
<td class=br>82:55</td><td class=br>+27</td>
<td class=bc>16 - 4 - 11</td>
<td class=br><strong>36</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt><a href="stats.php?idpl=239&x=-61&p=Be%20Suominen">Be Suominen</a></td><td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kL>1:5 K</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kW>2:1 K</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4 K</td>
<td class=kW>5:2 K</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>6:2</td>
<td class=kL>3:6</td>
<td class=kT>3:3 K</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kW>5:1 K</td>
<td class=kW>8:0 K</td>
<td class=br>87:84</td><td class=br>+3</td>
<td class=bc>14 - 7 - 10</td>
<td class=br><strong>35</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt><a href="stats.php?idpl=39&x=-61&p=Kr%20Rieksti%C5%86%C5%A1">Kr Rieksti��</a></td><td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kL>3:6 K</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kL>0:6 K</td>
<td class=kT>2:2</td>
<td class=kW>2:1 K</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3 K</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>3:1 K</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>4:5 K</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=br>75:72</td><td class=br>+3</td>
<td class=bc>13 - 8 - 10</td>
<td class=br><strong>34</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt><a href="stats.php?idpl=213&x=-61&p=Ed%20Ka%C5%86eps">Ed Ka�eps</a></td><td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>1:3 K</td>
<td class=kT>4:4</td>
<td class=kL>0:4</td>
<td class=kL>1:6 K</td>
<td class=kW>4:3</td>
<td class=kW>5:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kT>4:4 K</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>3:0 K</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>4:2 K</td>
<td class=kW>4:2</td>
<td class=kW>5:4 K</td>
<td class=kT>4:4</td>
<td class=kW>1:0</td>
<td class=kL>0:1</td>
<td class=kW>5:4</td>
<td class=br>84:84</td><td class=br>0</td>
<td class=bc>13 - 8 - 10</td>
<td class=br><strong>34</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt><a href="stats.php?idpl=97&x=-61&p=Gi%20Lasmanis">Gi Lasmanis</a></td><td class=kL>2:7</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>0:1 K</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>3:6 K</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kT>6:6 K</td>
<td class=kL>1:5</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2 K</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>4:3 K</td>
<td class=kT>2:2</td>
<td class=kW>7:2 K</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=br>86:86</td><td class=br>0</td>
<td class=bc>13 - 5 - 13</td>
<td class=br><strong>31</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="stats.php?idpl=30&x=-61&p=Ma%20Jakseboga">Ma Jakseboga</a></td><td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>0:4 K</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>1:10 K</td>
<td class=kW>6:0</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>4:4 K</td>
<td class=kT>6:6 K</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1 K</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1 K</td>
<td class=kL>2:4</td>
<td class=kL>1:3 K</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=br>80:92</td><td class=br>-12</td>
<td class=bc>10 - 10 - 11</td>
<td class=br><strong>30</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt><a href="stats.php?idpl=341&x=-61&p=J%C4%81%20Kaln%C4%93vics">J� Kaln�vics</a></td><td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>2:4 K</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kW>3:2 K</td>
<td class=kT>3:3</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3 K</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kL>0:3 K</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>1:2 K</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kW>4:0 K</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=br>73:77</td><td class=br>-4</td>
<td class=bc>9 - 12 - 10</td>
<td class=br><strong>30</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt><a href="stats.php?idpl=400&x=-61&p=Ja%20Matysek">Ja Matysek</a></td><td class=kL>1:5 K</td>
<td class=kL>2:5 K</td>
<td class=kL>1:5</td>
<td class=kW>5:4</td>
<td class=kL>1:7 K</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kT>6:6</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:2 K</td>
<td class=kW>5:3</td>
<td class=kL>0:2 K</td>
<td class=kT>0:0</td>
<td class=kT>3:3</td>
<td class=kT>1:1 K</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>5:4</td>
<td class=kL>3:6 K</td>
<td class=kL>3:6</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=br>73:91</td><td class=br>-18</td>
<td class=bc>10 - 10 - 11</td>
<td class=br><strong>30</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt><a href="stats.php?idpl=390&x=-61&p=Pe%20Miettinen">Pe Miettinen</a></td><td class=kL>3:5 K</td>
<td class=kL>3:8 K</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:5 K</td>
<td class=kL>0:2</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kL>2:3 K</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:3 K</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kL>1:2 K</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>3:1 K</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=br>75:87</td><td class=br>-12</td>
<td class=bc>13 - 3 - 15</td>
<td class=br><strong>29</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt><a href="stats.php?idpl=369&x=-61&p=My%20Spivakovskyy">My Spivakovskyy</a></td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kW>3:2 K</td>
<td class=kW>3:2</td>
<td class=kL>4:5</td>
<td class=kL>2:6 K</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kL>0:3 K</td>
<td class=kL>2:3 K</td>
<td class=kL>1:2 K</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>1:0 K</td>
<td class=kW>3:1</td>
<td class=kW>4:2 K</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=br>73:81</td><td class=br>-8</td>
<td class=bc>10 - 8 - 13</td>
<td class=br><strong>28</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt><a href="stats.php?idpl=103&x=-61&p=Ro%20Rieksti%C5%86%C5%A1">Ro Rieksti��</a></td><td class=kL>2:4 K</td>
<td class=kW>2:1 K</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kT>3:3 K</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kL>4:7</td>
<td class=kW>5:3</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>2:0 K</td>
<td class=kL>3:4 K</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>0:0</td>
<td class=kT>2:2 K</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kL>1:4 K</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=br>76:86</td><td class=br>-10</td>
<td class=bc>11 - 6 - 14</td>
<td class=br><strong>28</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt><a href="stats.php?idpl=431&x=-61&p=An%20Jalneskog">An Jalneskog</a></td><td class=kL>0:1</td>
<td class=kW>2:0</td>
<td class=kL>2:5</td>
<td class=kW>2:1 K</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>0:3 K</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kT>0:0 K</td>
<td class=kW>3:2 K</td>
<td class=kT>3:3 K</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kT>0:0</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>7:2</td>
<td class=kL>0:3</td>
<td class=kW>5:3 K</td>
<td class=kW>2:1 K</td>
<td class=br>56:71</td><td class=br>-15</td>
<td class=bc>9 - 8 - 14</td>
<td class=br><strong>26</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt><a href="stats.php?idpl=34&x=-61&p=J%C4%93%20Re%C4%B7is">J� Re�is</a></td><td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3 K</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>2:4 K</td>
<td class=kT>4:4</td>
<td class=kL>1:5 K</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kL>1:6</td>
<td class=kL>1:3 K</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>3:0 K</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kL>2:4</td>
<td class=kT>0:0</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kT>3:3 K</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kL>0:2 K</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=br>60:75</td><td class=br>-15</td>
<td class=bc>7 - 10 - 14</td>
<td class=br><strong>24</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt><a href="stats.php?idpl=403&x=-61&p=Mi%20Cernoch">Mi Cernoch</a></td><td class=kL>1:4 K</td>
<td class=kW>3:2 K</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>2:5 K</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1 K</td>
<td class=kW>2:1 K</td>
<td class=kL>0:3</td>
<td class=kT>2:2 K</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4 K</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kW>5:0</td>
<td class=br>58:88</td><td class=br>-30</td>
<td class=bc>8 - 7 - 16</td>
<td class=br><strong>23</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt><a href="stats.php?idpl=121&x=-61&p=Gu%20Hermansson">Gu Hermansson</a></td><td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>4:1 K</td>
<td class=kW>6:0</td>
<td class=kL>0:4</td>
<td class=kW>6:3 K</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kW>1:0</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>2:4 K</td>
<td class=kL>3:4 K</td>
<td class=kL>1:3 K</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>0:1 K</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:3 K</td>
<td class=kT>5:5</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=br>70:85</td><td class=br>-15</td>
<td class=bc>10 - 3 - 18</td>
<td class=br><strong>23</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt><a href="stats.php?idpl=377&x=-61&p=Bj%20Axelsen">Bj Axelsen</a></td><td class=kL>2:9</td>
<td class=kL>2:7</td>
<td class=kL>3:6 K</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kL>1:3 K</td>
<td class=kW>6:2</td>
<td class=kL>0:2 K</td>
<td class=kT>1:1</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kT>1:1 K</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1 K</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3 K</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2 K</td>
<td class=kW>4:1</td>
<td class=kL>2:6</td>
<td class=br>62:92</td><td class=br>-30</td>
<td class=bc>7 - 7 - 17</td>
<td class=br><strong>21</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt><a href="stats.php?idpl=112&x=-61&p=Ma%20Saveljeva">Ma Saveljeva</a></td><td class=kL>2:6</td>
<td class=kL>3:7</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>3:4 K</td>
<td class=kL>2:4</td>
<td class=kL>4:7</td>
<td class=kL>1:3 K</td>
<td class=kL>2:4</td>
<td class=kW>6:4</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>4:5 K</td>
<td class=kL>2:7 K</td>
<td class=kW>3:1 K</td>
<td class=kW>4:1</td>
<td class=kL>4:5</td>
<td class=kL>2:6</td>
<td class=kL>2:4 K</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kW>3:1 K</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=br>83:116</td><td class=br>-33</td>
<td class=bc>9 - 2 - 20</td>
<td class=br><strong>20</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt><a href="stats.php?idpl=384&x=-61&p=Fr%20Hagerup">Fr Hagerup</a></td><td class=kL>0:3 K</td>
<td class=kL>3:5 K</td>
<td class=kW>3:1</td>
<td class=kL>4:7</td>
<td class=kL>3:6 K</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kL>1:8</td>
<td class=kL>3:7</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kW>6:3 K</td>
<td class=kL>1:3 K</td>
<td class=kT>1:1</td>
<td class=kW>4:1 K</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kW>4:2 K</td>
<td class=kT>5:5</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=br>76:118</td><td class=br>-42</td>
<td class=bc>8 - 4 - 19</td>
<td class=br><strong>20</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt><a href="stats.php?idpl=432&x=-61&p=Gu%20Fagerberg">Gu Fagerberg</a></td><td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>5:9 K</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1 K</td>
<td class=kL>1:5</td>
<td class=kL>0:1 K</td>
<td class=kL>3:9</td>
<td class=kL>0:5</td>
<td class=kT>4:4</td>
<td class=kW>5:4 K</td>
<td class=kL>0:1</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kL>0:4 K</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kW>3:0</td>
<td class=kW>2:0 K</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2 K</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=br>59:106</td><td class=br>-47</td>
<td class=bc>7 - 4 - 20</td>
<td class=br><strong>18</strong></td><td class=d>30.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>31.</td><td class=kt><a href="stats.php?idpl=383&x=-61&p=Ve%20Klippen">Ve Klippen</a></td><td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>2:6 K</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4 K</td>
<td class=kL>2:3</td>
<td class=kL>0:9</td>
<td class=kL>1:2</td>
<td class=kL>2:3 K</td>
<td class=kL>2:3 K</td>
<td class=kL>1:5 K</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>3:5 K</td>
<td class=kL>1:2</td>
<td class=kW>6:2</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kT>3:3 K</td>
<td class=br>58:98</td><td class=br>-40</td>
<td class=bc>6 - 5 - 20</td>
<td class=br><strong>17</strong></td><td class=d>31.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>32.</td><td class=kt><a href="stats.php?idpl=79&x=-61&p=Mi%20Saul%C4%ABtis">Mi Saul�tis</a></td><td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>4:7</td>
<td class=kL>1:3 K</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>3:6 K</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kT>2:2 K</td>
<td class=kL>1:7 K</td>
<td class=kL>0:8 K</td>
<td class=kL>0:3</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>1:2 K</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kL>1:3</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kT>3:3 K</td>
<td class=kx>*</td>
<td class=br>58:116</td><td class=br>-58</td>
<td class=bc>3 - 5 - 23</td>
<td class=br><strong>11</strong></td><td class=d>32.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Matysek Jakub</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Ziemelis Didzis</td><td class=bc>-</td><td class=bl>Hagerup Frode</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>�sterman Hans</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=blW>Miettinen Petrus</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>Suominen Benjamin</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Cernoch Miroslav</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Saveljeva Maria</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Baumanis Toms</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>2 : 9</tr></td>
<tr><td class=brW>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=bl>Blume Olof</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Hagerup Frode</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Miettinen Petrus</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ziemelis Didzis</td><td class=bc>-</td><td class=bl>Cernoch Miroslav</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>�sterman Hans</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Umanskyy Anton</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Saveljeva Maria</td><td class=bc>-</td><td class=bl>Baumanis Toms</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Blume Olof</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Matysek Jakub</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Miettinen Petrus</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Cernoch Miroslav</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ziemelis Didzis</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>�sterman Hans</td><td class=bc>-</td><td class=blW>Jalneskog Anton</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>Baumanis Toms</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Caics Edgars</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Blume Olof</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Matysek Jakub</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Saveljeva Maria</td><td class=bc>-</td><td class=blW>Klippen Vegard</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Hagerup Frode</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=bl>Cernoch Miroslav</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=blW>Jalneskog Anton</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Baumanis Toms</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ziemelis Didzis</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>�sterman Hans</td><td class=bc>-</td><td class=blW>Blume Olof</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Matysek Jakub</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=blW>Hagerup Frode</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=blW>Miettinen Petrus</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Saveljeva Maria</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Cernoch Miroslav</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Saveljeva Maria</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=bl>Baumanis Toms</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=blW>Blume Olof</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ziemelis Didzis</td><td class=bc>-</td><td class=blW>Matysek Jakub</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>�sterman Hans</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Hagerup Frode</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Miettinen Petrus</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Umanskyy Anton</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Suominen Benjamin</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Matysek Jakub</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>�sterman Hans</td><td class=bc>-</td><td class=blW>Baumanis Toms</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=blW>Hagerup Frode</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>Blume Olof</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ziemelis Didzis</td><td class=bc>-</td><td class=bl>Miettinen Petrus</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>Klippen Vegard</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Cernoch Miroslav</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Saveljeva Maria</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Saveljeva Maria</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Fagerberg Gustaf</td><td class=bc>-</td><td class=bl>Matysek Jakub</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Baumanis Toms</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Hagerup Frode</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Blume Olof</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Miettinen Petrus</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Cernoch Miroslav</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ziemelis Didzis</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>�sterman Hans</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ziemelis Didzis</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>�sterman Hans</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=blW>Matysek Jakub</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Baumanis Toms</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Hagerup Frode</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Saveljeva Maria</td><td class=bc>-</td><td class=blW>Blume Olof</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Miettinen Petrus</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Cernoch Miroslav</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Spivakovskyy Mykhaylo</td><td class=bc>-</td><td class=blW>Suominen Benjamin</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Caics Edgars</td><td class=bc>-</td><td class=blW>Blume Olof</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=bl>Baumanis Toms</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Miettinen Petrus</td><td class=bc>-</td><td class=blW>Suominen Benjamin</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Hagerup Frode</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Matysek Jakub</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ziemelis Didzis</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=blW>Saveljeva Maria</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Spivakovskyy Mykhaylo</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Matysek Jakub</td><td class=bc>-</td><td class=bl>Baumanis Toms</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Umanskyy Anton</td><td class=bc>-</td><td class=blW>Suominen Benjamin</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Miettinen Petrus</td><td class=bc>-</td><td class=blW>Klippen Vegard</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Blume Olof</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ziemelis Didzis</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Spivakovskyy Mykhaylo</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Jalneskog Anton</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Matysek Jakub</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Caics Edgars</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Blume Olof</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Miettinen Petrus</td><td class=bc>-</td><td class=blW>Baumanis Toms</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ziemelis Didzis</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Miettinen Petrus</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Matysek Jakub</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Blume Olof</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Umanskyy Anton</td><td class=bc>-</td><td class=blW>Baumanis Toms</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=blW>Jalneskog Anton</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ziemelis Didzis</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Miettinen Petrus</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Hagerup Frode</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Matysek Jakub</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=bl>Blume Olof</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Baumanis Toms</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Umanskyy Anton</td><td class=bc>-</td><td class=blW>Jalneskog Anton</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Saveljeva Maria</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ziemelis Didzis</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Korabel Oleksii</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Umanskyy Anton</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=blW>Suominen Benjamin</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Miettinen Petrus</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Matysek Jakub</td><td class=bc>-</td><td class=bl>Blume Olof</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Caics Edgars</td><td class=bc>-</td><td class=bl>Baumanis Toms</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Spivakovskyy Mykhaylo</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>�sterman Hans</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Ziemelis Didzis</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=blW>Klippen Vegard</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Miettinen Petrus</td><td class=bc>-</td><td class=bl>Blume Olof</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Baumanis Toms</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Matysek Jakub</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fagerberg Gustaf</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ziemelis Didzis</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Blume Olof</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=blW>Baumanis Toms</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Miettinen Petrus</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Matysek Jakub</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Rieksti�� Kristaps</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kaln�vics J�nis</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Fagerberg Gustaf</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Axelsen Bjarne</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ziemelis Didzis</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Korabel Oleksii</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Blume Olof</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>�sterman Hans</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Baumanis Toms</td><td class=bc>-</td><td class=bl>Ziemelis Didzis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Jalneskog Anton</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Kaln�vics J�nis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Miettinen Petrus</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Suominen Benjamin</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Matysek Jakub</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Klippen Vegard</td><td class=bc>-</td><td class=blW>Axelsen Bjarne</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Matysek Jakub</td><td class=bc>-</td><td class=bl>�sterman Hans</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Klippen Vegard</td><td class=bc>-</td><td class=blW>Ziemelis Didzis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Blume Olof</td><td class=bc>-</td><td class=bl>Korabel Oleksii</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Baumanis Toms</td><td class=bc>-</td><td class=bl>Rieksti�� Kristaps</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Jalneskog Anton</td><td class=bc>-</td><td class=blW>Kaln�vics J�nis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Miettinen Petrus</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Suominen Benjamin</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>4 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Matysek Jakub</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Klippen Vegard</td><td class=bc>-</td><td class=bl>Rieksti�� Kristaps</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Blume Olof</td><td class=bc>-</td><td class=bl>Kaln�vics J�nis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Baumanis Toms</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jalneskog Anton</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Matantsev Evgeniy</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Miettinen Petrus</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Suominen Benjamin</td><td class=bc>-</td><td class=bl>Ziemelis Didzis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Miettinen Petrus</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Suominen Benjamin</td><td class=bc>-</td><td class=bl>Rieksti�� Kristaps</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Saveljeva Maria</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Kaln�vics J�nis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Matysek Jakub</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Klippen Vegard</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Blume Olof</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Baumanis Toms</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Jalneskog Anton</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Umanskyy Anton</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Ziemelis Didzis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Korabel Oleksii</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Rieksti�� Kristaps</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Miettinen Petrus</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Suominen Benjamin</td><td class=bc>-</td><td class=bl>Kaln�vics J�nis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Matysek Jakub</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Klippen Vegard</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Blume Olof</td><td class=bc>-</td><td class=blW>Axelsen Bjarne</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Baumanis Toms</td><td class=bc>-</td><td class=bl>Matantsev Evgeniy</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Jalneskog Anton</td><td class=bc>-</td><td class=bl>Ziemelis Didzis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Korabel Oleksii</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Kaln�vics J�nis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Fagerberg Gustaf</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Miettinen Petrus</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Suominen Benjamin</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Matysek Jakub</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>6 : 6</tr></td>
<tr><td class=br>Klippen Vegard</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Caics Edgars</td><td class=bc>-</td><td class=bl>�sterman Hans</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Blume Olof</td><td class=bc>-</td><td class=bl>Ziemelis Didzis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Baumanis Toms</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Jalneskog Anton</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Jalneskog Anton</td><td class=bc>-</td><td class=blW>Fagerberg Gustaf</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=blW>Spivakovskyy Mykhaylo</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Miettinen Petrus</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Suominen Benjamin</td><td class=bc>-</td><td class=bl>Matantsev Evgeniy</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Ziemelis Didzis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Matysek Jakub</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Klippen Vegard</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Caics Edgars</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Blume Olof</td><td class=bc>-</td><td class=bl>Rieksti�� Kristaps</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Saveljeva Maria</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Baumanis Toms</td><td class=bc>-</td><td class=blW>Kaln�vics J�nis</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Baumanis Toms</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Spivakovskyy Mykhaylo</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jalneskog Anton</td><td class=bc>-</td><td class=bl>Axelsen Bjarne</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Matantsev Evgeniy</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=blW>�sterman Hans</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=blW>Ziemelis Didzis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Miettinen Petrus</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Suominen Benjamin</td><td class=bc>-</td><td class=blW>Korabel Oleksii</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Rieksti�� Kristaps</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Matysek Jakub</td><td class=bc>-</td><td class=bl>Saveljeva Maria</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Klippen Vegard</td><td class=bc>-</td><td class=bl>Kaln�vics J�nis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Blume Olof</td><td class=bc>-</td><td class=blW>Fagerberg Gustaf</td><td class=bc>2 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
