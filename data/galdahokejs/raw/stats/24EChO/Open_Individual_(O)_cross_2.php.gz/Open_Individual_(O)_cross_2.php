<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Open Individual (O)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Open_Individual_(O)_list.php">Open Individual (O)</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group Open2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=7&x=-61&p=Ra%20Kalni%C5%86%C5%A1">Ra Kalni��</a></td><td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kW>6:5</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>7:4</td>
<td class=kW>9:3</td>
<td class=kW>3:2</td>
<td class=kW>7:4</td>
<td class=kW>4:3</td>
<td class=kW>8:3</td>
<td class=kW>4:1</td>
<td class=kW>10:1</td>
<td class=br>69:31</td><td class=br>+38</td>
<td class=bc>12 - 0 - 0</td>
<td class=br><strong>24</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=116&x=-61&p=Ar%20Matantsev">Ar Matantsev</a></td><td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=br>42:22</td><td class=br>+20</td>
<td class=bc>10 - 0 - 2</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=229&x=-61&p=Un%20%C3%96sterman">Un �sterman</a></td><td class=kL>5:6</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>10:3</td>
<td class=kW>5:1</td>
<td class=kW>6:5</td>
<td class=br>46:31</td><td class=br>+15</td>
<td class=bc>7 - 3 - 2</td>
<td class=br><strong>17</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=113&x=-61&p=Ha%20Ivantsova">Ha Ivantsova</a></td><td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>7:4</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=br>35:27</td><td class=br>+8</td>
<td class=bc>5 - 4 - 3</td>
<td class=br><strong>14</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=111&x=-61&p=Em%20Larsson">Em Larsson</a></td><td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>7:2</td>
<td class=kW>4:0</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>8:2</td>
<td class=kW>5:2</td>
<td class=br>37:24</td><td class=br>+13</td>
<td class=bc>6 - 2 - 4</td>
<td class=br><strong>14</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=65&x=-61&p=Ig%20Saveljev">Ig Saveljev</a></td><td class=kL>4:7</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=kW>8:0</td>
<td class=br>39:33</td><td class=br>+6</td>
<td class=bc>4 - 4 - 4</td>
<td class=br><strong>12</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=235&x=-61&p=An%20Fjermestad">An Fjermestad</a></td><td class=kL>3:9</td>
<td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kT>3:3</td>
<td class=kL>2:7</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kT>5:5</td>
<td class=br>36:43</td><td class=br>-7</td>
<td class=bc>4 - 4 - 4</td>
<td class=br><strong>12</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=118&x=-61&p=Da%20Landa">Da Landa</a></td><td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>4:7</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=br>31:37</td><td class=br>-6</td>
<td class=bc>4 - 2 - 6</td>
<td class=br><strong>10</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=392&x=-61&p=La%20Mets%C3%A4l%C3%A4">La Mets�l�</a></td><td class=kL>4:7</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>3:8</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=br>30:38</td><td class=br>-8</td>
<td class=bc>4 - 2 - 6</td>
<td class=br><strong>10</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=5&x=-61&p=Re%20Vazoli%C5%86%C5%A1">Re Vazoli��</a></td><td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>8:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=br>31:34</td><td class=br>-3</td>
<td class=bc>3 - 3 - 6</td>
<td class=br><strong>9</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=162&x=-61&p=Gi%20Remeika">Gi Remeika</a></td><td class=kL>3:8</td>
<td class=kL>1:4</td>
<td class=kL>3:10</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=br>24:50</td><td class=br>-26</td>
<td class=bc>2 - 2 - 8</td>
<td class=br><strong>6</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=125&x=-61&p=Si%20Thomas">Si Thomas</a></td><td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kL>2:8</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=br>22:45</td><td class=br>-23</td>
<td class=bc>1 - 2 - 9</td>
<td class=br><strong>4</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt><a href="stats.php?idpl=426&x=-61&p=Wi%20Wallin">Wi Wallin</a></td><td class=kL>1:10</td>
<td class=kL>2:5</td>
<td class=kL>5:6</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>0:8</td>
<td class=kT>5:5</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=br>26:53</td><td class=br>-27</td>
<td class=bc>0 - 4 - 8</td>
<td class=br><strong>4</strong></td><td class=d>13.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Mets�l� Lari</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=bl>Landa Daniil</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=bl>�sterman Uno</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Mets�l� Lari</td><td class=bc>-</td><td class=blW>Landa Daniil</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=blW>�sterman Uno</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>8 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=blW>Ivantsova Hanna</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Mets�l� Lari</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=bl>�sterman Uno</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Landa Daniil</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mets�l� Lari</td><td class=bc>-</td><td class=blW>�sterman Uno</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>4 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>�sterman Uno</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Landa Daniil</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mets�l� Lari</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>8 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>�sterman Uno</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mets�l� Lari</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>�sterman Uno</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>10 : 3</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mets�l� Lari</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>�sterman Uno</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Matantsev Artem</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=blW>Fjermestad Andreas</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>�sterman Uno</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>Saveljev Igor</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>Fjermestad Andreas</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Mets�l� Lari</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Saveljev Igor</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>�sterman Uno</td><td class=bc>-</td><td class=bl>Fjermestad Andreas</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Mets�l� Lari</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>Landa Daniil</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Fjermestad Andreas</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Mets�l� Lari</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>�sterman Uno</td><td class=bc>-</td><td class=bl>Landa Daniil</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=bl>Fjermestad Andreas</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Mets�l� Lari</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Landa Daniil</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Ivantsova Hanna</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>�sterman Uno</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=bl>Fjermestad Andreas</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Mets�l� Lari</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=bl>Landa Daniil</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>4 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
