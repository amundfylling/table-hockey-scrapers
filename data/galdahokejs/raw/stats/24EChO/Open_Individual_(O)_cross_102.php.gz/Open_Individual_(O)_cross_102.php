<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Open Individual (O)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Open_Individual_(O)_list.php">Open Individual (O)</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group OpenA2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>31</td>
<td class=ic>32</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=7&x=-61&p=Ra%20Kalni%C5%86%C5%A1">Ra Kalni��</a></td><td class=kx>*</td>
<td class=kW>9:1</td>
<td class=kT>2:2</td>
<td class=kW>6:4 K</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>6:5 K</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>8:1</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=kW>9:3 K</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1 K</td>
<td class=kW>6:3</td>
<td class=kW>2:0 K</td>
<td class=kW>7:4 K</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=kW>8:0</td>
<td class=kW>3:2 K</td>
<td class=kW>5:3</td>
<td class=br>152:55</td><td class=br>+97</td>
<td class=bc>28 - 3 - 0</td>
<td class=br><strong>59</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=105&x=-61&p=Pa%20Petr">Pa Petr</a></td><td class=kL>1:9</td>
<td class=kx>*</td>
<td class=kL>0:6</td>
<td class=kT>5:5</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>6:5 K</td>
<td class=kW>7:2</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kW>7:4 K</td>
<td class=kT>3:3</td>
<td class=kW>6:1 K</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kW>5:4 K</td>
<td class=kW>7:0</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>5:2 K</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0 K</td>
<td class=kW>5:0 K</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=br>138:72</td><td class=br>+66</td>
<td class=bc>25 - 2 - 4</td>
<td class=br><strong>52</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=269&x=-61&p=Ke%20Eriksson">Ke Eriksson</a></td><td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1 K</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>5:2 K</td>
<td class=kW>5:2</td>
<td class=kW>4:2 K</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>2:1 K</td>
<td class=kW>7:4 K</td>
<td class=kW>3:2</td>
<td class=kW>4:1 K</td>
<td class=kL>1:4</td>
<td class=kW>8:4</td>
<td class=kW>7:4</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>9:1 K</td>
<td class=kL>0:2</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=br>125:60</td><td class=br>+65</td>
<td class=bc>22 - 4 - 5</td>
<td class=br><strong>48</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=116&x=-61&p=Ar%20Matantsev">Ar Matantsev</a></td><td class=kL>4:6 K</td>
<td class=kT>5:5</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>4:0 K</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kL>2:6</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>4:2 K</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>4:1 K</td>
<td class=kW>5:2</td>
<td class=kW>3:2 K</td>
<td class=kW>4:3 K</td>
<td class=kW>5:4</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>2:1 K</td>
<td class=kW>5:0</td>
<td class=br>107:67</td><td class=br>+40</td>
<td class=bc>19 - 4 - 8</td>
<td class=br><strong>42</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=104&x=-61&p=Ed%20Nilsson">Ed Nilsson</a></td><td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:4 K</td>
<td class=kL>2:4</td>
<td class=kL>1:4 K</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0 K</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kW>4:2 K</td>
<td class=kW>2:0 K</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>8:3</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1 K</td>
<td class=kT>4:4</td>
<td class=kW>5:1 K</td>
<td class=br>97:68</td><td class=br>+29</td>
<td class=bc>19 - 3 - 9</td>
<td class=br><strong>41</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=29&x=-61&p=Kr%20Lagzdi%C5%86a">Kr Lagzdi�a</a></td><td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>1:3 K</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kT>1:1 K</td>
<td class=kW>3:1</td>
<td class=kW>4:3 K</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=kL>3:7</td>
<td class=kW>5:1 K</td>
<td class=kT>3:3 K</td>
<td class=kL>3:4</td>
<td class=kW>6:2 K</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>3:2 K</td>
<td class=kW>7:2</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=br>97:71</td><td class=br>+26</td>
<td class=bc>17 - 5 - 9</td>
<td class=br><strong>39</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=229&x=-61&p=Un%20%C3%96sterman">Un �sterman</a></td><td class=kL>5:6 K</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>0:4 K</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=kW>5:4 K</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kT>1:1 K</td>
<td class=kL>2:3</td>
<td class=kW>2:1 K</td>
<td class=kT>2:2 K</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>8:1</td>
<td class=kT>1:1</td>
<td class=kW>5:1 K</td>
<td class=kW>3:0</td>
<td class=br>100:75</td><td class=br>+25</td>
<td class=bc>16 - 6 - 9</td>
<td class=br><strong>38</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=381&x=-61&p=Ma%20Klippen">Ma Klippen</a></td><td class=kL>1:2</td>
<td class=kL>5:6 K</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kL>1:3 K</td>
<td class=kW>3:1</td>
<td class=kL>3:4 K</td>
<td class=kL>0:5</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>3:2 K</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kL>3:4 K</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kL>0:3 K</td>
<td class=kW>6:3 K</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=br>83:73</td><td class=br>+10</td>
<td class=bc>16 - 3 - 12</td>
<td class=br><strong>35</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=123&x=-61&p=Lu%20Jurka">Lu Jurka</a></td><td class=kL>1:6</td>
<td class=kL>2:7</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>4:1 K</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2 K</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kL>0:4 K</td>
<td class=kL>1:6</td>
<td class=kW>7:2</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>3:2 K</td>
<td class=kL>1:2 K</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>7:0</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kT>0:0 K</td>
<td class=kW>4:1</td>
<td class=kW>5:0 K</td>
<td class=br>88:74</td><td class=br>+14</td>
<td class=bc>15 - 5 - 11</td>
<td class=br><strong>35</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=44&x=-61&p=Kr%20Naglis">Kr Naglis</a></td><td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>2:5 K</td>
<td class=kL>0:6</td>
<td class=kW>4:2</td>
<td class=kT>1:1 K</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>1:6 K</td>
<td class=kL>1:6</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kT>3:3 K</td>
<td class=kL>3:5 K</td>
<td class=kL>3:5</td>
<td class=kW>3:1 K</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1 K</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>6:0</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=br>92:85</td><td class=br>+7</td>
<td class=bc>14 - 7 - 10</td>
<td class=br><strong>35</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=419&x=-61&p=Pe%20%C3%96stlund">Pe �stlund</a></td><td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kW>6:2</td>
<td class=kW>4:1 K</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3 K</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kW>4:2 K</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kT>1:1 K</td>
<td class=kW>4:1 K</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kL>1:4 K</td>
<td class=kW>5:1</td>
<td class=kW>4:1 K</td>
<td class=br>89:70</td><td class=br>+19</td>
<td class=bc>17 - 1 - 13</td>
<td class=br><strong>35</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=40&x=-61&p=Al%20Sili%C5%86%C5%A1">Al Sili��</a></td><td class=kL>1:8</td>
<td class=kL>3:7</td>
<td class=kL>2:4 K</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>3:4 K</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kW>6:1 K</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3 K</td>
<td class=kL>1:2 K</td>
<td class=kW>4:2</td>
<td class=kW>5:1 K</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kW>6:0</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kT>3:3 K</td>
<td class=kL>3:6</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=br>96:85</td><td class=br>+11</td>
<td class=bc>15 - 4 - 12</td>
<td class=br><strong>34</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt><a href="stats.php?idpl=43&x=-61&p=Ed%20Naglis">Ed Naglis</a></td><td class=kL>2:4</td>
<td class=kL>4:7 K</td>
<td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>3:1 K</td>
<td class=kL>0:2</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>3:4 K</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kT>5:5</td>
<td class=kW>6:4</td>
<td class=kT>2:2 K</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>4:5 K</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kW>4:3 K</td>
<td class=kW>4:2 K</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>6:1</td>
<td class=br>103:94</td><td class=br>+9</td>
<td class=bc>14 - 4 - 13</td>
<td class=br><strong>32</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt><a href="stats.php?idpl=108&x=-61&p=Ma%20Madera">Ma Madera</a></td><td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>0:3 K</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>4:0 K</td>
<td class=kL>1:4</td>
<td class=kL>2:4 K</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>6:0</td>
<td class=kL>1:6</td>
<td class=kW>5:2 K</td>
<td class=kW>4:2 K</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>7:1 K</td>
<td class=kW>7:0</td>
<td class=kW>4:1 K</td>
<td class=br>88:83</td><td class=br>+5</td>
<td class=bc>12 - 8 - 11</td>
<td class=br><strong>32</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt><a href="stats.php?idpl=42&x=-61&p=Em%20Liepi%C5%86%C5%A1">Em Liepi��</a></td><td class=kL>1:5</td>
<td class=kL>1:6 K</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>7:3</td>
<td class=kL>2:5</td>
<td class=kW>4:3 K</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>4:3 K</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kL>1:5 K</td>
<td class=kW>2:1</td>
<td class=kT>5:5</td>
<td class=kL>4:5</td>
<td class=kL>3:4 K</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kW>5:1 K</td>
<td class=kW>8:4 K</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=br>104:100</td><td class=br>+4</td>
<td class=bc>13 - 5 - 13</td>
<td class=br><strong>31</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt><a href="stats.php?idpl=186&x=-61&p=R%C5%AB%20Kamzols">R� Kamzols</a></td><td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:2 K</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>1:5 K</td>
<td class=kL>2:6</td>
<td class=kW>5:0</td>
<td class=kL>2:7</td>
<td class=kT>3:3 K</td>
<td class=kW>4:3</td>
<td class=kT>3:3 K</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>5:1 K</td>
<td class=kW>4:0</td>
<td class=kW>5:3 K</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>4:9</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kW>6:3</td>
<td class=kT>3:3 K</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=br>89:95</td><td class=br>-6</td>
<td class=bc>13 - 5 - 13</td>
<td class=br><strong>31</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="stats.php?idpl=382&x=-61&p=Oy%20Klippen">Oy Klippen</a></td><td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kL>4:7 K</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3 K</td>
<td class=kL>3:6</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kW>5:3 K</td>
<td class=kL>1:6</td>
<td class=kW>2:1 K</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kL>1:5 K</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kT>5:5 K</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>7:0</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>1:0 K</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kT>5:5</td>
<td class=kW>5:0</td>
<td class=br>93:100</td><td class=br>-7</td>
<td class=bc>11 - 8 - 12</td>
<td class=br><strong>30</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt><a href="stats.php?idpl=235&x=-61&p=An%20Fjermestad">An Fjermestad</a></td><td class=kL>3:9 K</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>2:4 K</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>4:5 K</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kT>5:5</td>
<td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>2:7 K</td>
<td class=kW>4:1</td>
<td class=kT>3:3 K</td>
<td class=kT>1:1 K</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2 K</td>
<td class=kW>3:0</td>
<td class=br>86:96</td><td class=br>-10</td>
<td class=bc>12 - 5 - 14</td>
<td class=br><strong>29</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt><a href="stats.php?idpl=420&x=-61&p=He%20Steen">He Steen</a></td><td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>1:4 K</td>
<td class=kL>0:3</td>
<td class=kW>5:1</td>
<td class=kL>2:6 K</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3 K</td>
<td class=kW>3:0</td>
<td class=kL>1:5 K</td>
<td class=kL>4:6</td>
<td class=kL>0:6</td>
<td class=kW>3:2</td>
<td class=kL>3:5 K</td>
<td class=kT>5:5 K</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>1:5 K</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=br>78:91</td><td class=br>-13</td>
<td class=bc>12 - 4 - 15</td>
<td class=br><strong>28</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt><a href="stats.php?idpl=430&x=-61&p=Ni%20Blomberg">Ni Blomberg</a></td><td class=kL>2:4</td>
<td class=kL>4:5 K</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kT>4:4</td>
<td class=kL>2:3 K</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kT>2:2 K</td>
<td class=kW>6:1</td>
<td class=kW>5:1 K</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>6:1 K</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>3:1 K</td>
<td class=kL>2:3 K</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kW>2:0</td>
<td class=br>81:75</td><td class=br>+6</td>
<td class=bc>10 - 8 - 13</td>
<td class=br><strong>28</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt><a href="stats.php?idpl=114&x=-61&p=An%20Bo%C5%BEi%C4%8D">An Bo�i�</a></td><td class=kL>2:3</td>
<td class=kL>0:7</td>
<td class=kL>4:8</td>
<td class=kW>3:2</td>
<td class=kL>2:4 K</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kL>2:5</td>
<td class=kL>2:3 K</td>
<td class=kL>2:5</td>
<td class=kT>1:1 K</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5 K</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>4:2 K</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1 K</td>
<td class=kW>4:2</td>
<td class=kL>3:4 K</td>
<td class=br>76:88</td><td class=br>-12</td>
<td class=bc>12 - 4 - 15</td>
<td class=br><strong>28</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt><a href="stats.php?idpl=32&x=-61&p=Sa%20Skarainis">Sa Skarainis</a></td><td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>4:7</td>
<td class=kL>2:6</td>
<td class=kL>0:2 K</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kW>2:1 K</td>
<td class=kL>3:4</td>
<td class=kL>1:4 K</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kL>2:4 K</td>
<td class=kT>5:5</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>2:4 K</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kL>1:2 K</td>
<td class=kW>2:1</td>
<td class=kT>2:2 K</td>
<td class=br>71:92</td><td class=br>-21</td>
<td class=bc>11 - 5 - 15</td>
<td class=br><strong>27</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt><a href="stats.php?idpl=111&x=-61&p=Em%20Larsson">Em Larsson</a></td><td class=kL>1:3 K</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>1:4 K</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>5:4</td>
<td class=kW>9:4</td>
<td class=kL>0:7</td>
<td class=kW>7:2 K</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>1:4 K</td>
<td class=kT>2:2 K</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>4:0 K</td>
<td class=kW>5:0</td>
<td class=br>80:101</td><td class=br>-21</td>
<td class=bc>10 - 6 - 15</td>
<td class=br><strong>26</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt><a href="stats.php?idpl=151&x=-61&p=Kr%20Lebl">Kr Lebl</a></td><td class=kL>3:6</td>
<td class=kL>2:5 K</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>4:3 K</td>
<td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kW>5:4 K</td>
<td class=kT>2:2</td>
<td class=kW>4:3 K</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kL>1:6 K</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kL>1:6</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kT>4:4 K</td>
<td class=kT>2:2 K</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=br>75:111</td><td class=br>-36</td>
<td class=bc>10 - 5 - 16</td>
<td class=br><strong>25</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt><a href="stats.php?idpl=113&x=-61&p=Ha%20Ivantsova">Ha Ivantsova</a></td><td class=kL>0:2 K</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kL>2:3 K</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kL>1:2 K</td>
<td class=kL>1:2</td>
<td class=kL>0:7</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kT>4:4</td>
<td class=kT>3:3 K</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>4:1 K</td>
<td class=kW>6:1</td>
<td class=kx>*</td>
<td class=kW>3:1 K</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kL>1:4</td>
<td class=kW>7:4 K</td>
<td class=kW>7:2</td>
<td class=br>75:77</td><td class=br>-2</td>
<td class=bc>10 - 4 - 17</td>
<td class=br><strong>24</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt><a href="stats.php?idpl=65&x=-61&p=Ig%20Saveljev">Ig Saveljev</a></td><td class=kL>4:7 K</td>
<td class=kL>0:6</td>
<td class=kW>3:2</td>
<td class=kL>3:4 K</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2 K</td>
<td class=kW>1:0</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kT>1:1 K</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kT>2:2 K</td>
<td class=kL>1:2</td>
<td class=kL>1:3 K</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kT>3:3 K</td>
<td class=kW>3:1</td>
<td class=br>55:71</td><td class=br>-16</td>
<td class=bc>8 - 8 - 15</td>
<td class=br><strong>24</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt><a href="stats.php?idpl=379&x=-61&p=Da%20Nyg%C3%A5rd">Da Nyg�rd</a></td><td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:9 K</td>
<td class=kL>4:5</td>
<td class=kL>3:8</td>
<td class=kL>2:3 K</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>1:4 K</td>
<td class=kL>0:1</td>
<td class=kT>3:3 K</td>
<td class=kL>4:5</td>
<td class=kT>3:3</td>
<td class=kL>0:6</td>
<td class=kT>3:3 K</td>
<td class=kL>0:1 K</td>
<td class=kT>3:3</td>
<td class=kW>5:1 K</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>5:5</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kT>0:0</td>
<td class=br>73:104</td><td class=br>-31</td>
<td class=bc>6 - 9 - 16</td>
<td class=br><strong>21</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt><a href="stats.php?idpl=115&x=-61&p=My%20Shalomayev">My Shalomayev</a></td><td class=kL>2:5</td>
<td class=kL>0:4 K</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kL>3:6</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kW>3:0 K</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kW>6:3</td>
<td class=kL>3:4 K</td>
<td class=kW>3:2</td>
<td class=kL>1:5 K</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>1:3 K</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>4:4 K</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:1 K</td>
<td class=kW>1:0</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=br>69:96</td><td class=br>-27</td>
<td class=bc>8 - 4 - 19</td>
<td class=br><strong>20</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt><a href="stats.php?idpl=124&x=-61&p=Ne%20Skrlep">Ne Skrlep</a></td><td class=kL>2:7</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kL>1:8</td>
<td class=kL>3:6 K</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>2:4 K</td>
<td class=kL>1:3</td>
<td class=kL>4:8 K</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kW>3:2 K</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2 K</td>
<td class=kL>1:6</td>
<td class=kW>4:2</td>
<td class=kT>5:5</td>
<td class=kL>1:5 K</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=br>67:128</td><td class=br>-61</td>
<td class=bc>8 - 4 - 19</td>
<td class=br><strong>20</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt><a href="stats.php?idpl=67&x=-61&p=Ti%20Mihhaljov">Ti Mihhaljov</a></td><td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>1:3 K</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kT>0:0 K</td>
<td class=kL>0:6</td>
<td class=kW>4:1 K</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:7 K</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>1:3 K</td>
<td class=kW>2:1 K</td>
<td class=kW>3:0</td>
<td class=kL>0:5</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>0:2 K</td>
<td class=br>53:93</td><td class=br>-40</td>
<td class=bc>7 - 4 - 20</td>
<td class=br><strong>18</strong></td><td class=d>30.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>31.</td><td class=kt><a href="stats.php?idpl=118&x=-61&p=Da%20Landa">Da Landa</a></td><td class=kL>2:3 K</td>
<td class=kL>2:7</td>
<td class=kL>0:7</td>
<td class=kL>1:2 K</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kL>1:5 K</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kL>0:7</td>
<td class=kL>4:5</td>
<td class=kL>2:5</td>
<td class=kT>5:5</td>
<td class=kL>2:4 K</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>0:4 K</td>
<td class=kL>2:4</td>
<td class=kL>4:7 K</td>
<td class=kT>3:3 K</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>75:122</td><td class=br>-47</td>
<td class=bc>5 - 8 - 18</td>
<td class=br><strong>18</strong></td><td class=d>31.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>32.</td><td class=kt><a href="stats.php?idpl=122&x=-61&p=Vi%20Henttonen">Vi Henttonen</a></td><td class=kL>3:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:5 K</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5</td>
<td class=kL>1:4 K</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>1:4 K</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kW>4:3 K</td>
<td class=kT>2:2 K</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>2:0 K</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>31:114</td><td class=br>-83</td>
<td class=bc>2 - 3 - 26</td>
<td class=br><strong>7</strong></td><td class=d>32.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Steen Herman</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Nyg�rd Daniel</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Blomberg Niklas</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>�sterman Uno</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Lebl Kry�tof</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Klippen Oystein</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Klippen Magnus</td><td class=bc>-</td><td class=bl>Jurka Lukass</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>�stlund Peter</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=blW>Eriksson Kevin</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Skrlep Nejc</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=bl>Nyg�rd Daniel</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Skrlep Nejc</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Blomberg Niklas</td><td class=bc>-</td><td class=blW>Mihhaljov Timur</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>�sterman Uno</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Klippen Oystein</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Lebl Kry�tof</td><td class=bc>-</td><td class=bl>Jurka Lukass</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Eriksson Kevin</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Klippen Magnus</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=blW>Steen Herman</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Skrlep Nejc</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=bl>Klippen Oystein</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Blomberg Niklas</td><td class=bc>-</td><td class=bl>Jurka Lukass</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>�sterman Uno</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Eriksson Kevin</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Lebl Kry�tof</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Steen Herman</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Nyg�rd Daniel</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Klippen Magnus</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Klippen Magnus</td><td class=bc>-</td><td class=blW>Mihhaljov Timur</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=bl>Klippen Oystein</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Skrlep Nejc</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=blW>Eriksson Kevin</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Blomberg Niklas</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>�sterman Uno</td><td class=bc>-</td><td class=bl>Steen Herman</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Nyg�rd Daniel</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Lebl Kry�tof</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>9 : 4</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Klippen Magnus</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Klippen Oystein</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Jurka Lukass</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Skrlep Nejc</td><td class=bc>-</td><td class=blW>�stlund Peter</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Eriksson Kevin</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Steen Herman</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Blomberg Niklas</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>�sterman Uno</td><td class=bc>-</td><td class=bl>Nyg�rd Daniel</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Lebl Kry�tof</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Klippen Magnus</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Klippen Oystein</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Skrlep Nejc</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=blW>Eriksson Kevin</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Jurka Lukass</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=bl>Steen Herman</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Blomberg Niklas</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Nyg�rd Daniel</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Lebl Kry�tof</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>�sterman Uno</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>�sterman Uno</td><td class=bc>-</td><td class=bl>Klippen Oystein</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Lebl Kry�tof</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Eriksson Kevin</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Steen Herman</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Klippen Magnus</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Nyg�rd Daniel</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Landa Daniil</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Skrlep Nejc</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Blomberg Niklas</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Blomberg Niklas</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>�sterman Uno</td><td class=bc>-</td><td class=blW>Eriksson Kevin</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Jurka Lukass</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Steen Herman</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Lebl Kry�tof</td><td class=bc>-</td><td class=blW>�stlund Peter</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Nyg�rd Daniel</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Klippen Magnus</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Skrlep Nejc</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Klippen Oystein</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Klippen Oystein</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>�sterman Uno</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Klippen Magnus</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Landa Daniil</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Eriksson Kevin</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Klippen Oystein</td><td class=bc>-</td><td class=blW>Mihhaljov Timur</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>�sterman Uno</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Klippen Magnus</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Skrlep Nejc</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Klippen Oystein</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>�stlund Peter</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=blW>Lebl Kry�tof</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Klippen Magnus</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>�sterman Uno</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Nyg�rd Daniel</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Klippen Oystein</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>�stlund Peter</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Lebl Kry�tof</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=blW>Klippen Magnus</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=blW>Skrlep Nejc</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�sterman Uno</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Klippen Oystein</td><td class=bc>-</td><td class=blW>�stlund Peter</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Fjermestad Andreas</td><td class=bc>-</td><td class=blW>Klippen Magnus</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Landa Daniil</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>�sterman Uno</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Steen Herman</td><td class=bc>-</td><td class=blW>Madera Martin</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Jurka Lukass</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Klippen Oystein</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=bl>Klippen Magnus</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Saveljev Igor</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>�sterman Uno</td><td class=bc>-</td><td class=blW>Lebl Kry�tof</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Klippen Oystein</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Bo�i� An�e</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=blW>�stlund Peter</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Steen Herman</td><td class=bc>-</td><td class=blW>Jurka Lukass</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>�sterman Uno</td><td class=bc>-</td><td class=bl>Klippen Magnus</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ivantsova Hanna</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Skrlep Nejc</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Landa Daniil</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Madera Martin</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>�stlund Peter</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Jurka Lukass</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Bo�i� An�e</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Klippen Oystein</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ivantsova Hanna</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Saveljev Igor</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Fjermestad Andreas</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Landa Daniil</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Klippen Magnus</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>�sterman Uno</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=bl>Kalni�� Rainers</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Matantsev Artem</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Klippen Oystein</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=blW>�sterman Uno</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mihhaljov Timur</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Klippen Magnus</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Saveljev Igor</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Nyg�rd Daniel</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Fjermestad Andreas</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Steen Herman</td><td class=bc>-</td><td class=blW>Skrlep Nejc</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Landa Daniil</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Steen Herman</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Madera Martin</td><td class=bc>-</td><td class=bl>�sterman Uno</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Klippen Oystein</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Klippen Magnus</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mihhaljov Timur</td><td class=bc>-</td><td class=blW>Fjermestad Andreas</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Landa Daniil</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>�sterman Uno</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Klippen Magnus</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Klippen Oystein</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=blW>Fjermestad Andreas</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Landa Daniil</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mihhaljov Timur</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Ivantsova Hanna</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Steen Herman</td><td class=bc>-</td><td class=blW>Klippen Magnus</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Saveljev Igor</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Eriksson Kevin</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=bl>Fjermestad Andreas</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Landa Daniil</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Klippen Oystein</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mihhaljov Timur</td><td class=bc>-</td><td class=bl>�sterman Uno</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Lebl Kry�tof</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mihhaljov Timur</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=blW>Klippen Magnus</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Steen Herman</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Fjermestad Andreas</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Madera Martin</td><td class=bc>-</td><td class=bl>Landa Daniil</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>�stlund Peter</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Klippen Oystein</td><td class=bc>-</td><td class=blW>Blomberg Niklas</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jurka Lukass</td><td class=bc>-</td><td class=bl>Matantsev Artem</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=blW>�sterman Uno</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Klippen Magnus</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mihhaljov Timur</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Fjermestad Andreas</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Landa Daniil</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Eriksson Kevin</td><td class=bc>-</td><td class=blW>Blomberg Niklas</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=bl>Matantsev Artem</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>�stlund Peter</td><td class=bc>-</td><td class=blW>�sterman Uno</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Klippen Oystein</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Jurka Lukass</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Klippen Oystein</td><td class=bc>-</td><td class=blW>Klippen Magnus</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Jurka Lukass</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Fjermestad Andreas</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Skrlep Nejc</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mihhaljov Timur</td><td class=bc>-</td><td class=bl>Landa Daniil</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Nyg�rd Daniel</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Matantsev Artem</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>�sterman Uno</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>�stlund Peter</td><td class=bc>-</td><td class=bl>Fjermestad Andreas</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Klippen Oystein</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Jurka Lukass</td><td class=bc>-</td><td class=bl>Landa Daniil</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Kalni�� Rainers</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mihhaljov Timur</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>�sterman Uno</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Bo�i� An�e</td><td class=bc>-</td><td class=bl>Ivantsova Hanna</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Steen Herman</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Klippen Magnus</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Madera Martin</td><td class=bc>-</td><td class=bl>Saveljev Igor</td><td class=bc>1 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
