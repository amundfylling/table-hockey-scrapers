<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Open Individual (O)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Open_Individual_(O)_list.php">Open Individual (O)</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group Open6</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=105&x=-61&p=Pa%20Petr">Pa Petr</a></td><td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>7:4</td>
<td class=kW>6:5</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>8:1</td>
<td class=kW>5:0 K</td>
<td class=br>71:24</td><td class=br>+47</td>
<td class=bc>13 - 0 - 0</td>
<td class=br><strong>26</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=430&x=-61&p=Ni%20Blomberg">Ni Blomberg</a></td><td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>8:3</td>
<td class=kW>7:3</td>
<td class=kW>5:2</td>
<td class=kW>5:0 K</td>
<td class=br>55:26</td><td class=br>+29</td>
<td class=bc>8 - 2 - 3</td>
<td class=br><strong>18</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=42&x=-61&p=Em%20Liepi%C5%86%C5%A1">Em Liepi��</a></td><td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>8:4</td>
<td class=kW>4:0</td>
<td class=kL>3:4</td>
<td class=kW>7:4</td>
<td class=kW>7:0</td>
<td class=kW>8:0</td>
<td class=kW>5:0 K</td>
<td class=br>60:34</td><td class=br>+26</td>
<td class=bc>9 - 0 - 4</td>
<td class=br><strong>18</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=151&x=-61&p=Kr%20Lebl">Kr Lebl</a></td><td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>8:1</td>
<td class=kW>5:0 K</td>
<td class=br>45:38</td><td class=br>+7</td>
<td class=bc>7 - 3 - 3</td>
<td class=br><strong>17</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=43&x=-61&p=Ed%20Naglis">Ed Naglis</a></td><td class=kL>4:7</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kL>1:5</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>5:0 K</td>
<td class=br>49:35</td><td class=br>+14</td>
<td class=bc>7 - 2 - 4</td>
<td class=br><strong>16</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=381&x=-61&p=Ma%20Klippen">Ma Klippen</a></td><td class=kL>5:6</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>5:0 K</td>
<td class=br>48:30</td><td class=br>+18</td>
<td class=bc>8 - 0 - 5</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=115&x=-61&p=My%20Shalomayev">My Shalomayev</a></td><td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>9:0</td>
<td class=kW>5:0 K</td>
<td class=br>38:26</td><td class=br>+12</td>
<td class=bc>6 - 3 - 4</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=124&x=-61&p=Ne%20Skrlep">Ne Skrlep</a></td><td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kL>4:8</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>5:4</td>
<td class=kW>8:0</td>
<td class=kW>6:1</td>
<td class=kW>5:0 K</td>
<td class=br>44:41</td><td class=br>+3</td>
<td class=bc>6 - 2 - 5</td>
<td class=br><strong>14</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=117&x=-61&p=Tr%20M%C3%A5nsson">Tr M�nsson</a></td><td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0 K</td>
<td class=br>30:31</td><td class=br>-1</td>
<td class=bc>5 - 3 - 5</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=241&x=-61&p=Pa%20Plesak">Pa Plesak</a></td><td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>7:4</td>
<td class=kW>10:1</td>
<td class=kW>5:0 K</td>
<td class=br>42:36</td><td class=br>+6</td>
<td class=bc>5 - 2 - 6</td>
<td class=br><strong>12</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=380&x=-61&p=Be%20Nyg%C3%A5rd">Be Nyg�rd</a></td><td class=kL>0:4</td>
<td class=kL>3:8</td>
<td class=kL>4:7</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>5:0 K</td>
<td class=br>33:44</td><td class=br>-11</td>
<td class=bc>3 - 1 - 9</td>
<td class=br><strong>7</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=133&x=-61&p=Au%20Pleikys">Au Pleikys</a></td><td class=kL>3:4</td>
<td class=kL>3:7</td>
<td class=kL>0:7</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>0:8</td>
<td class=kL>0:2</td>
<td class=kL>4:7</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:0 K</td>
<td class=br>29:56</td><td class=br>-27</td>
<td class=bc>3 - 0 - 10</td>
<td class=br><strong>6</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt><a href="stats.php?idpl=152&x=-61&p=To%20Ulis">To Ulis</a></td><td class=kL>1:8</td>
<td class=kL>2:5</td>
<td class=kL>0:8</td>
<td class=kL>1:8</td>
<td class=kL>0:6</td>
<td class=kL>2:7</td>
<td class=kL>0:9</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>1:10</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:0 K</td>
<td class=br>20:78</td><td class=br>-58</td>
<td class=bc>2 - 0 - 11</td>
<td class=br><strong>4</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt><a href="stats.php?idpl=396&x=-61&p=Va%20Hamdamov">Va Hamdamov</a></td><td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kx>*</td>
<td class=br>0:65</td><td class=br>-65</td>
<td class=bc>0 - 0 - 13</td>
<td class=br><strong>0</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Skrlep Nejc</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Klippen Magnus</td><td class=bc>-</td><td class=bl>Nyg�rd Benjamin</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Lebl Kry�tof</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Skrlep Nejc</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Nyg�rd Benjamin</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Klippen Magnus</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Hamdamov Vafa</td><td class=bc>5 : 0 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Blomberg Niklas</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Nyg�rd Benjamin</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Skrlep Nejc</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Klippen Magnus</td><td class=bc>-</td><td class=bl>Hamdamov Vafa</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Blomberg Niklas</td><td class=bc>-</td><td class=bl>Nyg�rd Benjamin</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Skrlep Nejc</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pleikys Audrius</td><td class=bc>-</td><td class=bl>Hamdamov Vafa</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Lebl Kry�tof</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Klippen Magnus</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Blomberg Niklas</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Hamdamov Vafa</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Skrlep Nejc</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Plesak Pavel</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Blomberg Niklas</td><td class=bc>-</td><td class=bl>Hamdamov Vafa</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Lebl Kry�tof</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Skrlep Nejc</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Klippen Magnus</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Plesak Pavel</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Hamdamov Vafa</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Nyg�rd Benjamin</td><td class=bc>-</td><td class=bl>Lebl Kry�tof</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Blomberg Niklas</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Klippen Magnus</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Skrlep Nejc</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Hamdamov Vafa</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Lebl Kry�tof</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Blomberg Niklas</td><td class=bc>-</td><td class=blW>Klippen Magnus</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Hamdamov Vafa</td><td class=bc>-</td><td class=blW>Lebl Kry�tof</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Klippen Magnus</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Blomberg Niklas</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ulis Tomas</td><td class=bc>-</td><td class=blW>Skrlep Nejc</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Lebl Kry�tof</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Hamdamov Vafa</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Klippen Magnus</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Skrlep Nejc</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Blomberg Niklas</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Lebl Kry�tof</td><td class=bc>-</td><td class=bl>Klippen Magnus</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Hamdamov Vafa</td><td class=bc>-</td><td class=blW>M�nsson Truls</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Plesak Pavel</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Ulis Tomas</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Klippen Magnus</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Lebl Kry�tof</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Hamdamov Vafa</td><td class=bc>-</td><td class=blW>Skrlep Nejc</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Blomberg Niklas</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Klippen Magnus</td><td class=bc>-</td><td class=bl>M�nsson Truls</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Lebl Kry�tof</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Hamdamov Vafa</td><td class=bc>-</td><td class=blW>Ulis Tomas</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Blomberg Niklas</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Nyg�rd Benjamin</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>M�nsson Truls</td><td class=bc>-</td><td class=bl>Pleikys Audrius</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Klippen Magnus</td><td class=bc>-</td><td class=bl>Skrlep Nejc</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Lebl Kry�tof</td><td class=bc>-</td><td class=blW>Blomberg Niklas</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Hamdamov Vafa</td><td class=bc>-</td><td class=blW>Nyg�rd Benjamin</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Plesak Pavel</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Pleikys Audrius</td><td class=bc>-</td><td class=blW>Skrlep Nejc</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>M�nsson Truls</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Klippen Magnus</td><td class=bc>-</td><td class=bl>Ulis Tomas</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Blomberg Niklas</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Nyg�rd Benjamin</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Lebl Kry�tof</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Hamdamov Vafa</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>0 : 5 K</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
