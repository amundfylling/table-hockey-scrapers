<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Open Individual (O)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Open_Individual_(O)_list.php">Open Individual (O)</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group Open8</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=423&x=-61&p=Ol%20Blume">Ol Blume</a></td><td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=br>48:17</td><td class=br>+31</td>
<td class=bc>11 - 0 - 2</td>
<td class=br><strong>22</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=83&x=-61&p=To%20Baumanis">To Baumanis</a></td><td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>1:0</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>9:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>6:4</td>
<td class=kW>5:3</td>
<td class=kW>10:2</td>
<td class=br>54:27</td><td class=br>+27</td>
<td class=bc>9 - 2 - 2</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=431&x=-61&p=An%20Jalneskog">An Jalneskog</a></td><td class=kL>0:3</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kL>1:5</td>
<td class=kW>3:0</td>
<td class=kL>0:4</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=br>34:27</td><td class=br>+7</td>
<td class=bc>8 - 2 - 3</td>
<td class=br><strong>18</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=28&x=-61&p=Sa%20Lagzdi%C5%86%C5%A1">Sa Lagzdi��</a></td><td class=kW>2:0</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>2:5</td>
<td class=kW>7:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=br>51:23</td><td class=br>+28</td>
<td class=bc>9 - 0 - 4</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=27&x=-61&p=El%20Sili%C5%86%C5%A1">El Sili��</a></td><td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=br>52:28</td><td class=br>+24</td>
<td class=bc>9 - 0 - 4</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=239&x=-61&p=Be%20Suominen">Be Suominen</a></td><td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>8:0</td>
<td class=kW>5:1</td>
<td class=kL>1:4</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=br>47:31</td><td class=br>+16</td>
<td class=bc>7 - 2 - 4</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=79&x=-61&p=Mi%20Saul%C4%ABtis">Mi Saul�tis</a></td><td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>0:8</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=br>34:39</td><td class=br>-5</td>
<td class=bc>5 - 2 - 6</td>
<td class=br><strong>12</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=383&x=-61&p=Ve%20Klippen">Ve Klippen</a></td><td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=br>37:41</td><td class=br>-4</td>
<td class=bc>5 - 2 - 6</td>
<td class=br><strong>12</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=401&x=-61&p=Ma%20Lezik">Ma Lezik</a></td><td class=kL>1:3</td>
<td class=kL>2:9</td>
<td class=kW>5:1</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kW>4:1</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>9:0</td>
<td class=kW>5:1</td>
<td class=br>38:41</td><td class=br>-3</td>
<td class=bc>6 - 0 - 7</td>
<td class=br><strong>12</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=427&x=-61&p=Ja%20Forsberg">Ja Forsberg</a></td><td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kW>6:0</td>
<td class=br>32:34</td><td class=br>-2</td>
<td class=bc>5 - 1 - 7</td>
<td class=br><strong>11</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=139&x=-61&p=Po%20Kvasnikova">Po Kvasnikova</a></td><td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kW>4:0</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=br>28:35</td><td class=br>-7</td>
<td class=bc>5 - 1 - 7</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=145&x=-61&p=Ma%20Zenisek">Ma Zenisek</a></td><td class=kL>2:3</td>
<td class=kL>4:6</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=br>31:52</td><td class=br>-21</td>
<td class=bc>2 - 2 - 9</td>
<td class=br><strong>6</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt><a href="stats.php?idpl=218&x=-61&p=Dm%20Stykailo">Dm Stykailo</a></td><td class=kL>2:7</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kL>0:9</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=br>24:59</td><td class=br>-35</td>
<td class=bc>1 - 3 - 9</td>
<td class=br><strong>5</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt><a href="stats.php?idpl=364&x=-61&p=Er%20Bernhauser">Er Bernhauser</a></td><td class=kL>0:6</td>
<td class=kL>2:10</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=br>18:74</td><td class=br>-56</td>
<td class=bc>0 - 1 - 12</td>
<td class=br><strong>1</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Lezik Matej</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=bl>Stykailo Dmitri</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Baumanis Toms</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Jalneskog Anton</td><td class=bc>-</td><td class=blW>Blume Olof</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=blW>Lezik Matej</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Suominen Benjamin</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Zenisek Martin</td><td class=bc>-</td><td class=bl>Stykailo Dmitri</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=blW>Blume Olof</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Baumanis Toms</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Lezik Matej</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=bl>Stykailo Dmitri</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Zenisek Martin</td><td class=bc>-</td><td class=blW>Blume Olof</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=blW>Jalneskog Anton</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Lezik Matej</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Stykailo Dmitri</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=blW>Blume Olof</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zenisek Martin</td><td class=bc>-</td><td class=blW>Jalneskog Anton</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Baumanis Toms</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Suominen Benjamin</td><td class=bc>-</td><td class=bl>Stykailo Dmitri</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Lezik Matej</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Blume Olof</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kvasnikova Polina</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Baumanis Toms</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Zenisek Martin</td><td class=bc>-</td><td class=blW>Forsberg James-John</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Suominen Benjamin</td><td class=bc>-</td><td class=bl>Blume Olof</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Lezik Matej</td><td class=bc>-</td><td class=blW>Klippen Vegard</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Jalneskog Anton</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Baumanis Toms</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kvasnikova Polina</td><td class=bc>-</td><td class=blW>Forsberg James-John</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Blume Olof</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=blW>Klippen Vegard</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Suominen Benjamin</td><td class=bc>-</td><td class=bl>Jalneskog Anton</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Lezik Matej</td><td class=bc>-</td><td class=blW>Baumanis Toms</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Forsberg James-John</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kvasnikova Polina</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Blume Olof</td><td class=bc>-</td><td class=bl>Klippen Vegard</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=blW>Jalneskog Anton</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=blW>Baumanis Toms</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Suominen Benjamin</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Lezik Matej</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Klippen Vegard</td><td class=bc>-</td><td class=blW>Jalneskog Anton</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Blume Olof</td><td class=bc>-</td><td class=bl>Baumanis Toms</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=blW>Forsberg James-John</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Suominen Benjamin</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Lezik Matej</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Kvasnikova Polina</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Jalneskog Anton</td><td class=bc>-</td><td class=bl>Baumanis Toms</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Klippen Vegard</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Blume Olof</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Suominen Benjamin</td><td class=bc>-</td><td class=blW>Kvasnikova Polina</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Lezik Matej</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Baumanis Toms</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Jalneskog Anton</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Klippen Vegard</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Blume Olof</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Kvasnikova Polina</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Suominen Benjamin</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Baumanis Toms</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Jalneskog Anton</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Klippen Vegard</td><td class=bc>-</td><td class=bl>Kvasnikova Polina</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Blume Olof</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=blW>Lezik Matej</td><td class=bc>0 : 9</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Zenisek Martin</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Baumanis Toms</td><td class=bc>-</td><td class=bl>Kvasnikova Polina</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Jalneskog Anton</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Klippen Vegard</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Blume Olof</td><td class=bc>-</td><td class=bl>Lezik Matej</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=blW>Suominen Benjamin</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Zenisek Martin</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Kvasnikova Polina</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Baumanis Toms</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>10 : 2</tr></td>
<tr><td class=br>Jalneskog Anton</td><td class=bc>-</td><td class=blW>Lezik Matej</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Klippen Vegard</td><td class=bc>-</td><td class=blW>Suominen Benjamin</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Blume Olof</td><td class=bc>-</td><td class=bl>Stykailo Dmitri</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Kvasnikova Polina</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Zenisek Martin</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=blW>Lezik Matej</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Baumanis Toms</td><td class=bc>-</td><td class=bl>Suominen Benjamin</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Jalneskog Anton</td><td class=bc>-</td><td class=bl>Stykailo Dmitri</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Klippen Vegard</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
