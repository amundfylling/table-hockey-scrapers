<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Open Individual (O)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Open_Individual_(O)_list.php">Open Individual (O)</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group Open4</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=4&x=-61&p=Ed%20Caics">Ed Caics</a></td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=kW>4:1</td>
<td class=kW>8:1</td>
<td class=br>60:17</td><td class=br>+43</td>
<td class=bc>12 - 0 - 1</td>
<td class=br><strong>24</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=92&x=-61&p=Va%20Smagars">Va Smagars</a></td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kW>10:1</td>
<td class=kW>3:2</td>
<td class=kW>8:1</td>
<td class=br>61:27</td><td class=br>+34</td>
<td class=bc>9 - 1 - 3</td>
<td class=br><strong>19</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=103&x=-61&p=Ro%20Rieksti%C5%86%C5%A1">Ro Rieksti��</a></td><td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>8:1</td>
<td class=kW>5:4</td>
<td class=kW>6:1</td>
<td class=br>45:31</td><td class=br>+14</td>
<td class=bc>8 - 2 - 3</td>
<td class=br><strong>18</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=368&x=-61&p=An%20Umanskyy">An Umanskyy</a></td><td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>8:3</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kW>9:1</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>10:0</td>
<td class=br>62:28</td><td class=br>+34</td>
<td class=bc>8 - 1 - 4</td>
<td class=br><strong>17</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=403&x=-61&p=Mi%20Cernoch">Mi Cernoch</a></td><td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>7:1</td>
<td class=br>30:30</td><td class=br>0</td>
<td class=bc>6 - 3 - 4</td>
<td class=br><strong>15</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=390&x=-61&p=Pe%20Miettinen">Pe Miettinen</a></td><td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kL>3:8</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kT>0:0</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>7:0</td>
<td class=kW>9:0</td>
<td class=br>45:29</td><td class=br>+16</td>
<td class=bc>7 - 1 - 5</td>
<td class=br><strong>15</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=384&x=-61&p=Fr%20Hagerup">Fr Hagerup</a></td><td class=kL>0:3</td>
<td class=kL>3:6</td>
<td class=kW>4:1</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kW>6:4</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=br>43:42</td><td class=br>+1</td>
<td class=bc>6 - 2 - 5</td>
<td class=br><strong>14</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=400&x=-61&p=Ja%20Matysek">Ja Matysek</a></td><td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>7:0</td>
<td class=kL>1:6</td>
<td class=kW>4:3</td>
<td class=kW>14:0</td>
<td class=br>45:41</td><td class=br>+4</td>
<td class=bc>6 - 1 - 6</td>
<td class=br><strong>13</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=425&x=-61&p=An%20Kimberg">An Kimberg</a></td><td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>8:0</td>
<td class=br>32:29</td><td class=br>+3</td>
<td class=bc>4 - 4 - 5</td>
<td class=br><strong>12</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=70&x=-61&p=An%20Kuz%C5%86ecovs">An Kuz�ecovs</a></td><td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>1:9</td>
<td class=kW>5:0</td>
<td class=kL>1:4</td>
<td class=kL>4:6</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>10:2</td>
<td class=br>49:42</td><td class=br>+7</td>
<td class=bc>6 - 0 - 7</td>
<td class=br><strong>12</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=378&x=-61&p=Ni%20Lyksholm">Ni Lyksholm</a></td><td class=kL>0:6</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kW>4:2</td>
<td class=kL>0:7</td>
<td class=kT>2:2</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:9</td>
<td class=kW>6:1</td>
<td class=br>29:52</td><td class=br>-23</td>
<td class=bc>3 - 3 - 7</td>
<td class=br><strong>9</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=413&x=-61&p=Fr%20Bruneske">Fr Bruneske</a></td><td class=kL>0:8</td>
<td class=kL>1:10</td>
<td class=kL>1:8</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=br>26:55</td><td class=br>-29</td>
<td class=bc>3 - 2 - 8</td>
<td class=br><strong>8</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt><a href="stats.php?idpl=127&x=-61&p=Mi%20Sevr">Mi Sevr</a></td><td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>0:7</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>0:6</td>
<td class=kW>9:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=br>32:47</td><td class=br>-15</td>
<td class=bc>3 - 0 - 10</td>
<td class=br><strong>6</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt><a href="stats.php?idpl=154&x=-61&p=Ju%20Steisunas">Ju Steisunas</a></td><td class=kL>1:8</td>
<td class=kL>1:8</td>
<td class=kL>1:6</td>
<td class=kL>0:10</td>
<td class=kL>1:7</td>
<td class=kL>0:9</td>
<td class=kL>3:5</td>
<td class=kL>0:14</td>
<td class=kL>0:8</td>
<td class=kL>2:10</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=br>11:100</td><td class=br>-89</td>
<td class=bc>0 - 0 - 13</td>
<td class=br><strong>0</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Hagerup Frode</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Miettinen Petrus</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Sevr Milos</td><td class=bc>-</td><td class=blW>Bruneske Frank</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Lyksholm Nico</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Matysek Jakub</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Hagerup Frode</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=bl>Miettinen Petrus</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Sevr Milos</td><td class=bc>-</td><td class=blW>Matysek Jakub</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Miettinen Petrus</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Matysek Jakub</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Sevr Milos</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Miettinen Petrus</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Lyksholm Nico</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Matysek Jakub</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sevr Milos</td><td class=bc>-</td><td class=blW>Cernoch Miroslav</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Miettinen Petrus</td><td class=bc>-</td><td class=blW>Matysek Jakub</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Umanskyy Anton</td><td class=bc>-</td><td class=blW>Cernoch Miroslav</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Smagars Valts</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Matysek Jakub</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Miettinen Petrus</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Hagerup Frode</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Cernoch Miroslav</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Umanskyy Anton</td><td class=bc>-</td><td class=bl>Sevr Milos</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Matysek Jakub</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Lyksholm Nico</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Miettinen Petrus</td><td class=bc>-</td><td class=blW>Cernoch Miroslav</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Sevr Milos</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Steisunas Julius</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Matysek Jakub</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Cernoch Miroslav</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>1 : 10</tr></td>
<tr><td class=brW>Miettinen Petrus</td><td class=bc>-</td><td class=bl>Sevr Milos</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Hagerup Frode</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Umanskyy Anton</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Cernoch Miroslav</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Matysek Jakub</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Sevr Milos</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Miettinen Petrus</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Hagerup Frode</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Cernoch Miroslav</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Sevr Milos</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Matysek Jakub</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=bl>Umanskyy Anton</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Miettinen Petrus</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=blW>Smagars Valts</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Sevr Milos</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>Caics Edgars</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Matysek Jakub</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Bruneske Frank</td><td class=bc>-</td><td class=bl>Hagerup Frode</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Sevr Milos</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Umanskyy Anton</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Caics Edgars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Matysek Jakub</td><td class=bc>-</td><td class=blW>Hagerup Frode</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Lyksholm Nico</td><td class=bc>-</td><td class=blW>Miettinen Petrus</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Sevr Milos</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Umanskyy Anton</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Hagerup Frode</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Miettinen Petrus</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Matysek Jakub</td><td class=bc>-</td><td class=blW>Bruneske Frank</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Umanskyy Anton</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Sevr Milos</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Smagars Valts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Cernoch Miroslav</td><td class=bc>-</td><td class=blW>Hagerup Frode</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Miettinen Petrus</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Bruneske Frank</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Umanskyy Anton</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sevr Milos</td><td class=bc>-</td><td class=blW>Hagerup Frode</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Smagars Valts</td><td class=bc>-</td><td class=bl>Miettinen Petrus</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Cernoch Miroslav</td><td class=bc>-</td><td class=bl>Bruneske Frank</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Lyksholm Nico</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Steisunas Julius</td><td class=bc>-</td><td class=blW>Matysek Jakub</td><td class=bc>0 : 14</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
