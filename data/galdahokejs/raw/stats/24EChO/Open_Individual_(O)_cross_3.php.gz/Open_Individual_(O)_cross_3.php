<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Open Individual (O)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Open_Individual_(O)_list.php">Open Individual (O)</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group Open3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=269&x=-61&p=Ke%20Eriksson">Ke Eriksson</a></td><td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>7:4</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>9:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kW>8:0</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=br>54:16</td><td class=br>+38</td>
<td class=bc>11 - 1 - 0</td>
<td class=br><strong>23</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=29&x=-61&p=Kr%20Lagzdi%C5%86a">Kr Lagzdi�a</a></td><td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=br>44:22</td><td class=br>+22</td>
<td class=bc>9 - 2 - 1</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=382&x=-61&p=Oy%20Klippen">Oy Klippen</a></td><td class=kL>4:7</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kW>5:3</td>
<td class=kW>1:0</td>
<td class=kT>5:5</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=br>37:32</td><td class=br>+5</td>
<td class=bc>6 - 3 - 3</td>
<td class=br><strong>15</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=40&x=-61&p=Al%20Sili%C5%86%C5%A1">Al Sili��</a></td><td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>7:3</td>
<td class=br>41:27</td><td class=br>+14</td>
<td class=bc>6 - 3 - 3</td>
<td class=br><strong>15</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=186&x=-61&p=R%C5%AB%20Kamzols">R� Kamzols</a></td><td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=br>39:30</td><td class=br>+9</td>
<td class=bc>5 - 4 - 3</td>
<td class=br><strong>14</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=44&x=-61&p=Kr%20Naglis">Kr Naglis</a></td><td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=br>33:35</td><td class=br>-2</td>
<td class=bc>4 - 4 - 4</td>
<td class=br><strong>12</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=379&x=-61&p=Da%20Nyg%C3%A5rd">Da Nyg�rd</a></td><td class=kL>1:9</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>8:1</td>
<td class=br>35:37</td><td class=br>-2</td>
<td class=bc>5 - 2 - 5</td>
<td class=br><strong>12</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=420&x=-61&p=He%20Steen">He Steen</a></td><td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kT>5:5</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>9:1</td>
<td class=kW>5:2</td>
<td class=br>37:41</td><td class=br>-4</td>
<td class=bc>5 - 1 - 6</td>
<td class=br><strong>11</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=405&x=-61&p=Va%20Pikl">Va Pikl</a></td><td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=br>26:28</td><td class=br>-2</td>
<td class=bc>4 - 2 - 6</td>
<td class=br><strong>10</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=66&x=-61&p=Da%20Hrustaljova">Da Hrustaljova</a></td><td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=br>26:32</td><td class=br>-6</td>
<td class=bc>2 - 4 - 6</td>
<td class=br><strong>8</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=226&x=-61&p=Ka%20Pirumshoieva">Ka Pirumshoieva</a></td><td class=kL>0:8</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=br>26:42</td><td class=br>-16</td>
<td class=bc>2 - 2 - 8</td>
<td class=br><strong>6</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=393&x=-61&p=Ju%20Itkonen">Ju Itkonen</a></td><td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>1:9</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=br>23:44</td><td class=br>-21</td>
<td class=bc>3 - 0 - 9</td>
<td class=br><strong>6</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt><a href="stats.php?idpl=416&x=-61&p=He%20Petuch">He Petuch</a></td><td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>3:7</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>1:8</td>
<td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=br>22:57</td><td class=br>-35</td>
<td class=bc>1 - 2 - 9</td>
<td class=br><strong>4</strong></td><td class=d>13.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Itkonen Juho</td><td class=bc>-</td><td class=blW>Eriksson Kevin</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=blW>Klippen Oystein</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=blW>Pikl Vaclav</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Steen Herman</td><td class=bc>-</td><td class=blW>Eriksson Kevin</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Pirumshoieva Karyna</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Itkonen Juho</td><td class=bc>-</td><td class=bl>Klippen Oystein</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Nyg�rd Daniel</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=blW>Eriksson Kevin</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Steen Herman</td><td class=bc>-</td><td class=bl>Klippen Oystein</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Itkonen Juho</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=blW>Klippen Oystein</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Itkonen Juho</td><td class=bc>-</td><td class=blW>Nyg�rd Daniel</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Klippen Oystein</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pikl Vaclav</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Steen Herman</td><td class=bc>-</td><td class=blW>Nyg�rd Daniel</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Klippen Oystein</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=blW>Petuch Hermann</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pikl Vaclav</td><td class=bc>-</td><td class=bl>Nyg�rd Daniel</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Steen Herman</td><td class=bc>-</td><td class=bl>Itkonen Juho</td><td class=bc>9 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Petuch Hermann</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Klippen Oystein</td><td class=bc>-</td><td class=blW>Kamzols R�dolfs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=blW>Nyg�rd Daniel</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pikl Vaclav</td><td class=bc>-</td><td class=bl>Itkonen Juho</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Hrustaljova Darja</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=bl>Kamzols R�dolfs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Nyg�rd Daniel</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Klippen Oystein</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Itkonen Juho</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pikl Vaclav</td><td class=bc>-</td><td class=blW>Steen Herman</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Nyg�rd Daniel</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Itkonen Juho</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Klippen Oystein</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=blW>Steen Herman</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Eriksson Kevin</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kamzols R�dolfs</td><td class=bc>-</td><td class=blW>Itkonen Juho</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Steen Herman</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Klippen Oystein</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pirumshoieva Karyna</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Itkonen Juho</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Steen Herman</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Klippen Oystein</td><td class=bc>-</td><td class=blW>Eriksson Kevin</td><td class=bc>4 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Itkonen Juho</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Steen Herman</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Nyg�rd Daniel</td><td class=bc>-</td><td class=bl>Hrustaljova Darja</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Eriksson Kevin</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Steen Herman</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Itkonen Juho</td><td class=bc>-</td><td class=blW>Hrustaljova Darja</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Pikl Vaclav</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Nyg�rd Daniel</td><td class=bc>-</td><td class=blW>Eriksson Kevin</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Kamzols R�dolfs</td><td class=bc>-</td><td class=bl>Pirumshoieva Karyna</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Petuch Hermann</td><td class=bc>-</td><td class=blW>Klippen Oystein</td><td class=bc>0 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
