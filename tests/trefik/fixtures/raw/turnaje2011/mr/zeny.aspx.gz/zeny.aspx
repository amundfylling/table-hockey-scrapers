<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN">
<html lang="cz">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<title>MR, Litomyšl</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
</head>
<body class="neop">
<a name="Zac"><p class=l>MR ženy, Litomyšl, 29. květen 2011</p></a>
<div align=center><p><a href="index.aspx">Back</a></p></div>
<p class=vm>Basic groups</p>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=2 cellspacing=0>
<tr><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>&nbsp;</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1</td><td class=kt>M.Pilařová</td><td class=kx>*</td>
<td class=k>2:4 + 3:1</td>
<td class=k>3:1 + 2:1</td>
<td class=k>4:3 + 2:0</td>
<td class=k>5:0 + 6:0</td>
<td class=br>27:10</td>
<td class=bc>7 - 0 - 1</td>
<td class=br>14</td>
<td class=d>1.</td>
</tr><tr><td class=ir>2</td><td class=kt>A.Jackowská</td><td class=k>4:2 + 1:3</td>
<td class=kx>*</td>
<td class=k>1:4 + 3:2</td>
<td class=k>3:0 + 2:3</td>
<td class=k>5:1 + 3:0</td>
<td class=br>22:15</td>
<td class=bc>5 - 0 - 3</td>
<td class=br>10</td>
<td class=d>2.</td>
</tr><tr><td class=ir>3</td><td class=kt>L.Vokounová</td><td class=k>1:3 + 1:2</td>
<td class=k>4:1 + 2:3</td>
<td class=kx>*</td>
<td class=k>3:1 + 1:1</td>
<td class=k>1:4 + 2:1</td>
<td class=br>15:16</td>
<td class=bc>3 - 1 - 4</td>
<td class=br>7</td>
<td class=d>3.</td>
</tr><tr><td class=ir>4</td><td class=kt>I.Mašková</td><td class=k>3:4 + 0:2</td>
<td class=k>0:3 + 3:2</td>
<td class=k>1:3 + 1:1</td>
<td class=kx>*</td>
<td class=k>8:2 + 6:0</td>
<td class=br>22:17</td>
<td class=bc>3 - 1 - 4</td>
<td class=br>7</td>
<td class=d>4.</td>
</tr><tr><td class=ir>5</td><td class=kt>K.Špičáková</td><td class=k>0:5 + 0:6</td>
<td class=k>1:5 + 0:3</td>
<td class=k>4:1 + 1:2</td>
<td class=k>2:8 + 0:6</td>
<td class=kx>*</td>
<td class=br>8:36</td>
<td class=bc>1 - 0 - 7</td>
<td class=br>2</td>
<td class=d>5.</td>
</tr></table></td></tr></table></div></p>





<p class=v>MR, Litomyšl - zápasy o umístění (play-off matches)<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
</tr>
<tr><td class=bl>Finále</td>
<td class=br><b>Jackowská Aneta</b></td>
<td class=bl>- Pilařová Markéta</td>
<td class=bl>2:1 P&nbsp;&nbsp;</td>
<td class=bl>0:3&nbsp;&nbsp;</td>
<td class=bl>1:0&nbsp;&nbsp;</td>
<td class=bl>1:0&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=al>Semifinále</td>
<td class=ar><b>Pilařová Markéta</b></td>
<td class=al>- Mašková Iva</td>
<td class=al>5:2&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>5:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=bl>Semifinále</td>
<td class=br><b>Jackowská Aneta</b></td>
<td class=bl>- Vokounová Lucie</td>
<td class=bl>5:2&nbsp;&nbsp;</td>
<td class=bl>5:0&nbsp;&nbsp;</td>
<td class=bl>2:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=al>O 3.místo</td>
<td class=ar><b>Mašková Iva</b></td>
<td class=al>- Vokounová Lucie</td>
<td class=al>6:1&nbsp;&nbsp;</td>
<td class=al>5:4 P&nbsp;&nbsp;</td>
<td class=al>3:0&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr>
</table>
</td></tr></table>

<p class=v>Konečné pořadí turnaje<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>Z</th>
<th>+</th>
<th>=</th>
<th>-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>B</th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al>Jackowská Aneta</td>
<td class=al>BSE České Budějovice</td>
<td class=ar>15</td>
<td class=ar>11</td>
<td class=ar>0</td>
<td class=ar>4</td>
<td class=ar>38</td>
<td class=al>: 22</td>
<td class=ar>22</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>2.</td>
<td class=bl>Pilařová Markéta</td>
<td class=bl>D.A.S. Gladiators Plzeň</td>
<td class=br>15</td>
<td class=br>11</td>
<td class=br>0</td>
<td class=br>4</td>
<td class=br>43</td>
<td class=bl>: 18</td>
<td class=br>22</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>3.</td>
<td class=al>Mašková Iva</td>
<td class=al>SHC Cheb</td>
<td class=ar>14</td>
<td class=ar>6</td>
<td class=ar>1</td>
<td class=ar>7</td>
<td class=ar>40</td>
<td class=al>: 34</td>
<td class=ar>13</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>4.</td>
<td class=bl>Vokounová Lucie</td>
<td class=bl>Kamax K.Újezdec</td>
<td class=br>14</td>
<td class=br>3</td>
<td class=br>1</td>
<td class=br>10</td>
<td class=br>23</td>
<td class=bl>: 42</td>
<td class=br>7</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>5.</td>
<td class=al>Špičáková Kamila</td>
<td class=al>Brno</td>
<td class=ar>8</td>
<td class=ar>1</td>
<td class=ar>0</td>
<td class=ar>7</td>
<td class=ar>8</td>
<td class=al>: 36</td>
<td class=ar>2</td>
<td class=ar>&nbsp;</td>
</tr></table></td></tr></table></div></p>



</body>
</html>
