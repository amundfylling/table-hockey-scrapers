<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2023">Czech Open</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=409&x=-390&p=Pa%20Petr">Pa Petr</a></td><td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kW>10:0</td>
<td class=br>74:26</td><td class=br>+48</td>
<td class=bc>10 - 4 - 0</td>
<td class=br><strong>24</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=993&x=-390&p=Ji%20Chyl%C3%ADk%20ml.">Ji Chylík ml.</a></td><td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kW>7:2</td>
<td class=kW>3:0</td>
<td class=kW>8:0</td>
<td class=br>62:22</td><td class=br>+40</td>
<td class=bc>10 - 3 - 1</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1&x=-390&p=Pa%20Ple%C5%A1%C3%A1k">Pa Plešák</a></td><td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>9:1</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>12:0</td>
<td class=br>63:24</td><td class=br>+39</td>
<td class=bc>8 - 5 - 1</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=101&x=-390&p=Mi%20Kubica">Mi Kubica</a></td><td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=kW>10:1</td>
<td class=kW>6:2</td>
<td class=kW>8:0</td>
<td class=br>63:27</td><td class=br>+36</td>
<td class=bc>9 - 2 - 3</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1815&x=-390&p=An%20Bo%C5%BEi%C4%8D">An Božič</a></td><td class=kT>3:3</td>
<td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=br>54:32</td><td class=br>+22</td>
<td class=bc>8 - 4 - 2</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1876&x=-390&p=Ad%20Kop%C5%99iva">Ad Kopřiva</a></td><td class=kT>3:3</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>9:3</td>
<td class=kW>8:4</td>
<td class=kW>7:3</td>
<td class=kW>4:0</td>
<td class=kW>10:0</td>
<td class=br>60:44</td><td class=br>+16</td>
<td class=bc>8 - 2 - 4</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=261&x=-390&p=Da%20Cibulka">Da Cibulka</a></td><td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>9:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>9:0</td>
<td class=br>53:32</td><td class=br>+21</td>
<td class=bc>6 - 3 - 5</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=40&x=-390&p=Da%20Mat%C3%BDsek">Da Matýsek</a></td><td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kW>7:0</td>
<td class=br>42:28</td><td class=br>+14</td>
<td class=bc>5 - 5 - 4</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1981&x=-390&p=Po%20Kvasnikova">Po Kvasnikova</a></td><td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kW>2:0</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=br>38:37</td><td class=br>+1</td>
<td class=bc>5 - 4 - 5</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=474&x=-390&p=Mi%20Margolis">Mi Margolis</a></td><td class=kL>1:6</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=br>33:43</td><td class=br>-10</td>
<td class=bc>6 - 1 - 7</td>
<td class=br><strong>13</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1957&x=-390&p=Er%20Bernhauser">Er Bernhauser</a></td><td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>3:9</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=br>31:56</td><td class=br>-25</td>
<td class=bc>4 - 1 - 9</td>
<td class=br><strong>9</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1917&x=-390&p=Fr%20Rasche">Fr Rasche</a></td><td class=kL>2:6</td>
<td class=kL>3:6</td>
<td class=kL>1:9</td>
<td class=kL>2:6</td>
<td class=kL>2:7</td>
<td class=kL>4:8</td>
<td class=kL>2:9</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=br>43:69</td><td class=br>-26</td>
<td class=bc>4 - 1 - 9</td>
<td class=br><strong>9</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1430&x=-390&p=Da%20Kadlec">Da Kadlec</a></td><td class=kL>0:5</td>
<td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kL>1:10</td>
<td class=kL>1:6</td>
<td class=kL>3:7</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>0:7</td>
<td class=kW>5:0</td>
<td class=br>26:67</td><td class=br>-41</td>
<td class=bc>2 - 1 - 11</td>
<td class=br><strong>5</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1869&x=-390&p=Pe%20Klazar">Pe Klazar</a></td><td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>0:8</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kW>7:0</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=br>24:58</td><td class=br>-34</td>
<td class=bc>2 - 0 - 12</td>
<td class=br><strong>4</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2021&x=-390&p=Kr%20Novotn%C3%BD">Kr Novotný</a></td><td class=kL>0:10</td>
<td class=kL>0:8</td>
<td class=kL>0:12</td>
<td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>0:10</td>
<td class=kL>0:9</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=br>4:105</td><td class=br>-101</td>
<td class=bc>0 - 0 - 14</td>
<td class=br><strong>0</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Er Bernhauser</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Mi Margolis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>5 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
