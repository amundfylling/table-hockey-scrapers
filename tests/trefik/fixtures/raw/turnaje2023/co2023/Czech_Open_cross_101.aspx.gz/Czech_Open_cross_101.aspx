<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2023">Czech Open</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group A1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1761&x=-390&p=Ra%20Kalnin%C5%A1">Ra Kalninš</a></td><td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>6:3 K</td>
<td class=kL>3:4</td>
<td class=kW>7:4</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>6:1 K</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kW>7:1</td>
<td class=kW>3:2 K</td>
<td class=kW>5:2 K</td>
<td class=kL>0:5</td>
<td class=kW>8:2</td>
<td class=kW>5:2</td>
<td class=kW>4:0 K</td>
<td class=kW>5:2 K</td>
<td class=kW>6:0</td>
<td class=kW>10:0</td>
<td class=kW>8:2</td>
<td class=kW>8:1</td>
<td class=kW>7:1 K</td>
<td class=kW>4:2</td>
<td class=kT>2:2 K</td>
<td class=kW>8:1</td>
<td class=kW>7:2 K</td>
<td class=br>149:52</td><td class=br>+97</td>
<td class=bc>25 - 1 - 3</td>
<td class=br><strong>51</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=409&x=-390&p=Pa%20Petr">Pa Petr</a></td><td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>5:5 K</td>
<td class=kW>5:1</td>
<td class=kL>0:5</td>
<td class=kT>3:3 K</td>
<td class=kW>8:1</td>
<td class=kT>3:3 K</td>
<td class=kW>6:2 K</td>
<td class=kW>6:0 K</td>
<td class=kW>9:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kT>3:3 K</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kW>4:3 K</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=kW>6:1 K</td>
<td class=kW>7:2</td>
<td class=kW>5:1 K</td>
<td class=kW>6:1</td>
<td class=br>129:56</td><td class=br>+73</td>
<td class=bc>20 - 5 - 4</td>
<td class=br><strong>45</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2002&x=-390&p=Hu%20L%C3%B6nnqvist">Hu Lönnqvist</a></td><td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:1 K</td>
<td class=kT>2:2</td>
<td class=kW>5:3 K</td>
<td class=kW>6:1 K</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>3:1 K</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kL>1:5</td>
<td class=kT>1:1 K</td>
<td class=kT>3:3 K</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>1:0 K</td>
<td class=kW>4:1 K</td>
<td class=kW>6:4</td>
<td class=kW>6:1 K</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=br>94:55</td><td class=br>+39</td>
<td class=bc>19 - 4 - 6</td>
<td class=br><strong>42</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1251&x=-390&p=Ho%20Sl%C3%A1dek">Ho Sládek</a></td><td class=kL>3:6 K</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kW>6:4</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kW>2:0 K</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>3:6 K</td>
<td class=kW>3:1 K</td>
<td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>3:2 K</td>
<td class=kW>4:1 K</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kT>4:4 K</td>
<td class=kW>5:4</td>
<td class=kW>3:0 K</td>
<td class=kW>4:2</td>
<td class=kW>4:1 K</td>
<td class=br>99:67</td><td class=br>+32</td>
<td class=bc>18 - 5 - 6</td>
<td class=br><strong>41</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2024&x=-390&p=Em%20Liepins">Em Liepins</a></td><td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3 K</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kL>2:3 K</td>
<td class=kT>3:3 K</td>
<td class=kW>7:3</td>
<td class=kW>5:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>6:4 K</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>4:2</td>
<td class=kW>7:2 K</td>
<td class=kW>3:2 K</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2 K</td>
<td class=kW>6:1 K</td>
<td class=kW>2:0</td>
<td class=kL>2:3 K</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=br>104:62</td><td class=br>+42</td>
<td class=bc>18 - 4 - 7</td>
<td class=br><strong>40</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=993&x=-390&p=Ji%20Chyl%C3%ADk%20ml.">Ji Chylík ml.</a></td><td class=kL>4:7</td>
<td class=kT>5:5 K</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>7:1 K</td>
<td class=kL>1:2</td>
<td class=kW>3:0 K</td>
<td class=kT>1:1 K</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>6:0 K</td>
<td class=kW>1:0</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kT>3:3</td>
<td class=kW>5:2 K</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kL>3:4 K</td>
<td class=kW>7:0</td>
<td class=kW>4:2 K</td>
<td class=kW>3:0</td>
<td class=br>101:61</td><td class=br>+40</td>
<td class=bc>17 - 6 - 6</td>
<td class=br><strong>40</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2026&x=-390&p=An%20Kuznecovs">An Kuznecovs</a></td><td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>3:5 K</td>
<td class=kL>4:6</td>
<td class=kW>3:2 K</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kT>4:4 K</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>5:2 K</td>
<td class=kW>3:2</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=kW>7:2 K</td>
<td class=kL>2:3 K</td>
<td class=kW>6:4</td>
<td class=kW>6:2</td>
<td class=kW>5:2 K</td>
<td class=kW>3:2 K</td>
<td class=kW>2:1</td>
<td class=kW>4:1 K</td>
<td class=kL>1:5</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=br>109:81</td><td class=br>+28</td>
<td class=bc>19 - 1 - 9</td>
<td class=br><strong>39</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1650&x=-390&p=Va%20Dietze">Va Dietze</a></td><td class=kL>3:5</td>
<td class=kW>5:0</td>
<td class=kL>1:6 K</td>
<td class=kW>3:2</td>
<td class=kT>3:3 K</td>
<td class=kL>2:3</td>
<td class=kT>4:4 K</td>
<td class=kx>*</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>7:2 K</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kL>0:3</td>
<td class=kW>5:3 K</td>
<td class=kL>2:8 K</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>2:3 K</td>
<td class=kL>3:4 K</td>
<td class=kW>5:2</td>
<td class=kT>3:3 K</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=br>98:80</td><td class=br>+18</td>
<td class=bc>15 - 5 - 9</td>
<td class=br><strong>35</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1815&x=-390&p=An%20Bo%C5%BEi%C4%8D">An Božič</a></td><td class=kL>0:3</td>
<td class=kT>3:3 K</td>
<td class=kW>4:2</td>
<td class=kL>3:5</td>
<td class=kL>3:7</td>
<td class=kL>1:7 K</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:5 K</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kW>5:1</td>
<td class=kW>3:1 K</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kW>2:1 K</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>6:2 K</td>
<td class=kW>6:0</td>
<td class=kT>4:4 K</td>
<td class=kW>5:1</td>
<td class=br>91:72</td><td class=br>+19</td>
<td class=bc>14 - 6 - 9</td>
<td class=br><strong>34</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1975&x=-390&p=Gu%20Hermansson">Gu Hermansson</a></td><td class=kL>1:6 K</td>
<td class=kL>1:8</td>
<td class=kL>2:5</td>
<td class=kL>0:2 K</td>
<td class=kL>4:5</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kW>5:1 K</td>
<td class=kT>2:2 K</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kL>1:3 K</td>
<td class=kT>2:2 K</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kW>4:2 K</td>
<td class=kW>5:0</td>
<td class=kW>4:1 K</td>
<td class=kW>2:1</td>
<td class=kW>7:2 K</td>
<td class=br>83:69</td><td class=br>+14</td>
<td class=bc>13 - 8 - 8</td>
<td class=br><strong>34</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=101&x=-390&p=Mi%20Kubica">Mi Kubica</a></td><td class=kL>1:3</td>
<td class=kT>3:3 K</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>0:3 K</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>5:2 K</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>2:6 K</td>
<td class=kW>5:2 K</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>7:1 K</td>
<td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kL>1:4 K</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>3:0 K</td>
<td class=kW>3:1</td>
<td class=kT>1:1 K</td>
<td class=kW>5:0</td>
<td class=br>83:70</td><td class=br>+13</td>
<td class=bc>15 - 3 - 11</td>
<td class=br><strong>33</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1&x=-390&p=Pa%20Ple%C5%A1%C3%A1k">Pa Plešák</a></td><td class=kW>3:1</td>
<td class=kL>2:6 K</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kT>1:1 K</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2</td>
<td class=kW>6:2 K</td>
<td class=kx>*</td>
<td class=kT>1:1 K</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kW>4:0 K</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kT>4:4 K</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kW>2:1 K</td>
<td class=kW>6:1</td>
<td class=kT>4:4 K</td>
<td class=kW>6:0</td>
<td class=br>82:69</td><td class=br>+13</td>
<td class=bc>12 - 8 - 9</td>
<td class=br><strong>32</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=40&x=-390&p=Da%20Mat%C3%BDsek">Da Matýsek</a></td><td class=kL>2:6</td>
<td class=kL>0:6 K</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kT>1:1 K</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kW>3:2</td>
<td class=kL>2:5 K</td>
<td class=kT>1:1 K</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>3:4 K</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kT>2:2 K</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kL>0:2 K</td>
<td class=kL>0:1</td>
<td class=kW>5:2 K</td>
<td class=kW>5:0</td>
<td class=br>67:70</td><td class=br>-3</td>
<td class=bc>12 - 7 - 10</td>
<td class=br><strong>31</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1845&x=-390&p=My%20Shalomayev">My Shalomayev</a></td><td class=kL>1:7</td>
<td class=kL>2:9</td>
<td class=kL>1:3 K</td>
<td class=kT>3:3</td>
<td class=kL>4:6 K</td>
<td class=kT>2:2</td>
<td class=kL>2:5 K</td>
<td class=kL>2:7 K</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kL>0:5 K</td>
<td class=kT>1:1 K</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>2:1 K</td>
<td class=kW>6:1 K</td>
<td class=kW>3:0</td>
<td class=kW>6:1 K</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=br>78:82</td><td class=br>-4</td>
<td class=bc>13 - 4 - 12</td>
<td class=br><strong>30</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=248&x=-390&p=Ma%20%C5%BDen%C3%AD%C5%A1ek">Ma Ženíšek</a></td><td class=kL>2:3 K</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kW>6:3 K</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kL>1:5 K</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:2 K</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kT>1:1 K</td>
<td class=kL>2:3 K</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kW>7:3</td>
<td class=kW>6:2</td>
<td class=kW>6:2 K</td>
<td class=kL>4:5</td>
<td class=kW>3:2 K</td>
<td class=kW>5:1</td>
<td class=kW>6:2 K</td>
<td class=br>89:79</td><td class=br>+10</td>
<td class=bc>13 - 4 - 12</td>
<td class=br><strong>30</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2022&x=-390&p=Da%20Hrustaljova">Da Hrustaljova</a></td><td class=kL>2:5 K</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3 K</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kW>5:4</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kW>2:1 K</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>1:0 K</td>
<td class=kW>2:0 K</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>4:2 K</td>
<td class=kT>1:1</td>
<td class=kL>1:2 K</td>
<td class=kW>2:0</td>
<td class=kW>4:2 K</td>
<td class=br>67:66</td><td class=br>+1</td>
<td class=bc>14 - 2 - 13</td>
<td class=br><strong>30</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1876&x=-390&p=Ad%20Kop%C5%99iva">Ad Kopřiva</a></td><td class=kW>5:0</td>
<td class=kT>3:3 K</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>0:6 K</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kL>1:3 K</td>
<td class=kT>3:3</td>
<td class=kL>1:7 K</td>
<td class=kL>0:4 K</td>
<td class=kW>4:3 K</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kW>5:3 K</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kT>3:3 K</td>
<td class=kW>3:0</td>
<td class=kW>5:2 K</td>
<td class=kT>5:5</td>
<td class=br>81:83</td><td class=br>-2</td>
<td class=bc>12 - 6 - 11</td>
<td class=br><strong>30</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1033&x=-390&p=Si%20Thomas">Si Thomas</a></td><td class=kL>2:8</td>
<td class=kL>0:2</td>
<td class=kT>1:1 K</td>
<td class=kL>0:4</td>
<td class=kL>2:7 K</td>
<td class=kL>0:1</td>
<td class=kL>2:7 K</td>
<td class=kL>3:5 K</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>5:0 K</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:1 K</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kL>0:4 K</td>
<td class=kT>5:5 K</td>
<td class=kT>3:3</td>
<td class=kW>5:0 K</td>
<td class=kL>1:6</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=br>74:78</td><td class=br>-4</td>
<td class=bc>11 - 7 - 11</td>
<td class=br><strong>29</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=64&x=-390&p=Da%20%C5%A0m%C3%ADd">Da Šmíd</a></td><td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kT>3:3 K</td>
<td class=kL>0:2</td>
<td class=kL>2:3 K</td>
<td class=kL>3:5</td>
<td class=kW>3:2 K</td>
<td class=kW>8:2 K</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kW>7:1</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kT>1:1 K</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>1:4 K</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>5:0 K</td>
<td class=kW>7:2 K</td>
<td class=kL>1:5</td>
<td class=kL>2:3 K</td>
<td class=kW>3:2</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>7:2</td>
<td class=br>85:80</td><td class=br>+5</td>
<td class=bc>13 - 3 - 13</td>
<td class=br><strong>29</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1980&x=-390&p=Ja%20Zalite">Ja Zalite</a></td><td class=kL>0:4 K</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3 K</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>4:6</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kW>3:1 K</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kT>1:1 K</td>
<td class=kL>0:1 K</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1</td>
<td class=kL>0:2 K</td>
<td class=kW>2:0</td>
<td class=kW>6:1 K</td>
<td class=br>55:62</td><td class=br>-7</td>
<td class=bc>9 - 6 - 14</td>
<td class=br><strong>24</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1488&x=-390&p=Ra%20Pommerenke">Ra Pommerenke</a></td><td class=kL>2:5 K</td>
<td class=kL>1:7</td>
<td class=kW>3:1</td>
<td class=kL>1:4 K</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kW>3:2 K</td>
<td class=kL>0:2 K</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>0:1</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1</td>
<td class=kT>4:4 K</td>
<td class=kW>4:1</td>
<td class=kW>5:4 K</td>
<td class=br>56:82</td><td class=br>-26</td>
<td class=bc>8 - 6 - 15</td>
<td class=br><strong>22</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1641&x=-390&p=Ma%20Klazar">Ma Klazar</a></td><td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>0:1 K</td>
<td class=kL>3:6</td>
<td class=kL>2:3 K</td>
<td class=kL>0:6</td>
<td class=kL>2:5 K</td>
<td class=kW>3:2 K</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>1:2 K</td>
<td class=kW>4:2</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kW>4:0 K</td>
<td class=kL>0:5 K</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:1 K</td>
<td class=kL>3:4</td>
<td class=kW>3:2 K</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=br>61:87</td><td class=br>-26</td>
<td class=bc>9 - 4 - 16</td>
<td class=br><strong>22</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2001&x=-390&p=Gl%20Storozhenko">Gl Storozhenko</a></td><td class=kL>0:10</td>
<td class=kL>3:7</td>
<td class=kL>1:4 K</td>
<td class=kT>3:3</td>
<td class=kL>1:6 K</td>
<td class=kT>3:3</td>
<td class=kL>2:3 K</td>
<td class=kW>4:3 K</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>4:5</td>
<td class=kL>1:6 K</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kW>5:1</td>
<td class=kT>5:5 K</td>
<td class=kL>2:7 K</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>1:3 K</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:3 K</td>
<td class=kW>7:1</td>
<td class=kW>8:4</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=br>76:109</td><td class=br>-33</td>
<td class=bc>8 - 4 - 17</td>
<td class=br><strong>20</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=261&x=-390&p=Da%20Cibulka">Da Cibulka</a></td><td class=kL>2:8</td>
<td class=kL>3:4 K</td>
<td class=kL>4:6</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>2:5 K</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>1:2 K</td>
<td class=kT>0:0</td>
<td class=kW>4:1 K</td>
<td class=kT>4:4 K</td>
<td class=kT>2:2 K</td>
<td class=kL>0:3</td>
<td class=kL>3:7</td>
<td class=kL>3:4</td>
<td class=kL>3:5 K</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>4:5</td>
<td class=kW>5:2 K</td>
<td class=kW>4:3</td>
<td class=kL>0:2 K</td>
<td class=kT>1:1</td>
<td class=br>74:95</td><td class=br>-21</td>
<td class=bc>7 - 5 - 17</td>
<td class=br><strong>19</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1291&x=-390&p=Ma%20Dion">Ma Dion</a></td><td class=kL>1:8</td>
<td class=kL>2:7</td>
<td class=kL>1:6 K</td>
<td class=kL>0:4</td>
<td class=kW>3:2 K</td>
<td class=kL>3:5</td>
<td class=kL>1:4 K</td>
<td class=kT>3:3 K</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kW>6:2</td>
<td class=kL>0:3</td>
<td class=kL>1:6 K</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>0:5 K</td>
<td class=kW>3:2 K</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3 K</td>
<td class=kL>3:4 K</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=br>59:103</td><td class=br>-44</td>
<td class=bc>8 - 3 - 18</td>
<td class=br><strong>19</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=26&x=-390&p=Mi%20%C5%A0evr">Mi Ševr</a></td><td class=kL>1:7 K</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kT>4:4 K</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kL>2:4 K</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>2:6 K</td>
<td class=kL>2:4 K</td>
<td class=kL>1:6</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2 K</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:3 K</td>
<td class=kL>0:3</td>
<td class=kL>0:1 K</td>
<td class=br>60:108</td><td class=br>-48</td>
<td class=bc>6 - 4 - 19</td>
<td class=br><strong>16</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=474&x=-390&p=Mi%20Margolis">Mi Margolis</a></td><td class=kL>2:4</td>
<td class=kL>1:6 K</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=kW>4:3 K</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>2:6 K</td>
<td class=kL>0:5</td>
<td class=kL>0:3 K</td>
<td class=kL>1:2 K</td>
<td class=kW>2:0 K</td>
<td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kT>1:1</td>
<td class=kT>3:3 K</td>
<td class=kL>3:5</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kL>4:8</td>
<td class=kL>2:5 K</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>2:1 K</td>
<td class=kW>1:0</td>
<td class=br>61:104</td><td class=br>-43</td>
<td class=bc>6 - 4 - 19</td>
<td class=br><strong>16</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1622&x=-390&p=He%20Petuch">He Petuch</a></td><td class=kT>2:2 K</td>
<td class=kL>2:7</td>
<td class=kT>1:1</td>
<td class=kL>0:3 K</td>
<td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kL>3:4</td>
<td class=kL>2:7</td>
<td class=kL>0:6</td>
<td class=kL>1:4 K</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kW>1:0</td>
<td class=kL>2:4</td>
<td class=kL>2:3 K</td>
<td class=kW>2:1 K</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>2:0 K</td>
<td class=kT>4:4 K</td>
<td class=kL>3:5</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kL>3:4 K</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>1:2 K</td>
<td class=br>53:96</td><td class=br>-43</td>
<td class=bc>6 - 4 - 19</td>
<td class=br><strong>16</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1981&x=-390&p=Po%20Kvasnikova">Po Kvasnikova</a></td><td class=kL>1:8</td>
<td class=kL>1:5 K</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>2:4 K</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kT>4:4 K</td>
<td class=kL>1:2</td>
<td class=kT>1:1 K</td>
<td class=kT>4:4 K</td>
<td class=kL>2:5 K</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>2:5 K</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>2:0 K</td>
<td class=kL>0:4</td>
<td class=kW>3:0</td>
<td class=kL>1:2 K</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=br>44:100</td><td class=br>-56</td>
<td class=bc>4 - 4 - 21</td>
<td class=br><strong>12</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=32&x=-390&p=Ji%20Krop%C3%A1%C4%8Dek">Ji Kropáček</a></td><td class=kL>2:7 K</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:4 K</td>
<td class=kL>0:7</td>
<td class=kL>0:3</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>2:7 K</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kL>2:6 K</td>
<td class=kL>2:4 K</td>
<td class=kT>5:5</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>1:6 K</td>
<td class=kL>4:5 K</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>1:0 K</td>
<td class=kL>0:1</td>
<td class=kW>2:1 K</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=br>46:130</td><td class=br>-84</td>
<td class=bc>3 - 3 - 23</td>
<td class=br><strong>9</strong></td><td class=d>30.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ja Zalite</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Hu Lönnqvist</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>An Kuznecovs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ra Kalninš</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Ma Dion</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ja Zalite</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>An Kuznecovs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Hu Lönnqvist</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Da Hrustaljova</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ja Zalite</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Margolis</td><td class=bc>-</td><td class=bl>Em Liepins</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Hu Lönnqvist</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>An Kuznecovs</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ja Zalite</td><td class=bc>-</td><td class=blW>Ma Dion</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Em Liepins</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Hu Lönnqvist</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>An Kuznecovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Da Hrustaljova</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ja Zalite</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Hu Lönnqvist</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>An Kuznecovs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Hu Lönnqvist</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>An Kuznecovs</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Em Liepins</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Da Hrustaljova</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ja Zalite</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Hu Lönnqvist</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>An Kuznecovs</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Ja Zalite</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Mi Margolis</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Em Liepins</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Hu Lönnqvist</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Kuznecovs</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Hrustaljova</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Ja Zalite</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Hu Lönnqvist</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>An Kuznecovs</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Ja Zalite</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>An Kuznecovs</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Hu Lönnqvist</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ra Kalninš</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Hu Lönnqvist</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>An Kuznecovs</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Hrustaljova</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Hu Lönnqvist</td><td class=bc>-</td><td class=blW>Ja Zalite</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>An Kuznecovs</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=blW>Ma Dion</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Da Hrustaljova</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Em Liepins</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Hu Lönnqvist</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>An Kuznecovs</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ma Dion</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Mi Margolis</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Hu Lönnqvist</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>An Kuznecovs</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>6 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>An Kuznecovs</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Hu Lönnqvist</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Hu Lönnqvist</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>An Kuznecovs</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Em Liepins</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Da Hrustaljova</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Dion</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>8 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Hu Lönnqvist</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>An Kuznecovs</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Da Hrustaljova</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Ra Kalninš</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ja Zalite</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Hu Lönnqvist</td><td class=bc>-</td><td class=bl>Da Hrustaljova</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>An Kuznecovs</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Em Liepins</td><td class=bc>-</td><td class=blW>Da Hrustaljova</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Hu Lönnqvist</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Kuznecovs</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Dion</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>An Kuznecovs</td><td class=bc>-</td><td class=blW>Da Hrustaljova</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Hu Lönnqvist</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
