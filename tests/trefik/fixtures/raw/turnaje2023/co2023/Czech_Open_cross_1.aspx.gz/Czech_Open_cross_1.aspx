<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2023">Czech Open</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1761&x=-390&p=Ra%20Kalnin%C5%A1">Ra Kalninš</a></td><td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>7:1</td>
<td class=kW>7:1</td>
<td class=kW>8:2</td>
<td class=kW>11:0</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=br>80:21</td><td class=br>+59</td>
<td class=bc>13 - 1 - 0</td>
<td class=br><strong>27</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1251&x=-390&p=Ho%20Sl%C3%A1dek">Ho Sládek</a></td><td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>3:6</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kW>9:1</td>
<td class=br>52:30</td><td class=br>+22</td>
<td class=bc>10 - 2 - 2</td>
<td class=br><strong>22</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1975&x=-390&p=Gu%20Hermansson">Gu Hermansson</a></td><td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=br>52:26</td><td class=br>+26</td>
<td class=bc>9 - 2 - 3</td>
<td class=br><strong>20</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=248&x=-390&p=Ma%20%C5%BDen%C3%AD%C5%A1ek">Ma Ženíšek</a></td><td class=kL>2:3</td>
<td class=kW>6:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=br>57:31</td><td class=br>+26</td>
<td class=bc>9 - 1 - 4</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2022&x=-390&p=Da%20Hrustaljova">Da Hrustaljova</a></td><td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=br>34:24</td><td class=br>+10</td>
<td class=bc>8 - 2 - 4</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1622&x=-390&p=He%20Petuch">He Petuch</a></td><td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=br>39:33</td><td class=br>+6</td>
<td class=bc>6 - 3 - 5</td>
<td class=br><strong>15</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1488&x=-390&p=Ra%20Pommerenke">Ra Pommerenke</a></td><td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=br>34:32</td><td class=br>+2</td>
<td class=bc>5 - 5 - 4</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1980&x=-390&p=Ja%20Zalite">Ja Zalite</a></td><td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>8:0</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=kW>8:0</td>
<td class=br>44:21</td><td class=br>+23</td>
<td class=bc>6 - 3 - 5</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=32&x=-390&p=Ji%20Krop%C3%A1%C4%8Dek">Ji Kropáček</a></td><td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>4:5</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>6:4</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kW>8:2</td>
<td class=br>38:49</td><td class=br>-11</td>
<td class=bc>7 - 0 - 7</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=26&x=-390&p=Mi%20%C5%A0evr">Mi Ševr</a></td><td class=kL>1:7</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>8:2</td>
<td class=kW>7:0</td>
<td class=br>47:41</td><td class=br>+6</td>
<td class=bc>5 - 4 - 5</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1318&x=-390&p=Jo%20Sedl%C3%A1%C4%8Dek">Jo Sedláček</a></td><td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>4:6</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=br>33:50</td><td class=br>-17</td>
<td class=bc>5 - 1 - 8</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1630&x=-390&p=Pe%20Holub">Pe Holub</a></td><td class=kL>2:8</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>0:8</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=br>35:49</td><td class=br>-14</td>
<td class=bc>3 - 3 - 8</td>
<td class=br><strong>9</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2014&x=-390&p=Ma%20Hlava%C4%8Dka">Ma Hlavačka</a></td><td class=kL>0:11</td>
<td class=kL>3:6</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>27:58</td><td class=br>-31</td>
<td class=bc>3 - 0 - 11</td>
<td class=br><strong>6</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=910&x=-390&p=Vl%20Gobyov%C3%A1">Vl Gobyová</a></td><td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=br>18:52</td><td class=br>-34</td>
<td class=bc>1 - 3 - 10</td>
<td class=br><strong>5</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1999&x=-390&p=Fi%20Pano%C5%A1">Fi Panoš</a></td><td class=kL>2:5</td>
<td class=kL>1:9</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kL>0:2</td>
<td class=kL>0:8</td>
<td class=kL>2:8</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=br>8:81</td><td class=br>-73</td>
<td class=bc>0 - 0 - 14</td>
<td class=br><strong>0</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ja Zalite</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>2 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
