<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2023">Final Ranking</a></span></h2></div></div></div></div><h3 align="right">Czech Open&nbsp;&nbsp;</h3>
<p><div align="center">
<p class=v><br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0 class="rnk">
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">M</th>
<th align="center">+</th>
<th align="center">=</th>
<th align="center">-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">Pts</th>
<th align="center">CZ pts</th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1761&x=-390&p=Kalnin%C5%A1%20Rainers">Kalninš Rainers</a></td>
<td class=al>* Latvia</td>
<td class=ar>58</td>
<td class=ar>50</td>
<td class=ar>1</td>
<td class=ar>7</td>
<td class=ar>278</td>
<td class=al>&nbsp;:&nbsp;121</td>
<td class=ar>101</td>
<td class=ar>180</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>2.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=409&x=-390&p=Petr%20Patrik">Petr Patrik</a></td>
<td class=bl>THC Stiga Elites</td>
<td class=br>58</td>
<td class=br>43</td>
<td class=br>5</td>
<td class=br>10</td>
<td class=br>250</td>
<td class=bl>&nbsp;:&nbsp;111</td>
<td class=br>91</td>
<td class=br>172</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>3.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=2002&x=-390&p=L%C3%B6nnqvist%20Hugo">Lönnqvist Hugo</a></td>
<td class=al>* Sweden</td>
<td class=ar>59</td>
<td class=ar>38</td>
<td class=ar>4</td>
<td class=ar>17</td>
<td class=ar>192</td>
<td class=al>&nbsp;:&nbsp;122</td>
<td class=ar>80</td>
<td class=ar>166</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>4.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1174&x=-390&p=Mad%C4%9Bra%20Martin">Maděra Martin</a></td>
<td class=bl>THC Stiga-Game Příbram</td>
<td class=br>60</td>
<td class=br>44</td>
<td class=br>2</td>
<td class=br>14</td>
<td class=br>227</td>
<td class=bl>&nbsp;:&nbsp;135</td>
<td class=br>90</td>
<td class=br>161</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>5.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1772&x=-390&p=Silin%C5%A1%20Elvijs">Silinš Elvijs</a></td>
<td class=al>* Latvia</td>
<td class=ar>49</td>
<td class=ar>34</td>
<td class=ar>2</td>
<td class=ar>13</td>
<td class=ar>188</td>
<td class=al>&nbsp;:&nbsp;97</td>
<td class=ar>70</td>
<td class=ar>157</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>6.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=2024&x=-390&p=Liepins%20Emils">Liepins Emils</a></td>
<td class=bl>* Latvia</td>
<td class=br>50</td>
<td class=br>32</td>
<td class=br>4</td>
<td class=br>14</td>
<td class=br>187</td>
<td class=bl>&nbsp;:&nbsp;106</td>
<td class=br>68</td>
<td class=br>154</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>7.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=993&x=-390&p=Chyl%C3%ADk%20ml.%20Ji%C5%99%C3%AD">Chylík ml. Jiří</a></td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>50</td>
<td class=ar>32</td>
<td class=ar>6</td>
<td class=ar>12</td>
<td class=ar>166</td>
<td class=al>&nbsp;:&nbsp;102</td>
<td class=ar>70</td>
<td class=ar>152</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>8.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=310&x=-390&p=%C4%8Cernoch%20Miroslav">Černoch Miroslav</a></td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>49</td>
<td class=br>31</td>
<td class=br>1</td>
<td class=br>17</td>
<td class=br>149</td>
<td class=bl>&nbsp;:&nbsp;96</td>
<td class=br>63</td>
<td class=br>151</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>9.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1477&x=-390&p=Kobrle%20Michal">Kobrle Michal</a></td>
<td class=al>THC Stiga Elites</td>
<td class=ar>45</td>
<td class=ar>35</td>
<td class=ar>1</td>
<td class=ar>9</td>
<td class=ar>201</td>
<td class=al>&nbsp;:&nbsp;95</td>
<td class=ar>71</td>
<td class=ar>148</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>10.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1649&x=-390&p=Miglinieks%20Raivis">Miglinieks Raivis</a></td>
<td class=bl>* Latvia</td>
<td class=br>43</td>
<td class=br>30</td>
<td class=br>5</td>
<td class=br>8</td>
<td class=br>175</td>
<td class=bl>&nbsp;:&nbsp;72</td>
<td class=br>65</td>
<td class=br>147</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>11.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1616&x=-390&p=Larsson%20Emil">Larsson Emil</a></td>
<td class=al>* Sweden</td>
<td class=ar>47</td>
<td class=ar>31</td>
<td class=ar>4</td>
<td class=ar>12</td>
<td class=ar>172</td>
<td class=al>&nbsp;:&nbsp;105</td>
<td class=ar>66</td>
<td class=ar>146</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>12.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=567&x=-390&p=Lebl%20Kry%C5%A1tof">Lebl Kryštof</a></td>
<td class=bl>Big Band</td>
<td class=br>46</td>
<td class=br>30</td>
<td class=br>3</td>
<td class=br>13</td>
<td class=br>165</td>
<td class=bl>&nbsp;:&nbsp;86</td>
<td class=br>63</td>
<td class=br>145</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>13.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=386&x=-390&p=Sl%C3%A1dek%20Kuba">Sládek Kuba</a></td>
<td class=al>THC Stiga-Game Příbram</td>
<td class=ar>44</td>
<td class=ar>24</td>
<td class=ar>9</td>
<td class=ar>11</td>
<td class=ar>128</td>
<td class=al>&nbsp;:&nbsp;90</td>
<td class=ar>57</td>
<td class=ar>144</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>14.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=2003&x=-390&p=Kimberg%20Anton">Kimberg Anton</a></td>
<td class=bl>* Sweden</td>
<td class=br>45</td>
<td class=br>26</td>
<td class=br>5</td>
<td class=br>14</td>
<td class=br>126</td>
<td class=bl>&nbsp;:&nbsp;91</td>
<td class=br>57</td>
<td class=br>143</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>15.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1815&x=-390&p=Bo%C5%BEi%C4%8D%20An%C5%BEe">Božič Anže</a></td>
<td class=al>* Slovenia</td>
<td class=ar>44</td>
<td class=ar>23</td>
<td class=ar>6</td>
<td class=ar>15</td>
<td class=ar>154</td>
<td class=al>&nbsp;:&nbsp;111</td>
<td class=ar>52</td>
<td class=ar>142</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>16.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=53&x=-390&p=Pikl%20V%C3%A1clav">Pikl Václav</a></td>
<td class=bl>THC Stiga Elites</td>
<td class=br>46</td>
<td class=br>22</td>
<td class=br>4</td>
<td class=br>20</td>
<td class=br>112</td>
<td class=bl>&nbsp;:&nbsp;109</td>
<td class=br>48</td>
<td class=br>141</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>17.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1251&x=-390&p=Sl%C3%A1dek%20Honza">Sládek Honza</a></td>
<td class=al>THC Stiga Elites</td>
<td class=ar>41</td>
<td class=ar>25</td>
<td class=ar>6</td>
<td class=ar>10</td>
<td class=ar>140</td>
<td class=al>&nbsp;:&nbsp;92</td>
<td class=ar>56</td>
<td class=ar>139</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>18.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=2026&x=-390&p=Kuznecovs%20Andrejs">Kuznecovs Andrejs</a></td>
<td class=bl>* Latvia</td>
<td class=br>38</td>
<td class=br>24</td>
<td class=br>1</td>
<td class=br>13</td>
<td class=br>153</td>
<td class=bl>&nbsp;:&nbsp;108</td>
<td class=br>49</td>
<td class=br>138</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>19.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1977&x=-390&p=Dion%20Till">Dion Till</a></td>
<td class=al>* Germany</td>
<td class=ar>40</td>
<td class=ar>24</td>
<td class=ar>4</td>
<td class=ar>12</td>
<td class=ar>144</td>
<td class=al>&nbsp;:&nbsp;110</td>
<td class=ar>52</td>
<td class=ar>137</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>20.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1650&x=-390&p=Dietze%20Valentin">Dietze Valentin</a></td>
<td class=bl>* Germany</td>
<td class=br>40</td>
<td class=br>22</td>
<td class=br>5</td>
<td class=br>13</td>
<td class=br>137</td>
<td class=bl>&nbsp;:&nbsp;99</td>
<td class=br>49</td>
<td class=br>136</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>21.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1975&x=-390&p=Hermansson%20Gustaf">Hermansson Gustaf</a></td>
<td class=al>* Sweden</td>
<td class=ar>39</td>
<td class=ar>19</td>
<td class=ar>8</td>
<td class=ar>12</td>
<td class=ar>120</td>
<td class=al>&nbsp;:&nbsp;92</td>
<td class=ar>46</td>
<td class=ar>135</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>22.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1065&x=-390&p=Herold%20Kry%C5%A1tof">Herold Kryštof</a></td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>39</td>
<td class=br>22</td>
<td class=br>2</td>
<td class=br>15</td>
<td class=br>110</td>
<td class=bl>&nbsp;:&nbsp;85</td>
<td class=br>46</td>
<td class=br>134</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>23.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=101&x=-390&p=Kubica%20Miloslav">Kubica Miloslav</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>39</td>
<td class=ar>21</td>
<td class=ar>3</td>
<td class=ar>15</td>
<td class=ar>129</td>
<td class=al>&nbsp;:&nbsp;92</td>
<td class=ar>45</td>
<td class=ar>133</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>24.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1&x=-390&p=Ple%C5%A1%C3%A1k%20Pavel">Plešák Pavel</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>39</td>
<td class=br>18</td>
<td class=br>8</td>
<td class=br>13</td>
<td class=br>131</td>
<td class=bl>&nbsp;:&nbsp;93</td>
<td class=br>44</td>
<td class=br>132</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>25.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1579&x=-390&p=Henttonen%20Ville">Henttonen Ville</a></td>
<td class=al>* Finland</td>
<td class=ar>38</td>
<td class=ar>18</td>
<td class=ar>6</td>
<td class=ar>14</td>
<td class=ar>92</td>
<td class=al>&nbsp;:&nbsp;91</td>
<td class=ar>42</td>
<td class=ar>131</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>26.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=40&x=-390&p=Mat%C3%BDsek%20Daniel">Matýsek Daniel</a></td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>41</td>
<td class=br>19</td>
<td class=br>8</td>
<td class=br>14</td>
<td class=br>112</td>
<td class=bl>&nbsp;:&nbsp;98</td>
<td class=br>46</td>
<td class=br>129</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>27.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=961&x=-390&p=Bo%C5%A1t%C3%ADk%20Michal">Boštík Michal</a></td>
<td class=al>THC Stiga Elites</td>
<td class=ar>39</td>
<td class=ar>21</td>
<td class=ar>1</td>
<td class=ar>17</td>
<td class=ar>127</td>
<td class=al>&nbsp;:&nbsp;96</td>
<td class=ar>43</td>
<td class=ar>127</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>28.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1845&x=-390&p=Shalomayev%20Mykhaylo">Shalomayev Mykhaylo</a></td>
<td class=bl>* Ukraine</td>
<td class=br>38</td>
<td class=br>17</td>
<td class=br>5</td>
<td class=br>16</td>
<td class=br>115</td>
<td class=bl>&nbsp;:&nbsp;105</td>
<td class=br>39</td>
<td class=br>126</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>29.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=248&x=-390&p=%C5%BDen%C3%AD%C5%A1ek%20Martin">Ženíšek Martin</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>38</td>
<td class=ar>18</td>
<td class=ar>4</td>
<td class=ar>16</td>
<td class=ar>122</td>
<td class=al>&nbsp;:&nbsp;106</td>
<td class=ar>40</td>
<td class=ar>125</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>30.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=448&x=-390&p=Waclawek%20Tom%C3%A1%C5%A1">Waclawek Tomáš</a></td>
<td class=bl>THC Třinec</td>
<td class=br>38</td>
<td class=br>16</td>
<td class=br>7</td>
<td class=br>15</td>
<td class=br>126</td>
<td class=bl>&nbsp;:&nbsp;105</td>
<td class=br>39</td>
<td class=br>124</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>31.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=2022&x=-390&p=Hrustaljova%20Darja">Hrustaljova Darja</a></td>
<td class=al>* Estonia</td>
<td class=ar>40</td>
<td class=ar>19</td>
<td class=ar>3</td>
<td class=ar>18</td>
<td class=ar>95</td>
<td class=al>&nbsp;:&nbsp;91</td>
<td class=ar>41</td>
<td class=ar>123</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>32.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1828&x=-390&p=Mansson%20Truls">Mansson Truls</a></td>
<td class=bl>* Sweden</td>
<td class=br>38</td>
<td class=br>16</td>
<td class=br>5</td>
<td class=br>17</td>
<td class=br>100</td>
<td class=bl>&nbsp;:&nbsp;83</td>
<td class=br>37</td>
<td class=br>122</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>33.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1876&x=-390&p=Kop%C5%99iva%20Adam">Kopřiva Adam</a></td>
<td class=al>BSE United</td>
<td class=ar>34</td>
<td class=ar>17</td>
<td class=ar>6</td>
<td class=ar>11</td>
<td class=ar>119</td>
<td class=al>&nbsp;:&nbsp;93</td>
<td class=ar>40</td>
<td class=ar>120</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>34.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=344&x=-390&p=Regula%20Gergely">Regula Gergely</a></td>
<td class=bl>* Hungary</td>
<td class=br>34</td>
<td class=br>15</td>
<td class=br>5</td>
<td class=br>14</td>
<td class=br>99</td>
<td class=bl>&nbsp;:&nbsp;93</td>
<td class=br>35</td>
<td class=br>119</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>35.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1033&x=-390&p=Thomas%20Simon">Thomas Simon</a></td>
<td class=al>Big Band</td>
<td class=ar>34</td>
<td class=ar>15</td>
<td class=ar>7</td>
<td class=ar>12</td>
<td class=ar>96</td>
<td class=al>&nbsp;:&nbsp;87</td>
<td class=ar>37</td>
<td class=ar>118</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>36.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=893&x=-390&p=%C5%A0krlep%20Nejc">Škrlep Nejc</a></td>
<td class=bl>* Slovenia</td>
<td class=br>35</td>
<td class=br>18</td>
<td class=br>2</td>
<td class=br>15</td>
<td class=br>105</td>
<td class=bl>&nbsp;:&nbsp;76</td>
<td class=br>38</td>
<td class=br>117</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>37.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=64&x=-390&p=%C5%A0m%C3%ADd%20David">Šmíd David</a></td>
<td class=al>THC Stiga Elites</td>
<td class=ar>34</td>
<td class=ar>18</td>
<td class=ar>3</td>
<td class=ar>13</td>
<td class=ar>105</td>
<td class=al>&nbsp;:&nbsp;83</td>
<td class=ar>39</td>
<td class=ar>116</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>38.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1872&x=-390&p=Fuchs%20Petr">Fuchs Petr</a></td>
<td class=bl>Big Band</td>
<td class=br>35</td>
<td class=br>12</td>
<td class=br>12</td>
<td class=br>11</td>
<td class=br>91</td>
<td class=bl>&nbsp;:&nbsp;90</td>
<td class=br>36</td>
<td class=br>115</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>39.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1912&x=-390&p=Krejza%20Ale%C5%A1">Krejza Aleš</a></td>
<td class=al>THC Třinec</td>
<td class=ar>35</td>
<td class=ar>16</td>
<td class=ar>3</td>
<td class=ar>16</td>
<td class=ar>100</td>
<td class=al>&nbsp;:&nbsp;92</td>
<td class=ar>35</td>
<td class=ar>114</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>40.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1980&x=-390&p=Zalite%20Janis">Zalite Janis</a></td>
<td class=bl>* Latvia</td>
<td class=br>34</td>
<td class=br>13</td>
<td class=br>6</td>
<td class=br>15</td>
<td class=br>83</td>
<td class=bl>&nbsp;:&nbsp;66</td>
<td class=br>32</td>
<td class=br>113</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>41.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=2006&x=-390&p=L%C3%B6nnqvist%20G%C3%B6ran">Lönnqvist Göran</a></td>
<td class=al>* Sweden</td>
<td class=ar>34</td>
<td class=ar>15</td>
<td class=ar>5</td>
<td class=ar>14</td>
<td class=ar>97</td>
<td class=al>&nbsp;:&nbsp;98</td>
<td class=ar>35</td>
<td class=ar>112</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>42.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1488&x=-390&p=Pommerenke%20Ralph">Pommerenke Ralph</a></td>
<td class=bl>* Germany</td>
<td class=br>34</td>
<td class=br>11</td>
<td class=br>7</td>
<td class=br>16</td>
<td class=br>69</td>
<td class=bl>&nbsp;:&nbsp;87</td>
<td class=br>29</td>
<td class=br>111</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>43.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=201&x=-390&p=Bucek%20Tom%C3%A1%C5%A1">Bucek Tomáš</a></td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>35</td>
<td class=ar>14</td>
<td class=ar>7</td>
<td class=ar>14</td>
<td class=ar>108</td>
<td class=al>&nbsp;:&nbsp;99</td>
<td class=ar>35</td>
<td class=ar>110</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>44.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1641&x=-390&p=Klazar%20Maty%C3%A1%C5%A1">Klazar Matyáš</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>34</td>
<td class=br>13</td>
<td class=br>5</td>
<td class=br>16</td>
<td class=br>82</td>
<td class=bl>&nbsp;:&nbsp;91</td>
<td class=br>31</td>
<td class=br>109</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>45.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1117&x=-390&p=Kahoun%20ml.%20Tom%C3%A1%C5%A1">Kahoun ml. Tomáš</a></td>
<td class=al>BSE United</td>
<td class=ar>34</td>
<td class=ar>13</td>
<td class=ar>6</td>
<td class=ar>15</td>
<td class=ar>76</td>
<td class=al>&nbsp;:&nbsp;87</td>
<td class=ar>32</td>
<td class=ar>108</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>46.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=2001&x=-390&p=Storozhenko%20Glib">Storozhenko Glib</a></td>
<td class=bl>* Ukraine</td>
<td class=br>34</td>
<td class=br>11</td>
<td class=br>5</td>
<td class=br>18</td>
<td class=br>105</td>
<td class=bl>&nbsp;:&nbsp;120</td>
<td class=br>27</td>
<td class=br>106</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>47.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=347&x=-390&p=Papp%20Magor">Papp Magor</a></td>
<td class=al>* Hungary</td>
<td class=ar>34</td>
<td class=ar>16</td>
<td class=ar>2</td>
<td class=ar>16</td>
<td class=ar>90</td>
<td class=al>&nbsp;:&nbsp;92</td>
<td class=ar>34</td>
<td class=ar>104</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>48.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=261&x=-390&p=Cibulka%20David">Cibulka David</a></td>
<td class=bl>THC Třinec</td>
<td class=br>34</td>
<td class=br>11</td>
<td class=br>6</td>
<td class=br>17</td>
<td class=br>103</td>
<td class=bl>&nbsp;:&nbsp;100</td>
<td class=br>28</td>
<td class=br>103</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>49.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1978&x=-390&p=Verbytskyy%20Mykola">Verbytskyy Mykola</a></td>
<td class=al>* Ukraine</td>
<td class=ar>34</td>
<td class=ar>12</td>
<td class=ar>6</td>
<td class=ar>16</td>
<td class=ar>69</td>
<td class=al>&nbsp;:&nbsp;88</td>
<td class=ar>30</td>
<td class=ar>102</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>50.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1291&x=-390&p=Dion%20Martin">Dion Martin</a></td>
<td class=bl>* Canada</td>
<td class=br>34</td>
<td class=br>12</td>
<td class=br>4</td>
<td class=br>18</td>
<td class=br>76</td>
<td class=bl>&nbsp;:&nbsp;109</td>
<td class=br>28</td>
<td class=br>101</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>51.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=26&x=-390&p=%C5%A0evr%20Milo%C5%A1">Ševr Miloš</a></td>
<td class=al>THC Stiga Elites</td>
<td class=ar>34</td>
<td class=ar>10</td>
<td class=ar>5</td>
<td class=ar>19</td>
<td class=ar>88</td>
<td class=al>&nbsp;:&nbsp;116</td>
<td class=ar>25</td>
<td class=ar>100</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>52.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=346&x=-390&p=Nagy%20B%C3%A1lint">Nagy Bálint</a></td>
<td class=bl>* Hungary</td>
<td class=br>35</td>
<td class=br>11</td>
<td class=br>2</td>
<td class=br>22</td>
<td class=br>66</td>
<td class=bl>&nbsp;:&nbsp;102</td>
<td class=br>24</td>
<td class=br>99</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>53.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=474&x=-390&p=Margolis%20Mihail">Margolis Mihail</a></td>
<td class=al>* Israel</td>
<td class=ar>34</td>
<td class=ar>9</td>
<td class=ar>4</td>
<td class=ar>21</td>
<td class=ar>77</td>
<td class=al>&nbsp;:&nbsp;118</td>
<td class=ar>22</td>
<td class=ar>98</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>54.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=18&x=-390&p=%C5%A0ur%C3%BDn%20Anton%C3%ADn">Šurýn Antonín</a></td>
<td class=bl>Big Band</td>
<td class=br>34</td>
<td class=br>11</td>
<td class=br>0</td>
<td class=br>23</td>
<td class=br>69</td>
<td class=bl>&nbsp;:&nbsp;108</td>
<td class=br>22</td>
<td class=br>97</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>55.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1622&x=-390&p=Petuch%20Hermann">Petuch Hermann</a></td>
<td class=al>* Germany</td>
<td class=ar>34</td>
<td class=ar>10</td>
<td class=ar>5</td>
<td class=ar>19</td>
<td class=ar>75</td>
<td class=al>&nbsp;:&nbsp;106</td>
<td class=ar>25</td>
<td class=ar>96</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>56.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=70&x=-390&p=Srba%20Stanislav">Srba Stanislav</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>35</td>
<td class=br>8</td>
<td class=br>6</td>
<td class=br>21</td>
<td class=br>67</td>
<td class=bl>&nbsp;:&nbsp;105</td>
<td class=br>22</td>
<td class=br>95</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>57.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1981&x=-390&p=Kvasnikova%20Polina">Kvasnikova Polina</a></td>
<td class=al>* Ukraine</td>
<td class=ar>34</td>
<td class=ar>8</td>
<td class=ar>5</td>
<td class=ar>21</td>
<td class=ar>63</td>
<td class=al>&nbsp;:&nbsp;107</td>
<td class=ar>21</td>
<td class=ar>94</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>58.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=2000&x=-390&p=Hasler%20David">Hasler David</a></td>
<td class=bl>* Switzerland</td>
<td class=br>34</td>
<td class=br>7</td>
<td class=br>3</td>
<td class=br>24</td>
<td class=br>69</td>
<td class=bl>&nbsp;:&nbsp;120</td>
<td class=br>17</td>
<td class=br>93</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>59.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=32&x=-390&p=Krop%C3%A1%C4%8Dek%20Ji%C5%99%C3%AD">Kropáček Jiří</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>34</td>
<td class=ar>8</td>
<td class=ar>3</td>
<td class=ar>23</td>
<td class=ar>67</td>
<td class=al>&nbsp;:&nbsp;139</td>
<td class=ar>19</td>
<td class=ar>92</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>60.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1409&x=-390&p=Mal%C3%ADk%20Ji%C5%99%C3%AD">Malík Jiří</a></td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>34</td>
<td class=br>3</td>
<td class=br>2</td>
<td class=br>29</td>
<td class=br>43</td>
<td class=bl>&nbsp;:&nbsp;149</td>
<td class=br>8</td>
<td class=br>91</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>61.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=176&x=-390&p=Lopaur%20Zden%C4%9Bk">Lopaur Zdeněk</a></td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>40</td>
<td class=ar>23</td>
<td class=ar>4</td>
<td class=ar>13</td>
<td class=ar>152</td>
<td class=al>&nbsp;:&nbsp;88</td>
<td class=ar>50</td>
<td class=ar>90</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>62.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=4&x=-390&p=Kraus%20Vladim%C3%ADr">Kraus Vladimír</a></td>
<td class=bl>Rokycany</td>
<td class=br>38</td>
<td class=br>19</td>
<td class=br>4</td>
<td class=br>15</td>
<td class=br>122</td>
<td class=bl>&nbsp;:&nbsp;91</td>
<td class=br>42</td>
<td class=br>89</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>63.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1917&x=-390&p=Rasche%20Frank">Rasche Frank</a></td>
<td class=al>* Germany</td>
<td class=ar>34</td>
<td class=ar>16</td>
<td class=ar>5</td>
<td class=ar>13</td>
<td class=ar>117</td>
<td class=al>&nbsp;:&nbsp;127</td>
<td class=ar>37</td>
<td class=ar>88</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>64.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=227&x=-390&p=Ma%C5%A1ika%20Michal">Mašika Michal</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>36</td>
<td class=br>15</td>
<td class=br>9</td>
<td class=br>12</td>
<td class=br>105</td>
<td class=bl>&nbsp;:&nbsp;87</td>
<td class=br>39</td>
<td class=br>87</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>65.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1940&x=-390&p=Ko%C5%A1%C5%88ar%20Martin">Košňar Martin</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>31</td>
<td class=ar>15</td>
<td class=ar>5</td>
<td class=ar>11</td>
<td class=ar>89</td>
<td class=al>&nbsp;:&nbsp;78</td>
<td class=ar>35</td>
<td class=ar>86</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>66.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1318&x=-390&p=Sedl%C3%A1%C4%8Dek%20Josef">Sedláček Josef</a></td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>31</td>
<td class=br>14</td>
<td class=br>5</td>
<td class=br>12</td>
<td class=br>91</td>
<td class=bl>&nbsp;:&nbsp;100</td>
<td class=br>33</td>
<td class=br>85</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>67.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=818&x=-390&p=Je%C5%BE%20Robert">Jež Robert</a></td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>31</td>
<td class=ar>14</td>
<td class=ar>2</td>
<td class=ar>15</td>
<td class=ar>96</td>
<td class=al>&nbsp;:&nbsp;77</td>
<td class=ar>30</td>
<td class=ar>84</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>68.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1973&x=-390&p=Sabo%20Branislav">Sabo Branislav</a></td>
<td class=bl>*THC Predators (SVK)</td>
<td class=br>31</td>
<td class=br>10</td>
<td class=br>3</td>
<td class=br>18</td>
<td class=br>66</td>
<td class=bl>&nbsp;:&nbsp;101</td>
<td class=br>23</td>
<td class=br>83</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>69.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1630&x=-390&p=Holub%20Petr">Holub Petr</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>31</td>
<td class=ar>10</td>
<td class=ar>5</td>
<td class=ar>16</td>
<td class=ar>80</td>
<td class=al>&nbsp;:&nbsp;97</td>
<td class=ar>25</td>
<td class=ar>82</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>70.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=204&x=-390&p=Nechutn%C3%BD%20Hynek">Nechutný Hynek</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>31</td>
<td class=br>7</td>
<td class=br>10</td>
<td class=br>14</td>
<td class=br>54</td>
<td class=bl>&nbsp;:&nbsp;75</td>
<td class=br>24</td>
<td class=br>81</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>71.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1587&x=-390&p=Herold%20Adam">Herold Adam</a></td>
<td class=al>Praha</td>
<td class=ar>32</td>
<td class=ar>12</td>
<td class=ar>2</td>
<td class=ar>18</td>
<td class=ar>59</td>
<td class=al>&nbsp;:&nbsp;88</td>
<td class=ar>26</td>
<td class=ar>80</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>72.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1058&x=-390&p=Marek%20Franti%C5%A1ek">Marek František</a></td>
<td class=bl>BSE United</td>
<td class=br>31</td>
<td class=br>10</td>
<td class=br>2</td>
<td class=br>19</td>
<td class=br>64</td>
<td class=bl>&nbsp;:&nbsp;96</td>
<td class=br>22</td>
<td class=br>79</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>73.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1957&x=-390&p=Bernhauser%20Erik">Bernhauser Erik</a></td>
<td class=al>*THC Predators (SVK)</td>
<td class=ar>31</td>
<td class=ar>8</td>
<td class=ar>5</td>
<td class=ar>18</td>
<td class=ar>77</td>
<td class=al>&nbsp;:&nbsp;122</td>
<td class=ar>21</td>
<td class=ar>78</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>74.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=2014&x=-390&p=Hlava%C4%8Dka%20Martin">Hlavačka Martin</a></td>
<td class=bl>Uherské Hradiště</td>
<td class=br>31</td>
<td class=br>7</td>
<td class=br>3</td>
<td class=br>21</td>
<td class=br>65</td>
<td class=bl>&nbsp;:&nbsp;109</td>
<td class=br>17</td>
<td class=br>77</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>75.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1927&x=-390&p=Kraus%20Vojt%C4%9Bch">Kraus Vojtěch</a></td>
<td class=al>Rokycany</td>
<td class=ar>31</td>
<td class=ar>7</td>
<td class=ar>4</td>
<td class=ar>20</td>
<td class=ar>60</td>
<td class=al>&nbsp;:&nbsp;98</td>
<td class=ar>18</td>
<td class=ar>76</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>76.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=2017&x=-390&p=Pirumshoeva%20Karina">Pirumshoeva Karina</a></td>
<td class=bl>* Ukraine</td>
<td class=br>31</td>
<td class=br>8</td>
<td class=br>2</td>
<td class=br>21</td>
<td class=br>49</td>
<td class=bl>&nbsp;:&nbsp;79</td>
<td class=br>18</td>
<td class=br>75</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>77.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=2005&x=-390&p=Zupan%C4%8Di%C4%8D%20Domen">Zupančič Domen</a></td>
<td class=al>* Slovenia</td>
<td class=ar>31</td>
<td class=ar>6</td>
<td class=ar>2</td>
<td class=ar>23</td>
<td class=ar>46</td>
<td class=al>&nbsp;:&nbsp;102</td>
<td class=ar>14</td>
<td class=ar>74</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>78.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1430&x=-390&p=Kadlec%20Daniel">Kadlec Daniel</a></td>
<td class=bl>Big Band</td>
<td class=br>31</td>
<td class=br>3</td>
<td class=br>3</td>
<td class=br>25</td>
<td class=br>48</td>
<td class=bl>&nbsp;:&nbsp;144</td>
<td class=br>9</td>
<td class=br>73</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>79.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1941&x=-390&p=Kopeck%C3%BD%20Jaroslav">Kopecký Jaroslav</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>35</td>
<td class=ar>15</td>
<td class=ar>5</td>
<td class=ar>15</td>
<td class=ar>75</td>
<td class=al>&nbsp;:&nbsp;73</td>
<td class=ar>35</td>
<td class=ar>72</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>80.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1896&x=-390&p=Hrn%C4%8D%C3%AD%C5%99%20Radek">Hrnčíř Radek</a></td>
<td class=bl>Big Band</td>
<td class=br>37</td>
<td class=br>15</td>
<td class=br>3</td>
<td class=br>19</td>
<td class=br>74</td>
<td class=bl>&nbsp;:&nbsp;109</td>
<td class=br>33</td>
<td class=br>71</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>81.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=910&x=-390&p=Gobyov%C3%A1%20Vlasta">Gobyová Vlasta</a></td>
<td class=al>THC Teplýšovice</td>
<td class=ar>30</td>
<td class=ar>13</td>
<td class=ar>4</td>
<td class=ar>13</td>
<td class=ar>70</td>
<td class=al>&nbsp;:&nbsp;70</td>
<td class=ar>30</td>
<td class=ar>70</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>82.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=2020&x=-390&p=Jerabek%20Daniel">Jerabek Daniel</a></td>
<td class=bl>* Sweden</td>
<td class=br>32</td>
<td class=br>12</td>
<td class=br>0</td>
<td class=br>20</td>
<td class=br>56</td>
<td class=bl>&nbsp;:&nbsp;97</td>
<td class=br>24</td>
<td class=br>69</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>83.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1959&x=-390&p=Chlebo%20Ond%C5%99ej">Chlebo Ondřej</a></td>
<td class=al>BSE United</td>
<td class=ar>27</td>
<td class=ar>7</td>
<td class=ar>3</td>
<td class=ar>17</td>
<td class=ar>36</td>
<td class=al>&nbsp;:&nbsp;100</td>
<td class=ar>17</td>
<td class=ar>68</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>84.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=2025&x=-390&p=Gorej%20Vojt%C4%9Bch">Gorej Vojtěch</a></td>
<td class=bl>Děčín</td>
<td class=br>28</td>
<td class=br>6</td>
<td class=br>4</td>
<td class=br>18</td>
<td class=br>59</td>
<td class=bl>&nbsp;:&nbsp;113</td>
<td class=br>16</td>
<td class=br>67</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>85.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=2018&x=-390&p=Janou%C5%A1kovec%20Jan">Janouškovec Jan</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>27</td>
<td class=ar>6</td>
<td class=ar>2</td>
<td class=ar>19</td>
<td class=ar>42</td>
<td class=al>&nbsp;:&nbsp;145</td>
<td class=ar>14</td>
<td class=ar>66</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>86.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1626&x=-390&p=Hor%C3%A1kov%C3%A1%20Miroslava">Horáková Miroslava</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>28</td>
<td class=br>9</td>
<td class=br>0</td>
<td class=br>19</td>
<td class=br>66</td>
<td class=bl>&nbsp;:&nbsp;138</td>
<td class=br>18</td>
<td class=br>65</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>87.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1869&x=-390&p=Klazar%20Petr">Klazar Petr</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>27</td>
<td class=ar>6</td>
<td class=ar>2</td>
<td class=ar>19</td>
<td class=ar>52</td>
<td class=al>&nbsp;:&nbsp;93</td>
<td class=ar>14</td>
<td class=ar>64</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>88.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1999&x=-390&p=Pano%C5%A1%20Filip">Panoš Filip</a></td>
<td class=bl>Pelhřimov</td>
<td class=br>27</td>
<td class=br>2</td>
<td class=br>4</td>
<td class=br>21</td>
<td class=br>16</td>
<td class=bl>&nbsp;:&nbsp;105</td>
<td class=br>8</td>
<td class=br>63</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>89.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=2004&x=-390&p=Me%C5%BEek%20Urban">Mežek Urban</a></td>
<td class=al>NHK Kranj</td>
<td class=ar>27</td>
<td class=ar>4</td>
<td class=ar>4</td>
<td class=ar>19</td>
<td class=ar>42</td>
<td class=al>&nbsp;:&nbsp;115</td>
<td class=ar>12</td>
<td class=ar>62</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>90.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=2019&x=-390&p=Janou%C5%A1kovec%20Pavel">Janouškovec Pavel</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>28</td>
<td class=br>4</td>
<td class=br>1</td>
<td class=br>23</td>
<td class=br>35</td>
<td class=bl>&nbsp;:&nbsp;134</td>
<td class=br>9</td>
<td class=br>61</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>91.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=2021&x=-390&p=Novotn%C3%BD%20Kry%C5%A1tof">Novotný Kryštof</a></td>
<td class=al>Praha</td>
<td class=ar>27</td>
<td class=ar>1</td>
<td class=ar>3</td>
<td class=ar>23</td>
<td class=ar>15</td>
<td class=al>&nbsp;:&nbsp;150</td>
<td class=ar>5</td>
<td class=ar>60</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>92.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=2023&x=-390&p=Vinnichuk%20Alan">Vinnichuk Alan</a></td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>13</td>
<td class=br>1</td>
<td class=br>0</td>
<td class=br>12</td>
<td class=br>8</td>
<td class=bl>&nbsp;:&nbsp;49</td>
<td class=br>2</td>
<td class=br>59</td>
<td class=br>&nbsp;</td>
</tr></table></td></tr></table></div></p>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
